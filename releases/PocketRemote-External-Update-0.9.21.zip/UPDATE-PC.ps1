﻿param([Parameter(Mandatory=$true)][string]$Archive, [Parameter(Mandatory=$true)][string]$Manifest, [string]$NodePath='')
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
. (Join-Path $PSScriptRoot 'bridge\setup-host.ps1')
. (Join-Path $PSScriptRoot 'bridge\setup-update.ps1')
$node = if ($NodePath) { $NodePath } else { (Get-Command node.exe -ErrorAction Stop).Source }
$worker = Join-Path $PSScriptRoot 'bridge\update-worker.mjs'
$statePath = Join-Path $PSScriptRoot '.pc-update.json'
function Save-UpdateState($status, $version, $errorText='') {
    $state = @{ status=$status; availableVersion=$version; updatedAt=[DateTime]::UtcNow.ToString('o'); error=$errorText }
    if ($status -eq 'failed') { $state.retryAfter = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + 86400000 }
    [IO.File]::WriteAllText($statePath, ($state | ConvertTo-Json -Compress), [Text.UTF8Encoding]::new($false))
}
$stopped = $null; $previous = @{}; $changed = @(); $taskEnabled = $false; $releaseVersion = ''; $extractRoot = $null
try {
    & $node $worker --verify $Archive $Manifest *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Update verification failed' }
    $release = (Get-Content -LiteralPath $Manifest -Raw -Encoding UTF8 | ConvertFrom-Json).release
    $releaseVersion = [string]$release.version
    $currentVersion = Get-InstalledPCVersion $PSScriptRoot
    & $node $worker --newer $releaseVersion $currentVersion *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Update is not newer than the installed version' }
    $stageRoot = Join-Path $PSScriptRoot ('.updates\' + $releaseVersion)
    foreach ($directory in @($PSScriptRoot, (Join-Path $PSScriptRoot '.updates'), $stageRoot)) {
        if ((Get-Item -LiteralPath $directory -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point in staging directory' }
    }
    foreach ($item in @($Archive, $Manifest)) {
        $fullPath = [IO.Path]::GetFullPath($item)
        if (![string]::Equals([IO.Path]::GetDirectoryName($fullPath), $stageRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Update files are outside the staging directory' }
    }
    $wizardPath = Join-Path $PSScriptRoot 'PocketRemoteSetup.exe'
    if (@(Get-CimInstance Win32_Process | Where-Object { [string]::Equals([string]$_.ExecutablePath, $wizardPath, [StringComparison]::OrdinalIgnoreCase) }).Count) {
        Save-UpdateState 'waiting-for-wizard-close' $releaseVersion; exit 2
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($Archive)
    $extractRoot = Join-Path $stageRoot ('payload-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $extractRoot | Out-Null
    try {
        $expected = @{}; foreach ($property in $release.files.PSObject.Properties) { $expected[$property.Name] = $property.Value }
        $seen = @{}
        foreach ($entry in $zip.Entries) {
            if ($entry.FullName.EndsWith('/')) { continue }
            $name = $entry.FullName.Replace('\', '/')
            if (!$expected.ContainsKey($name) -or $seen.ContainsKey($name) -or $entry.Length -ne $expected[$name].bytes) { throw 'Unexpected update archive entry' }
            $seen[$name] = $true
            $target = [IO.Path]::GetFullPath((Join-Path $extractRoot $name))
            if (!$target.StartsWith($extractRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe update archive path' }
            $directory = [IO.Path]::GetDirectoryName($target)
            New-Item -ItemType Directory -Path $directory -Force | Out-Null
            $stream = $entry.Open(); $output = [IO.File]::Create($target)
            try { $stream.CopyTo($output) } finally { $stream.Dispose(); $output.Dispose() }
            if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected[$name].sha256) { throw 'Update file hash differs' }
        }
        if ($seen.Count -ne $expected.Count) { throw 'Update archive is incomplete' }
        if ((Get-Content -LiteralPath (Join-Path $extractRoot 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version -ne $releaseVersion) { throw 'Update package version differs' }
    } finally { $zip.Dispose() }
    foreach ($name in $expected.Keys) {
        $target = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot $name))
        if (!$target.StartsWith($PSScriptRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe installation path' }
        # Reparse points must not redirect signed files outside this installation.
        $parent = $target
        while ($parent.Length -ge $PSScriptRoot.Length) {
            if ((Test-Path -LiteralPath $parent) -and ((Get-Item -LiteralPath $parent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Reparse point in update path' }
            if ([string]::Equals($parent, $PSScriptRoot, [StringComparison]::OrdinalIgnoreCase)) { break }
            $parent = [IO.Path]::GetDirectoryName($parent)
        }
        if (Test-Path -LiteralPath $target -PathType Leaf) { $previous[$name] = [IO.File]::ReadAllBytes($target) }
        else { $previous[$name] = $null }
    }
    # Check again immediately before terminating owned host processes.
    if (!(Get-Command Get-SetupHostProcesses -ErrorAction SilentlyContinue) -or @(Get-SetupHostProcesses $PSScriptRoot).Count) {
        & $node $worker --idle *> $null
        if ($LASTEXITCODE -ne 0) { Save-UpdateState 'waiting-for-idle' $releaseVersion; exit 2 }
    }
    $stopped = Stop-SetupHost $PSScriptRoot; $taskEnabled = [bool]$stopped.taskEnabled
    foreach ($name in $expected.Keys) {
        $target = Join-Path $PSScriptRoot $name
        New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
        $changed += $name
        Copy-Item -LiteralPath (Join-Path $extractRoot $name) -Destination $target -Force
    }
    if ($taskEnabled) { Enable-ScheduledTask -TaskName PocketRemoteExternal | Out-Null }
    $shell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    & $shell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'SETUP-REMOTE.ps1') -Action Start -HostOnly *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Updated host failed to start' }
    Save-UpdateState 'installed' $releaseVersion
} catch {
    if ($stopped.stopped) {
        try {
            Stop-SetupHost $PSScriptRoot | Out-Null
            foreach ($name in $changed) {
                $target = Join-Path $PSScriptRoot $name
                if ($null -ne $previous[$name]) { [IO.File]::WriteAllBytes($target, [byte[]]$previous[$name]) }
                elseif (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target -Force }
            }
            if ($taskEnabled) { Enable-ScheduledTask -TaskName PocketRemoteExternal | Out-Null }
            $shell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
            & $shell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'SETUP-REMOTE.ps1') -Action Start -HostOnly *> $null
            if ($LASTEXITCODE -ne 0) { throw 'Previous host could not restart' }
        } catch { Save-UpdateState 'failed' $releaseVersion '업데이트 복구를 완료하지 못했습니다. PC 마법사에서 연결을 확인하세요.'; exit 1 }
    }
    Save-UpdateState 'failed' $releaseVersion '업데이트를 적용하지 못했습니다. 이전 파일과 연결을 유지하며 나중에 재시도합니다.'
    exit 1
} finally {
    if ($extractRoot -and (Test-Path -LiteralPath $extractRoot)) {
        $cleanupPath = [IO.Path]::GetFullPath($extractRoot)
        $cleanupBase = [IO.Path]::GetFullPath($stageRoot) + '\'
        if ($cleanupPath.StartsWith($cleanupBase, [StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($cleanupPath) -match '^payload-[a-f0-9]{32}$') {
            Remove-Item -LiteralPath $cleanupPath -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

const changesUI = { records: new Map(), busy: new Set(), open: '', timer: null };
function changesRecord() {
  const key = sessionScope();
  if (!changesUI.records.has(key)) {
    const mode = typeof saved === 'function' ? saved('remote.changeScope.' + state.currentId) : '';
    changesUI.records.set(key, { mode: ['unstaged','staged','latest-turn'].includes(mode) ? mode : 'unstaged', files: [], additions: 0, deletions: 0, scanning: false });
  }
  while (changesUI.records.size > 40) changesUI.records.delete(changesUI.records.keys().next().value);
  return changesUI.records.get(key);
}
function changesScope() { return sessionScope() + ':' + changesRecord().mode; }
function closeChanges() { $('changesOverlay')?.classList.add('hidden'); changesUI.open = ''; }
function renderChangesChip(root) {
  const r = changesRecord();
  if (!r.files.length && !r.scanning && r.available !== false) return;
  const chip = action('', () => changesPanel(), 'session-chip changes-chip');
  chip.append(el('span', r.supported === false ? '변경 파일 · PC 업데이트 필요' : r.available === false ? '변경 조회 재시도' : r.scanning ? '변경 확인 중…' : '변경된 파일 ' + r.files.length + '개'));
  if (r.files.length && !r.scanning && r.available !== false) chip.append(el('span', '+' + r.additions, 'diff-added-count'), el('span', '−' + r.deletions, 'diff-deleted-count'));
  root.append(chip);
}
async function refreshChanges() {
  if (!state.currentId || !state.online || document.hidden || state.current?.ephemeral) return;
  const scope = changesScope(), record = changesRecord();
  if (!state.serverCapabilities?.reviewScopes) {
    Object.assign(record, { files: [], additions: 0, deletions: 0, scanning: false, available: false, supported: false, warning: 'PC 업데이트 후 공식 기준의 변경 파일을 확인할 수 있습니다.', note: '과거 전체 변경 기록을 현재 변경량으로 표시하지 않습니다.' });
    renderSessionChips(); if (changesUI.open === sessionScope()) drawChanges(); return;
  }
  if (changesUI.busy.has(scope)) return;
  changesUI.busy.add(scope);
  try {
    const result = await rpc('bridge/changes/list', { threadId: state.currentId, scope: record.mode, view: 'review' });
    if (scope !== changesScope()) return;
    if (result.reviewPolicy !== 1 || result.scope !== record.mode) throw Error('PC가 이 변경 조회 기준을 지원하지 않습니다. PC를 업데이트하세요.');
    const changed = JSON.stringify(record.files) !== JSON.stringify(result.files) || record.available !== result.available;
    Object.assign(record, { repo: '', note: '', warning: '', scopeLabel: '', supported: true }, result); renderSessionChips();
    if (changesUI.open === sessionScope()) { if (changed) drawChanges(); else updateChangesTitle(); }
  } catch (e) { if (scope === changesScope()) { record.available = false; record.scanning = false; record.warning = e.message; renderSessionChips(); if (changesUI.open === sessionScope()) drawChanges(); } }
  finally { changesUI.busy.delete(scope); }
}
function changesEvent(method, p) {
  if (p.threadId !== state.currentId && !sessionRecord().agents.some(a => a.id === p.threadId)) return;
  if (method === 'turn/diff/updated' || method === 'item/fileChange/patchUpdated' || p.item?.type === 'fileChange') {
    clearTimeout(changesUI.timer); changesUI.timer = setTimeout(refreshChanges, 300);
  }
}
function updateChangesTitle() {
  const r = changesRecord(); $('changesTitle').textContent = r.available === false ? '변경된 파일' : r.scanning ? '변경 확인 중…' : '변경된 파일 ' + r.files.length + '개';
  $('changesNote').textContent = r.warning || (r.scanning ? '변경 기록을 불러오는 중…' : r.scopeLabel || '현재 변경');
}
function changesPanel() {
  closeMenus(); changesUI.open = sessionScope(); $('changesOverlay').classList.remove('hidden'); drawChanges(); refreshChanges();
}
function drawChanges() {
  const root = $('changesContent'), scope = changesScope(); updateChangesTitle();
  if (root.diffScope !== scope) {
    root.replaceChildren(); root.diffScope = scope; root.fileNodes = new Map();
    const controls = el('label', '조회 범위 ', 'diff-scope'), select = el('select'); select.setAttribute('aria-label', '변경 파일 조회 범위');
    for (const [value,text] of [['unstaged','미스테이징'],['staged','스테이징됨'],['latest-turn','최근 턴']]) { const option=el('option',text);option.value=value;select.append(option); }
    select.value=changesRecord().mode;select.disabled=!state.serverCapabilities?.reviewScopes;
    select.onchange=()=>{const r=changesRecord();r.mode=select.value;persist('remote.changeScope.'+state.currentId,r.mode);Object.assign(r,{files:[],additions:0,deletions:0,scanning:true,available:true,repo:'',warning:'',note:'',scopeLabel:''});drawChanges();renderSessionChips();refreshChanges();};
    controls.append(select);root.scopeControls=controls;root.scopeSelect=select;
  }
  root.scopeSelect.disabled=!state.serverCapabilities?.reviewScopes;
  const restoreScroll = capturePanelScroll(root);
  const record = changesRecord(), nodes = [root.scopeControls];
  if (record.repo) nodes.push(el('p', '저장소: ' + record.repo, 'diff-note'));
  if (record.note) nodes.push(el('p', record.note, 'diff-note'));
  if (record.available === false) nodes.push(action('다시 확인', refreshChanges, 'ghost full'));
  else if (!record.files.length) nodes.push(el('p', record.scanning ? '변경 기록을 확인하고 있습니다.' : '이 범위에 변경된 파일이 없습니다.', 'muted'));
  for (const file of record.available === false ? [] : record.files) {
    let details = root.fileNodes.get(file.id);
    if (!details) {
      details = el('details', undefined, 'changed-file'); details.dataset.fileId = file.id;
      const heading = el('summary'), counts = el('span', undefined, 'diff-counts');
      details.addedNode = el('span', undefined, 'diff-added-count'); details.deletedNode = el('span', undefined, 'diff-deleted-count'); counts.append(details.addedNode, details.deletedNode);
      details.nameNode = el('strong'); heading.append(details.nameNode, counts); details.append(heading);
      details.renameNode = el('p', undefined, 'diff-note'); details.append(details.renameNode);
      const body = el('div', undefined, 'file-diff'); details.bodyNode = body;
      details.refreshNode = action('새 변경 보기', () => { details.diffRevision = (details.diffRevision || 0) + 1; details.loaded = true; details.snapshotVersion = details.currentVersion; details.refreshNode.classList.add('hidden'); body.replaceChildren(); loadFileDiff(details, body, file.id); }, 'ghost full diff-refresh hidden');
      details.append(details.refreshNode, body);
      details.ontoggle = () => { if (details.open && !details.loaded) { details.loaded = true; details.snapshotVersion = details.currentVersion; body.replaceChildren(); loadFileDiff(details, body, file.id); } };
      root.fileNodes.set(file.id, details);
    }
    details.currentVersion = file.version;
    details.renameNode.textContent = file.previousPath ? '이름 변경: ' + file.previousPath + ' → ' + file.path : ''; details.renameNode.classList.toggle('hidden', !file.previousPath);
    details.nameNode.textContent = file.path.replace(String(record.repo || state.current?.cwd || '').replace(/\\/g, '/') + '/', '');
    details.addedNode.textContent = '+' + file.additions; details.deletedNode.textContent = '−' + file.deletions;
    // Keep the snapshot being read intact; new revisions are opt-in.
    details.refreshNode.classList.toggle('hidden', !details.loaded || (details.snapshotVersion === details.currentVersion && !details.diffError));
    nodes.push(details);
  }
  syncPanelChildren(root, nodes); restoreScroll();
  const wanted = new Set(record.files.map(f => f.id)); for (const id of root.fileNodes.keys()) if (!wanted.has(id)) root.fileNodes.delete(id);
}
async function loadFileDiff(details, body, fileId, cursor = null) {
  const scope = changesScope(), threadId = state.currentId, mode = changesRecord().mode, revision = details.diffRevision || 0;
  const loading = el('p', '변경 내용을 불러오는 중…', 'diff-note'); body.append(loading);
  try {
    const result = await rpc('bridge/changes/read', { threadId, fileId, scope: mode, view: 'review', changesOnly: true, ...(cursor ? { cursor } : {}) });
    if (scope !== changesScope() || changesUI.open !== sessionScope() || !details.isConnected || revision !== (details.diffRevision || 0)) return;
    loading.remove(); details.diffError = false;
    if (result.empty) body.append(el('p', '텍스트 diff가 없는 변경입니다.', 'diff-note'));
    if (result.binary) body.append(el('p', '바이너리 파일 변경 · 텍스트 비교 불가', 'diff-note'));
    if (result.truncated) body.append(el('p', '매우 긴 줄은 일부 생략했습니다. 전체 내용은 PC 파일에서 확인하세요.', 'diff-note'));
    function row(r) {
      const node = el('div', undefined, 'diff-line ' + r.type);
      node.append(el('span', r.old ?? '', 'diff-number'), el('span', r.next ?? '', 'diff-number'), el('code', (r.type === 'add' ? '+ ' : r.type === 'delete' ? '− ' : '  ') + r.text)); return node;
    }
    for (const r of result.rows || []) {
      if (r.type === 'context') continue;
      if (r.type === 'hunk') body.append(el('div', r.text, 'diff-hunk'));
      else if (r.type === 'patch' || r.type === 'note') body.append(el('div', r.text, 'diff-note'));
      else body.append(row(r));
    }
    if (result.nextCursor) { const more = action('변경 내용 이어 보기', async () => { more.disabled = true; await loadFileDiff(details, body, fileId, result.nextCursor); more.remove(); }, 'ghost full'); body.append(more); }
  } catch (e) { if (scope === changesScope() && details.isConnected && revision === (details.diffRevision || 0)) { loading.textContent = e.message; details.diffError = true; if (!cursor) details.loaded = false; else details.refreshNode.classList.remove('hidden'); } }
}
document.addEventListener('DOMContentLoaded', () => {
  const overlay = el('div', undefined, 'overlay hidden'); overlay.id = 'changesOverlay';
  const sheet = el('section', undefined, 'sheet changes-sheet'); sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', '변경된 파일');
  const head = el('div', undefined, 'sheet-head'), titles = el('div');
  const note = el('small'); note.id = 'changesNote'; const title = el('h2', '변경된 파일'); title.id = 'changesTitle'; titles.append(note, title);
  const close = action('✕', closeChanges, 'icon'); close.setAttribute('aria-label', '변경 파일 닫기'); head.append(titles, close);
  const content = el('div'); content.id = 'changesContent'; sheet.append(head, content); overlay.append(sheet); $('app').append(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) closeChanges(); });
  setInterval(refreshChanges, 5000);
});

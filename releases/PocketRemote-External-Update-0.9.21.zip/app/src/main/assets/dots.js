/* Dot owns a cloud messaging room. Keep its state separate from PC writers,
   local Queue / goal state and the user's open local session. */
function normalizeDotMessages(messages, previous = new Map()) {
  return (messages || []).map(m => {
    // A receipt from this app already proved ownership of this exact message.
    if (m.fromSelf == null && m.role === 'user' && previous.get(m.id)?.fromSelf === true) m = { ...m, fromSelf: true };
    return { ...m, role: m.fromSelf === true ? 'user' : m.fromSelf === false ? 'assistant' : m.role === 'user' ? 'unknown' : m.role };
  });
}
function createDotViewCache({ read, write, now = Date.now }) {
  let data = { schema: 2, scope: '', dots: [], rooms: {} };
  const persistCache = () => {
    if (!data.scope) return;
    while (new TextEncoder().encode(JSON.stringify(data)).length > 262144 && Object.keys(data.rooms).length) delete data.rooms[Object.keys(data.rooms).sort((a,b)=>data.rooms[a].at-data.rooms[b].at)[0]];
    write(data);
  };
  return {
    bind(scope, dots) {
      const valid = typeof scope === 'string' && /^[a-f0-9]{64}$/.test(scope);
      if (!valid || data.scope !== scope) {
        const old = valid ? read() : null;
        data = old?.schema === 2 && old?.scope === scope && Array.isArray(old.dots) && old.rooms && typeof old.rooms === 'object' ? old : { schema: 2, scope: valid ? scope : '', dots: [], rooms: {} };
      }
      if (Array.isArray(dots)) { data.dots = dots.slice(0,32); const ids=new Set(data.dots.map(p=>p.id));for(const id of Object.keys(data.rooms))if(!ids.has(id))delete data.rooms[id];persistCache(); }
      return data.dots;
    },
    room(id) { const room=Object.hasOwn(data.rooms,id)?data.rooms[id]:null;return room&&Array.isArray(room.messages)?room:null; },
    save(id, page) {
      if (!id || !Array.isArray(page.messages) || page.messages.length>60) return;
      const previous = new Map((data.rooms[id]?.messages || []).map(m => [m.id, m]));
      Object.defineProperty(data.rooms,id,{value:{messages:normalizeDotMessages(page.messages,previous),before:page.before||null,at:now()},enumerable:true,writable:true,configurable:true});
      const ids=Object.keys(data.rooms).sort((a,b)=>data.rooms[b].at-data.rooms[a].at);for(const id of ids.slice(8))delete data.rooms[id];persistCache();
    },
    clear() { data={schema:2,scope:'',dots:[],rooms:{}};write(data); }
  };
}
(() => {
  const ui = { open: false, dot: null, mode: 'list', dotList: [], scope: '', task: null, messages: new Map(), before: null, taskCursor: null, request: 0, busy: false, loadingOlder: false, nodes: new Map(), pinned: true, refresh: null, poll: null, lastTasks: 0, tasks: new Map(), pending: saved('remote.dotPending') || [], drafts: saved('remote.dotDrafts') || {} };
  const cache=createDotViewCache({read:()=>saved('remote.dotCache'),write:value=>persist('remote.dotCache',value)});
  const historyReader = new HistoryPageReader();
  let previousScroll = 0;
  function readOlder(token, consume = false) {
    const mode = ui.mode, dotId = ui.dot?.id, threadId = ui.task?.id;
    historyReader.bind(state.socket, dotId + ':' + (threadId || 'chat'), ui.request);
    return historyReader.read('older', token, () => mode === 'chat' ? rpc('bridge/dots/messages', { dotId, before: token }) : rpc('bridge/dots/task/read', { dotId, threadId, cursor: token }), consume);
  }
  function warmOlder() {
    if (!ui.open || !state.online || document.hidden || !['chat', 'task'].includes(ui.mode)) return;
    const token = ui.mode === 'chat' ? ui.before : ui.taskCursor;
    if (token) readOlder(token).catch(() => {});
  }
  const overlay = el('section', undefined, 'dot-overlay hidden'); overlay.id = 'dotsOverlay'; overlay.setAttribute('role', 'dialog'); overlay.setAttribute('aria-label', 'Dot 대화와 작업'); overlay.setAttribute('aria-modal', 'true');
  const head = el('header', undefined, 'dot-head'), back = action('‹', goBack, 'icon'), title = el('strong', 'Dots'), close = action('✕', closeDots, 'icon');
  back.setAttribute('aria-label', 'Dot 목록으로'); close.setAttribute('aria-label', 'Dot 닫기'); head.append(back, title, close);
  const nav = el('nav', undefined, 'dot-tabs'), chat = action('대화', () => openChat(), 'ghost'), work = action('작업', () => openTasks(), 'ghost'), control = action('일시중지', togglePause, 'ghost'); nav.append(chat, work, control);
  const note = el('p', '', 'dot-note'); note.setAttribute('role', 'status');
  const content = el('div', undefined, 'dot-content'); content.tabIndex = 0;
  const compose = el('form', undefined, 'dot-composer hidden'), target = el('small', '', 'muted'), input = el('textarea'), send = el('button', '↑', 'send-button');
  input.rows = 1; input.placeholder = 'Dot에게 메시지'; input.setAttribute('aria-label', 'Dot 메시지'); send.type = 'submit'; send.setAttribute('aria-label', 'Dot에게 메시지 보내기');
  compose.append(target, input, send); compose.onsubmit = e => { e.preventDefault(); submit().catch(error => setNote(error.message, true)); };
  overlay.append(head, nav, note, content, compose); $('app').append(overlay);
  registerMessageCopyRoot(content);
  const button = action('◉ Dot 대화와 작업', openDots, 'ghost full dot-entry hidden'); $('connectionButton').after(button);
  let allowed = false, accessRequest = 0, accessCheckedAt = 0, accessPending = null;
  function setAccess(value, invalidate=false) {
    allowed = value; button.classList.toggle('hidden', !value);
    if(invalidate){cache.clear();ui.scope='';ui.dotList=[];}
    if (!value && ui.open) closeDots();
  }
  async function refreshAccess(force = false) {
    if (!state.online || state.leaving || !state.serverCapabilities.dots) { accessRequest++; accessCheckedAt = 0; setAccess(false); return false; }
    if (!force && accessPending) return accessPending;
    if (!force && Date.now() - accessCheckedAt < 30000) return allowed;
    const request = ++accessRequest, socket = state.socket;
    const pending = (async () => {
      let result;
      try { result = await rpc('bridge/dots/access', { refresh: force }); } catch { result = { allowed: false }; }
      if (request !== accessRequest || state.socket !== socket || !state.online || state.leaving) return false;
      accessCheckedAt = Date.now();
      if(result.allowed===true){const previous=ui.scope;ui.scope=result.scope||'';ui.dotList=cache.bind(ui.scope,result.dots);if(previous&&previous!==ui.scope&&ui.open)closeDots();}
      setAccess(result.allowed === true,result.allowed!==true); return allowed;
    })();
    accessPending = pending;
    try { return await pending; } finally { if (accessPending === pending) accessPending = null; }
  }
  function setNote(text = '', error = false) { note.textContent = text; note.classList.toggle('inline-error', error); }
  function draftKey() { return (ui.dot?.id || '') + ':' + (ui.task?.id || 'chat'); }
  function saveDraft() { if (!ui.dot || !['chat', 'task'].includes(ui.mode)) return; ui.drafts[draftKey()] = input.value; persist('remote.dotDrafts', ui.drafts); }
  function savePending() { persist('remote.dotPending', ui.pending); }
  function prepareInput() { input.value = ui.drafts[draftKey()] || ''; inputChanged(); }
  function inputChanged() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 130) + 'px'; }
  input.addEventListener('input', () => { saveDraft(); inputChanged(); });
  const call = (operation, p = {}) => rpc('bridge/dots/' + operation, { dotId: ui.dot?.id, ...p });
  function valid(n) { return ui.open && ui.request === n && !state.leaving; }
  function resetView(mode) {
    ui.request++; ui.mode = mode; ui.nodes.clear(); ui.messages.clear(); ui.before = null; ui.taskCursor = null; ui.loadingOlder = false; ui.busy = false; content.replaceChildren(); content.scrollTop = 0; previousScroll = 0; ui.pinned = true;
    nav.classList.toggle('hidden', mode === 'list'); compose.classList.toggle('hidden', !['chat', 'task'].includes(mode));
    chat.classList.toggle('active', mode === 'chat'); work.classList.toggle('active', mode !== 'chat');
    title.textContent = mode === 'list' ? 'Dots' : ui.task?.name || ui.dot?.name || 'Dot';
    target.textContent = mode === 'task' ? '이 작업에 대한 추가 지시를 Dot에게 전달합니다.' : 'Dot와 대화'; control.textContent = ui.dot?.paused ? '계속하기' : '일시중지';
    setNote(); prepareInput(); return ui.request;
  }
  async function openDots() {
    if (!allowed && !await refreshAccess(true)) return;
    saveDraft(); closeMenus(); ui.open = true; overlay.classList.remove('hidden'); ui.task = null;
    const n = resetView('list'); renderDots(ui.dotList); if(!ui.dotList.length)setNote('Dot 목록을 불러오는 중…');
    if (!state.serverCapabilities.dots) { setNote('이 PC의 Pocket Remote를 0.7.0 이상으로 업데이트해주세요.', true); return; }
    try {
      const r = await rpc('bridge/dots/list'); if (!valid(n)) return;
      ui.dotList=cache.bind(ui.scope,r.dots);renderDots(ui.dotList);
    } catch (e) { if (valid(n)) { setNote(e.message, true); content.append(action('다시 연결', openDots, 'primary')); } }
    startPolling(); resize();
  }
  function renderDots(dots) {
    content.replaceChildren();ui.nodes.clear();setNote(dots.length?'개인 클라우드 · 공식 앱과 같은 Dot':'');
    for(const p of dots)pickerRow(content,p.name,p.preview||(p.paused?'일시중지됨':'대화와 연결 작업 보기'),()=>{ui.dot=p;ui.task=null;openChat();},{icon:'◉'});
    if(!dots.length)setNote('연결된 Dot가 없습니다. 공식 앱에서 Dot를 만들어주세요.');
  }
  async function openChat() {
    saveDraft(); ui.task = null; const n = resetView('chat'), recent=cache.room(ui.dot.id);
    if(recent){ui.before=recent.before;mergeMessages(recent.messages);renderMessages(true);setNote(Date.now()-recent.at>=4000?'최신 대화 확인 중…':'');}else setNote('대화를 불러오는 중…');
    startPolling();renewWatch().catch(e=>{if(valid(n))setNote(e.message,true);});
    if(recent&&Date.now()-recent.at<4000){warmOlder();return;}
    ui.busy=true;
    try { const r = await call('messages'); if (!valid(n)) return; ui.before = r.before; mergeMessages(r.messages);cache.save(ui.dot.id,r);renderMessages(!recent);warmOlder(); setNote(); }
    catch (e) { if (valid(n)) setNote(e.message, true); }
    finally { if(valid(n))ui.busy=false; }
  }
  function mergeMessages(messages) {
    for (const m of normalizeDotMessages(messages, ui.messages)) {
      const old = ui.messages.get(m.id);
      if (old?.updatedAt && m.updatedAt && Date.parse(old.updatedAt) > Date.parse(m.updatedAt)) continue;
      ui.messages.set(m.id, m);
    }
  }
  function renderMessages(bottom = false) {
    const pinned = bottom || ui.pinned, oldTop = content.scrollTop;
    const all = [...ui.messages.values()].sort((a, b) => (a.createdAt || '').localeCompare(b.createdAt || '') || a.id.localeCompare(b.id));
    for (const e of ui.pending.filter(e => e.dotId === ui.dot?.id && (e.taskId || '') === (ui.task?.id || ''))) {
      if (all.some(m => m.requestId === e.requestId)) { ui.pending = ui.pending.filter(p => p !== e); savePending(); continue; }
      all.push({ id: 'pending:' + e.requestId, role: 'user', text: e.text, pending: e });
    }
    patchRows(all, m => m.id, (row, m) => {
      row.className = 'item dot-message ' + (m.role === 'user' ? 'userMessage' : 'agentMessage') + (m.role === 'unknown' ? ' authorship-unknown' : '');
      const body = el('div', undefined, 'body'); if (m.role === 'user') body.textContent = m.text; else renderMarkdown(body, m.text);
      row.replaceChildren(el('small', m.role === 'user' ? '나' : m.role === 'unknown' ? '작성자 확인 필요 · PC 업데이트' : '◉ '+(ui.dot?.name || 'Dot'), 'kind'), body);
      row.removeAttribute('tabindex');row.removeAttribute('aria-label');delete row.bodyNode;
      if (m.role === 'user') { row.bodyNode = body; body.remoteText = m.text; row.tabIndex = 0; row.setAttribute('aria-label', '내 메시지 · 길게 눌러 복사'); }
      for (const a of m.attachments || []) {
        if (a.type === 'thread') row.append(action('연결 작업 보기', async () => { try { const r = await call('tasks'); ui.tasks = new Map(r.tasks.map(x => [x.id, x])); const t = ui.tasks.get(a.threadId); if (!t) throw new Error('이 Dot의 표시 가능한 작업이 아닙니다.'); openTask(t); } catch (e) { setNote(e.message, true); } }, 'ghost'));
        else if (a.type === 'link' && a.url) { const link = el('a', a.name); link.href = a.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; row.append(link); }
        else if (a.type === 'file') row.append(el('small', '▤ ' + a.name, 'muted'));
      }
      if (m.pending) {
        row.append(el('small', m.pending.error || (m.pending.sending ? '전송 중…' : '보내기 대기'), 'inline-error'));
        if (!m.pending.sending) row.append(action('같은 메시지 다시 보내기', () => sendEntry(m.pending), 'ghost'), action('복사', () => copySheet(m.text), 'ghost'));
      }
    });
    if (pinned) content.scrollTop = content.scrollHeight; else content.scrollTop = oldTop;
  }
  function patchRows(rows, key, draw) {
    const keep = new Set(); let previous = null;
    for (const value of rows) {
      const k = key(value); let row = ui.nodes.get(k); if (!row) { row = el('article'); row.dataset.dotKey = k; ui.nodes.set(k, row); }
      const version = JSON.stringify(value);
      if (row.dotVersion !== version) { draw(row, value); row.dotVersion = version; }
      const expected = previous ? previous.nextSibling : content.firstChild;
      if (expected !== row) content.insertBefore(row, expected); previous = row; keep.add(k);
    }
    for (const [k, row] of ui.nodes) if (!keep.has(k)) { row.remove(); ui.nodes.delete(k); }
  }
  async function openTasks() {
    saveDraft(); ui.task = null; const n = resetView('tasks'); setNote('연결 작업을 불러오는 중…');
    try { const r = await call('tasks'); if (!valid(n)) return; ui.tasks = new Map(r.tasks.map(t => [t.id, t])); renderTasks(); ui.lastTasks = Date.now(); setNote(r.tasks.length ? '' : '연결된 작업이 없습니다. Dot에게 작업을 요청해보세요.'); }
    catch (e) { if (valid(n)) setNote(e.message, true); }
    startPolling();
  }
  const statusName = s => ({ idle: '대기 중', active: '작업 중', running: '작업 중', inProgress: '작업 중', archived: '보관됨', completed: '완료', unknown: '상태 확인 필요', systemError: '오류' })[s] || s;
  function renderTasks() {
    const top = content.scrollTop;
    patchRows([...ui.tasks.values()], t => t.id, (row, t) => {
      row.className = 'dot-task agent-card'; row.dataset.status = ['active', 'running', 'inProgress'].includes(t.status) ? 'running' : t.status === 'completed' ? 'completed' : t.status === 'systemError' ? 'failed' : 'idle'; const b = action('', () => openTask(t), 'picker-row');
      const body = el('span', undefined, 'row-body'); body.append(el('strong', t.name), el('small', [t.model, t.effort, t.error].filter(Boolean).join(' · ')));
      const badge = el('span', statusName(t.status), 'agent-state ' + row.dataset.status);
      b.append(body, badge); row.replaceChildren(b);
    }); content.scrollTop = top;
  }
  async function openTask(t) {
    saveDraft(); ui.task = t; const n = resetView('task'); setNote('작업 내역을 불러오는 중…');
    try { const r = await call('task/read', { threadId: t.id }); if (!valid(n)) return; ui.taskCursor = r.nextCursor; mergeTask(r.data); renderTask(true);warmOlder(); setNote(); }
    catch (e) { if (valid(n)) setNote(e.message, true); }
    startPolling();
  }
  function mergeTask(entries) { for (const e of [...entries].reverse()) if (e.item?.id) ui.messages.set(e.item.id, e); }
  function renderTask(bottom = false) {
    const top = content.scrollTop, pinned = bottom || ui.pinned;
    const all = [...ui.messages.values()].sort((a, b) => (a.startedAtMs || a.completedAtMs || 0) - (b.startedAtMs || b.completedAtMs || 0));
    for (const p of ui.pending.filter(p => p.dotId === ui.dot?.id && p.taskId === ui.task?.id)) all.push({ item: { id: 'pending:' + p.requestId, type: 'userMessage', content: [{ type: 'inputText', text: p.text }] }, pending: p });
    patchRows(all, e => e.item.id, (row, e) => {
      const expanded = row.querySelector('details')?.open;
      const i = e.item; row.className = 'item ' + i.type;
      const body = el('div', undefined, 'body');
      if (['agentMessage', 'userMessage'].includes(i.type)) { if (i.type === 'agentMessage') renderMarkdown(body, i.text); else { body.textContent = describe(i); body.remoteText = body.textContent; row.bodyNode = body; row.tabIndex = 0; } row.replaceChildren(el('small', i.type === 'agentMessage' ? 'Codex' : '나', 'kind'), body); }
      else if (i.type === 'contextCompaction') row.replaceChildren(el('p', '≋ 문맥이 압축되었습니다.', 'muted'));
      else { const details = el('details'), summary = el('summary', ({ reasoning: '생각 중', commandExecution: '명령 실행', fileChange: '파일 변경', subAgentActivity: '서브에이전트 작업', collabAgentToolCall: '서브에이전트', plan: '계획' })[i.type] || '작업 상세'); details.open = !!expanded; details.append(summary, el('pre', describe(i), 'file-source')); row.replaceChildren(details); }
      if (e.pending) { row.append(el('small', e.pending.error || (e.pending.sending ? '전송 중…' : '보내기 대기'), 'inline-error')); if (!e.pending.sending) row.append(action('같은 메시지 다시 보내기', () => sendEntry(e.pending), 'ghost'), action('복사', () => copySheet(e.pending.text), 'ghost')); }
    }); content.scrollTop = pinned ? content.scrollHeight : top;
  }
  async function older() {
    const token = ui.mode === 'chat' ? ui.before : ui.taskCursor;
    if (!token || ui.loadingOlder || !state.online || !['chat', 'task'].includes(ui.mode)) return;
    const n = ui.request; ui.loadingOlder = true;
    try {
      const r = await readOlder(token, true);
      if (!valid(n)) return;
      const edge = content.getBoundingClientRect().top;
      const anchor = [...content.children].find(row => row.getBoundingClientRect().bottom > edge);
      const offset = anchor?.getBoundingClientRect().top;
      const height = content.scrollHeight, top = content.scrollTop; ui.pinned = false;
      if (ui.mode === 'chat') { ui.before = r.before === token ? null : r.before; mergeMessages(r.messages); renderMessages(); } else { ui.taskCursor = r.nextCursor === token ? null : r.nextCursor; mergeTask(r.data); renderTask(); }
      if (anchor?.isConnected) content.scrollTop += anchor.getBoundingClientRect().top - offset;
      else content.scrollTop = top + content.scrollHeight - height;
      warmOlder();
    } catch (e) { if (valid(n)) setNote(e.message, true); } finally { if (valid(n)) {
      ui.loadingOlder = false;
      const next = ui.mode === 'chat' ? ui.before : ui.taskCursor;
      if (next && next !== token && content.scrollTop < historyLoadDistance(content)) requestAnimationFrame(older);
    } }
  }
  content.addEventListener('scroll', () => {
    ui.pinned = content.scrollHeight - content.scrollTop - content.clientHeight < 80;
    const upwards = content.scrollTop <= previousScroll; previousScroll = content.scrollTop;
    if (upwards && content.scrollTop < historyWarmDistance(content)) warmOlder();
    if (upwards && content.scrollTop < historyLoadDistance(content)) older();
  }, { passive: true });
  async function renewWatch() { if (ui.dot && state.online) await call('watch'); }
  async function refresh() {
    if (!ui.open || ui.busy || ui.loadingOlder || document.hidden || !state.online || !ui.dot || ui.mode === 'list') return;
    const n = ui.request; ui.busy = true;
    try {
      if (ui.mode === 'chat') { const r = await call('messages'); if (valid(n)) { mergeMessages(r.messages);cache.save(ui.dot.id,r);renderMessages(); } }
      else if (ui.mode === 'task') { const r = await call('task/read', { threadId: ui.task.id }); if (valid(n)) { mergeTask(r.data); renderTask(); } }
      else if (Date.now() - ui.lastTasks > 10000) { const r = await call('tasks'); if (valid(n)) { ui.tasks = new Map(r.tasks.map(t => [t.id, t])); renderTasks(); ui.lastTasks = Date.now(); } }
      if (valid(n)) { setNote(); await renewWatch(); }
    } catch (e) { if (valid(n)) setNote(e.message, true); } finally { if (valid(n)) ui.busy = false; }
  }
  function startPolling() { clearInterval(ui.poll); ui.poll = setInterval(refresh, 4000); }
  async function submit() {
    const text = input.value.trim(); if (!text || !ui.dot) return;
    const entry = { dotId: ui.dot.id, taskId: ui.task?.id || '', requestId: uuid(), text };
    ui.pending.push(entry); if (!persist('remote.dotPending', ui.pending)) { ui.pending.pop(); throw new Error('메시지를 저장하지 못했습니다.'); }
    input.value = ''; saveDraft(); inputChanged(); await sendEntry(entry);
  }
  async function sendEntry(entry) {
    if (entry.sending) return;
    if (!state.online) { entry.error = 'PC에 다시 연결한 뒤 보내기를 눌러주세요.'; savePending(); if (ui.mode === 'chat') renderMessages(); else renderTask(); return; }
    const n = ui.request; entry.sending = true; entry.error = ''; savePending(); if (ui.mode === 'chat') renderMessages(); else renderTask();
    try {
      const r = await rpc('bridge/dots/send', { dotId: entry.dotId, taskId: entry.taskId || undefined, requestId: entry.requestId, text: entry.text });
      ui.pending = ui.pending.filter(e => e !== entry); savePending();
      if (valid(n)) { if (ui.mode === 'chat') { const message=r.message&&{...r.message,fromSelf:true};mergeMessages([message].filter(Boolean));const recent=cache.room(ui.dot.id);if(recent)cache.save(ui.dot.id,{...recent,messages:[...recent.messages.filter(m=>m.id!==message?.id),message].filter(Boolean)});renderMessages(true); } else setNote('Dot에게 이 작업의 추가 지시를 전달했습니다.'); }
    } catch (e) { entry.error = e.message; if (valid(n)) setNote(e.message, true); }
    finally { entry.sending = false; savePending(); if (valid(n)) { if (ui.mode === 'chat') renderMessages(); else if (ui.mode === 'task') renderTask(); } }
  }
  function copySheet(text) { const root = picker('메시지'); addMessageCopyRow(root, text); }
  async function togglePause() {
    control.disabled = true;
    try { await call(ui.dot.paused ? 'resume' : 'pause'); const r = await rpc('bridge/dots/list', { refresh: true }); const p = r.dots.find(p => p.id === ui.dot.id); if (p) ui.dot = p; control.textContent = ui.dot.paused ? '계속하기' : '일시중지'; setNote('Dot 상태를 갱신했습니다. 연결 작업은 별도로 계속될 수 있습니다.'); }
    catch (e) { setNote(e.message, true); }
    finally { control.disabled = false; }
  }
  function goBack() { if (ui.mode === 'task') openTasks(); else if (ui.mode !== 'list') openDots(); else closeDots(); }
  function closeDots() { saveDraft(); closeMessageCopy(); ui.open = false; ui.request++; clearInterval(ui.poll); clearTimeout(ui.refresh); overlay.classList.add('hidden'); if (state.online && !state.leaving) call('unwatch').catch(() => {}); }
  const resize = () => { if (!ui.open) return; overlay.style.height = (window.visualViewport?.height || $('app').clientHeight) + 'px'; if (ui.pinned) requestAnimationFrame(() => { content.scrollTop = content.scrollHeight; }); };
  window.visualViewport?.addEventListener('resize', resize); new ResizeObserver(resize).observe($('app'));
  const previousClose = window.remoteCloseMenu;
  window.remoteCloseMenu = () => { if (ui.open && $('messageCopyOverlay').classList.contains('hidden') && ![...document.querySelectorAll('.overlay')].some(x => !x.classList.contains('hidden'))) { goBack(); return true; } return previousClose?.(); };
  window.pocketDots = { event(message) { if(message.method==='account/updated'){cache.clear();ui.scope='';ui.dotList=[];accessCheckedAt=0;setAccess(false);refreshAccess(true);}if (ui.open && message.method === 'pocket/dots/changed' && message.params.dotId === ui.dot?.id) { clearTimeout(ui.refresh); ui.refresh = setTimeout(refresh, 180); } }, close: closeDots, refreshAccess, ui };
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { refresh(); refreshAccess(); } });
  refreshAccess();
  for (const e of ui.pending) { e.sending = false; if (!e.error) e.error = '수신 내역을 확인한 뒤 같은 메시지를 다시 시도하세요.'; }
})();

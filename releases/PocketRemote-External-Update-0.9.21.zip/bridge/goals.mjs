import { readFileSync } from 'node:fs';
import { readFile, writeFile, rename } from 'node:fs/promises';
import { resolve, extname } from 'node:path';

// App Server owns execution and continuation. Never send preparation or
// continuation turns. Only temporarily yield to explicitly queued user input.
export function createGoalRunner({ root, call, ensureThread, notify, online, canStart }) {
  const path = resolve(root, '.goal-runners.json');
  let holds = {};
  try { const saved = JSON.parse(readFileSync(path, 'utf8')); if (saved.version === 2) holds = saved.holds || {}; } catch {}
  let saving = Promise.resolve(), stopped = false;
  const busy = new Set(), timers = new Map();
  function save() {
    const data = JSON.stringify({ version: 2, holds });
    saving = saving.catch(() => {}).then(async () => { await writeFile(path + '.tmp', data, { mode: 0o600 }); await rename(path + '.tmp', path); });
    return saving;
  }
  function publish(threadId, error = '') { notify({ method: 'pocket/goal/state', params: { threadId, native: true, error } }); }
  async function loaded(threadId) {
    if (ensureThread) return ensureThread(threadId);
    const page = await call('thread/loaded/list', {});
    if (!(page.data || []).includes(threadId)) await call('thread/resume', { threadId, excludeTurns: true });
  }
  function schedule(id, delay = 1000) {
    clearTimeout(timers.get(id));
    if (!stopped && holds[id]) timers.set(id, setTimeout(() => release(id), delay));
  }
  async function release(id) {
    if (stopped || !holds[id] || busy.has(id) || !online()) return;
    if (!canStart(id)) { schedule(id); return; }
    busy.add(id);
    try {
      const hold = holds[id], { goal } = await call('thread/goal/get', { threadId: id });
      if (hold !== holds[id]) return;
      // A user edit or explicit pause supersedes this automatic queue yield.
      if (goal?.status === 'paused' && goal.objective === hold.objective && goal.updatedAt === hold.updatedAt) {
        await loaded(id);
        await call('thread/goal/set', { threadId: id, status: 'active' });
      }
      if (holds[id] === hold) { delete holds[id]; await save(); publish(id); }
    } catch (e) { publish(id, e.message); schedule(id, 10000); }
    finally { busy.delete(id); }
  }
  async function contextItems(input) {
    const content = [];
    for (const item of input || []) {
      if (item.type === 'text' && item.text) content.push({ type: 'input_text', text: item.text });
      else if (item.type === 'skill' || item.type === 'mention') content.push({ type: 'input_text', text: `사용 지시: ${item.type === 'skill' ? '$' : '@'}${item.name} (${item.path})` });
      else if (item.type === 'localImage') {
        const mime = ({ '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' })[extname(item.path).toLowerCase()];
        if (!mime) throw new Error('목표 첨부 이미지 형식을 확인하세요.');
        const bytes = await readFile(item.path);
        if (bytes.length > 20 * 1024 * 1024) throw new Error('목표 이미지는 20MB 이내로 첨부하세요.');
        content.push({ type: 'input_image', image_url: `data:${mime};base64,${bytes.toString('base64')}` });
      } else if (item.type === 'image') content.push({ type: 'input_image', image_url: item.url });
    }
    return content.length ? [{ type: 'message', role: 'user', content }] : [];
  }
  return {
    isYielded(threadId) { return !!holds[threadId]; },
    onReady() { for (const id of Object.keys(holds)) schedule(id); },
    onOffline() { for (const timer of timers.values()) clearTimeout(timer); },
    onEvent(message) { if (message.method === 'turn/completed') schedule(message.params?.threadId); },
    async onQueueWaiting(threadId) {
      if (!online() || holds[threadId]) return;
      let goal;
      try { ({ goal } = await call('thread/goal/get', { threadId })); }
      catch (e) { if (e.code === -32601 || /unknown method|unsupported|not found|not supported/i.test(e.message)) return; throw e; }
      if (goal?.status !== 'active') return;
      const result = await call('thread/goal/set', { threadId, status: 'paused' });
      holds[threadId] = { objective: result.goal.objective, updatedAt: result.goal.updatedAt };
      await save(); schedule(threadId); publish(threadId);
    },
    async handle(method, params) {
      const { threadId } = params;
      if (typeof threadId !== 'string' || !threadId || threadId.length > 100) throw new Error('대화를 먼저 선택하세요.');
      if (method === 'bridge/goal/get') return { ...await call('thread/goal/get', { threadId }), native: true };
      if (!['bridge/goal/clear', 'bridge/goal/pause', 'bridge/goal/save', 'bridge/goal/resume'].includes(method)) throw new Error('지원되지 않는 목표 작업입니다.');
      const args = { threadId, status: method === 'bridge/goal/pause' || params.status === 'paused' ? 'paused' : 'active' };
      if (method === 'bridge/goal/save') {
        const objective = String(params.objective || '').trim();
        if (!objective || [...objective].length > 4000) throw new Error('목표를 4,000자 이내로 입력하세요.');
        if (params.tokenBudget != null && (!Number.isSafeInteger(params.tokenBudget) || params.tokenBudget <= 0)) throw new Error('토큰 예산은 양의 정수로 입력하세요.');
        args.objective = objective; args.tokenBudget = params.tokenBudget ?? null;
      }
      const extra = method === 'bridge/goal/save' ? await contextItems(params.inputExtras) : [];
      delete holds[threadId]; clearTimeout(timers.get(threadId)); await save();
      if (method === 'bridge/goal/clear') { const r = await call('thread/goal/clear', { threadId }); publish(threadId); return r; }
      await loaded(threadId);
      if (method === 'bridge/goal/save' || method === 'bridge/goal/resume') {
        const settings = {};
        for (const key of ['cwd', 'model', 'effort', 'sandboxPolicy', 'approvalPolicy', 'summary']) if (params.settings?.[key] != null) settings[key] = params.settings[key];
        if (params.settings && (Object.hasOwn(params.settings, 'serviceTierForTurn') || Object.hasOwn(params.settings, 'serviceTier'))) settings.serviceTier = params.settings.serviceTierForTurn ?? params.settings.serviceTier ?? null;
        // Planning mode deliberately does not execute native goals. Apply the
        // selected work model in execution mode, as the official goal UI does.
        if (settings.model) settings.collaborationMode = { mode: 'default', settings: { model: settings.model, reasoning_effort: settings.effort ?? null, developer_instructions: null } };
        if (Object.keys(settings).length) await call('thread/settings/update', { threadId, ...settings });
      }
      if (extra.length) await call('thread/inject_items', { threadId, items: extra });
      const result = await call('thread/goal/set', args);
      if (method === 'bridge/goal/pause') {
        const page = await call('thread/turns/list', { threadId, limit: 1, sortDirection: 'desc', itemsView: 'notLoaded' });
        if (page.data?.[0]?.status === 'inProgress') await call('turn/interrupt', { threadId, turnId: page.data[0].id });
      }
      if (args.status === 'active' && !canStart(threadId)) await this.onQueueWaiting(threadId);
      publish(threadId); return { ...result, native: true };
    },
    stop() { stopped = true; for (const timer of timers.values()) clearTimeout(timer); }
  };
}

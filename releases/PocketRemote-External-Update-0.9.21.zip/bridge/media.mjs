import { mkdir, writeFile, readFile, stat, open, readdir, unlink } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, basename, extname, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

const types = { '.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.svg':'image/svg+xml','.avif':'image/avif','.mp4':'video/mp4','.webm':'video/webm','.mov':'video/quicktime','.mp3':'audio/mpeg','.wav':'audio/wav','.ogg':'audio/ogg','.m4a':'audio/mp4','.pdf':'application/pdf','.zip':'application/zip','.apk':'application/vnd.android.package-archive','.txt':'text/plain','.md':'text/markdown','.json':'application/json' };
const maxSize = 100 * 1024 * 1024;
const digest = value => createHash('sha256').update(value).digest('hex');

// This is presentation metadata for each occurrence, never for the cached file.
// Unknown tool output remains available behind a disclosure rather than being lost.
export function imagePresentation(item, annotations) {
  const audience = annotations?.audience;
  if (Array.isArray(audience) && audience.length) return audience.includes('user') ? 'inline' : 'attachment';
  if (['userMessage', 'agentMessage', 'imageGeneration'].includes(item.type)) return 'inline';
  if (item.type === 'imageView') return 'attachment';
  const tool = [item.server, item.namespace, item.tool, item.name].filter(Boolean).join('/');
  return /(?:^|[_.:/])(?:image_gen|imagegen|image_generation)(?:$|[_.:/])/i.test(tool) ? 'inline' : 'attachment';
}

/** Files are registered from native conversation items. Clients receive opaque IDs, not a general PC file API. */
export function createMedia({ root }) {
  const directory = resolve(root, '.media-cache'), cache = new Map(), registering = new Map(), aliases = new Map();
  let cleaning=null,cleanedAt=0;
  async function prune() {
    if(cleaning||Date.now()-cleanedAt<60000)return;
    cleanedAt=Date.now();
    cleaning=(async()=>{
      const entries=[];
      for(const name of await readdir(directory).catch(()=>[]))if(/^[a-f0-9]{64}\.json$/.test(name)){
        try{const metadata=resolve(directory,name),info=await stat(metadata),data=JSON.parse(await readFile(metadata,'utf8'));entries.push({id:name.slice(0,64),at:info.mtimeMs,bytes:data.inline?data.size:0});}catch{}
      }
      entries.sort((a,b)=>b.at-a.at);let kept=0,bytes=0;
      for(const entry of entries){
        if((Date.now()-entry.at<7*86400000&&kept<512&&bytes+entry.bytes<=512*1024*1024)||Date.now()-entry.at<60000){kept++;bytes+=entry.bytes;continue;}
        if(registering.has(entry.id))continue;
        const p=paths(entry.id);await unlink(p.metadata).catch(()=>{});await unlink(p.content).catch(()=>{});cache.delete(entry.id);
      }
    })().catch(()=>{}).finally(()=>cleaning=null);
    await cleaning;
  }
  function paths(id) {
    if (typeof id !== 'string' || !/^[a-f0-9]{64}$/.test(id)) throw new Error('파일 ID가 올바르지 않습니다.');
    return { metadata:resolve(directory,id+'.json'), content:resolve(directory,id+'.bin') };
  }
  const publicInfo = data => ({ id:data.id,name:data.name,mime:data.mime,size:data.size,kind:data.kind,modifiedAt:data.modifiedAt,sourcePath:data.inline?data.sourcePath:data.path });
  async function register({ threadId,itemId,part,path,url,mime,name }) {
    if(url&&typeof url==='object')url=url.url;
    let bytes, local = path;
    if(url?.startsWith('file:')){try{local=fileURLToPath(url);url=undefined;}catch{return null;}}
    if (url?.startsWith('data:')) {
      const match = url.match(/^data:([a-z0-9.+/-]+);base64,([\s\S]+)$/i);
      if (!match || match[2].length > maxSize*4/3+4) return null;
      mime = match[1]; bytes = Buffer.from(match[2],'base64');
    } else if (url && /^https:\/\//i.test(url)) {
      const pathname=new URL(url).pathname;mime=mime||types[extname(pathname).toLowerCase()]||'application/octet-stream';
      return {url,kind:mime.startsWith('image/')?'image':mime.startsWith('audio/')?'audio':mime.startsWith('video/')?'video':'file',name:name||basename(pathname)||'결과 파일',mime};
    }
    if (!bytes && (!local || !isAbsolute(local) || local.includes('\0'))) return null;
    let sourceStat;
    try { if (local) sourceStat = await stat(local); } catch { return null; }
    if (sourceStat && (!sourceStat.isFile() || sourceStat.size > maxSize)) return null;
    if (bytes && bytes.length > maxSize) return null;
    mime = mime || types[extname(local||'').toLowerCase()] || 'application/octet-stream';
    name = name || (local?basename(local):'결과-'+String(part)+'.'+({ 'image/png':'png','image/jpeg':'jpg','image/webp':'webp','audio/wav':'wav','audio/mpeg':'mp3' }[mime]||'bin'));
    const localKey=local?JSON.stringify([local,sourceStat.size,sourceStat.mtimeMs]):null;
    if(localKey&&aliases.has(localKey)&&cache.has(aliases.get(localKey)))return publicInfo(cache.get(aliases.get(localKey)));
    const id = digest(bytes?bytes: mime.startsWith('image/')&&sourceStat.size<=12*1024*1024?await readFile(local):JSON.stringify([threadId,itemId,local,sourceStat.size,sourceStat.mtimeMs]));
    if(localKey){aliases.set(localKey,id);while(aliases.size>512)aliases.delete(aliases.keys().next().value);}
    if (cache.has(id)) {const cached=cache.get(id);if(local&&cached.inline&&cached.sourcePath!==local){cached.sourcePath=local;cached.name=name;await writeFile(paths(id).metadata,JSON.stringify(cached),{mode:0o600});}return publicInfo(cached);}
    if (registering.has(id)) return registering.get(id);
    const task = (async () => {
      const p = paths(id); await mkdir(directory,{recursive:true,mode:0o700});
      const data = { id,threadId,itemId,name,mime,size:bytes?.length??sourceStat.size,kind:mime.startsWith('image/')?'image':mime.startsWith('video/')?'video':mime.startsWith('audio/')?'audio':'file',path:local||p.content,inline:!!bytes,modifiedAt:sourceStat?.mtimeMs||0 };
      if (bytes) { try { await writeFile(p.content,bytes,{flag:'wx',mode:0o600}); } catch(e) { if(e.code!=='EEXIST') throw e; } }
      await writeFile(p.metadata,JSON.stringify(data),{mode:0o600}); cache.set(id,data);
      while(cache.size>512) cache.delete(cache.keys().next().value);
      prune();
      return publicInfo(data);
    })();
    registering.set(id,task); try { return await task; } finally { registering.delete(id); }
  }
  async function load(id) {
    if (cache.has(id)) return cache.get(id);
    let data; try { data=JSON.parse(await readFile(paths(id).metadata,'utf8')); } catch { throw new Error('파일을 다시 불러오려면 대화를 동기화하세요.'); }
    cache.set(id,data); return data;
  }
  async function decorate(entry,threadId) {
    const original=entry.item||{}, item={...original}, media=[];
    let part=0;
    const add=async value=>{const registered=await register({threadId,itemId:item.id,part:++part,...value});if(registered){const descriptor={...registered,...(registered.kind==='image'?{presentation:value.annotations?.audience?.length?imagePresentation(item,value.annotations):value.presentation||imagePresentation(item)}:{})};const existing=media.find(m=>m.id===descriptor.id&&m.url===descriptor.url);if(existing){const visible=existing.presentation==='inline'||descriptor.presentation==='inline';Object.assign(existing,descriptor);if(visible)existing.presentation='inline';}else media.push(descriptor);}};
    const inspectText=async text=>{
      if(typeof text!=='string')return;
      for(const m of text.matchAll(/!?\[[^\]]*\]\(<?((?:[A-Za-z]:[\\/]|\/)[^\n<>]*?)>?(?:\s+"[^"]*")?\)/g)) {
        const path=m[1].replace(/:\d+(?::\d+)?$/,''); await add({path});
      }
      for(const m of text.matchAll(/as ([A-Za-z]:[\\/][^\n]+?\.(?:png|jpe?g|webp|gif|avif)) by default/g)) await add({path:m[1],presentation:'inline'});
      if(text.includes('[첨부 파일: PC에 업로드됨]'))for(const m of text.matchAll(/^"(?:[^"\\]|\\.)+": ([A-Za-z]:[\\/][^\n]+)$/gm))await add({path:m[1]});
    };
    async function blocks(values, annotations) {
      const out=[];
      for(const value of values||[]) {
        if(!value||typeof value!=='object'){out.push(value);continue;}
        const type=value.type;
        if(['input_image','inputImage','image','input_audio','inputAudio','audio'].includes(type)) {
          const before=media.length;
          await add({url:value.image_url||value.imageUrl||value.url||value.audio_url||value.audioUrl||(value.data?'data:'+(value.mimeType||'image/png')+';base64,'+value.data:''),mime:value.mimeType,annotations:value.annotations||annotations});
          if(media.length>before)out.push({type:'pocketMedia',media:media.at(-1)});
        } else if(type==='resource'&&value.resource){const resource=value.resource;await inspectText(resource.text);await add({url:resource.blob?'data:'+(resource.mimeType||'application/octet-stream')+';base64,'+resource.blob:resource.uri,mime:resource.mimeType,annotations:value.annotations||annotations});out.push({type:'text',text:resource.text||resource.uri});}
        else if(type==='resource_link'){await add({url:value.uri,mime:value.mimeType,name:value.name||value.title,annotations:value.annotations||annotations});out.push({type:'text',text:value.title||value.name||'결과 파일'});}
        else if(['localImage','localAudio'].includes(type)) { await add({path:value.path,annotations:value.annotations||annotations});out.push({...value,path:undefined}); }
        else { await inspectText(value.text); out.push(value); }
      }
      return out;
    }
    if(item.type==='userMessage')item.content=await blocks(item.content);
    if(item.type==='functionCallOutput'){
      if(Array.isArray(item.output))item.output=await blocks(item.output);
      else if(typeof item.output==='string'){await inspectText(item.output);try{const parsed=JSON.parse(item.output);if(Array.isArray(parsed.content)){item.output=await blocks(parsed.content);}}catch{}}
    }
    if(item.type==='mcpToolCall'&&item.result){item.result={...item.result,content:await blocks(item.result.content,item.result.annotations)};if(item.result.structuredContent)await inspectText(JSON.stringify(item.result.structuredContent));}
    if(item.type==='dynamicToolCall'&&item.contentItems)item.contentItems=await blocks(item.contentItems);
    if(item.type==='imageView')await add({path:item.path});
    if(item.type==='imageGeneration'){
      if(item.savedPath)await add({path:item.savedPath});
      if(!media.length&&item.result)await add({url:item.result.startsWith('data:')||item.result.startsWith('https://')?item.result:'data:image/png;base64,'+item.result,name:'생성 이미지.png'});
      item.result='';
    }
    await inspectText(item.text);
    if(item.type==='commandExecution')await inspectText(item.aggregatedOutput);
    if(media.length)item.media=media;
    return {...entry,item};
  }
  return {
    async page(page,threadId) {const data=[];for(const entry of page.data||[])data.push(await decorate(entry,threadId));return {...page,data};},
    async item(item,threadId,turnId) {return (await decorate({item,turnId},threadId)).item;},
    async handle(method,params={}) {
      const data=await load(params.id), s=await stat(data.path);
      if(!s.isFile()||s.size!==data.size||(!data.inline&&s.mtimeMs!==data.modifiedAt))throw new Error('PC 파일이 변경되었습니다. 대화를 다시 동기화하세요.');
      if(method==='bridge/media/info')return publicInfo(data);
      if(method!=='bridge/media/chunk')throw new Error('지원되지 않는 파일 요청입니다.');
      const offset=Number(params.offset); if(!Number.isSafeInteger(offset)||offset<0||offset>data.size)throw new Error('파일 위치가 올바르지 않습니다.');
      const length=Math.min(192*1024,data.size-offset), bytes=Buffer.alloc(length), file=await open(data.path,'r');
      let bytesRead;try{({bytesRead}=await file.read(bytes,0,length,offset));}finally{await file.close();}
      return {id:data.id,offset,data:bytes.subarray(0,bytesRead).toString('base64'),nextOffset:offset+bytesRead,size:data.size};
    }
  };
}

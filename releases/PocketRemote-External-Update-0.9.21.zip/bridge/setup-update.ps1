﻿param([string]$VersionRoot='')

function Get-InstalledPCVersion([string]$InstallRoot) {
    $package = (Get-Content -LiteralPath (Join-Path $InstallRoot 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
    $executable = Join-Path $InstallRoot 'PocketRemoteHost.exe'
    if (Test-Path -LiteralPath $executable -PathType Leaf) {
        $binary = [Diagnostics.FileVersionInfo]::GetVersionInfo($executable).FileVersion
        if ($binary -match '^(\d+\.\d+\.\d+)\.\d+$' -and [version]$Matches[1] -lt [version]$package) { return $Matches[1] }
    }
    return $package
}
function Test-ExistingPCInstall([string]$InstallRoot) {
    foreach ($name in @('package.json','bridge\host.mjs','bridge\activity.mjs')) {
        if (!(Test-Path -LiteralPath (Join-Path $InstallRoot $name) -PathType Leaf)) { return $false }
    }
    $endpoint = if (Get-Command Get-PocketSetting -ErrorAction SilentlyContinue) { Get-PocketSetting $InstallRoot '.endpoint.json' } else { Join-Path $InstallRoot '.endpoint.json' }
    if (!(Test-Path -LiteralPath $endpoint)) { return $false }
    return $true
}
function Find-ExistingPCInstall([string]$SourceRoot) {
    if (Test-ExistingPCInstall $SourceRoot) { return [IO.Path]::GetFullPath($SourceRoot) }
    $task = Get-ScheduledTask -TaskName PocketRemoteExternal -ErrorAction SilentlyContinue
    foreach ($action in $task.Actions) {
        if ([IO.Path]::GetFileName([string]$action.Execute) -ne 'PocketRemoteHost.exe') { continue }
        $directory = [IO.Path]::GetDirectoryName([string]$action.Execute)
        if ($directory -and (Test-ExistingPCInstall $directory)) { return [IO.Path]::GetFullPath($directory) }
    }
    return ''
}
function Install-PCUpdateBootstrap([string]$SourceRoot, [string]$InstallRoot) {
    $SourceRoot = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
    $InstallRoot = [IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
    if (!(Test-ExistingPCInstall $InstallRoot)) { throw '기존 Pocket Remote 설치 폴더를 선택하세요.' }
    $current = Get-InstalledPCVersion $InstallRoot
    $next = (Get-Content -LiteralPath (Join-Path $SourceRoot 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
    if ([version]$next -lt [version]$current) { throw '더 오래된 버전으로 업데이트할 수 없습니다.' }
    $files = @('bridge\settings.ps1','bridge\settings.mjs','SETUP-REMOTE.ps1','SETUP-RELAY-LOGIN.ps1','UPDATE-PC.ps1','bridge\setup-host.ps1','bridge\setup-update.ps1','bridge\host.mjs','bridge\pc-updates.mjs','bridge\update-worker.mjs','bridge\update-key.mjs','bridge\relay-setup.mjs','bridge\relay-login.mjs','bridge\relay-server.py','bridge\setup-config.mjs','bridge\setup-test.mjs')
    $previous = @{}; $changed = @()
    if (Test-Path -LiteralPath (Join-Path $SourceRoot 'distribution.json')) { $files += 'distribution.json' }
    foreach ($name in $files) {
        $source = Join-Path $SourceRoot $name; $target = Join-Path $InstallRoot $name
        if (!(Test-Path -LiteralPath $source -PathType Leaf)) { throw '업데이트 배포 파일이 누락되었습니다. PC ZIP을 모두 압축 해제하세요.' }
        foreach ($path in @($SourceRoot, $InstallRoot, (Join-Path $InstallRoot 'bridge'), $source, $target)) {
            if ((Test-Path -LiteralPath $path) -and ((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw '연결된 경로에 업데이트할 수 없습니다.' }
        }
        if (Test-Path -LiteralPath $target -PathType Leaf) { $previous[$name] = [IO.File]::ReadAllBytes($target) } else { $previous[$name] = $null }
    }
    try {
        if (![string]::Equals($SourceRoot, $InstallRoot, [StringComparison]::OrdinalIgnoreCase)) {
            foreach ($name in $files) { $changed += $name; Copy-Item -LiteralPath (Join-Path $SourceRoot $name) -Destination (Join-Path $InstallRoot $name) -Force }
        }
        # Preserve package version, executable, setup, tokens, DPAPI and work state.
        $shell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $started = & $shell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $InstallRoot 'SETUP-REMOTE.ps1') -Action Start -HostOnly | ConvertFrom-Json
        if ($LASTEXITCODE -ne 0 -or !$started.ok) { throw '기존 설정으로 연결을 시작하지 못했습니다.' }
        $node = (Get-Command node.exe -ErrorAction Stop).Source
        $hostId = [int](Get-Content -LiteralPath (Join-Path $InstallRoot '.host.pid') -Raw).Trim()
        Start-Process -FilePath $node -ArgumentList @(('"' + (Join-Path $InstallRoot 'bridge\update-worker.mjs') + '"'), '--check-now', '--parent', $hostId) -WorkingDirectory $InstallRoot -WindowStyle Hidden | Out-Null
        return @{ installRoot=$InstallRoot; installedVersion=$current; message='기존 설정과 페어링을 유지하며 업데이트를 확인합니다. 작업이 진행 중이면 종료 후 적용합니다. 다시 페어링할 필요가 없습니다.' }
    } catch {
        foreach ($name in $changed) {
            $target = Join-Path $InstallRoot $name
            if ($null -ne $previous[$name]) { [IO.File]::WriteAllBytes($target, [byte[]]$previous[$name]) }
            elseif (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target -Force }
        }
        throw
    }
}
if ($VersionRoot) { Get-InstalledPCVersion $VersionRoot }

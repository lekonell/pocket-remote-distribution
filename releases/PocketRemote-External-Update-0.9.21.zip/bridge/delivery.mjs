// Large read responses are reproducible; mutation receipts must survive a
// disconnected requester so its retry cannot execute the mutation twice.
const repeatable = /^(?:model\/list|thread\/(?:list|read|turns\/list|items\/list)|account\/rateLimits\/read|bridge\/(?:media\/(?:info|chunk)|file\/status|catalog\/list|sync\/read|status\/read|retry\/list|notifications\/list|question\/list|queue\/(?:list|get)|goal\/get))$/;

export function createDelivery(send) {
  const pending = new Map(), receipts = new Map();
  return {
    begin(socket, message) {
      const cached = receipts.get(message.id);
      if (cached) { send(socket, cached); return false; }
      const running = pending.get(message.id);
      if (running) { running.clients.add(socket); return false; }
      pending.set(message.id, { clients: new Set([socket]), retain: !repeatable.test(message.method) });
      return true;
    },
    complete(message) {
      const request = pending.get(message.id);
      if (!request) return;
      pending.delete(message.id);
      const wire = JSON.stringify({ type: 'response', message });
      if (request.retain) {
        receipts.set(message.id, wire);
        while (receipts.size > 1000) receipts.delete(receipts.keys().next().value);
      }
      for (const client of request.clients) send(client, wire);
    },
    disconnect(socket) { for (const request of pending.values()) request.clients.delete(socket); },
    failAll(message) { for (const id of [...pending.keys()]) this.complete({ id, error: { code: -32000, message } }); }
  };
}

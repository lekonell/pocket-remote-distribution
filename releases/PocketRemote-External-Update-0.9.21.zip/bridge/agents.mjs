import { agentParent, isInternalAgent, subagentSource } from './thread-source.mjs';
const statuses = { pendingInit: 'starting', running: 'running', interrupted: 'interrupted', completed: 'completed', errored: 'failed', shutdown: 'stopped', notFound: 'unavailable' };
export const agentName = path => String(path || '').split('/').filter(Boolean).at(-1)?.replace(/[_-]+/g, ' ') || '서브 에이전트';
export function agentActivityTime(...values) {
  return Math.max(0, ...values.map(value => {
    if (value == null || value === '') return 0;
    const n = typeof value === 'number' || /^\d+(?:\.\d+)?$/.test(String(value)) ? Number(value) : Date.parse(value);
    return Number.isFinite(n) && n > 0 ? (n < 1e11 ? n * 1000 : n) : 0;
  }));
}

export function createAgents({ call, pager, ensureThread }) {
  const families = new Map(), plans = new Map(), results = new Map(), pending = new Map();
  function family(id) { if (!families.has(id)) families.set(id, new Map()); return families.get(id); }
  function observe(threadId, entries, live = false) {
    const map = family(threadId);
    for (const entry of entries || []) {
      const item = entry.item || entry;
      const at = agentActivityTime(entry.startedAtMs, entry.completedAtMs, entry.createdAt, entry.updatedAt, entry.timestamp, item.createdAt, item.updatedAt, live ? Date.now() : 0);
      if (item.type === 'subAgentActivity' && item.agentThreadId) {
        const old = map.get(item.agentThreadId) || {};
        const status = ({ started: 'running', interacted: old.status || 'running', interrupted: 'interrupted', completed: 'completed' })[item.kind] || old.status;
        map.set(item.agentThreadId, { ...old, id: item.agentThreadId, parentThreadId: threadId, path: item.agentPath || old.path, name: agentName(item.agentPath || old.path), lastActivityAt: Math.max(old.lastActivityAt || 0, at), status: !live && old.status && ['running', 'starting'].includes(status) ? old.status : status });
      }
      if (item.type === 'collabAgentToolCall') for (const id of item.receiverThreadIds || []) {
        const old = map.get(id) || {}, state = item.agentsStates?.[id];
        map.set(id, { ...old, id, parentThreadId: threadId, name: old.name || '서브 에이전트', task: item.prompt || old.task, model: item.model || old.model, status: statuses[state?.status] || old.status || 'starting', result: state?.message || old.result, lastActivityAt: Math.max(old.lastActivityAt || 0, at) });
      }
    }
    while (families.size > 64) families.delete(families.keys().next().value);
  }
  function normalize(thread, known = {}) {
    const active = thread.status?.type === 'active';
    const path = known.path || subagentSource(thread)?.thread_spawn?.agent_path;
    return { ...known, id: thread.id, parentThreadId: agentParent(thread) || known.parentThreadId, internal: isInternalAgent(thread), path, name: path ? agentName(path) : thread.name || thread.agentNickname || thread.agentRole || known.name || '서브 에이전트', task: known.task || thread.preview || '', model: thread.model || known.model, status: active ? 'running' : thread.status?.type === 'systemError' ? 'failed' : ['running', 'starting'].includes(known.status) ? 'idle' : known.status || 'idle', plan: plans.get(thread.id) || [], lastActivityAt: agentActivityTime(known.lastActivityAt, thread.updatedAt, thread.createdAt) };
  }
  const visible = (agent, parent) => !agent.internal && (!agent.parentThreadId || agent.parentThreadId === parent);
  return {
    observe,
    relatedIds(id) { return [...family(id).values()].filter(a => !a.internal).map(a => a.id); },
    reset() { results.clear(); pending.clear(); },
    onEvent(message) {
      const p = message.params || {};
      if (p.item) observe(p.threadId, [p.item], true);
      if (message.method === 'turn/plan/updated') { plans.set(p.threadId, p.plan || []); while (plans.size > 256) plans.delete(plans.keys().next().value); }
      if (message.method === 'turn/started') plans.delete(p.threadId);
      for (const map of families.values()) if (map.has(p.threadId)) {
        const a = map.get(p.threadId);
        if (p.item || ['turn/started', 'turn/completed', 'turn/plan/updated'].includes(message.method)) a.lastActivityAt = agentActivityTime(a.lastActivityAt, p.timestamp, Date.now());
        if (message.method === 'turn/started') a.status = 'running';
        if (message.method === 'turn/completed') a.status = p.turn?.status === 'failed' ? 'failed' : p.turn?.status === 'interrupted' ? 'interrupted' : 'completed';
      }
      if (p.threadId) for (const key of results.keys()) if (key.includes(JSON.stringify(p.threadId)) || [...families].some(([id, map]) => map.has(p.threadId) && key.includes(JSON.stringify(id)))) results.delete(key);
    },
    async handle(method, p) {
      if (typeof p.threadId !== 'string' || !p.threadId || p.threadId.length > 100) throw Error('대화를 먼저 선택하세요.');
      const key = JSON.stringify([method, p.threadId, p.agentId, p.cursor]);
      if (results.has(key) && Date.now() - results.get(key).at < 2000) return results.get(key).value;
      if (pending.has(key)) return pending.get(key);
      const work = (async () => {
        const map = family(p.threadId);
        if (method === 'bridge/agents/list') {
          let page = { data: [], nextCursor: null }, warning = '';
          try { page = await call('thread/list', { ancestorThreadId: p.threadId, useStateDbOnly: true, sourceKinds: ['subAgent', 'subAgentThreadSpawn', 'subAgentOther'], limit: 100, sortKey: 'created_at', ...(p.cursor ? { cursor: p.cursor } : {}) }); }
          catch (e) { warning = '이 PC 버전은 서브 에이전트 검색을 지원하지 않습니다. 대화에 기록된 작업을 표시합니다.'; }
          // Legacy hosts still expose native collab/activity entries.
          if (!page.data?.length && !map.size) { try { observe(p.threadId, (await pager.list({ threadId: p.threadId, limit: 100, sortDirection: 'desc' })).data); } catch {} }
          for (const t of page.data || []) map.set(t.id, normalize(t, map.get(t.id)));
          const agents = (p.cursor ? (page.data || []).map(t => map.get(t.id)) : [...map.values()]).filter(a => visible(a, p.threadId));
          return { agents, nextCursor: page.nextCursor || null, warning };
        }
        if (method !== 'bridge/agents/read' || typeof p.agentId !== 'string' || p.agentId.length > 100 || !map.has(p.agentId) || !visible(map.get(p.agentId), p.threadId)) throw Error('현재 세션의 서브 에이전트를 선택하세요.');
        const { thread } = await call('thread/read', { threadId: p.agentId, includeTurns: false });
        if (ensureThread) await ensureThread(p.agentId);
        const page = await pager.list({ threadId: p.agentId, limit: 60, sortDirection: 'desc' });
        const entries = page.data || [], agent = normalize(thread, map.get(p.agentId));
        const last = entries.find(e => ['reasoning', 'commandExecution', 'agentMessage', 'fileChange', 'mcpToolCall', 'dynamicToolCall'].includes(e.item?.type))?.item;
        agent.progress = last?.type || ''; agent.progressText = last?.text || last?.summary?.join('\n') || last?.command || last?.tool || '';
        agent.planText = entries.find(e => e.item?.type === 'plan')?.item.text || '';
        agent.result = entries.find(e => e.item?.type === 'agentMessage' && e.item.phase !== 'commentary')?.item.text || agent.result || '';
        map.set(p.agentId, agent);
        return { agent, entries, hasOlder: !!page.nextCursor };
      })().then(value => { results.set(key, { value, at: Date.now() }); while (results.size > 128) results.delete(results.keys().next().value); return value; }).finally(() => pending.delete(key));
      pending.set(key, work); return work;
    }
  };
}

import { settingsPath, migrateSettings } from './settings.mjs';
import { createHash, verify, randomUUID } from 'node:crypto';
import { readFile, writeFile, mkdir, rename } from 'node:fs/promises';
import { resolve } from 'node:path';
import { homedir } from 'node:os';
import { WebSocket } from 'ws';
import { activityReader, writerLockReader, serverIdle } from './activity.mjs';
import { updatePublicKey } from './update-key.mjs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

export async function installedVersion(root) {
  if (process.platform !== 'win32') return JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8')).version;
  const shell = resolve(process.env.WINDIR, 'System32/WindowsPowerShell/v1.0/powershell.exe');
  const { stdout } = await promisify(execFile)(shell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', resolve(root, 'bridge/setup-update.ps1'), '-VersionRoot', root], { windowsHide: true, timeout: 8000 });
  const version = stdout.trim(); if (!versionParts(version)) throw Error('Installed PC version unavailable'); return version;
}

export const UPDATE_FEED = 'https://raw.githubusercontent.com/lekonell/pocket-remote-distribution/main/latest.json';
const BASE = 'https://raw.githubusercontent.com/lekonell/pocket-remote-distribution/main/';
export const UPDATE_CHANNEL = 'external';
const MAX_BYTES = 40 * 1024 * 1024;
const versionParts = value => /^\d{1,5}\.\d{1,5}\.\d{1,5}$/.test(value) ? value.split('.').map(Number) : null;
export function newerVersion(value, current) {
  const next = versionParts(value), old = versionParts(current);
  if (!next || !old) throw Error('Invalid update version');
  for (let i = 0; i < 3; i++) { if (next[i] !== old[i]) return next[i] > old[i]; }
  return false;
}
export function allowedUpdatePath(name) {
  if (typeof name !== 'string' || name.includes('\\') || name.split('/').some(part => !part || part.startsWith('.')) || name.includes(':')) return false;
  if (/^(bridge|launcher|docs|app\/src\/main\/assets|node_modules\/(?:ws|qrcode-generator))\//.test(name)) return true;
  return /^(?:PocketRemoteHost\.exe|PocketRemoteSetup\.exe|[A-Z][A-Z0-9-]*\.ps1|START-(?:BRIDGE|REMOTE)\.cmd|[A-Z][A-Z0-9-]*\.md|package(?:-lock)?\.json|distribution\.json|endpoint\.example\.json)$/.test(name);
}
export function verifyRelease(envelope, publicKey = updatePublicKey) {
  const release = envelope?.release;
  if (!release || typeof envelope.signature !== 'string' || !verify(null, Buffer.from(JSON.stringify(release)), publicKey, Buffer.from(envelope.signature, 'base64'))) throw Error('Update signature is invalid');
  if ((release.channel || 'standard') !== UPDATE_CHANNEL) throw Error('Update channel differs');
  if (!versionParts(release.version) || !Number.isInteger(release.bytes) || release.bytes < 1 || release.bytes > MAX_BYTES || !/^[a-f0-9]{64}$/.test(release.sha256)) throw Error('Invalid update metadata');
  const url = new URL(release.url);
  if (!url.href.startsWith(BASE + 'releases/') || url.username || url.password || url.hash || url.search) throw Error('Untrusted update URL');
  const files = Object.entries(release.files || {});
  if (!files.length || files.length > 2000 || !release.files['package.json'] || !release.files['bridge/host.mjs'] || !release.files['UPDATE-PC.ps1']) throw Error('Incomplete update payload');
  for (const [name, file] of files) if (!allowedUpdatePath(name) || !/^[a-f0-9]{64}$/.test(file.sha256) || !Number.isInteger(file.bytes) || file.bytes < 0 || file.bytes > MAX_BYTES) throw Error('Invalid update file');
  if (files.reduce((sum, [, file]) => sum + file.bytes, 0) > 100 * 1024 * 1024) throw Error('Update extraction exceeds limit');
  return release;
}
async function limitedBody(response, limit) {
  if (!response.ok || Number(response.headers.get('content-length') || 0) > limit) throw Error('Update download failed');
  const chunks = []; let bytes = 0;
  for await (const chunk of response.body) { bytes += chunk.length; if (bytes > limit) throw Error('Update response exceeds limit'); chunks.push(chunk); }
  return Buffer.concat(chunks);
}
export async function fetchRelease(fetcher = fetch) {
  const response = await fetcher(UPDATE_FEED, { signal: AbortSignal.timeout(15000), redirect: 'error', headers: { 'Cache-Control': 'no-cache' } });
  const envelope = JSON.parse((await limitedBody(response, 512 * 1024)).toString('utf8'));
  verifyRelease(envelope); return envelope;
}
export async function stageRelease(root, envelope, fetcher = fetch, publicKey = updatePublicKey) {
  const release = verifyRelease(envelope, publicKey), directory = resolve(root, '.updates', release.version);
  await mkdir(directory, { recursive: true });
  const archive = resolve(directory, 'update.zip'), manifest = resolve(directory, 'manifest.json');
  const hash = bytes => createHash('sha256').update(bytes).digest('hex');
  let bytes = await readFile(archive).catch(() => null);
  if (!bytes || bytes.length !== release.bytes || hash(bytes) !== release.sha256) {
    const response = await downloadResponse(release.url, fetcher);
    bytes = await limitedBody(response, release.bytes);
    if (bytes.length !== release.bytes || hash(bytes) !== release.sha256) throw Error('Update archive hash differs');
    await writeFile(archive + '.partial', bytes, { mode: 0o600 }); await rename(archive + '.partial', archive);
  }
  await writeFile(manifest, JSON.stringify(envelope), { mode: 0o600 });
  return { archive, manifest, release };
}
async function downloadResponse(url, fetcher) {
  for (let count = 0; count < 4; count++) {
    const response = await fetcher(url, { signal: AbortSignal.timeout(120000), redirect: 'manual' });
    if (![301, 302, 303, 307, 308].includes(response.status)) return response;
    if (UPDATE_CHANNEL !== 'external') throw Error('Untrusted update redirect');
    const next = new URL(response.headers.get('location'), url);
    if (next.protocol !== 'https:' || next.username || next.password || next.hash || !['github.com', 'release-assets.githubusercontent.com', 'objects.githubusercontent.com'].includes(next.hostname)) throw Error('Untrusted update redirect');
    await response.body?.cancel(); url = next.href;
  }
  throw Error('Update redirect limit exceeded');
}
export async function verifyStaged(archive, manifest) {
  const release = verifyRelease(JSON.parse(await readFile(manifest, 'utf8')));
  const bytes = await readFile(archive);
  if (bytes.length !== release.bytes || createHash('sha256').update(bytes).digest('hex') !== release.sha256) throw Error('Staged update archive differs');
  return release;
}

/** Read-only authenticated probes; never resume threads or send model input. */
export async function localBridgeClient(root) {
  const config = JSON.parse((await readFile(settingsPath(root, '.endpoint.json'), 'utf8')).replace(/^\uFEFF/, ''));
  const token = (await readFile(settingsPath(root, '.remote-secret'), 'utf8')).trim();
  // A specific-interface management listener intentionally has no RPC socket.
  const bind = config.bindAddress || '127.0.0.1';
  const address = ['0.0.0.0', '::'].includes(bind) ? '127.0.0.1' : bind;
  const ws = new WebSocket('ws://' + (address.includes(':') ? '[' + address + ']' : address) + ':' + (config.localPort || 4545) + '/socket', ['codex-remote', 'auth.' + token]);
  const pending = new Map();
  const ready = new Promise((done, reject) => {
    const timer = setTimeout(() => { ws.terminate(); reject(Error('Update idle probe unavailable')); }, 5000);
    ws.once('error', () => { clearTimeout(timer); reject(Error('Update idle probe unavailable')); });
    ws.once('open', () => ws.send(JSON.stringify({ type: 'hello', epoch: '', since: 0 })));
    ws.on('message', bytes => {
      let packet; try { packet = JSON.parse(bytes); } catch { return; }
      if (packet.type === 'ready') { clearTimeout(timer); packet.online ? done() : reject(Error('Native server is offline')); }
      const message = packet.type === 'response' ? packet.message : null, request = message && pending.get(message.id);
      if (request) { clearTimeout(request.timer); pending.delete(message.id); message.error ? request.reject(Object.assign(Error(message.error.message), { code: message.error.code })) : request.done(message.result); }
    });
  });
  ws.on('error', () => {});
  ws.on('close', () => { for (const request of pending.values()) { clearTimeout(request.timer); request.reject(Error('Idle probe disconnected')); } pending.clear(); });
  try { await ready; } catch (error) { ws.terminate(); throw error; }
  return {
    rpc: (method, params = {}) => new Promise((done, reject) => {
      const id = 'c:' + randomUUID(), timer = setTimeout(() => { pending.delete(id); reject(Error('Idle probe timed out')); }, 8000);
      pending.set(id, { done, reject, timer }); ws.send(JSON.stringify({ type: 'rpc', message: { id, method, params } }));
    }), close: () => ws.terminate()
  };
}
export async function pcIdle(root, probe = localBridgeClient) {
  for (const name of ['.message-queue.json', '.goal-runners.json', '.desktop-switch.json']) {
    let value; try { value = JSON.parse((await readFile(resolve(root, name), 'utf8')).replace(/^\uFEFF/, '')); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    if (name.includes('queue') && value.some(x => ['queued', 'dispatching', 'uncertain'].includes(x.status))) return false;
    if (name.includes('goal') && (value.version === 2 ? Object.keys(value.holds || {}).length : Object.values(value).some(x => x.enabled))) return false;
    if (name.includes('switch') && ['prepared', 'waiting-for-idle', 'applying'].includes(value.status)) return false;
  }
  const client = await probe(root);
  try {
    const { active, notices } = await client.rpc('bridge/notifications/list');
    if (!Array.isArray(active) || !Array.isArray(notices)) throw Error('Idle state unavailable');
    if (active.length || notices.some(x => x.kind === 'question' && ['pending', 'answering', 'uncertain'].includes(x.status))) return false;
    const loaded = await client.rpc('thread/loaded/list');
    if (!Array.isArray(loaded.data)) throw Error('Loaded thread state unavailable');
    for (const threadId of loaded.data) {
      try { if ((await client.rpc('thread/goal/get', { threadId })).goal?.status === 'active') return false; }
      catch (error) { if (!/unknown method|unknown variant|unsupported|not supported/i.test(error.message) && error.code !== -32601) throw error; }
    }
    return await serverIdle(client, activityReader({ hasWriter: writerLockReader(resolve(process.env.CODEX_HOME || resolve(homedir(), '.codex'), 'thread-writer-locks')) }));
  } finally { client.close(); }
}
export async function saveUpdateState(root, state) {
  const path = resolve(root, '.pc-update.json');
  await writeFile(path + '.tmp', JSON.stringify({ ...state, updatedAt: new Date().toISOString() }), { mode: 0o600 }); await rename(path + '.tmp', path);
}

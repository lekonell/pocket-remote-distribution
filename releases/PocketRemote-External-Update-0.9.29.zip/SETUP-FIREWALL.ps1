﻿param([ValidateRange(1024,65535)][int]$Port, [ValidatePattern('^(LocalSubnet|[a-fA-F0-9:.,/]+)$')][string]$RemoteAddress = 'LocalSubnet')
$ErrorActionPreference = 'Stop'
try {
    $hash = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($RemoteAddress))).Replace('-','').Substring(0,12)
    $ruleName = 'PocketRemote-' + $Port + '-' + $hash
    if (!(Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -Name $ruleName -DisplayName ('Pocket Remote LAN/VPN ' + $Port) -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -RemoteAddress $RemoteAddress -Profile Any | Out-Null
    }
    exit 0
} catch { exit 1 }

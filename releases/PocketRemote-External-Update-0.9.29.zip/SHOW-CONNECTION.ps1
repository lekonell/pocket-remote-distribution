﻿. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
$ErrorActionPreference = 'Stop'
$profile = Get-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint.json') -Raw | ConvertFrom-Json
Write-Host ('Android WSS address: ' + $profile.websocketUrl)
Write-Host 'Pairing token (enter only in your personal app):'
Get-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.remote-secret')

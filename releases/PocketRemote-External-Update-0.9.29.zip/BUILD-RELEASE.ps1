﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (!$env:JAVA_HOME -or !$env:ANDROID_HOME) { throw 'Set JAVA_HOME and ANDROID_HOME for release builds.' }
$version = (Get-Content -LiteralPath 'package.json' -Raw -Encoding UTF8 | ConvertFrom-Json).version
$buildRoot = Join-Path $PSScriptRoot ('build\release-' + $version + '-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $buildRoot -Force | Out-Null
& (Join-Path $PSScriptRoot 'gradlew.bat') :app:testDebugUnitTest :app:assembleDebug --no-daemon
if ($LASTEXITCODE -ne 0) { throw 'Android build failed' }
& (Join-Path $PSScriptRoot 'package-dist.ps1')
& python (Join-Path $PSScriptRoot 'bridge\build-external.py') (Join-Path $buildRoot 'external')
if ($LASTEXITCODE -ne 0) { throw 'External build failed' }
& python (Join-Path $PSScriptRoot 'bridge\package-external.py') (Join-Path $buildRoot 'external') (Join-Path $PSScriptRoot 'dist')
if ($LASTEXITCODE -ne 0) { throw 'External packaging/audit failed' }
Write-Host ('Prepared both editions: ' + $version + '. Publish after verification and source/tag push.')

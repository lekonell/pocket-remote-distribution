﻿param([switch]$Start)
. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint.json'))) { throw 'Configure a fixed endpoint first. See ENDPOINT.md.' }
$nodePath = Join-Path $PSScriptRoot 'tools\node.exe'
if (!(Test-Path -LiteralPath $nodePath)) { $nodePath = (Get-Command node.exe).Source }
if (!$nodePath) { throw 'Node.js is required.' }
$shellCommand = Get-Command pwsh.exe -ErrorAction SilentlyContinue
$shellPath = if ($shellCommand) { $shellCommand.Source } else { Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe' }
$launcherPath = Join-Path $PSScriptRoot 'PocketRemoteHost.exe'
$existingTask = Get-ScheduledTask -TaskName PocketRemoteExternal -ErrorAction SilentlyContinue
if ($existingTask -and @($existingTask.Actions | Where-Object { $_.Execute -ne $launcherPath }).Count -and !(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'distribution.json'))) { throw 'Pocket Remote is registered from another folder. Keep that installation folder or remove its startup registration before moving.' }
if (!(Test-Path -LiteralPath $launcherPath)) { & (Join-Path $PSScriptRoot 'BUILD-LAUNCHER.ps1') }
@{ shellPath=$shellPath; nodePath=$nodePath } | ConvertTo-Json | Set-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.launcher.json') -Encoding UTF8
$account = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute $launcherPath -WorkingDirectory $PSScriptRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $account
$principal = New-ScheduledTaskPrincipal -UserId $account -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 99 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName 'PocketRemoteExternal' -Description 'Codex Pocket Remote: silent background bridge; starts at Windows sign-in without a console or taskbar window.' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Enable-ScheduledTask -TaskName 'PocketRemoteExternal' | Out-Null
if ($Start) { Start-ScheduledTask -TaskName 'PocketRemoteExternal' }
Write-Host 'Installed: silent background startup after Windows sign-in; no taskbar window.'

﻿$ErrorActionPreference = 'Stop'
$compilerPaths = @(
    (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
    (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe')
)
$compiler = $compilerPaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (!$compiler) { throw 'The Windows .NET Framework C# compiler is required.' }
$source = Join-Path $PSScriptRoot 'launcher\RemoteHostLauncher.cs'
$output = Join-Path $PSScriptRoot 'build\launchers'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$target = Join-Path $output 'PocketRemoteHost.exe'
& $compiler /nologo /target:winexe /optimize+ /platform:anycpu /reference:System.Web.Extensions.dll /reference:System.Windows.Forms.dll /reference:System.Drawing.dll ('/out:' + $target) $source
if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $target)) { throw 'Background launcher build failed.' }
Write-Host 'Built PocketRemoteHost.exe (Windows GUI executable; no console window).'
$sharedTarget = Join-Path $output 'PocketRemoteSharedHost.exe'
& $compiler /nologo /target:winexe /optimize+ /platform:anycpu /reference:System.Web.Extensions.dll /reference:System.Windows.Forms.dll /reference:System.Drawing.dll ('/out:' + $sharedTarget) $source
if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $sharedTarget)) { throw 'Shared server launcher build failed.' }
Write-Host 'Built PocketRemoteSharedHost.exe (independent background App Server).'
$setupTarget = Join-Path $output 'PocketRemoteSetup.exe'
& $compiler /nologo /target:winexe /optimize+ /platform:anycpu /reference:System.Web.Extensions.dll /reference:System.Windows.Forms.dll /reference:System.Drawing.dll ('/out:' + $setupTarget) (Join-Path $PSScriptRoot 'launcher\RemoteSetupWizard.cs')
if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $setupTarget)) { throw 'Setup wizard build failed.' }
Write-Host 'Built PocketRemoteSetup.exe (PC setup GUI wizard).'
foreach ($name in @('PocketRemoteHost.exe','PocketRemoteSharedHost.exe','PocketRemoteSetup.exe')) {
    try { Copy-Item -LiteralPath (Join-Path $output $name) -Destination (Join-Path $PSScriptRoot $name) -Force -ErrorAction Stop }
    catch {
        $running = Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($name)) -ErrorAction SilentlyContinue | Where-Object Path -eq (Join-Path $PSScriptRoot $name)
        if (!$running) { throw }
        Write-Host ($name + ' is running; the fresh build is in build\launchers and will be packaged without interrupting it.')
    }
}

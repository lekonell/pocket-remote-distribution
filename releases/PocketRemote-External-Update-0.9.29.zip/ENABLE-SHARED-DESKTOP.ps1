﻿param([ValidateRange(1024,65535)][int]$Port = 4546, [ValidateRange(1024,65535)][int]$DesktopProxyPort = 4549, [string]$WatchedThread = $env:CODEX_THREAD_ID)
. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$existingTask = Get-ScheduledTask -TaskName PocketRemoteExternalSharedServer -ErrorAction SilentlyContinue
if ($existingTask -and @($existingTask.Actions | Where-Object { $_.Execute -ne (Join-Path $root 'PocketRemoteSharedHost.exe') }).Count) { throw 'A shared server is registered from another installation folder. Keep that folder or restore its configuration before moving.' }
$recordPath = Join-Path $root '.desktop-switch.json'
if (Test-Path -LiteralPath $recordPath) {
    $previous = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
    if ($previous.status -eq 'waiting-for-idle') {
        $worker = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $previous.workerPid) -ErrorAction SilentlyContinue
        if ($worker -and $worker.CommandLine.Contains((Join-Path $root 'bridge\desktop-switch.mjs'))) { Write-Host 'A shared desktop transition is already waiting for idle.'; return }
    }
}
$package = Get-AppxPackage -Name 'OpenAI.Codex' | Select-Object -First 1
if (!$package) { throw 'The official Codex desktop app must be installed for this Windows user.' }
$desktopPath = Join-Path $package.InstallLocation 'app\ChatGPT.exe'
if (!(Test-Path -LiteralPath $desktopPath)) { throw 'The desktop executable was not found.' }
$nodePath = (Get-Command node.exe).Source
if (!$nodePath) { throw 'Node.js is required.' }
$shellPath = (Get-Process -Id $PID).Path
@{ shellPath=$shellPath; nodePath=$nodePath } | ConvertTo-Json | Set-Content -LiteralPath (Get-PocketSetting $root '.launcher.json') -Encoding UTF8
if (!(Test-Path -LiteralPath (Join-Path $root 'PocketRemoteSharedHost.exe'))) { & (Join-Path $root 'BUILD-LAUNCHER.ps1') }
$url = 'ws://127.0.0.1:' + $Port
$sharedPath = Get-PocketSetting $root '.shared-server.json'
$config = if (Test-Path -LiteralPath $sharedPath) { Get-Content -LiteralPath $sharedPath -Raw | ConvertFrom-Json } else { $null }
if ($config -and $config.url -ne $url) { throw 'A shared server is already configured on another port. Restore it before changing ports.' }
if ($DesktopProxyPort -eq $Port -or $DesktopProxyPort -eq 4545) { throw 'The desktop proxy needs a separate loopback port.' }
$desktopUrl = 'ws://127.0.0.1:' + $DesktopProxyPort
$wasEnabled = $config -and $config.enabled
if ($wasEnabled -and $config.desktopUrl -eq $desktopUrl -and [Environment]::GetEnvironmentVariable('CODEX_APP_SERVER_WS_URL','User') -eq $desktopUrl) { Write-Host 'Shared desktop proxy mode is already enabled.'; return }
@{ prepared=$true; enabled=[bool]$wasEnabled; url=$url; desktopUrl=$desktopUrl } | ConvertTo-Json | Set-Content -LiteralPath $sharedPath -Encoding UTF8
$account = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute (Join-Path $root 'PocketRemoteSharedHost.exe') -WorkingDirectory $root
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $account
$principal = New-ScheduledTaskPrincipal -UserId $account -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 99 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName 'PocketRemoteExternalSharedServer' -Description 'Independent loopback App Server shared by the official Codex desktop and Pocket Remote.' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
if (!$wasEnabled) { Start-ScheduledTask -TaskName 'PocketRemoteExternalSharedServer' }
$runtime = $null
for ($i=0; $i -lt 100; $i++) {
    Start-Sleep -Milliseconds 200
    try { $runtime = Get-Content -LiteralPath (Join-Path $root '.shared-server-runtime.json') -Raw | ConvertFrom-Json } catch { continue }
    if ($runtime.status -eq 'error') { throw $runtime.error }
    if ($runtime.status -eq 'ready' -and $runtime.url -eq $url) { break }
}
if (!$runtime -or $runtime.status -ne 'ready') { throw 'Shared server did not become ready. See .shared-server-runtime.json.' }
$desktop = @(Get-CimInstance Win32_Process -Filter "Name = 'ChatGPT.exe'" | Where-Object { $_.ExecutablePath -eq $desktopPath -and $_.CommandLine -notmatch '--type=' })
if ($desktop.Count -gt 1) { throw 'More than one main desktop process was found; close the duplicate app before switching.' }
$hostPid = if (Test-Path -LiteralPath (Join-Path $root '.host.pid')) { [int](Get-Content -LiteralPath (Join-Path $root '.host.pid') -Raw) } else { 0 }
$bridge = @(Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" | Where-Object { $_.ParentProcessId -eq $hostPid -and $_.CommandLine.Contains((Join-Path $root 'bridge/server.mjs')) })
if ($bridge.Count -gt 1) { throw 'Multiple bridges were found.' }
$request = @{ status='prepared'; requestedAt=[DateTime]::UtcNow.ToString('o'); desktopPath=$desktopPath; desktopPid=if($desktop.Count){$desktop[0].ProcessId}else{0}; hostPid=$hostPid; bridgePid=if($bridge.Count){$bridge[0].ProcessId}else{0}; watchedThreads=@(); shellPath=$shellPath; workerPid=0 }
if ($WatchedThread) { $request.watchedThreads=@($WatchedThread) }
$request | ConvertTo-Json | Set-Content -LiteralPath $recordPath -Encoding UTF8
$worker = Start-Process -FilePath $nodePath -ArgumentList ('"' + (Join-Path $root 'bridge\desktop-switch.mjs') + '"') -WorkingDirectory $root -WindowStyle Hidden -PassThru
Write-Host ('Shared server ready. Background transition worker PID ' + $worker.Id + ' will restart the desktop and bridge after all work is idle.')

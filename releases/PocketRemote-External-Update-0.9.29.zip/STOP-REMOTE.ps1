﻿$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'bridge\setup-host.ps1')
$result = Stop-SetupHost $PSScriptRoot -IncludeUpdater
if ($result.taskEnabled) { Enable-ScheduledTask -TaskName 'PocketRemoteExternal' | Out-Null }
Write-Host 'Stopped this installation bridge, host, tunnel and updater. Login startup preference is preserved.'

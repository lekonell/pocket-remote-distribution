﻿param([ValidateSet('ngrok','cloudflare')][string]$Provider = 'ngrok')
. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
$ErrorActionPreference = 'Stop'
$publicUrl = (Read-Host 'Fixed HTTPS address, for example https://your-domain.ngrok-free.app').Trim().TrimEnd('/')
$uri = [Uri]$publicUrl
if ($uri.Scheme -ne 'https' -or !$uri.Host -or $uri.UserInfo) { throw 'A valid HTTPS URL is required.' }
$secret = Read-Host 'Service tunnel token (input is hidden)' -AsSecureString
$secret | ConvertFrom-SecureString | Set-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint-secret')
@{ provider=$Provider; localPort=4545; publicUrl=$publicUrl; websocketUrl=($publicUrl -replace '^https:', 'wss:') + '/socket' } | ConvertTo-Json | Set-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint.json')
Write-Host 'Saved. The tunnel credential is protected with Windows DPAPI for this user.'

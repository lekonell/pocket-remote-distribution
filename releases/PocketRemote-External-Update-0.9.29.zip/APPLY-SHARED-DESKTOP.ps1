﻿. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
# Invoked by desktop-switch.mjs only after checking all conversation activity.
$ErrorActionPreference = 'Stop'
$request = Get-Content -LiteralPath (Join-Path $PSScriptRoot '.desktop-switch.json') -Raw | ConvertFrom-Json
if ($request.status -ne 'applying') { throw 'Use ENABLE-SHARED-DESKTOP.ps1 to schedule a safe transition.' }
$restartDesktop = $request.skipDesktopRestart -ne $true
if (!$restartDesktop -and $request.action -eq 'restore') { throw 'Restoring requires restarting the official desktop.' }
if ($restartDesktop) {
    $package = Get-AppxPackage -Name 'OpenAI.Codex' | Where-Object { (Join-Path $_.InstallLocation 'app\ChatGPT.exe') -eq $request.desktopPath } | Select-Object -First 1
    if (!$package) { throw 'The requested official desktop package is not installed.' }
    $manifest = $package | Get-AppxPackageManifest
    $application = $manifest.Package.Applications.Application | Where-Object { $_.Executable.Replace('/','\') -eq 'app\ChatGPT.exe' } | Select-Object -First 1
    if (!$application) { throw 'The official desktop package entry point was not found.' }
    $desktopAppId = $package.PackageFamilyName + '!' + $application.Id
    if (!('PocketDesktopActivation' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
[ComImport, Guid("2E941141-7F97-4756-BA1D-9DECDE894A3D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface PocketActivationManager {
    [PreserveSig] int ActivateApplication([MarshalAs(UnmanagedType.LPWStr)] string appId, [MarshalAs(UnmanagedType.LPWStr)] string arguments, uint options, out uint pid);
}
public static class PocketDesktopActivation {
    [DllImport("ole32.dll")] private static extern int CoCreateInstance(ref Guid clsid, IntPtr outer, uint context, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out PocketActivationManager manager);
    [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)] private static extern IntPtr SendMessageTimeout(IntPtr window, uint message, UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);
    public static void RefreshEnvironment() {
        UIntPtr result;
        SendMessageTimeout(new IntPtr(0xffff), 0x1a, UIntPtr.Zero, "Environment", 2, 2000, out result);
    }
    public static uint Launch(string appId) {
        Guid clsid=new Guid("45BA127D-10A8-46EA-8AB7-56EA9078943C"), iid=new Guid("2E941141-7F97-4756-BA1D-9DECDE894A3D");
        PocketActivationManager manager;
        Marshal.ThrowExceptionForHR(CoCreateInstance(ref clsid, IntPtr.Zero, 4, ref iid, out manager));
        try {
            uint pid;
            Marshal.ThrowExceptionForHR(manager.ActivateApplication(appId, null, 2, out pid));
            return pid;
        } finally { Marshal.ReleaseComObject(manager); }
    }
}
'@
    }
}
$desktop = $null; $bridge = $null; $children = @()
if ($request.desktopPid) {
    $desktop = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $request.desktopPid)
    if (!$desktop -or $desktop.ExecutablePath -ne $request.desktopPath -or $desktop.CommandLine -match '--type=') { throw 'Desktop identity changed. Schedule the transition again.' }
}
if ($request.bridgePid) {
    $bridge = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $request.bridgePid)
    if (!$bridge -or $bridge.Name -ne 'node.exe' -or $bridge.ParentProcessId -ne $request.hostPid -or !$bridge.CommandLine.Contains((Join-Path $PSScriptRoot 'bridge/server.mjs'))) { throw 'Bridge identity changed. Schedule the transition again.' }
    $children = @(Get-CimInstance Win32_Process -Filter ('ParentProcessId = ' + $request.bridgePid) | Where-Object Name -eq 'codex.exe')
}
$backupPath = Get-PocketSetting $PSScriptRoot '.desktop-shared-backup'
if (!(Test-Path -LiteralPath $backupPath)) {
    $backup = @{ websocket=[Environment]::GetEnvironmentVariable('CODEX_APP_SERVER_WS_URL','User'); forceCli=[Environment]::GetEnvironmentVariable('CODEX_APP_SERVER_FORCE_CLI','User') } | ConvertTo-Json -Compress
    ConvertTo-SecureString -String $backup -AsPlainText -Force | ConvertFrom-SecureString | Set-Content -LiteralPath $backupPath -Encoding UTF8
}
$configPath = Get-PocketSetting $PSScriptRoot '.shared-server.json'
$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
if ($config.url -notmatch '^ws://127\.0\.0\.1:[0-9]+$') { throw 'Invalid shared endpoint.' }
$desktopUrl = if ($config.desktopUrl) { $config.desktopUrl } else { $config.url }
if ($desktopUrl -notmatch '^ws://127\.0\.0\.1:[0-9]+$') { throw 'Invalid desktop proxy endpoint.' }
$restoring = $request.action -eq 'restore'
if ($restoring) {
    $protected = Get-Content -LiteralPath $backupPath -Raw | ConvertTo-SecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($protected)
    try { $previous = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) | ConvertFrom-Json }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
    [Environment]::SetEnvironmentVariable('CODEX_APP_SERVER_WS_URL',$previous.websocket,'User')
    [Environment]::SetEnvironmentVariable('CODEX_APP_SERVER_FORCE_CLI',$previous.forceCli,'User')
    $env:CODEX_APP_SERVER_WS_URL = $previous.websocket
    $env:CODEX_APP_SERVER_FORCE_CLI = $previous.forceCli
    $config.enabled = $false
    $config.prepared = $false
} else {
    [Environment]::SetEnvironmentVariable('CODEX_APP_SERVER_WS_URL',$desktopUrl,'User')
    [Environment]::SetEnvironmentVariable('CODEX_APP_SERVER_FORCE_CLI',$null,'User')
    $env:CODEX_APP_SERVER_WS_URL = $desktopUrl
    Remove-Item Env:CODEX_APP_SERVER_FORCE_CLI -ErrorAction SilentlyContinue
    $config.enabled = $true
}
$config | ConvertTo-Json | Set-Content -LiteralPath $configPath -Encoding UTF8
if ($restartDesktop) { [PocketDesktopActivation]::RefreshEnvironment() }
if ($desktop -and $restartDesktop) {
    & taskkill.exe /PID $desktop.ProcessId /T /F | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'The idle desktop could not be stopped.' }
}
if ($bridge) {
    Stop-Process -Id $bridge.ProcessId -ErrorAction Stop
    foreach ($child in $children) {
        $current = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $child.ProcessId)
        if ($current -and $current.ExecutablePath -eq $child.ExecutablePath -and $current.CreationDate -eq $child.CreationDate) { & taskkill.exe /PID $child.ProcessId /T /F | Out-Null }
    }
}
if ($restartDesktop) {
    $startedDesktopPid = [PocketDesktopActivation]::Launch($desktopAppId)
    Write-Host ('Official desktop package activated; PID ' + $startedDesktopPid + '.')
}
if ($restoring) {
    Disable-ScheduledTask -TaskName 'PocketRemoteExternalSharedServer' -ErrorAction SilentlyContinue | Out-Null
    $runtime = Get-Content -LiteralPath (Join-Path $PSScriptRoot '.shared-server-runtime.json') -Raw | ConvertFrom-Json
    $manager = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $runtime.managerPid)
    if ($manager -and $manager.Name -eq 'node.exe' -and $manager.CommandLine.Contains((Join-Path $PSScriptRoot 'bridge\shared-server.mjs'))) {
        & taskkill.exe /PID $manager.ProcessId /T /F | Out-Null
    }
    Stop-ScheduledTask -TaskName 'PocketRemoteExternalSharedServer' -ErrorAction SilentlyContinue
}
Write-Host 'Desktop configuration applied.'

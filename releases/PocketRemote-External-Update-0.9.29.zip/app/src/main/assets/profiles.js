// Each page owns one immutable desktop scope. Switching reloads the bundled
// page so an async operation can never continue against another PC's socket.
const connectionStore = (() => {
  const read = key => { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } };
  const write = (key,value) => { try { localStorage.setItem(key,JSON.stringify(value)); return true; } catch { return false; } };
  const globals = new Set(['remote.theme','remote.notifications']);
  const scope = (id,key) => globals.has(key) ? key : 'remote.p.'+id+'.'+key.replace(/^remote\./,'');
  const tokenKey = id => 'remote.profileToken.'+id;
  const getToken = id => {
    if (!id) return '';
    if (window.RemoteSecrets?.getProfileToken) return window.RemoteSecrets.getProfileToken(id) || (id==='desktop-default' ? window.RemoteSecrets.getToken() || read('remote.token') || '' : '');
    return read(tokenKey(id)) || (id==='desktop-default' ? window.RemoteSecrets?.getToken() || read('remote.token') || '' : '');
  };
  const putToken = (id,token) => window.RemoteSecrets?.setProfileToken ? window.RemoteSecrets.setProfileToken(id,token) : !window.RemoteSecrets && write(tokenKey(id),token);
  const eraseToken = id => {
    if (window.RemoteSecrets?.removeProfileToken && !window.RemoteSecrets.removeProfileToken(id)) return false;
    localStorage.removeItem(tokenKey(id)); return true;
  };
  const stored = read('remote.profiles');
  let profiles = Array.isArray(stored) ? stored.filter(p=>p&&/^[A-Za-z0-9_-]{1,100}$/.test(p.id)&&typeof p.url==='string').slice(0,8).map(p=>({id:p.id,name:String(p.name||'Desktop').slice(0,48),url:p.url,cwd:String(p.cwd||''),lastThread:String(p.lastThread||''),lastUsed:p.lastUsed||0})) : null;
  let error='',migrationAllowed=true;
  if (!profiles) {
    const legacy=window.RemoteSecrets?.getToken()||read('remote.token')||'';
    const legacyUrl=read('remote.url'),legacyCwd=read('remote.cwd');
    const hasLegacy=!!(legacy||(typeof legacyUrl==='string'&&legacyUrl)||read('remote.currentId'));
    profiles=hasLegacy?[{id:'desktop-default',name:'내 PC',url:typeof legacyUrl==='string'?legacyUrl:'',cwd:typeof legacyCwd==='string'?legacyCwd:'',lastThread:'',lastUsed:0}]:[];
    const tokenSaved=!legacy||putToken('desktop-default',legacy);
    if (!(tokenSaved && write('remote.profiles',profiles))) {
      migrationAllowed=false;error='기존 연결 정보를 안전하게 저장하지 못했습니다. 설정에서 토큰을 다시 저장해 주세요.';
    }
  }
  // Retry leftover legacy keys on every launch. A temporary quota failure must
  // never strand a draft or a durable message outside its desktop namespace.
  if(migrationAllowed&&profiles.some(p=>p.id==='desktop-default')) {
    const legacy=window.RemoteSecrets?.getToken()||read('remote.token')||'';
    const existing=window.RemoteSecrets?.getProfileToken?window.RemoteSecrets.getProfileToken('desktop-default'):read(tokenKey('desktop-default'));
    if(!legacy||existing||putToken('desktop-default',legacy)) {
      for (const key of Object.keys(localStorage)) {
        if (!key.startsWith('remote.')||globals.has(key)||['remote.profiles','remote.activeProfile','remote.token'].includes(key)||key.startsWith('remote.p.')||key.startsWith('remote.profileToken.')) continue;
        const value=localStorage.getItem(key);
        try { if(localStorage.getItem(scope('desktop-default',key))===null)localStorage.setItem(scope('desktop-default',key),value);localStorage.removeItem(key); } catch { error='기존 PC 설정을 옮길 저장 공간이 부족합니다. 남은 정보는 다음 실행에 다시 옮깁니다.'; }
      }
      localStorage.removeItem('remote.token');
      if (legacy && window.RemoteSecrets?.setProfileToken) window.RemoteSecrets.setToken('');
    } else error='기존 페어링 토큰을 옮기지 못했습니다. 설정에서 다시 저장해 주세요.';
  }
  const chosen=read('remote.activeProfile');
  const activeId=profiles.some(p=>p.id===chosen)?chosen:profiles[0]?.id||'';
  write('remote.activeProfile',activeId);
  return {read,write,scope,getToken,putToken,eraseToken,globals,profiles,activeId,error,active:()=>profiles.find(p=>p.id===activeId)||null,
    replace(next){if(!write('remote.profiles',next))throw new Error('저장 공간이 부족해 연결 정보를 저장하지 못했습니다.');profiles=next;this.profiles=next;},
    prune(id){for(const key of Object.keys(localStorage))if(key.startsWith('remote.p.'+id+'.'))localStorage.removeItem(key);}
  };
})();
function scopedKey(key) { return connectionStore.scope(connectionStore.activeId,key); }
function scopedSaved(key) { const value=connectionStore.read(scopedKey(key));return value===null&&connectionStore.activeId==='desktop-default'?connectionStore.read(key):value; }
function removeLegacySaved(key) { if(connectionStore.activeId==='desktop-default'&&!connectionStore.globals.has(key))localStorage.removeItem(key); }
function activeConnectionName() { return connectionStore.active()?.name || '연결 대상 선택'; }
function activeConnectionToken() { return connectionStore.getToken(connectionStore.activeId); }
function connectionHost(value) { try{return new URL(value).host;}catch{return '연결 주소 확인 필요';} }
function connectionAddressCode(value) { return ''; }
function connectionEndpoint(value) {
  let url; try { url = new URL(value.trim()); } catch { throw Error('PC의 QR코드를 스캔하거나 PC 마법사의 연결 주소를 입력하세요.'); }
  if (!['ws:', 'wss:'].includes(url.protocol) || url.username || url.password || url.hash || !url.pathname.endsWith('/socket')) throw Error('PC 마법사에 표시된 WS·WSS 주소를 확인하세요.');
  return url.toString();
}
function redeemPairingCode(url, code) {
  if (!/^[A-HJ-NP-Z2-9]{8}$/.test(code.toUpperCase())) return Promise.reject(Error('PC에서 발급한 8자리 코드를 입력하세요.'));
  return new Promise((resolve, reject) => {
    let socket, finished = false;
    const finish = (error, result) => { if (finished) return; finished = true; clearTimeout(timer); socket?.close(); error ? reject(error) : resolve(result); };
    const timer = setTimeout(() => finish(Error('PC에 연결하지 못했습니다. 주소와 LAN·VPN·터널 연결을 확인하세요.')), 12000);
    try {
      socket = new WebSocket(url, ['codex-pair']);
      socket.onopen = () => socket.send(JSON.stringify({ type: 'pair', code: code.toUpperCase() }));
      socket.onmessage = event => { try { const result = JSON.parse(event.data); if (result.type === 'paired' && /^[A-Za-z0-9_-]{43,128}$/.test(result.token || '')) finish(null, result); else finish(Error(result.message || 'PC의 페어링 응답을 확인하세요.')); } catch { finish(Error('PC의 페어링 응답을 확인하세요.')); } };
      socket.onerror = socket.onclose = () => finish(Error('페어링에 실패했습니다. PC 브리지를 업데이트하고 새 코드를 발급해 주세요.'));
    } catch (e) { finish(e); }
  });
}
function connectionTransfersBusy() { return feature.attachments.some(a=>a.uploading)||v03.downloads.size>0; }
function saveConnectionView() {
  if(state.currentId){
    if(!persist('remote.draft.'+state.currentId,$('messageInput').value))throw new Error('입력을 저장하지 못했습니다. 저장 공간을 확인해 주세요.');
    saveAssets(); saveQuestionDrafts();
    persist('remote.checkpoint',{epoch:state.epoch,seq:state.seq,threadId:state.currentId,items:cachedItems(state.items)});
  }
  saveOutbox(); saveQueue();
  const current=connectionStore.active();
  if(current)connectionStore.replace(connectionStore.profiles.map(p=>p.id===current.id?{...p,lastThread:state.current?.name||state.current?.preview||p.lastThread,lastUsed:Date.now()}:p));
}
function leaveConnectionPage() {
  state.leaving=true; state.online=false;
  clearTimeout(reconnectTimer);clearTimeout(refreshTimer);loadToken++;
  const ws=state.socket;state.socket=null;ws?.close();
  for(const pending of state.pending.values()){clearTimeout(pending.timer);pending.reject(Object.assign(new Error('연결 대상 전환 중'),{profileSwitch:true}));}
  state.pending.clear();
  document.documentElement.classList.add('switching-connection');
  location.reload();
}
function switchConnection(id,threadId='') {
  if(!connectionStore.profiles.some(p=>p.id===id))throw new Error('저장된 연결 대상을 찾지 못했습니다.');
  if(id===connectionStore.activeId){closePicker();if(threadId)openThread(threadId);return;}
  if(connectionTransfersBusy())throw new Error('파일 전송이 끝나거나 첨부를 제거한 뒤 연결 대상을 전환해 주세요.');
  saveConnectionView();
  if(threadId&&!connectionStore.write(connectionStore.scope(id,'remote.currentId'),threadId))throw new Error('대화 이동 정보를 저장하지 못했습니다.');
  if(!connectionStore.write('remote.activeProfile',id))throw new Error('연결 대상 선택을 저장하지 못했습니다.');
  leaveConnectionPage();
}
function renderConnectionChrome() {
  const profile=connectionStore.active(),name=activeConnectionName();
  $('messageInput').placeholder=profile?name+'에서 작업':'연결 대상을 추가하세요';
  $('sidebarHost').textContent=name;
  const button=$('connectionButton');button.replaceChildren();
  const avatar=el('span','▱','connection-avatar');avatar.setAttribute('aria-hidden','true');
  const body=el('span',undefined,'connection-body');body.append(el('strong',name),el('small',profile?'PC 전환 · '+connectionStore.profiles.length+'개 연결':'PC 연결 추가'));
  const chevron=el('span','⌄','connection-chevron');chevron.setAttribute('aria-hidden','true');button.append(avatar,body,chevron);
  $('savedConnections').textContent=connectionStore.profiles.length+'개 PC · '+name;
}
function connectionPicker() {
  const root=picker('연결 대상','PC별 대화와 설정을 이어서 사용하세요.'),list=el('div',undefined,'connection-list');
  root.append(list);
  for(const p of connectionStore.profiles){
    const selected=p.id===connectionStore.activeId,row=el('div',undefined,'connection-row'+(selected?' selected':''));
    const main=action('',()=>switchConnection(p.id),'connection-select');main.setAttribute('aria-label',p.name+' 연결');main.setAttribute('aria-current',selected?'true':'false');
    const body=el('span',undefined,'connection-row-body'),pending=(connectionStore.read(connectionStore.scope(p.id,'remote.outbox'))||[]).filter(e=>['queued','sending','failed','uncertain'].includes(e.status)).length;
    body.append(el('strong',p.name),el('small',pending?'미전송 메시지 '+pending+'개':p.lastThread?'최근 대화 · '+p.lastThread:connectionHost(p.url)));
    main.append(el('span','▱','connection-avatar'),body,el('span',selected?(state.online?'현재 연결':'선택됨'):'','connection-badge'));
    const edit=action('⋯',()=>connectionEditor(p.id),'connection-edit icon');edit.setAttribute('aria-label',p.name+' 연결 편집');row.append(main,edit);list.append(row);
  }
  root.append(action('＋ 연결 대상 추가',()=>connectionEditor(),'primary full'));
  if(connectionTransfersBusy())root.append(el('p','파일 전송이 끝나면 다른 PC로 전환할 수 있습니다.','connection-note'));
  if(!connectionStore.profiles.length)root.prepend(el('p','PC 설정 마법사에 표시된 주소 코드 또는 연결 주소와 휴대폰 인증용 페어링 코드로 연결 대상을 추가하세요.','connection-note'));
}
function syncHostDefaults(cwd) {
  if(typeof cwd!=='string'||!cwd.trim()||cwd.length>1000||/[\x00-\x1f]/.test(cwd))return;
  state.defaultCwd=cwd;persist('remote.defaultCwd',cwd);
  if(!state.currentId)state.cwd=cwd;
  const profile=connectionStore.active();
  if(profile&&profile.cwd!==cwd){try{connectionStore.replace(connectionStore.profiles.map(p=>p.id===profile.id?{...p,cwd}:p));}catch{}}
}
function connectionEditor(id='') {
  const profile=connectionStore.profiles.find(p=>p.id===id),savedAuth=!!(profile&&connectionStore.getToken(profile.id)),root=picker(profile?'연결 편집':'연결 대상 추가',savedAuth?'PC 주소를 수정해도 저장된 휴대폰 인증을 그대로 사용합니다.':'PC 주소를 입력한 뒤 휴대폰 인증용 페어링 코드를 입력하세요.');
  const form=el('form',undefined,'connection-editor');root.append(form);
  if(window.RemoteNative?.scanPairing){const scan=action('QR코드 스캔으로 연결',()=>window.RemoteNative.scanPairing(),'primary full');scan.type='button';form.append(scan);}
  function field(label,fieldId,value,placeholder,type='text',parent=form){
    const wrap=el('label',label),input=el('input');input.id=fieldId;input.name=fieldId;input.type=type;input.value=value;input.placeholder=placeholder;input.spellcheck=false;input.autocomplete='off';wrap.htmlFor=fieldId;wrap.append(input);parent.append(wrap);return input;
  }
  const name=field('PC 이름','connectionName',profile?.name||'','예: 집 PC · 업무 노트북');name.maxLength=48;
  const url=field('PC 연결 주소','connectionUrl',connectionAddressCode(profile?.url)||profile?.url||'','예: ws://192.168.0.10:4545/socket');url.inputMode='text';url.autocapitalize='none';url.maxLength=500;
  form.append(el('p','PC의 QR코드를 스캔하면 주소와 인증 코드가 자동으로 입력됩니다. 직접 입력할 때는 PC 마법사에 표시된 전체 주소와 8자리 인증 코드를 입력하세요.','connection-note'));
  if(savedAuth)form.append(el('p','✓ 기존 휴대폰 인증 사용 · 주소 수정에는 새 페어링 코드가 필요하지 않습니다.','connection-auth-saved'));
  const authSection=el(savedAuth?'details':'section',undefined,'connection-auth'),authBody=el('div',undefined,'connection-auth-body');
  authSection.append(el(savedAuth?'summary':'strong',savedAuth?'휴대폰 인증 다시 설정':'휴대폰 인증'),authBody);form.append(authSection);
  const token=field('휴대폰 인증용 페어링 코드','connectionToken','','PC에서 새로 발급한 8자리 코드','text',authBody);token.maxLength=8;token.autocapitalize='characters';token.setAttribute('aria-label','휴대폰 인증용 페어링 코드');
  authBody.append(el('p','PC가 발급한 휴대폰 인증용 코드입니다. PC에서 발급 후 5분 안에 입력하세요.'+(savedAuth?' 비워 두면 기존 인증을 사용합니다.':''),'connection-note'));
  const advancedLabel=el('label','기존 긴 토큰으로 연결 (고급)','connection-option'),advanced=el('input');advanced.type='checkbox';advancedLabel.prepend(advanced);authBody.append(advancedLabel);
  advanced.onchange=()=>{token.type=advanced.checked?'password':'text';token.maxLength=advanced.checked?128:8;token.value='';const label=advanced.checked?'기존 페어링 토큰':'휴대폰 인증용 페어링 코드';token.parentNode.firstChild.textContent=label;token.setAttribute('aria-label',label);};
  if(savedAuth)authSection.addEventListener('toggle',()=>{if(!authSection.open){advanced.checked=false;advanced.onchange();redeemed=null;}});
  const plainLabel=el('label','신뢰하는 내부망·VPN에서 암호화되지 않은 WS 사용','connection-option'),plain=el('input');plain.type='checkbox';plainLabel.prepend(plain);plainLabel.classList.add('hidden');form.append(plainLabel);
  const plainNeeded=()=>{try{const u=new URL(url.value);return u.protocol==='ws:'&&!['localhost','127.0.0.1','[::1]'].includes(u.hostname);}catch{return false;}};
  url.addEventListener('input',()=>{plainLabel.classList.toggle('hidden',!plainNeeded());plain.checked=false;});plainLabel.classList.toggle('hidden',!plainNeeded());
  form.append(el('p','기본 작업 폴더는 연결된 PC의 설정을 자동으로 가져옵니다. PC 설정 마법사에서 변경할 수 있습니다.','connection-note'));
  form.append(el('p','주소나 토큰을 바꾸면 대화와 설정을 새 연결로 분리합니다. 미전송 메시지는 먼저 처리하거나 취소해 주세요.','connection-note'));
  const error=el('p','','inline-error hidden');error.setAttribute('role','alert');
  const save=el('button',profile?'변경 저장':'추가하고 연결','primary full');save.id='saveConnection';save.type='submit';form.append(error,save);
  let redeemed=null;
  form.onsubmit=async event=>{event.preventDefault();save.disabled=true;error.classList.add('hidden');try{
    const endpoint=connectionEndpoint(url.value),authOpen=!savedAuth||authSection.open,code=authOpen?token.value.trim():'';
    if(plainNeeded()&&!plain.checked)throw Error('외부 인터넷은 WSS를 사용하세요. 내부망·VPN에서 WS를 쓰려면 위 항목을 선택하세요.');
    let auth=code,defaultCwd=endpoint===profile?.url?profile.cwd||'':'';
    if(!advanced.checked&&code){
      if(code.toUpperCase()===connectionAddressCode(endpoint))throw Error('이 코드는 PC 주소 코드입니다. 위의 「PC 연결 주소」 칸에 입력하세요. 페어링 칸에는 PC에서 별도로 발급한 인증용 코드를 입력합니다.');
      const key=endpoint+'\0'+code.toUpperCase();
      if(redeemed?.key!==key)redeemed={key,result:await redeemPairingCode(endpoint,code)};
      auth=redeemed.result.token;defaultCwd=redeemed.result.cwd||'';if(!name.value.trim())name.value=redeemed.result.name||'Desktop';
    }
    if(!savedAuth&&!auth)throw Error('PC에서 발급한 휴대폰 인증용 페어링 코드를 입력하세요. PC 주소가 아닌 인증 코드를 입력하세요.');
    saveConnectionProfile(profile,{name:name.value.trim(),url:endpoint,token:auth,cwd:defaultCwd});
  }catch(e){error.textContent=e.message;error.classList.remove('hidden');}finally{save.disabled=false;}};
  if(profile)root.append(action('연결 삭제',()=>confirmConnectionDelete(profile),'ghost full danger'));
  root.append(action('취소',connectionPicker,'ghost full'));
}
function parsePairingLink(value) {
  if(typeof value!=='string'||value.length>4096)throw Error('PC 마법사의 연결 QR코드를 스캔하세요.');
  const link=new URL(value);
  if(link.protocol!=='pocketremote:'||link.hostname!=='pair'||!['','/'].includes(link.pathname)||link.username||link.password||link.hash||[...link.searchParams.keys()].some(key=>!['url','code','name'].includes(key))||['url','code','name'].some(key=>link.searchParams.getAll(key).length>1))throw Error('PC 마법사의 연결 QR코드를 스캔하세요.');
  const url=connectionEndpoint(link.searchParams.get('url')||''),code=link.searchParams.get('code')||'',name=link.searchParams.get('name')||'내 PC';
  if(!/^[A-HJ-NP-Z2-9]{8}$/.test(code)||name.length>48||/[\x00-\x1f]/.test(name))throw Error('연결 코드가 올바르지 않습니다. PC에서 새 QR코드를 발급하세요.');
  return {url,code,name};
}
window.pocketPairing={receive(result){
  try{
    if(result?.error)throw Error(result.error);
    const values=parsePairingLink(result?.value),root=picker('이 PC에 연결할까요?','PC의 QR코드를 확인했습니다.');
    root.append(el('h3',values.name),el('p',values.url,'connection-note'));
    if(values.url.startsWith('ws:'))root.append(el('p','같은 Wi-Fi 또는 같은 VPN에서 연결하세요. 이 연결 주소는 자체적으로 암호화하지 않습니다.','connection-note'));
    root.append(el('p','기본 작업 폴더는 PC에서 자동으로 가져옵니다.','connection-note'));
    const error=el('p','','inline-error hidden');error.setAttribute('role','alert');root.append(error);
    let paired;
    const connect=action('이 PC에 연결',async()=>{
      connect.disabled=true;error.classList.add('hidden');
      try{
        paired ||= await redeemPairingCode(values.url,values.code);
        saveConnectionProfile(connectionStore.profiles.find(p=>p.url===values.url),{name:paired.name||values.name,url:values.url,token:paired.token,cwd:paired.cwd||''});
      }catch(failure){error.textContent=failure.message;error.classList.remove('hidden');connect.disabled=false;}
    },'primary full');root.append(connect);
    root.append(action('다른 QR코드 스캔',()=>window.RemoteNative?.scanPairing(),'ghost full'),action('취소',connectionPicker,'ghost full'));
  }catch(error){const root=$('pickerContent');if(root)root.append(el('p',error.message,'inline-error'));}
}};
function saveConnectionProfile(previous,values) {
  if(!values.name)throw new Error('PC 이름을 입력하세요.');
  if(connectionStore.profiles.some(p=>p.id!==previous?.id&&p.url===values.url))throw new Error('같은 주소의 연결 대상이 이미 있습니다.');
  const oldToken=previous?connectionStore.getToken(previous.id):'',token=values.token||oldToken;
  if(!/^[A-Za-z0-9_-]{1,128}$/.test(token))throw new Error('올바른 페어링 토큰을 입력하세요.');
  if(!previous&&connectionStore.profiles.length>=8)throw new Error('연결 대상은 최대 8개까지 추가할 수 있습니다.');
  const changedIdentity=!!previous&&(previous.url!==values.url||(!!values.token&&values.token!==oldToken));
  const oldOutbox=previous?connectionStore.read(connectionStore.scope(previous.id,'remote.outbox'))||[]:[];
  if(changedIdentity&&oldOutbox.some(e=>['queued','sending','failed','uncertain'].includes(e.status)))throw new Error('이 PC의 미전송 메시지를 처리하거나 취소한 뒤 주소·토큰을 변경하세요.');
  if((!previous||previous.id===connectionStore.activeId)&&connectionTransfersBusy())throw new Error('파일 전송이 끝나거나 첨부를 제거한 뒤 연결 정보를 변경해 주세요.');
  if(!previous||previous.id===connectionStore.activeId)saveConnectionView();
  if(previous)previous=connectionStore.profiles.find(p=>p.id===previous.id);
  const id=previous&&!changedIdentity?previous.id:uuid();
  if(!connectionStore.putToken(id,token))throw new Error('페어링 토큰을 안전하게 저장하지 못했습니다.');
  const next={id,name:values.name,url:values.url,cwd:values.cwd,lastThread:changedIdentity?'':previous?.lastThread||'',lastUsed:previous?.lastUsed||0};
  const before=connectionStore.profiles;
  try{connectionStore.replace(previous?before.map(p=>p.id===previous.id?next:p):[...before,next]);}catch(e){if(id!==previous?.id)connectionStore.eraseToken(id);throw e;}
  if(changedIdentity){if(!connectionStore.eraseToken(previous.id)){connectionStore.replace(before);connectionStore.eraseToken(id);throw new Error('이전 토큰을 삭제하지 못했습니다. 변경을 다시 시도하세요.');}connectionStore.prune(previous.id);}
  if(!connectionStore.write(connectionStore.scope(id,'remote.cwd'),values.cwd))throw new Error('기본 작업 폴더를 저장하지 못했습니다.');
  if(!previous||previous.id===connectionStore.activeId){
    if(!connectionStore.write('remote.activeProfile',id))throw new Error('PC 선택 정보를 저장하지 못했습니다.');
    configureNativeNotifications();leaveConnectionPage();
  }else{configureNativeNotifications();renderConnectionChrome();connectionPicker();}
}
function confirmConnectionDelete(profile) {
  const root=picker('연결 삭제',profile.name),outbox=connectionStore.read(connectionStore.scope(profile.id,'remote.outbox'))||[],pending=outbox.filter(e=>['queued','sending','failed','uncertain'].includes(e.status)).length;
  root.append(el('p','이 휴대폰에 저장된 연결 정보·토큰·초안·대화 캐시를 삭제합니다. 다시 추가하려면 주소와 페어링 토큰이 필요합니다.','connection-note'));
  if(pending)root.append(el('p','이 PC의 미전송 메시지 '+pending+'개도 휴대폰에서 삭제됩니다.','inline-error'));
  root.append(action('연결 삭제',()=>{
    if(profile.id===connectionStore.activeId&&connectionTransfersBusy())throw new Error('파일 전송이 끝난 뒤 연결 대상을 삭제해 주세요.');
    const before=connectionStore.profiles,next=before.filter(p=>p.id!==profile.id);
    connectionStore.replace(next);
    if(!connectionStore.eraseToken(profile.id)){connectionStore.replace(before);throw new Error('저장된 토큰을 삭제하지 못했습니다. 다시 시도하세요.');}
    connectionStore.prune(profile.id);configureNativeNotifications();
    if(profile.id===connectionStore.activeId){if(!connectionStore.write('remote.activeProfile',next[0]?.id||''))throw new Error('연결 선택 정보를 저장하지 못했습니다.');leaveConnectionPage();}
    else{renderConnectionChrome();connectionPicker();}
  },'primary full danger'),action('취소',()=>connectionEditor(profile.id),'ghost full'));
}
function initConnectionUI() {
  $('connectionButton').onclick=$('connectionSwitch').onclick=$('manageConnections').onclick=connectionPicker;
  renderConnectionChrome();
  if(connectionStore.error)banner(connectionStore.error);
}

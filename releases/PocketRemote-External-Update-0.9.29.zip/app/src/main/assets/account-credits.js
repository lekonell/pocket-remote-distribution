// A read-only account snapshot shared by balance and reset-credit views.
// The cache belongs to one live PC socket and is never persisted.
class AccountLimitsReader {
  constructor({ read, scope, now = Date.now, ttl = 15000 }) {
    this.read = read; this.scope = scope; this.now = now; this.ttl = ttl;
    this.key = null; this.value = null; this.at = 0; this.pending = null; this.revision = 0;
  }
  invalidate() { this.revision++; this.value = null; this.at = 0; this.pending = null; }
  async get(force = false) {
    const key = this.scope();
    if (key !== this.key) { this.invalidate(); this.key = key; }
    if (!key) throw Error('PC 연결을 확인해 주세요.');
    const revision = this.revision;
    if (force && this.pending) {
      await this.pending.catch(() => {});
      if (revision !== this.revision || key !== this.scope()) throw Error('계정 연결이 변경되었습니다. 다시 조회해 주세요.');
      return this.get(true);
    }
    if (this.pending) return this.pending;
    if (!force && this.value && this.now() - this.at < this.ttl) return this.value;
    const pending = Promise.resolve().then(() => this.read()).then(value => {
      if (revision !== this.revision || key !== this.scope()) throw Error('계정 연결이 변경되었습니다. 다시 조회해 주세요.');
      this.value = value; this.at = this.now(); return value;
    }).finally(() => { if (this.pending === pending) this.pending = null; });
    this.pending = pending;
    return pending;
  }
}
function accountCreditsFromLimits(snapshot) {
  const buckets = snapshot?.rateLimitsByLimitId || {};
  const raw = snapshot?.rateLimits?.credits || buckets.codex?.credits || Object.values(buckets).find(b => b?.limitId === 'codex')?.credits;
  if (!raw || typeof raw !== 'object') return null;
  return { hasCredits: raw.hasCredits === true, unlimited: raw.unlimited === true, balance: ['string', 'number'].includes(typeof raw.balance) ? String(raw.balance) : null };
}

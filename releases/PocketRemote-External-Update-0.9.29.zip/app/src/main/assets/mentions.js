const pluginHints = { key: '', catalog: null, pending: null, loadedAt: 0, failedAt: 0, error: '', options: [], index: 0, composing: false, dismissed: '' };
const pluginCatalogScope = () => JSON.stringify([connectionStore.activeId, state.cwd, state.currentId]);
const pluginAliases = p => [...new Set([p.name, p.label].filter(Boolean))];
const mentionIdentity = m => m.kind + ':' + (m.id || m.path || m.name);
function mergeMentions(...lists) { return [...new Map(lists.flat().map(m => [mentionIdentity(m), m])).values()]; }
function mentionInCode(text, offset) { return [...text.matchAll(/```[\s\S]*?(?:```|$)|`[^`\n]*(?:`|$)/g)].some(m => offset >= m.index && offset < m.index + m[0].length); }
function pluginMentionAt(text, caret, plugins = []) {
  const prefix = text.slice(0, caret), start = prefix.lastIndexOf('@');
  if (start < 0 || start && !/[\s([{]/.test(prefix[start - 1]) || mentionInCode(text, start)) return null;
  const query = prefix.slice(start + 1);
  if (!/^[\p{L}\p{N}_ .:/-]*$/u.test(query)) return null;
  const lower = query.toLocaleLowerCase();
  if (/\s$/.test(query) && plugins.some(p => pluginAliases(p).some(a => a.toLocaleLowerCase() === lower.trim()))) return null;
  if (query.includes(' ') && !plugins.some(p => pluginAliases(p).some(a => a.toLocaleLowerCase().includes(lower)))) return null;
  return { start, end: caret, query };
}
function resolvePluginMentions(text, plugins) {
  const aliases = plugins.flatMap(p => pluginAliases(p).map(name => ({ name, plugin: p }))).sort((a, b) => b.name.length - a.name.length), found = [];
  for (const match of text.matchAll(/(?:^|[\s([{])@/g)) {
    const start = match.index + match[0].length - 1; if (mentionInCode(text, start)) continue;
    const rest = text.slice(start + 1), entry = aliases.find(({ name }) => {
      const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const boundary = '(?=$|[^\\p{L}\\p{N}_-]|(?:으로|에서|에게|한테|을|를|은|는|이|가|로|도|와|과|랑)(?=$|[^\\p{L}\\p{N}_-]))';
      return new RegExp('^' + escaped + boundary, 'iu').test(rest);
    });
    if (!entry) continue;
    const p = entry.plugin;
    if (!p.enabled) throw new Error((p.label || p.name) + ' 플러그인은 PC에서 활성화한 뒤 사용할 수 있습니다.');
    found.push({ kind: 'plugin', id: p.id, name: p.name, label: p.label });
  }
  return mergeMentions(found);
}
async function readPluginCatalog(force = false) {
  const key = pluginCatalogScope();
  if (pluginHints.key !== key) Object.assign(pluginHints, { key, catalog: null, pending: null, loadedAt: 0, failedAt: 0, error: '' });
  if (!force && pluginHints.catalog && (Date.now() - pluginHints.loadedAt < 30000 || !state.online)) return pluginHints.catalog;
  if (pluginHints.pending) return pluginHints.pending;
  if (!state.online) throw new Error('연결 후 사용 가능한 플러그인 목록을 불러올 수 있습니다.');
  const promise = rpc('bridge/catalog/list', { cwd: state.cwd, threadId: state.currentId || undefined }).then(catalog => {
    if (!catalog.plugins?.length && catalog.warnings?.some(w => w.includes('플러그인'))) throw new Error('PC에서 플러그인 목록을 읽지 못했습니다. 다시 시도해 주세요.');
    if (key === pluginCatalogScope()) { pluginHints.catalog = catalog; pluginHints.loadedAt = Date.now(); pluginHints.error = ''; feature.catalog = catalog; }
    return catalog;
  }).catch(error => { if (key === pluginCatalogScope()) { pluginHints.error = error.message; pluginHints.failedAt = Date.now(); } throw error; }).finally(() => { if (pluginHints.pending === promise) pluginHints.pending = null; });
  pluginHints.pending = promise; return promise;
}
function dismissPluginHints() {
  const input = $('messageInput'); pluginHints.dismissed = input.value + '|' + input.selectionStart;
  $('commandHints').classList.add('hidden'); input.removeAttribute('aria-activedescendant');
}
function choosePluginHint(plugin) {
  const input = $('messageInput'), token = pluginMentionAt(input.value, input.selectionStart, pluginHints.catalog?.plugins);
  if (!token || !plugin.enabled) return;
  input.setRangeText('@' + plugin.name + ' ', token.start, token.end, 'end'); input.focus({ preventScroll: true });
  if (state.currentId) persist('remote.draft.' + state.currentId, input.value);
  pluginHints.dismissed = ''; inputChanged();
}
function highlightPluginHint() {
  const buttons = [...$('commandHints').querySelectorAll('[role=option]')];
  buttons.forEach((button, index) => { const active = index === pluginHints.index; button.setAttribute('aria-selected', String(active)); if (active) { $('messageInput').setAttribute('aria-activedescendant', button.id); button.scrollIntoView({ block: 'nearest' }); } });
}
function renderPluginHints() {
  const input = $('messageInput'), hints = $('commandHints'), key = pluginCatalogScope(), catalog = pluginHints.key === key ? pluginHints.catalog : null, token = pluginMentionAt(input.value, input.selectionStart, catalog?.plugins);
  pluginHints.options = []; input.removeAttribute('aria-activedescendant'); hints.removeAttribute('role'); hints.removeAttribute('aria-label');
  if (!token || document.activeElement !== input || pluginHints.composing) return false;
  if (pluginHints.dismissed === input.value + '|' + input.selectionStart) return true;
  hints.classList.remove('hidden'); hints.classList.add('plugin-hints'); hints.setAttribute('role', 'listbox'); hints.setAttribute('aria-label', '사용 가능한 플러그인'); input.setAttribute('aria-autocomplete', 'list'); input.setAttribute('aria-controls', 'commandHints');
  const label = el('p', '플러그인 · 이름 입력 또는 추천 선택', 'plugin-hints-label'); hints.append(label);
  if (!catalog) {
    const recentError = pluginHints.key === key && pluginHints.error && Date.now() - pluginHints.failedAt < 5000;
    hints.append(el('p', recentError ? pluginHints.error : state.online ? '목록을 불러오는 중…' : '연결 후 목록을 불러올 수 있습니다.', 'plugin-hints-note'));
    if (recentError) hints.append(action('다시 시도', () => { pluginHints.failedAt = 0; pluginHints.dismissed = ''; input.focus({ preventScroll: true }); inputChanged(); }, 'ghost'));
    else if (state.online) readPluginCatalog().then(() => { if (key === pluginCatalogScope()) inputChanged(); }, () => { if (key === pluginCatalogScope()) inputChanged(); });
    return true;
  }
  const query = token.query.toLocaleLowerCase(), matches = (catalog.plugins || []).filter(p => pluginAliases(p).some(a => a.toLocaleLowerCase().includes(query))).sort((a, b) => Number(b.enabled) - Number(a.enabled));
  pluginHints.options = matches.filter(p => p.enabled); pluginHints.index = Math.min(pluginHints.index, Math.max(0, pluginHints.options.length - 1));
  if (!matches.length) hints.append(el('p', '일치하는 플러그인이 없습니다.', 'plugin-hints-note'));
  for (const p of matches) {
    const button = action('', () => choosePluginHint(p), 'plugin-hint-option'); button.disabled = !p.enabled;
    const text = el('span'); text.append(el('strong', p.label || p.name), el('small', '@' + p.name + (p.enabled ? '' : ' · PC에서 활성화 필요'))); button.append(el('span', '◇', 'plugin-hint-icon'), text);
    if (p.enabled) { button.id = 'plugin-option-' + pluginHints.options.indexOf(p); button.setAttribute('role', 'option'); button.setAttribute('aria-selected', String(pluginHints.options.indexOf(p) === pluginHints.index)); }
    // Preserve textarea focus/caret when choosing with touch or mouse.
    button.onpointerdown = event => event.preventDefault(); hints.append(button);
  }
  highlightPluginHint(); return true;
}
function initPluginHints() {
  const input = $('messageInput');
  input.addEventListener('compositionstart', () => { pluginHints.composing = true; }); input.addEventListener('compositionend', () => { pluginHints.composing = false; inputChanged(); });
  input.addEventListener('click', () => { pluginHints.dismissed = ''; inputChanged(); });
  input.addEventListener('keyup', e => { if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key) && !e.isComposing) { pluginHints.dismissed = ''; inputChanged(); } });
  input.addEventListener('keydown', event => {
    if (event.isComposing || event.keyCode === 229 || event.ctrlKey || event.metaKey || $('commandHints').classList.contains('hidden') || !$('commandHints').classList.contains('plugin-hints')) return;
    if (event.key === 'Escape') { event.preventDefault(); dismissPluginHints(); return; }
    if (!pluginHints.options.length) return;
    if (['ArrowDown', 'ArrowUp'].includes(event.key)) { event.preventDefault(); pluginHints.index = (pluginHints.index + (event.key === 'ArrowDown' ? 1 : -1) + pluginHints.options.length) % pluginHints.options.length; highlightPluginHint(); }
    if (event.key === 'Enter' || event.key === 'Tab') { event.preventDefault(); choosePluginHint(pluginHints.options[pluginHints.index]); }
  });
}

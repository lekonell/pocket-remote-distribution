// Coordinates are relative to the center of the viewing area. 1× means fit.
class ImageTransform {
  constructor() { this.scale = 1; this.x = 0; this.y = 0; this.width = 0; this.height = 0; this.baseWidth = 0; this.baseHeight = 0; }
  resize(width, height, imageWidth, imageHeight) {
    if (![width, height, imageWidth, imageHeight].every(v => Number.isFinite(v) && v > 0)) return false;
    const fit = Math.min(width / imageWidth, height / imageHeight, 1), oldWidth = this.baseWidth;
    this.width = width; this.height = height; this.baseWidth = imageWidth * fit; this.baseHeight = imageHeight * fit;
    if (oldWidth) { this.x *= this.baseWidth / oldWidth; this.y *= this.baseWidth / oldWidth; }
    this.clamp(); return true;
  }
  clamp() {
    const maxX = Math.max(0, (this.baseWidth * this.scale - this.width) / 2), maxY = Math.max(0, (this.baseHeight * this.scale - this.height) / 2);
    this.x = maxX ? Math.max(-maxX, Math.min(maxX, this.x)) : 0; this.y = maxY ? Math.max(-maxY, Math.min(maxY, this.y)) : 0;
  }
  zoom(next, point = { x: 0, y: 0 }) {
    const scale = Math.max(1, Math.min(8, next)), ratio = scale / this.scale;
    this.x = point.x - (point.x - this.x) * ratio; this.y = point.y - (point.y - this.y) * ratio;
    this.scale = scale; this.clamp();
  }
  pan(dx, dy) { this.x += dx; this.y += dy; this.clamp(); }
  pinch(start, center, distance) {
    if (start.distance <= 0) return;
    this.scale = Math.max(1, Math.min(8, start.scale * distance / start.distance));
    const ratio = this.scale / start.scale;
    this.x = center.x - (start.center.x - start.x) * ratio; this.y = center.y - (start.center.y - start.y) * ratio; this.clamp();
  }
  reset() { this.scale = 1; this.x = 0; this.y = 0; }
}

// Kept separate from DOM binding so transitions between one and two fingers
// (including cancellation) are testable without synthetic browser injection.
class ImageGesture {
  constructor(transform) { this.transform = transform; this.points = new Map(); this.start = null; this.tap = null; }
  rebase() {
    const points = [...this.points.values()];
    if (points.length >= 2) {
      this.tap = null;
      this.start = { kind: 'pinch', center: { x: (points[0].x + points[1].x) / 2, y: (points[0].y + points[1].y) / 2 }, distance: Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y), scale: this.transform.scale, x: this.transform.x, y: this.transform.y };
    } else this.start = points.length ? { kind: 'pan', point: { ...points[0] }, x: this.transform.x, y: this.transform.y } : null;
  }
  down(id, point) { this.points.set(id, point); this.tap = this.points.size === 1 ? { ...point } : null; this.rebase(); }
  move(id, point) {
    if (!this.points.has(id)) return;
    this.points.set(id, point);
    if (this.tap && Math.hypot(point.x - this.tap.x, point.y - this.tap.y) > 5) this.tap = null;
    if (this.start?.kind === 'pinch') {
      const [a, b] = [...this.points.values()];
      this.transform.pinch(this.start, { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, Math.hypot(a.x - b.x, a.y - b.y));
    } else if (this.start) {
      this.transform.x = this.start.x + point.x - this.start.point.x; this.transform.y = this.start.y + point.y - this.start.point.y; this.transform.clamp();
    }
  }
  up(id, cancelled = false) {
    if (!this.points.has(id)) return null;
    const tap = !cancelled && this.points.size === 1 ? this.tap : null;
    this.points.delete(id); this.tap = null; this.rebase(); return tap;
  }
  clear() { this.points.clear(); this.start = null; this.tap = null; }
}

function createImageViewer(image) {
  const model = new ImageTransform(), gesture = new ImageGesture(model), root = el('div', undefined, 'image-viewer'), viewport = el('div', undefined, 'image-viewport');
  viewport.tabIndex = 0; viewport.setAttribute('role', 'group'); viewport.setAttribute('aria-label', '이미지 상세 보기 · 두 손가락으로 확대·축소, 드래그로 이동');
  image.draggable = false; viewport.append(image);
  const controls = el('div', undefined, 'image-zoom-controls'), percent = el('output', '100%'), hint = el('p', '두 손가락으로 확대·축소 · 드래그로 이동 · 두 번 탭으로 확대·맞춤', 'image-gesture-hint');
  let frame = 0, disposed = false, lastTap = null;
  function paint() {
    frame = 0; if (disposed) return;
    image.style.width = model.baseWidth + 'px'; image.style.height = model.baseHeight + 'px';
    image.style.transform = `translate(-50%, -50%) translate(${model.x}px, ${model.y}px) scale(${model.scale})`;
    viewport.classList.toggle('zoomed', model.scale > 1);
    percent.value = Math.round(model.scale * 100) + '%'; percent.textContent = percent.value;
    minus.disabled = !model.baseWidth || model.scale <= 1; plus.disabled = !model.baseWidth || model.scale >= 8; reset.disabled = !model.baseWidth;
  }
  function update() { if (!disposed && !frame) frame = requestAnimationFrame(paint); }
  function coordinate(event) { const rect = viewport.getBoundingClientRect(); return { x: event.clientX - rect.left - rect.width / 2, y: event.clientY - rect.top - rect.height / 2 }; }
  function change(scale) { gesture.clear(); lastTap = null; model.zoom(scale); update(); }
  const minus = action('−', () => change(model.scale / 1.5), 'ghost'), plus = action('＋', () => change(model.scale * 1.5), 'ghost'), reset = action('화면 맞춤', () => { gesture.clear(); lastTap = null; model.reset(); update(); }, 'ghost');
  minus.setAttribute('aria-label', '이미지 축소'); plus.setAttribute('aria-label', '이미지 확대'); reset.setAttribute('aria-label', '이미지 화면에 맞추기'); percent.setAttribute('aria-label', '화면 맞춤 대비 확대 비율');
  controls.append(minus, percent, plus, reset); root.append(viewport, controls, hint);
  function resize() { if (disposed) return; const rect = viewport.getBoundingClientRect(); if (model.resize(rect.width, rect.height, image.naturalWidth, image.naturalHeight)) { gesture.clear(); update(); } }
  const observer = new ResizeObserver(resize); observer.observe(viewport); image.addEventListener('load', resize);
  viewport.onpointerdown = event => { if (event.pointerType === 'mouse' && event.button !== 0) return; event.preventDefault(); viewport.setPointerCapture(event.pointerId); gesture.down(event.pointerId, coordinate(event)); };
  viewport.onpointermove = event => { if (!gesture.points.has(event.pointerId)) return; event.preventDefault(); gesture.move(event.pointerId, coordinate(event)); update(); };
  function end(event, cancelled) {
    const tap = gesture.up(event.pointerId, cancelled);
    if (viewport.hasPointerCapture(event.pointerId)) viewport.releasePointerCapture(event.pointerId);
    if (tap) {
      const now = Date.now();
      if (lastTap && now - lastTap.at < 320 && Math.hypot(tap.x - lastTap.x, tap.y - lastTap.y) < 24) { model.scale > 1 ? model.reset() : model.zoom(2.5, tap); lastTap = null; update(); }
      else lastTap = { ...tap, at: now };
    } else lastTap = null;
  }
  viewport.onpointerup = event => end(event, false); viewport.onpointercancel = event => end(event, true); viewport.onlostpointercapture = event => { gesture.up(event.pointerId, true); };
  viewport.addEventListener('wheel', event => { event.preventDefault(); gesture.clear(); model.zoom(model.scale * Math.exp(-event.deltaY * 0.0015), coordinate(event)); update(); }, { passive: false });
  viewport.onkeydown = event => {
    if (['+', '=', '-', '0', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) { event.preventDefault(); gesture.clear();
      if (event.key === '+' || event.key === '=') model.zoom(model.scale * 1.5);
      else if (event.key === '-') model.zoom(model.scale / 1.5);
      else if (event.key === '0') model.reset();
      else model.pan(event.key === 'ArrowLeft' ? 40 : event.key === 'ArrowRight' ? -40 : 0, event.key === 'ArrowUp' ? 40 : event.key === 'ArrowDown' ? -40 : 0);
      update();
    }
  };
  resize(); paint();
  return { element: root, destroy() { disposed = true; observer.disconnect(); image.removeEventListener('load', resize); gesture.clear(); if (frame) cancelAnimationFrame(frame); } };
}

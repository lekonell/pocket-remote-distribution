// Search a detached history window. Intermediate pages never reach the DOM;
// only a successful target window is committed, synchronously before scrolling.
async function seekUserMessagePage({ history, currentItems, direction, read, isCurrent, overrides = () => new Map() }) {
  const staged = new HistoryWindow(), current = new Map(currentItems.map(entry => [entry.item.id, entry]));
  staged.pages = history.pages.map(page => ({ ...page, items: page.items.map(entry => current.get(entry.item.id) || entry) }));
  const visited = new Set();
  let cursor = direction === 'older' ? staged.olderCursor : staged.newerCursor;
  if (!cursor && direction === 'newer') {
    if (!isCurrent()) return null;
    const page = await read(null, 'older');
    if (!isCurrent()) return null;
    const changed = overrides(), items = (page.data || []).slice().reverse().map(entry => changed.get(entry.item.id) || entry);
    const target = items.find(entry => entry.item.type === 'userMessage' && !current.has(entry.item.id));
    if (!target) return { targetId: null };
    staged.reset(page, items);
    return { history: staged, targetId: target.item.id, atLatest: true };
  }
  while (cursor && !visited.has(cursor)) {
    if (!isCurrent()) return null;
    visited.add(cursor);
    const page = await read(cursor, direction);
    if (!isCurrent()) return null;
    const known = new Set([...current.keys(), ...staged.items.map(entry => entry.item.id)]);
    const target = (page.data || []).find(entry => entry.item.type === 'userMessage' && !known.has(entry.item.id));
    staged.accept({ ...page, nextCursor: page.nextCursor === cursor ? null : page.nextCursor }, direction, staged.items, overrides());
    if (target) return { history: staged, targetId: target.item.id, atLatest: false };
    cursor = direction === 'older' ? staged.olderCursor : staged.newerCursor;
  }
  return { targetId: null };
}
class UserMessageNavigation {
  constructor({ root, context, search, apply, update, announce, reportError = () => {} }) {
    Object.assign(this, { root, context, search, apply, update, announce, reportError });
    this.key = null; this.selected = null; this.busy = false; this.settling = false; this.ticket = 0;
    this.exhausted = {};
  }
  get isNavigating() { return this.busy || this.settling; }
  users() { return [...this.root.children].filter(node => node.classList.contains('userMessage')); }
  candidate(direction) {
    const users = this.users(), index = users.findIndex(node => node.dataset.itemId === this.selected);
    if (index >= 0) return users[index + (direction === 'older' ? -1 : 1)];
    const edge = this.root.getBoundingClientRect().top + 12;
    return direction === 'older'
      ? users.filter(node => node.getBoundingClientRect().top < edge - 2).at(-1)
      : users.find(node => node.getBoundingClientRect().top > edge + 2);
  }
  canLoad(direction, ctx = this.context()) {
    return ctx.online && !ctx.ephemeral && this.exhausted[direction] !== this.edgeKey(direction, ctx) && (direction === 'older' ? !!ctx.older : !!ctx.newer || ctx.historyMode);
  }
  edgeKey(direction, ctx = this.context()) {
    const nodes = this.root.children;
    return JSON.stringify([ctx.key, direction === 'older' ? ctx.older : ctx.newer, direction === 'older' ? nodes[0]?.dataset.itemId : nodes[nodes.length - 1]?.dataset.itemId, direction === 'newer' ? ctx.revision : null]);
  }
  refresh() {
    const ctx = this.context();
    if (ctx.key !== this.key) { this.cancel(); this.selected = null; this.exhausted = {}; this.key = ctx.key; }
    this.update({ busy: this.busy, older: !ctx.opening && !ctx.loading && !this.busy && (!!this.candidate('older') || this.canLoad('older', ctx)), newer: !ctx.opening && !ctx.loading && !this.busy && (!!this.candidate('newer') || this.canLoad('newer', ctx)) });
  }
  cancel() { this.ticket++; this.busy = false; this.settling = false; }
  manualScroll() {
    if (!this.isNavigating && Math.abs(this.root.scrollTop - (this.alignedTop ?? this.root.scrollTop)) > 2) this.selected = null;
    this.refresh();
  }
  select(node) {
    this.settling = true; this.selected = node.dataset.itemId;
    this.root.scrollTop += node.getBoundingClientRect().top - this.root.getBoundingClientRect().top - 12;
    this.alignedTop = this.root.scrollTop;
    const ticket = this.ticket;
    requestAnimationFrame(() => requestAnimationFrame(() => { if (ticket === this.ticket) { this.settling = false; this.refresh(); } }));
    this.announce('사용자 메시지로 이동했습니다.');
  }
  async jump(direction) {
    this.refresh();
    const ctx = this.context();
    if (this.busy || ctx.opening || ctx.loading || ctx.active === false) return;
    const immediate = this.candidate(direction);
    if (immediate) { this.select(immediate); this.refresh(); return; }
    if (!this.canLoad(direction, ctx)) return;
    const key = ctx.key, ticket = ++this.ticket;
    const isCurrent = () => ticket === this.ticket && this.context().key === key && this.context().active !== false;
    this.busy = true; this.refresh(); this.announce('사용자 메시지를 찾는 중입니다.');
    try {
      const result = await this.search(direction, isCurrent);
      if (!isCurrent() || !result) return;
      if (result.targetId) {
        this.apply(result);
        const target = this.users().find(node => node.dataset.itemId === result.targetId);
        if (!target) throw new Error('찾은 메시지를 표시하지 못했습니다. 다시 시도해 주세요.');
        this.select(target); return;
      }
      this.exhausted[direction] = this.edgeKey(direction);
      this.announce(direction === 'older' ? '더 이전 사용자 메시지가 없습니다.' : '더 다음 사용자 메시지가 없습니다.');
    } catch (error) {
      if (isCurrent()) { this.announce('메시지 탐색에 실패했습니다. 다시 시도해 주세요.'); this.reportError(error); }
    } finally {
      if (ticket === this.ticket) { this.busy = false; this.refresh(); }
    }
  }
}
function initMessageNavigation() {
  const root = $('transcript'), nav = $('messageNavigation');
  if (!root || !nav) return;
  const previous = $('previousUserMessage'), next = $('nextUserMessage'), cancel = $('cancelMessageNavigation');
  const controller = new UserMessageNavigation({ root,
    context: () => ({ key: loadToken + ':' + state.currentId, active: !document.hidden && !state.leaving, online: state.online, ephemeral: state.current?.ephemeral, opening: state.openingThread, loading: state.historyLoading, older: state.historyWindow.olderCursor, newer: state.historyWindow.newerCursor, historyMode: state.historyMode, revision: state.revision }),
    search: async (direction, isCurrent) => {
      const revision = state.revision,threadId=state.currentId;
      const overrides=()=>new Map([...state.items,...state.liveItems.values()].filter(entry=>(state.itemVersions.get(entry.item.id)||0)>revision||entry.liveComplete===false).map(entry=>[entry.item.id,entry]));
      if(state.serverCapabilities.userMessageJump){
        const edge=direction==='older'?state.items[0]:state.items.at(-1),knownIds=state.items.map(e=>e.item.id),visited=new Set();
        let cursor=direction==='older'?state.historyWindow.olderCursor:state.historyWindow.newerCursor;
        for(;;){
          if(!isCurrent()||!state.online)return null;
          const result=await rpc('bridge/history/userMessage',{threadId,direction,cursor,knownIds,anchor:edge&&{itemId:edge.item.id,turnId:edge.turnId}});
          if(!isCurrent())return null;
          if(result.targetId&&result.page){
            const page=result.page,changed=overrides(),items=(result.direction==='older'?[...page.data].reverse():page.data).map(e=>changed.get(e.item.id)||e),history=new HistoryWindow();
            history.reset({nextCursor:result.direction==='older'?page.nextCursor:page.backwardsCursor},items,result.direction==='older'?page.backwardsCursor:page.nextCursor);
            return {history,targetId:result.targetId,atLatest:result.atLatest};
          }
          if(!result.continuation||visited.has(result.continuation))return {targetId:null};
          cursor=result.continuation;visited.add(cursor);
        }
      }
      return seekUserMessagePage({ history: state.historyWindow, currentItems: state.items.slice(), direction,
        isCurrent: () => isCurrent() && state.online,
        read: (cursor, direction) => rpc('thread/items/list', { threadId, limit: HISTORY_PAGE_SIZE, sortDirection: direction === 'older' ? 'desc' : 'asc', ...(cursor ? { cursor } : {}) }),
        overrides
      });
    },
    apply: result => {
      for (const entry of state.items) if (entry.liveComplete === false) state.liveItems.set(entry.item.id, entry);
      state.historyWindow = result.history; state.items = result.history.items; state.itemCursor = result.history.olderCursor;
      state.historyMode = !result.atLatest; $('latestItems').classList.toggle('hidden', !state.historyMode);
      v03.ignoreScroll = true; renderTranscript(false);
      const token = loadToken; requestAnimationFrame(() => { if (token === loadToken) v03.ignoreScroll = false; });
    },
    update: status => { previous.disabled = !status.older; next.disabled = !status.newer; cancel.classList.toggle('hidden', !status.busy); nav.classList.toggle('searching', status.busy); nav.setAttribute('aria-busy', String(status.busy)); },
    announce: text => { $('messageNavigationStatus').textContent = text; },
    reportError: error => banner('메시지 탐색: ' + error.message)
  });
  window.userMessageNavigation = controller;
  previous.onclick = () => controller.jump('older'); next.onclick = () => controller.jump('newer');
  cancel.onclick = () => { controller.cancel(); controller.refresh(); };
  root.addEventListener('scroll', () => controller.manualScroll(), { passive: true });
  const manual = () => { controller.cancel(); controller.selected = null; controller.refresh(); };
  root.addEventListener('pointerdown', manual, { passive: true }); root.addEventListener('wheel', manual, { passive: true });
  root.addEventListener('keydown', event => { if (['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(event.key)) manual(); });
  new ResizeObserver(() => controller.refresh()).observe(root);
  controller.refresh();
}

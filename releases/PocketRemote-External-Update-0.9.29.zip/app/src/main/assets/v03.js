const v03 = { favoriteThreads:{},favoriteProjects:{},collapsedProjects:{},pendingThread:'',questionStates:new Map(),questionDrafts:{},objects:new Map(),loading:new Map(),downloads:new Set(),imageGroups:new Map(),pinned:true,scrollHeight:0,anchor:null,ignoreScroll:false,statusBusy:false,notificationSettings:{enabled:true,progress:true,completion:true,questions:true} };
const projectKey = cwd => /^[A-Za-z]:/.test(cwd||'') ? String(cwd).replace(/\\/g,'/').replace(/\/+$/,'').toLowerCase() : String(cwd||'').replace(/\/+$/,'');
const projectName = cwd => String(cwd||'프로젝트 없음').replace(/[\\/]+$/,'').split(/[\\/]/).at(-1);
const threadName = thread => thread.name||thread.preview||'새 대화';
function conversationRunning(thread) { return !!(state.retries?.has(thread.id)||state.activeTurns.has(thread.id)||thread.status?.type==='active'); }
function prioritizeFavoriteThreads(threads) {
  const current=thread=>state.threads.find(t=>t.id===thread.id)||thread;
  return threads.slice().sort((a,b)=>Number(conversationRunning(current(b)))-Number(conversationRunning(current(a))));
}
function conversationActivity(thread) {
  if(state.retries?.has(thread.id))return '↻ 모델 혼잡 · 자동 재시도 대기';
  const turnId = state.activeTurns.get(thread.id);
  if (!turnId && thread.status?.type !== 'active') return '';
  const execution = state.executions.get(thread.id);
  const current = execution && turnId && execution.turnId === turnId ? execution : { model: thread.model };
  const label=executionLabel(current);
  return '● 진행 중 · ' + (!current.speedKnown&&state.activityFlights?.has(thread.id)?label.replace('속도 정보 없음','속도 확인 중'):label);
}
let projectSearch='',searchCollapsedProjects={};

function closeSidebar() { v03.favoriteDragging?.cancel(); $('sidebar').classList.add('hidden'); $('sidebarBackdrop').classList.add('hidden'); }
function closeStatus() { pocketResetCredits.close(); $('statusOverlay').classList.add('hidden'); $('headerNew').setAttribute('aria-expanded','false'); }
function closeMenus() {
  closeQuestionEditor();
  closeMessageCopy();
  closeSidebar(); closeStatus();
  closeMedia();
  closeChanges();
  for(const id of ['pickerOverlay','goalOverlay','settingsOverlay','commandHints','mediaOverlay'])$(id)?.classList.add('hidden');
}
window.remoteCloseMenu = () => {
  const open=!!v03.questionEditor||['sidebar','statusOverlay','pickerOverlay','goalOverlay','settingsOverlay','commandHints','mediaOverlay','messageCopyOverlay','changesOverlay'].some(id=>$(id)&&!$(id).classList.contains('hidden'));
  closeMenus();return open;
};
function toggleSidebar() { const wasOpen=!$('sidebar').classList.contains('hidden'); closeMenus(); if(!wasOpen){$('sidebar').classList.remove('hidden');$('sidebarBackdrop').classList.remove('hidden');window.pocketAppUpdates?.check();renderThreads();if(state.online){loadThreads(true);window.pocketDots?.refreshAccess(true);}} }
function toggleThreadFavorite(thread) {
  if(v03.favoriteThreads[thread.id])delete v03.favoriteThreads[thread.id];
  else v03.favoriteThreads[thread.id]={id:thread.id,name:threadName(thread),model:thread.model,cwd:thread.cwd||state.cwd,archived:state.archived};
  persist('remote.favoriteThreads',v03.favoriteThreads);renderThreads();
}
function toggleProjectFavorite(cwd) {
  const key=projectKey(cwd); if(v03.favoriteProjects[key])delete v03.favoriteProjects[key];else v03.favoriteProjects[key]={cwd,name:projectName(cwd)};
  persist('remote.favoriteProjects',v03.favoriteProjects);renderThreads();
}
function reorderFavoriteEntries(entries, visibleIds) {
  const ids=Object.keys(entries),selected=new Set(visibleIds);
  if(selected.size!==visibleIds.length||visibleIds.some(id=>!Object.hasOwn(entries,id)))return entries;
  let index=0;
  return Object.fromEntries(ids.map(id=>{const next=selected.has(id)?visibleIds[index++]:id;return [next,entries[next]];}));
}
function saveFavoriteOrder(ids) {
  const next=reorderFavoriteEntries(v03.favoriteThreads,ids);
  if(JSON.stringify(next)===JSON.stringify(v03.favoriteThreads))return;
  if(!persist('remote.favoriteThreads',next)){banner('즐겨찾기 순서를 저장하지 못했습니다.');return;}
  v03.favoriteThreads=next;
}
function favoriteDragHandle(row,thread) {
  const handle=el('button','⠿','favorite-drag-handle');handle.type='button';
  handle.setAttribute('aria-label',threadName(thread)+' 같은 작업 상태 안에서 순서 옮기기');handle.title='진행 중인 대화가 먼저 표시됩니다. 같은 상태 안에서 드래그 · 위/아래 방향키로 이동';
  let drag=null;
  const rows=()=>[...row.parentNode.querySelectorAll('.favorite-thread-row')].filter(n=>n.dataset.favoriteActive===row.dataset.favoriteActive);
  function finish(save) {
    if(!drag)return;
    const session=drag;drag=null;v03.favoriteDragging=null;cancelAnimationFrame(session.frame);session.preview?.remove();row.classList.remove('favorite-dragging');
    for(const [type,listener]of session.listeners)session.capture.removeEventListener(type,listener);
    if(session.capture.hasPointerCapture(session.pointer))session.capture.releasePointerCapture(session.pointer);
    if(save&&session.preview)saveFavoriteOrder(rows().map(n=>n.dataset.favoriteId));
    const sidebar=$('sidebar'),top=sidebar.scrollTop;$('threadList').remoteKey='';renderThreads();sidebar.scrollTop=top;
  }
  function place(y) {
    const other=rows().filter(n=>n!==row),before=other.find(n=>y<n.getBoundingClientRect().top+n.getBoundingClientRect().height/2);
    if(row.nextSibling!==(before||drag.end))row.parentNode.insertBefore(row,before||drag.end);
  }
  function scrollFrame() {
    if(!drag?.preview)return;
    const sidebar=$('sidebar'),rect=sidebar.getBoundingClientRect(),delta=drag.y<rect.top+48?-8:drag.y>rect.bottom-48?8:0;
    if(delta){sidebar.scrollTop+=delta;place(drag.y);}
    drag.frame=requestAnimationFrame(scrollFrame);
  }
  handle.onpointerdown=event=>{
    if(event.button!==0||drag||v03.favoriteDragging)return;event.preventDefault();
    const capture=row.parentNode,listeners=[['pointermove',handle.onpointermove],['pointerup',handle.onpointerup],['pointercancel',()=>finish(false)],['lostpointercapture',()=>finish(false)]];
    drag={pointer:event.pointerId,startY:event.clientY,y:event.clientY,end:rows().at(-1).nextSibling,frame:0,capture,listeners};
    for(const [type,listener]of listeners)capture.addEventListener(type,listener);
    v03.favoriteDragging={cancel:()=>finish(false)};capture.setPointerCapture(event.pointerId);
  };
  handle.onpointermove=event=>{
    if(!drag||event.pointerId!==drag.pointer)return;event.preventDefault();drag.y=event.clientY;
    if(!drag.preview&&Math.abs(drag.y-drag.startY)<6)return;
    if(!drag.preview){
      const rect=row.getBoundingClientRect(),preview=row.cloneNode(true);preview.classList.add('favorite-drag-preview');preview.setAttribute('aria-hidden','true');
      preview.querySelectorAll('button').forEach(b=>b.tabIndex=-1);Object.assign(preview.style,{left:rect.left+'px',top:rect.top+'px',width:rect.width+'px'});
      document.body.append(preview);drag.preview=preview;row.classList.add('favorite-dragging');drag.frame=requestAnimationFrame(scrollFrame);
    }
    drag.preview.style.transform='translateY('+(drag.y-drag.startY)+'px)';place(drag.y);
  };
  handle.onpointerup=event=>{if(drag?.pointer===event.pointerId)finish(true);};
  handle.onkeydown=event=>{
    if(!['ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();
    const ids=rows().map(n=>n.dataset.favoriteId),from=ids.indexOf(thread.id),to=from+(event.key==='ArrowUp'?-1:1);
    if(to<0||to>=ids.length)return;[ids[from],ids[to]]=[ids[to],ids[from]];saveFavoriteOrder(ids);renderThreads();
    [...$('threadList').querySelectorAll('.favorite-thread-row')].find(n=>n.dataset.favoriteId===thread.id)?.querySelector('.favorite-drag-handle').focus();
  };
  return handle;
}
function threadProjectGroup(thread) {
  const assignment=saved('remote.projectAssignment.'+thread.id),projectId=thread.projectId===undefined?assignment:thread.projectId;
  if(projectId){const project=saved('remote.projects')?.projects?.find(p=>p.id===projectId);return{key:'project:'+projectId,projectId,name:project?.name||projectName(thread.cwd),cwd:project?.roots?.[0]?.path||thread.cwd||''};}
  if(assignment!==undefined&&assignment!==null)return{key:'project:',projectId:'',name:'프로젝트 없음',cwd:''};
  return{key:projectKey(thread.cwd),name:projectName(thread.cwd),cwd:thread.cwd||''};
}
async function moveConversationProject(thread, project) {
  const socket=state.socket,epoch=state.epoch;
  const result=await rpc('thread/metadata/update',{threadId:thread.id,projectId:project?.id||''});
  if(socket!==state.socket||epoch!==state.epoch||state.leaving)return;
  if(result.thread?.id!==thread.id)throw new Error('프로젝트 변경 결과를 확인하지 못했습니다.');
  Object.assign(thread,result.thread);
  const listed=state.threads.find(t=>t.id===thread.id);if(listed&&listed!==thread)Object.assign(listed,result.thread);
  if(state.currentId===thread.id)Object.assign(state.current||{},result.thread);
  if(v03.favoriteThreads[thread.id]){Object.assign(v03.favoriteThreads[thread.id],result.thread);persist('remote.favoriteThreads',v03.favoriteThreads);}
  persist('remote.projectAssignment.'+thread.id,project?.id||'');persist('remote.meta.'+thread.id,result.thread);
  state.projectFilter='';renderThreads();loadThreads(true,{background:true});
}
function renameConversation(thread) {
  const socket=state.socket,epoch=state.epoch,root=picker('이름 변경',threadName(thread));
  const input=el('input');input.value=thread.name||thread.preview||'';input.maxLength=250;input.setAttribute('aria-label','대화 이름');
  const error=el('p','','inline-error hidden'),buttons=el('div',undefined,'conversation-menu-actions');
  const save=action('저장',async()=>{
    if(!input.value.trim()){error.textContent='대화 이름을 입력해 주세요.';error.classList.remove('hidden');return;}
    if(socket!==state.socket||epoch!==state.epoch||state.leaving)return;
    save.disabled=true;
    try{await rpc('thread/name/set',{threadId:thread.id,name:input.value.trim()});if(socket!==state.socket||epoch!==state.epoch)return;applyThreadName(thread.id,input.value);if(root.contains(input))closePicker();}
    catch(e){error.textContent=e.message;error.classList.remove('hidden');}finally{save.disabled=false;}
  },'primary');buttons.append(save,action('취소',closePicker,'ghost'));root.append(input,error,buttons);input.focus();
}
function conversationContextMenu(thread) {
  const root=picker('대화 메뉴',threadName(thread)),socket=state.socket,epoch=state.epoch,archived=state.archived;
  const valid=()=>socket===state.socket&&epoch===state.epoch&&!state.leaving;
  const online={disabled:!state.online};
  pickerRow(root,'이름 변경','대화 이름을 직접 설정합니다.',()=>renameConversation(thread),{...online,icon:'✎'});
  pickerRow(root,'프로젝트 변경','프로젝트 소속을 이동하거나 해제합니다.',()=>selectThreadProject('프로젝트 변경',project=>valid()?moveConversationProject(thread,project):undefined,{noneLabel:'프로젝트 없음',noneDescription:'프로젝트 소속만 해제합니다.',subtitle:'실행 중인 작업 폴더는 유지됩니다.',selectedId:thread.projectId||''}),{...online,icon:'▱'});
  pickerRow(root,v03.favoriteThreads[thread.id]?'즐겨찾기 해제':'즐겨찾기','목록 상단에서 빠르게 접근합니다.',()=>{if(valid())toggleThreadFavorite(thread);closePicker();},{icon:'☆'});
  pickerRow(root,archived?'보관 해제':'대화 보관',archived?'일반 대화 목록으로 되돌립니다.':'보관된 대화에서 다시 확인할 수 있습니다.',async()=>{
    if(!valid())return;await rpc(archived?'thread/unarchive':'thread/archive',{threadId:thread.id});if(!valid())return;closePicker();state.threads=state.threads.filter(t=>t.id!==thread.id);if(v03.favoriteThreads[thread.id]){v03.favoriteThreads[thread.id].archived=!archived;persist('remote.favoriteThreads',v03.favoriteThreads);}renderThreads();loadThreads(true,{background:true});
  },{disabled:!state.online||!archived&&(state.activeTurns.has(thread.id)||thread.status?.type==='active'),icon:'▤'});
  pickerRow(root,'분기 대화 만들기','이 대화의 내역으로 새 대화를 만듭니다.',async()=>{
    if(!valid())return;const navigation=loadToken,result=await rpc('thread/fork',{threadId:thread.id,excludeTurns:true});if(!valid())return;if(!result.thread?.id)throw new Error('분기 대화를 만들지 못했습니다.');state.threads.unshift(result.thread);if(navigation===loadToken){closePicker();await openThread(result.thread.id);}loadThreads(true,{background:true});
  },{...online,icon:'⑂'});
  pickerRow(root,'대화 ID 복사',thread.id,async()=>{await copyMessageText(thread.id);closePicker();},{icon:'⧉'});
}
function initConversationMenu() {
  const root=$('threadList');let suppress=false;
  const target=e=>{const node=e.target.closest?.('.thread-entry[data-thread-id]');if(!node||!root.contains(node))return null;return{node,id:node.dataset.threadId,profile:connectionStore.activeId};};
  const show=p=>{if(!p?.node.isConnected||p.profile!==connectionStore.activeId||state.leaving)return;const thread=state.threads.find(t=>t.id===p.id)||v03.favoriteThreads[p.id];if(thread)conversationContextMenu(thread);};
  const press=new MessagePress(p=>{suppress=true;show(p);window.RemoteNative?.messageLongPressFeedback?.();},undefined,undefined,(p,down)=>{v03.conversationPressing=down;p.node.classList.toggle('thread-pressed',down);});
  root.addEventListener('pointerdown',e=>{const p=target(e);if(p&&e.button===0)press.down(e.pointerId,e.clientX,e.clientY,p);else press.cancel();},{passive:true});
  window.addEventListener('pointerdown',()=>{suppress=false;},true);
  window.addEventListener('pointermove',e=>press.move(e.pointerId,e.clientX,e.clientY),{passive:true});window.addEventListener('pointerup',e=>press.up(e.pointerId),{passive:true});window.addEventListener('pointercancel',()=>press.cancel(),{passive:true});window.addEventListener('blur',()=>press.cancel());
  root.addEventListener('scroll',()=>press.cancel(),{passive:true});document.addEventListener('visibilitychange',()=>{if(document.hidden)press.cancel();});
  root.addEventListener('click',e=>{if(suppress){suppress=false;e.preventDefault();e.stopImmediatePropagation();}},true);
  root.addEventListener('contextmenu',e=>{const p=target(e);if(p){e.preventDefault();press.cancel();show(p);}});
  root.addEventListener('keydown',e=>{if(e.key==='ContextMenu'||e.key==='F10'&&e.shiftKey){const p=target(e);if(p){e.preventDefault();press.cancel();show(p);}}});
}
function renderConversationList() {
  if(v03.favoriteDragging||v03.conversationPressing)return;
  const list=$('threadList'),filter=$('searchThreads').value.trim().toLowerCase();
  if(projectSearch!==filter){projectSearch=filter;searchCollapsedProjects={};}
  const collapsedState=filter?searchCollapsedProjects:v03.collapsedProjects;
  const matches=t=>(threadName(t)+' '+(t.cwd||'')).toLowerCase().includes(filter);
  const threads=state.threads.filter(matches);
  const before=JSON.stringify(v03.favoriteThreads);
  for(const t of state.threads)if(v03.favoriteThreads[t.id])Object.assign(v03.favoriteThreads[t.id],{name:threadName(t),cwd:t.cwd,model:t.model,archived:state.archived});
  if(before!==JSON.stringify(v03.favoriteThreads))persist('remote.favoriteThreads',v03.favoriteThreads);
  const key=JSON.stringify([state.currentId,state.archived,state.projectFilter,filter,threads.map(t=>[t.id,t.name,t.preview,t.cwd,threadProjectGroup(t).key,conversationActivity(t)]),saved('remote.projects'),v03.favoriteThreads,Object.values(v03.favoriteThreads).map(t=>conversationActivity(state.threads.find(s=>s.id===t.id)||t)),v03.favoriteProjects,collapsedState]);
  if(list.remoteKey===key)return;list.remoteKey=key;list.replaceChildren();
  if(state.projectFilter)list.append(action('‹ 모든 프로젝트',()=>{state.projectFilter='';loadThreads(true);},'ghost full'));
  function row(thread,parent,reorder=false){
    const wrap=el('div',undefined,'thread-row'),button=action('',()=>openThread(thread.id),'thread-entry'+(thread.id===state.currentId?' active':''));
    button.append(el('span',threadName(thread)));
    button.dataset.threadId=thread.id;button.setAttribute('aria-haspopup','dialog');button.title='길게 눌러 대화 메뉴';
    const activity=conversationActivity(thread);if(activity)button.append(el('small',activity));
    const favorite=!!v03.favoriteThreads[thread.id],star=action(favorite?'★':'☆',()=>toggleThreadFavorite(thread),'favorite-button'+(favorite?' selected':''));
    star.setAttribute('aria-label',(favorite?'즐겨찾기 해제: ':'즐겨찾기: ')+threadName(thread));star.setAttribute('aria-pressed',String(favorite));
    if(reorder){wrap.classList.add('favorite-thread-row');wrap.dataset.favoriteId=thread.id;wrap.dataset.favoriteActive=conversationRunning(thread)?'1':'0';wrap.append(favoriteDragHandle(wrap,thread));}
    wrap.append(button,star);parent.append(wrap);
  }
  const favorites=Object.values(v03.favoriteThreads).filter(t=>!!t.archived===state.archived&&matches(t)&&(!state.projectFilter||(state.projectFilter.startsWith('project:')?threadProjectGroup(state.threads.find(s=>s.id===t.id)||t).key===state.projectFilter:projectKey(t.cwd)===projectKey(state.projectFilter))));
  if(favorites.length){list.append(el('h3','즐겨찾는 대화','list-label'));for(const t of prioritizeFavoriteThreads(favorites))row(state.threads.find(s=>s.id===t.id)||t,list,true);}
  const groups=new Map();
  for(const t of threads){const group=threadProjectGroup(t);if(!groups.has(group.key))groups.set(group.key,{...group,threads:[]});groups.get(group.key).threads.push(t);}
  if(!state.archived&&!state.projectFilter)for(const [key,p]of Object.entries(v03.favoriteProjects))if(!groups.has(key)&&(p.name+' '+p.cwd).toLowerCase().includes(filter))groups.set(key,{cwd:p.cwd,name:p.name,projectId:p.projectId,threads:[]});
  const sorted=[...groups].sort(([a],[b])=>Number(!!v03.favoriteProjects[b])-Number(!!v03.favoriteProjects[a]));
  if(sorted.length){
    const controls=el('div',undefined,'project-controls'),buttons=el('div');controls.append(el('h3','프로젝트','list-label'),buttons);
    for(const [label,collapsed]of [['모두 접기',true],['모두 펼치기',false]])buttons.append(action(label,()=>{
      for(const [key]of sorted)if(collapsed)collapsedState[key]=true;else delete collapsedState[key];
      if(!filter)persist('remote.collapsedProjects',v03.collapsedProjects);renderThreads();
    },''));list.append(controls);
  }
  for(const [index,[key,group]]of sorted.entries()){
    const section=el('section',undefined,'project-group'),head=el('div',undefined,'project-heading');
    const content=el('div',undefined,'project-threads');content.id='project-threads-'+index;
    const name=action('',()=>{
      const collapsed=!collapsedState[key];
      if(collapsed)collapsedState[key]=true;else delete collapsedState[key];
      if(!filter)persist('remote.collapsedProjects',v03.collapsedProjects);
      content.classList.toggle('hidden',collapsed);name.setAttribute('aria-expanded',String(!collapsed));
      name.setAttribute('aria-label',group.name+(collapsed?' 펼치기':' 접기'));
      section.classList.toggle('collapsed',collapsed);
    },'project-name');
    const label=el('span',undefined,'project-label');label.append(el('strong',group.name),el('small',group.cwd));
    const chevron=el('span','⌄','project-chevron');chevron.setAttribute('aria-hidden','true');name.append(chevron,label);
    const count=el('span',String(group.threads.length),'project-count');count.title='불러온 대화 '+group.threads.length+'개';count.setAttribute('aria-hidden','true');name.append(count);
    const collapsed=!!collapsedState[key];content.classList.toggle('hidden',collapsed);section.classList.toggle('collapsed',collapsed);
    name.setAttribute('aria-expanded',String(!collapsed));name.setAttribute('aria-controls',content.id);name.setAttribute('aria-label',group.name+(collapsed?' 펼치기':' 접기'));name.title=group.cwd;
    head.append(name);
    if(group.cwd||group.projectId){const favorite=!!v03.favoriteProjects[key],star=action(favorite?'★':'☆',()=>{if(favorite)delete v03.favoriteProjects[key];else v03.favoriteProjects[key]={cwd:group.cwd,name:group.name,projectId:group.projectId};persist('remote.favoriteProjects',v03.favoriteProjects);renderThreads();},'favorite-button'+(favorite?' selected':''));star.setAttribute('aria-label',(favorite?'프로젝트 즐겨찾기 해제: ':'프로젝트 즐겨찾기: ')+group.name);star.setAttribute('aria-pressed',String(favorite));head.append(star);}
    section.append(head,content);for(const t of group.threads)row(t,content);
    if((group.cwd||group.projectId!==undefined)&&!state.projectFilter)content.append(action('프로젝트 대화 모두 보기 ›',()=>{state.projectFilter=group.projectId!==undefined?'project:'+(group.projectId||''):group.cwd;loadThreads(true);},'project-view'));
    else if(!group.threads.length)content.append(el('small','대화가 없습니다.','project-empty'));list.append(section);
  }
  if(!threads.length&&!favorites.length&&!sorted.length)list.append(el('p',filter?'검색 결과가 없습니다.':'대화가 없습니다.','project-empty'));
}

function rememberScroll() {
  const root=$('transcript'); if(!root||!root.clientHeight||v03.questionEditor)return;
  v03.pinned=root.scrollHeight-root.scrollTop-root.clientHeight<80;
  v03.lastScrollTop=root.scrollTop;
  v03.scrollHeight=root.clientHeight;
  const top=root.getBoundingClientRect().top,first=[...root.children].find(n=>n.getBoundingClientRect().bottom>top);
  v03.anchor=first?{id:first.dataset.itemId,offset:first.getBoundingClientRect().top-top}:null;
}
function maintainViewport() {
  const active=document.activeElement,small=innerHeight<560;
  document.documentElement.classList.toggle('keyboard-open',small&&!!active?.matches('#messageInput,.question-card textarea,.question-card input[type=password]'));
  if(v03.questionEditor){
    document.documentElement.style.setProperty('--answer-viewport-height',(window.visualViewport?.height||innerHeight)+'px');
    if(active?.closest('.question-fields'))requestAnimationFrame(()=>{
      if(v03.questionEditor&&document.activeElement===active)active.scrollIntoView({block:'nearest'});
    });
    return;
  }
  const root=$('transcript');if(!root.clientHeight)return;
  const resized=root.clientHeight!==v03.scrollHeight;
  if(resized){
    v03.ignoreScroll=true;
    if((v03.pinned||v03.keyboardPin)&&!state.historyMode&&!globalThis.userMessageNavigation?.busy)root.scrollTop=root.scrollHeight;
    else if(v03.anchor){const a=[...root.children].find(n=>n.dataset.itemId===v03.anchor.id);if(a)root.scrollTop+=a.getBoundingClientRect().top-root.getBoundingClientRect().top-v03.anchor.offset;}
    v03.scrollHeight=root.clientHeight;requestAnimationFrame(()=>{v03.ignoreScroll=false;rememberScroll();});
  }
  if(!$('commandHints').classList.contains('hidden'))$('commandHints').style.bottom=($('app').getBoundingClientRect().bottom-$('composer').getBoundingClientRect().top+8)+'px';
}

function accountCreditLabel(credits) {
  if (!credits) return '';
  if (credits.unlimited === true) return '무제한';
  const text = ['string', 'number'].includes(typeof credits.balance) ? String(credits.balance).trim() : '', value = text && /^-?\d+(?:\.\d+)?$/.test(text) ? Number(text) : null;
  if (value !== null) return Number.isFinite(value) && value > 0 ? value.toLocaleString('ko-KR', { maximumFractionDigits: 0 }) + ' 크레딧' : '';
  return credits.hasCredits === true ? '보유 중 · 잔액 정보 없음' : '';
}
async function statusPopup() {
  const open=!$('statusOverlay').classList.contains('hidden');closeMenus();if(open)return;
  $('statusOverlay').classList.remove('hidden');$('headerNew').setAttribute('aria-expanded','true');await refreshStatus();
}
async function refreshStatus() {
  if(v03.statusBusy||$('statusOverlay').classList.contains('hidden'))return;
  const root=$('statusContent'),id=state.currentId;v03.statusBusy=true;
  try {
    const limitsPromise = state.online ? accountLimits.get() : Promise.resolve(null), socket = state.socket, revision = accountLimits.revision;
    const [statusRead, limitsRead] = await Promise.allSettled([id&&state.online?rpc('bridge/status/read',{threadId:id}):Promise.resolve(null), limitsPromise]);
    if(id!==state.currentId||socket!==state.socket||revision!==accountLimits.revision||$('statusOverlay').classList.contains('hidden'))return;
    const data=statusRead.status==='fulfilled'?statusRead.value:null;
    const credits=limitsRead.status==='fulfilled'?accountCreditsFromLimits(limitsRead.value):null;
    function renderBalance() {
      const balance=accountCreditLabel(credits || data?.credits);
      if(balance || limitsRead.status==='rejected') {
        const section=el('div',undefined,'status-section');section.id='accountCreditBalance';
        section.append(el('small','보유 크레딧'),el('strong',balance || '잔액 조회 실패'));
        if(!balance)section.append(action('다시 조회',()=>{accountLimits.invalidate();refreshStatus();},'ghost'));
        root.append(section);
      }
    }
    root.replaceChildren();
    if(!id){root.append(el('p','대화를 선택하면 세션 정보를 확인할 수 있습니다.'));renderBalance();pocketResetCredits.mount(root);return;}
    const thread=el('div',undefined,'status-section');thread.append(el('small','스레드 ID'));
    const line=el('div',undefined,'status-copy'),copy=action('⧉',async()=>{if(window.RemoteNative)window.RemoteNative.copyText(id);else await navigator.clipboard.writeText(id);copy.textContent='✓';},'icon small');copy.setAttribute('aria-label','스레드 ID 복사');line.append(el('code',id),copy);thread.append(line);root.append(thread);
    const cwd=el('div',undefined,'status-section');cwd.append(el('small','디렉터리'),el('p',data?.cwd||state.current?.cwd||state.cwd));root.append(cwd);
    function meter(title,remaining,detail){const s=el('div',undefined,'status-section');s.append(el('small',title),el('strong',remaining===null?'정보 없음':Math.round(remaining)+'% 남음'));if(remaining!==null){const m=el('progress');m.max=100;m.value=remaining;s.append(m);}s.append(el('p',detail));root.append(s);}
    const context=data?.context,weekly=data?.weekly;
    meter('컨텍스트 창',context?Math.max(0,100-context.used/context.limit*100):null,context?context.limit.toLocaleString()+' 토큰 중 '+context.used.toLocaleString()+' 사용':'호스트에서 제공되지 않은 정보입니다.');
    meter('7일 한도',weekly?Math.max(0,100-weekly.usedPercent):null,weekly?.resetsAt?new Date(weekly.resetsAt*1000).toLocaleString('ko-KR')+' 초기화':'계정에서 한도 정보를 제공하지 않았습니다.');
    renderBalance();
    pocketResetCredits.mount(root);
  }catch(e){root.replaceChildren(el('p',e.message));pocketResetCredits.mount(root);}finally{v03.statusBusy=false;}
}

function renderNotificationSettings() {
  for(const [id,key]of [['notifyEnabled','enabled'],['notifyProgress','progress'],['notifyCompletion','completion'],['notifyQuestions','questions']])if($(id))$(id).checked=v03.notificationSettings[key];
  let status={};try{status=JSON.parse(window.RemoteNative?.notificationStatus()||'{}');}catch{}
  $('androidSettings').classList.toggle('hidden',!window.RemoteNative);
  $('notificationStatus').textContent=!window.RemoteNative?'휴대폰 앱에서 알림 설정을 사용할 수 있습니다.':!v03.notificationSettings.enabled?'백그라운드 알림이 꺼져 있습니다.':status.suspended?'연결을 일시 해제했습니다. 앱을 다시 열면 알림 수신을 재개합니다.':!status.permission||!status.allowed?'Android 설정에서 알림을 허용해 주세요.':'앱을 벗어나도 알림을 수신합니다. 배터리 설정에서 제한 없음을 선택하면 연결 유지에 도움이 됩니다.';
}
function configureNativeNotifications() {
  const n=v03.notificationSettings;
  if(window.RemoteNative?.configureNotificationProfiles)window.RemoteNative.configureNotificationProfiles(JSON.stringify(connectionStore.profiles.map(({id,name,url})=>({id,name,url}))),n.enabled,n.progress,n.completion,n.questions);
  else window.RemoteNative?.configureNotifications(state.url,n.enabled,n.progress,n.completion,n.questions);
  renderNotificationSettings();
}
window.remoteNotificationStatusChanged=renderNotificationSettings;
window.remoteNotificationOpened=()=>{
  let target;try{target=JSON.parse(window.RemoteNative?.takePendingConnection?.()||'null');}catch{}
  if(target?.profileId&&target.profileId!==connectionStore.activeId){try{switchConnection(target.profileId,target.threadId||'');}catch(e){banner(e.message);connectionPicker();}return;}
  const id=target?.threadId||window.RemoteNative?.takePendingThread();if(id)v03.pendingThread=id;openNotificationThread();
};
function openNotificationThread() {if(v03.pendingThread&&state.online){const id=v03.pendingThread;v03.pendingThread='';openThread(id);}}

function v03Event(method,p) {
  if(method==='pocket/notifications/question'){v03.questionStates.set(p.threadId+':'+p.itemId,p);if(p.threadId===state.currentId){scheduleRender();renderApprovals();}}
  if(method==='pocket/notifications/questionResolved'){const key=p.threadId+':'+p.itemId;v03.questionStates.set(key,{...v03.questionStates.get(key),...p});if(p.threadId===state.currentId){scheduleRender();renderApprovals();}}
  if(method.startsWith('pocket/notifications/question'))renderQuestionAttention();
}
async function loadPendingQuestions() {
  const socket=state.socket,epoch=state.epoch;
  try{const result=await rpc('bridge/notifications/list');if(state.socket!==socket||state.epoch!==epoch||state.leaving)return;
    for(const q of result.notices||[])if(q.kind==='question')v03.questionStates.set(q.threadId+':'+q.itemId,q);
    renderQuestionAttention();
  }catch{}
}
function renderQuestionAttention() {
  const box=$('questionAttention');if(!box)return;
  const pending=[...v03.questionStates.values()].filter(q=>!q.subagent&&['pending','answering','uncertain'].includes(q.status));
  for(const request of state.approvals.values())if(request.method?.endsWith('requestUserInput')&&!['answered','skipped'].includes(v03.questionStates.get(request.params?.threadId+':'+request.params?.itemId)?.status)&&!pending.some(q=>q.threadId===request.params?.threadId&&q.itemId===request.params?.itemId))pending.push({...request.params,status:'pending'});
  const q=pending.find(q=>q.threadId===state.currentId)||pending.sort((a,b)=>(a.createdAt||0)-(b.createdAt||0))[0];
  box.classList.toggle('hidden',!q);if(!q)return;
  $('questionAttentionLabel').textContent='답변 필요'+(pending.length>1?' · '+pending.length+'건':'');
  $('questionAttentionText').textContent=q.summary||q.questions?.[0]?.question||q.questions?.[0]?.title||q.title||'질문을 확인해 주세요.';
  const profileId=connectionStore.activeId,button=$('questionAttentionButton');
  button.onclick=async()=>{
    if(profileId!==connectionStore.activeId)return;
    if(q.threadId!==state.currentId)await openThread(q.threadId);
    if(profileId!==connectionStore.activeId||q.threadId!==state.currentId)return;
    openQuestionEditor(q.itemId);
  };
}
function openQuestionEditor(itemId) {
  const card=[...$('approvalBox').children].find(node=>node.dataset?.questionItemId===itemId&&node.querySelector('.question-form'));
  if(!card)return;
  closeMenus();rememberScroll();
  v03.questionEditor={profileId:connectionStore.activeId,threadId:state.currentId,itemId,card};
  card.classList.add('question-editing');
  card.querySelector('.question-open').setAttribute('aria-expanded','true');
  document.documentElement.classList.add('question-answering');
  // Keep the exact input nodes mounted while the conversation keeps updating.
  maintainViewport();
  card.querySelector('.question-back').focus({preventScroll:true});
  card.dismissNotice?.();
}
function closeQuestionEditor(restoreFocus=false) {
  const editor=v03.questionEditor;if(!editor)return;
  v03.questionEditor=null;
  if(editor.card.contains(document.activeElement))document.activeElement.blur();
  editor.card.classList.remove('question-editing');
  editor.card.querySelector('.question-open')?.setAttribute('aria-expanded','false');
  v03.ignoreScroll=true;v03.scrollHeight=-1;
  document.documentElement.classList.remove('question-answering');
  document.documentElement.style.removeProperty('--answer-viewport-height');
  if(restoreFocus&&editor.profileId===connectionStore.activeId&&editor.threadId===state.currentId)editor.card.querySelector('.question-open')?.focus({preventScroll:true});
  maintainViewport();
}
function syncQuestionEditor(cards) {
  const editor=v03.questionEditor;if(!editor)return;
  if(editor.profileId!==connectionStore.activeId||editor.threadId!==state.currentId||!cards.includes(editor.card))closeQuestionEditor();
}
function questionCard(itemId,questions,turnId,requestId=null) {
  v03.questionCards ||= new Map();
  const cacheKey=connectionStore.activeId+':'+state.currentId+':'+itemId;
  const renderKey=JSON.stringify([questions,['answered','skipped'].includes(v03.questionStates.get(state.currentId+':'+itemId)?.status)?v03.questionStates.get(state.currentId+':'+itemId).status:'pending',!v03.questionStates.has(state.currentId+':'+itemId)&&state.historyMode]);
  const existing=v03.questionCards.get(cacheKey);
  if(existing?.remoteKey===renderKey)return existing;
  const key=state.currentId+':'+itemId,record=v03.questionStates.get(key),card=el('section',undefined,'question-card');
  card.remoteKey=renderKey;v03.questionCards.set(cacheKey,card);
  while(v03.questionCards.size>64){const oldest=[...v03.questionCards].find(([,node])=>!node.isConnected);if(!oldest)break;v03.questionCards.delete(oldest[0]);}
  const threadId=state.currentId,profileId=connectionStore.activeId;
  card.dataset.questionItemId=itemId;
  if(['answered','skipped'].includes(record?.status)){card.append(el('strong',record.status==='skipped'?'질문을 건너뛰었습니다':'답변이 전달되었습니다'));return card;}
  if(!record&&state.historyMode){card.replaceChildren(el('strong','이전 대화의 질문'));for(const q of questions)card.append(el('p',q.title||q.question));return card;}
  const dismissNotice=()=>{if(profileId!==connectionStore.activeId)return;const q=v03.questionStates.get(key);window.RemoteNative?.dismissQuestionNotification?.(profileId,threadId,q?.id||'question:'+threadId+':'+itemId);};
  card.dismissNotice=dismissNotice;
  card.addEventListener('focusin',dismissNotice,{once:true});card.addEventListener('change',dismissNotice,{once:true});
  const drafts=v03.questionDrafts[key]||{answerId:uuid(),answers:questions.map(()=>''),choices:questions.map(()=>null)};v03.questionDrafts[key]=drafts;
  drafts.secrets=questions.map(q=>!!q.isSecret);
  const preview=action('질문에 답변하기 · '+questions.length+'개',()=>openQuestionEditor(itemId),'question-open');
  preview.setAttribute('aria-expanded','false');
  const form=el('div',undefined,'question-form'),head=el('div',undefined,'question-editor-head');
  const back=action('‹',()=>closeQuestionEditor(true),'icon question-back');back.setAttribute('aria-label','대화로 돌아가기');
  const heading=el('div');heading.append(el('strong','답변 작성'),el('small','질문 '+questions.length+'개'));
  head.append(back,heading);
  const fields=el('div',undefined,'question-fields'),footer=el('div',undefined,'question-footer');
  form.append(head,fields,footer);card.append(preview,form);
  const inputs=[];
  questions.forEach((q,i)=>{
    const field=el('fieldset'),legend=el('legend',q.title||q.question);field.append(legend);
    const input=el(q.isSecret?'input':'textarea');if(q.isSecret)input.type='password';else input.rows=2;input.placeholder='직접 입력';input.value=drafts.answers[i]||'';input.setAttribute('aria-label',(q.title||q.question)+' 직접 입력');
    const options=(q.options||[]).map(o=>typeof o==='string'?{label:o}:o);
    options.forEach((o,index)=>{const label=el('label',undefined,'question-option'),radio=el('input');radio.type='radio';radio.name='question-'+itemId+'-'+i;radio.value=o.label;radio.checked=drafts.choices[i]===index;
      const text=el('span');text.append(el('strong',o.label));if(o.description)text.append(el('small',o.description));label.append(radio,text);radio.onchange=()=>{drafts.choices[i]=index;drafts.answers[i]=o.label;input.value='';};field.append(label);});
    input.oninput=()=>{drafts.answers[i]=input.value;drafts.choices[i]=null;for(const radio of field.querySelectorAll('input[type=radio]'))radio.checked=false;};field.append(input);fields.append(field);inputs.push(input);
  });
  const error=el('p','', 'inline-error hidden');
  async function sendAnswer(skip=false){
    error.classList.add('hidden');submit.disabled=true;skipButton.disabled=true;
    try{
      const answers=drafts.answers.map(a=>a.trim());const missing=answers.findIndex(a=>!a);
      if(!skip&&missing!==-1){inputs[missing]?.focus();throw new Error('각 질문에서 선택하거나 직접 입력해 주세요.');}
      if(!state.online)throw new Error('연결 후 답변을 전송할 수 있습니다. 입력은 유지됩니다.');
      if(threadId!==state.currentId||profileId!==connectionStore.activeId)throw new Error('질문이 있는 대화에서 답변해 주세요.');
      const result=await rpc('bridge/question/answer',{threadId,itemId,...skip?{skip:true}:{answers},answerId:drafts.answerId,settings:settingsSnapshot()});
      if(threadId!==state.currentId||profileId!==connectionStore.activeId)return;
      dismissNotice();v03.questionStates.set(key,{...record,status:result.status|| (skip?'skipped':'answered')});delete v03.questionDrafts[key];saveQuestionDrafts();renderApprovals();scheduleRender();
    }catch(e){error.textContent=e.message;error.classList.remove('hidden');}finally{submit.disabled=false;skipButton.disabled=false;}
  }
  const submit=action('답변 보내기',()=>sendAnswer(),'primary'),skipButton=action('건너뛰기',()=>sendAnswer(true),'ghost question-skip');
  skipButton.title='답변 없이 질문을 닫습니다';
  const buttons=el('div',undefined,'question-footer-actions');buttons.append(submit,skipButton);footer.append(error,buttons);
  card.addEventListener('input',saveQuestionDrafts);card.addEventListener('change',saveQuestionDrafts);
  return card;
}
function saveQuestionDrafts(){persist('remote.questionDrafts',Object.fromEntries(Object.entries(v03.questionDrafts).map(([key,d])=>[key,{...d,answers:d.answers.map((a,i)=>d.secrets?.[i]?'':a),choices:d.choices.map((a,i)=>d.secrets?.[i]?null:a)}])));}

async function mediaBlob(media,onProgress=()=>{},limit=Infinity) {
  if(media.url){const response=await fetch(media.url);if(!response.ok)throw new Error('파일을 불러오지 못했습니다.');return response.blob();}
  const info=await rpc('bridge/media/info',{id:media.id}),chunks=[];let offset=0;
  if (info.size > limit) throw new Error('미리보기는 2MB 이하 문서를 지원합니다.');
  while(offset<info.size){
    if(!state.online)throw new Error('연결이 끊겼습니다. 다시 누르면 파일을 불러옵니다.');
    const chunk=await mediaChunk(media.id,offset);
    if(chunk.offset!==offset||chunk.nextOffset<=offset)throw new Error('파일 전송 위치를 확인하지 못했습니다.');
    const binary=atob(chunk.data),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));chunks.push(bytes);offset=chunk.nextOffset;onProgress(offset/info.size);
  }
  return new Blob(chunks,{type:info.mime});
}
async function mediaChunk(id,offset) {
  for(let attempt=0;;attempt++)try{return await rpc('bridge/media/chunk',{id,offset});}
  catch(e){if(attempt>=3||!/(연결|재시작|초과|reconnect|timed out|restarted)/i.test(e.message))throw e;const end=Date.now()+20000;while(!state.online&&Date.now()<end)await new Promise(r=>setTimeout(r,300));if(!state.online)throw e;}
}
async function mediaObject(media) {
  const key=media.id||media.url;if(v03.objects.has(key))return v03.objects.get(key).url;
  if(v03.loading.has(key))return v03.loading.get(key);
  const promise=mediaBlob(media).then(blob=>{
    const url=URL.createObjectURL(blob);v03.objects.set(key,{url,size:blob.size});
    let size=[...v03.objects.values()].reduce((sum,m)=>sum+m.size,0);
    while(v03.objects.size>20||size>40*1024*1024){const oldest=v03.objects.keys().next().value;if(oldest===key)break;const old=v03.objects.get(oldest);size-=old.size;URL.revokeObjectURL(old.url);v03.objects.delete(oldest);}
    return url;
  }).finally(()=>v03.loading.delete(key));v03.loading.set(key,promise);return promise;
}
async function downloadMedia(media,button) {
  if(v03.downloads.has(media.id))return;v03.downloads.add(media.id);const original=button?.textContent;if(button)button.disabled=true;
  let downloadId;
  try{
    if(media.url&&window.RemoteNative){window.RemoteNative.openExternal(media.url);return;}
    if(window.RemoteNative){
      const info=await rpc('bridge/media/info',{id:media.id});downloadId=window.RemoteNative.beginDownload(info.name,info.mime);
      if(!downloadId)throw new Error('다른 파일 저장을 먼저 완료해 주세요.');let offset=0;
      while(offset<info.size){const chunk=await mediaChunk(media.id,offset);if(chunk.offset!==offset||chunk.nextOffset<=offset)throw new Error('파일 전송 위치가 올바르지 않습니다.');if(!window.RemoteNative.appendDownload(downloadId,offset,chunk.data))throw new Error('휴대폰에 파일을 저장하지 못했습니다.');offset=chunk.nextOffset;if(button)button.textContent=Math.round(offset/info.size*100)+'%';}
      window.RemoteNative.finishDownload(downloadId);downloadId=null;
    }else{const blob=await mediaBlob(media,p=>{if(button)button.textContent=Math.round(p*100)+'%';});const a=el('a');a.href=URL.createObjectURL(blob);a.download=media.name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),10000);}
  }catch(e){banner(e.message);}finally{if(downloadId)window.RemoteNative?.cancelDownload(downloadId);v03.downloads.delete(media.id);if(button){button.textContent=original;button.disabled=false;}}
}
function closeMedia() {
  v03.mediaRequest=(v03.mediaRequest||0)+1;v03.mediaViewer?.destroy();v03.mediaViewer=null;
  const overlay=$('mediaOverlay');if(!overlay)return;overlay.classList.add('hidden');for(const n of overlay.querySelectorAll('audio,video'))n.pause();$('mediaContent').replaceChildren();
}
async function showMedia(media) {
  closeMenus();const request=++v03.mediaRequest,overlay=$('mediaOverlay'),content=$('mediaContent');overlay.classList.remove('hidden');content.classList.remove('document-view');content.replaceChildren(el('p','불러오는 중…'));$('mediaTitle').textContent=media.name||'결과';
  const save=$('mediaDownload');save.onclick=()=>downloadMedia(media,save);
  try{
    if (media.kind === 'file' && /\.(?:md|markdown|mdx|txt|text|json|ya?ml|toml|xml|html?|css|csv|log|[cm]?js|jsx|tsx?|py|sh|ps1|sql)$/i.test(media.name || '')) {
      if (media.size > 2 * 1024 * 1024) { content.replaceChildren(el('p', '2MB보다 큰 문서는 저장한 뒤 열어 주세요.')); return; }
      let blob;
      if (media.url) {
        const response = await fetch(media.url); if (!response.ok || !response.body) throw new Error('문서를 불러오지 못했습니다.');
        const reader = response.body.getReader(), chunks = []; let size = 0;
        try { for (;;) { const part = await reader.read(); if (part.done) break; size += part.value.byteLength; if (size > 2 * 1024 * 1024) throw new Error('미리보기는 2MB 이하 문서를 지원합니다.'); chunks.push(part.value); } }
        finally { await reader.cancel().catch(() => {}); }
        blob = new Blob(chunks);
      } else blob = await mediaBlob(media, undefined, 2 * 1024 * 1024);
      if (overlay.classList.contains('hidden') || request !== v03.mediaRequest) return;
      const text = await blob.text(); if (request !== v03.mediaRequest) return;
      const document = el('div', undefined, 'file-preview'), toolbar = el('div', undefined, 'file-preview-toolbar'); document.setAttribute('role', 'document');
      const markdown = /\.(?:md|markdown|mdx)$/i.test(media.name); let source = false;
      const draw = () => { if (markdown && !source) renderMarkdown(document, text); else { document.classList.remove('markdown'); document.replaceChildren(el('pre', text, 'file-source')); } };
      if (markdown) { const toggle = action('원문 보기', () => { source = !source; toggle.textContent = source ? 'Markdown 보기' : '원문 보기'; toggle.setAttribute('aria-pressed', String(source)); draw(); }, 'ghost'); toolbar.append(toggle); }
      draw(); content.classList.add('document-view'); content.replaceChildren(toolbar, document); return;
    }
    if(media.kind==='file'||media.size>32*1024*1024){content.replaceChildren(el('p',media.size>32*1024*1024?'큰 파일은 저장한 뒤 휴대폰의 앱에서 열어 주세요.':'파일을 저장한 뒤 휴대폰의 앱에서 열 수 있습니다.'));return;}
    const url=media.url||await mediaObject(media);if(overlay.classList.contains('hidden')||request!==v03.mediaRequest)return;
    const node=el(media.kind==='video'?'video':media.kind==='audio'?'audio':'img');node.src=url;
    if(node.tagName==='IMG'){node.alt=media.name;v03.mediaViewer=createImageViewer(node);content.replaceChildren(v03.mediaViewer.element);}
    else{node.controls=true;node.preload='metadata';content.replaceChildren(node);}
  }catch(e){if(request===v03.mediaRequest)content.replaceChildren(el('p',e.message),action('다시 시도',()=>showMedia(media),'ghost'));}
}
function releaseItemMedia(article) { for(const card of article.querySelectorAll('.media-card'))v03.mediaObserver?.unobserve(card); }
function observeMedia(card, load) {
  if(!v03.mediaObserver)v03.mediaObserver=new IntersectionObserver(entries=>{
    for(const entry of entries)if(entry.isIntersecting){v03.mediaObserver.unobserve(entry.target);entry.target.loadMedia?.();entry.target.loadMedia=null;}
  },{root:$('transcript'),rootMargin:'250px'});
  card.loadMedia=load;v03.mediaObserver.observe(card);
}
function collapsedImage(media,item) {
  return media.kind==='image'&&(media.presentation?media.presentation==='attachment':!['userMessage','agentMessage','imageGeneration'].includes(item.type));
}
function renderItemExtras(article,entry) {
  const item=entry.item||{},groupKey=connectionStore.activeId+':'+state.currentId+':'+item.id,expanded=!!v03.imageGroups.get(groupKey),copyable=item.type==='agentMessage'&&item.phase!=='commentary'&&!!item.text?.trim(),key=JSON.stringify([state.currentId,state.historyMode,item.media,item.questions,v03.questionStates.get(state.currentId+':'+item.id)?.status,copyable,expanded]);
  if(article.extrasKey===key)return;article.extrasKey=key;releaseItemMedia(article);article.querySelector('.item-extras')?.remove();
  if(!item.media?.length&&!item.questions?.length&&!copyable)return;
  const root=el('div',undefined,'item-extras');
  const renderMedia=media=>{
    const card=el('div',undefined,'media-card'),open=action('',()=>showMedia(media),'media-open');
    if(media.kind==='image'){
      const image=el('img');image.alt=media.name;image.loading='lazy';image.decoding='async';open.append(image);
      const load=()=>{if(!card.isConnected)return;card.retry=null;open.replaceChildren(image);if(media.size>32*1024*1024){open.replaceChildren(el('span','큰 이미지 · 저장해서 보기'));return;}if(media.url)image.src=media.url;else mediaObject(media).then(url=>{if(card.isConnected){image.src=url;requestAnimationFrame(()=>{if(v03.pinned&&!state.historyMode)$('transcript').scrollTop=$('transcript').scrollHeight;});}}).catch(()=>{image.remove();card.retry=load;open.replaceChildren(el('span','이미지 보기 · 눌러 다시 불러오기'));});};
      observeMedia(card,load);
    }else open.append(el('span',media.kind==='video'?'▶ 동영상 보기':media.kind==='audio'?'♫ 오디오 듣기':'▤ 파일 열기'));
    const info=el('div',undefined,'media-info'),save=action('저장',()=>downloadMedia(media,save),'ghost');info.append(el('span',media.name),save);card.append(open,info);return card;
  };
  const references=(item.media||[]).filter(m=>collapsedImage(m,item));
  for(const media of item.media||[])if(!collapsedImage(media,item))root.append(renderMedia(media));
  if(references.length){
    const group=el('div',undefined,'image-attachment-group'),images=el('div',undefined,'image-attachment-content');images.id='images-'+uuid();images.classList.toggle('hidden',!expanded);
    const toggle=action('▧ 이미지 '+references.length+'개 첨부됨 '+(expanded?'⌃':'⌄'),()=>{
      v03.imageGroups.set(groupKey,!expanded);while(v03.imageGroups.size>1000)v03.imageGroups.delete(v03.imageGroups.keys().next().value);
      renderItemExtras(article,entry);
    },'image-attachment-toggle');toggle.setAttribute('aria-expanded',String(expanded));toggle.setAttribute('aria-controls',images.id);
    // Do not create thumbnails or download image bytes until the user opens it.
    if(expanded)for(const media of references)images.append(renderMedia(media));
    group.append(toggle,images);root.append(group);
  }
  if(item.questions?.length){
    const q=v03.questionStates.get(state.currentId+':'+item.id);
    // Pending cards have one stable home outside the refreshed transcript.
    if(q&&!['answered','skipped'].includes(q.status))root.append(action('질문에 답변하기',()=>openQuestionEditor(item.id),'ghost'));
    else root.append(questionCard(item.id,item.questions,entry.turnId));
  }
  if(copyable){
    const actions=el('div',undefined,'reply-actions'),copy=action('⧉ 답변 복사',async()=>{
      const text=state.items.find(e=>e.item.id===item.id)?.item.text||'';
      if(window.RemoteNative)window.RemoteNative.copyText(text);else await navigator.clipboard.writeText(text);
      copy.textContent='✓ 복사됨';setTimeout(()=>{if(copy.isConnected)copy.textContent='⧉ 답변 복사';},1800);
    },'reply-copy');copy.setAttribute('aria-label','답변 전체 복사');actions.append(copy);root.append(actions);
  }
  article.append(root);
}
function retryVisibleMedia(){for(const card of document.querySelectorAll('.media-card'))if(card.retry&&card.getBoundingClientRect().bottom>0)card.retry();}

function positionSendMode() {
  const chat = $('chatView').getBoundingClientRect(), composer = $('composer').getBoundingClientRect();
  $('chatView').style.setProperty('--composer-offset', Math.max(0, chat.bottom - composer.top) + 'px');
  $('chatView').style.setProperty('--send-mode-width', Math.ceil($('followupRow').getBoundingClientRect().width) + 'px');
  $('chatView').style.setProperty('--composer-height', Math.ceil(composer.height) + 'px');
}
function initV03UI() {
  initConversationMenu();
  const neonToggle=el('label',undefined,'toggle-row'),neonInput=el('input');neonInput.type='checkbox';neonInput.checked=saved('remote.goalNeonAnimation')!==false;neonInput.id='goalNeonAnimation';
  neonToggle.append(el('span','진행 중 목표의 네온 애니메이션'),neonInput);$('themeChoices').after(neonToggle);
  neonInput.onchange=()=>{persist('remote.goalNeonAnimation',neonInput.checked);refreshGoalNeon();};
  $('chatView').append($('followupRow'));
  const sendModeObserver = new ResizeObserver(positionSendMode);
  sendModeObserver.observe($('composer')); sendModeObserver.observe($('chatView')); sendModeObserver.observe($('followupRow'));
  positionSendMode();
  $('app').append($('commandHints'));
  const mark=$('emptyState').querySelector('.mark');const brand=el('img');brand.src='app-icon.png';brand.alt='Pocket Remote';mark.replaceChildren(brand);
  const questionToggle=el('label',undefined,'toggle-row');questionToggle.append(el('span','질문·선택지 답변 요청'));const questionInput=el('input');questionInput.id='notifyQuestions';questionInput.type='checkbox';questionToggle.append(questionInput);$('notificationStatus').before(questionToggle);
  v03.favoriteThreads=saved('remote.favoriteThreads')||{};v03.favoriteProjects=saved('remote.favoriteProjects')||{};v03.collapsedProjects=saved('remote.collapsedProjects')||{};v03.questionDrafts=saved('remote.questionDrafts')||{};
  Object.assign(v03.notificationSettings,saved('remote.notifications')||{});
  $('headerNew').onclick=statusPopup;$('closeStatus').onclick=closeStatus;$('statusOverlay').onclick=e=>{if(e.target===$('statusOverlay'))closeStatus();};$('sidebarBackdrop').onclick=closeSidebar;
  for(const [id,key]of [['notifyEnabled','enabled'],['notifyProgress','progress'],['notifyCompletion','completion'],['notifyQuestions','questions']])if($(id))$(id).onchange=()=>{v03.notificationSettings[key]=$(id).checked;persist('remote.notifications',v03.notificationSettings);configureNativeNotifications();};
  $('androidSettings').onclick=()=>window.RemoteNative?.openAndroidSettings();
  $('transcript').addEventListener('scroll',()=>{
    if(v03.ignoreScroll||v03.questionEditor)return;
    const root=$('transcript'),previous=v03.lastScrollTop??root.scrollTop;
    v03.lastScrollTop=root.scrollTop;rememberScroll();
    if(state.historyLoading||state.openingThread||window.userMessageNavigation?.isNavigating)return;
    if(root.scrollTop<=previous) {
      if(root.scrollTop<historyWarmDistance(root))warmHistoryPage('older');
      if(root.scrollTop<historyLoadDistance(root))loadOlderItems();
    } else if(state.historyMode) {
      const remaining=root.scrollHeight-root.scrollTop-root.clientHeight;
      if(remaining<historyWarmDistance(root))warmHistoryPage('newer');
      if(remaining<historyLoadDistance(root))loadNewerItems();
    }
  },{passive:true});
  $('messageInput').addEventListener('focus',()=>{v03.keyboardPin=v03.pinned&&!state.historyMode;});$('messageInput').addEventListener('blur',()=>{v03.keyboardPin=false;});$('transcript').addEventListener('pointerdown',()=>{v03.keyboardPin=false;},{passive:true});
  new ResizeObserver(maintainViewport).observe($('transcript'));window.visualViewport?.addEventListener('resize',maintainViewport);
  document.addEventListener('focusin',maintainViewport);document.addEventListener('focusout',()=>requestAnimationFrame(maintainViewport));
  document.addEventListener('pointerdown',e=>{if(!$('commandHints').contains(e.target)&&e.target!==$('messageInput'))dismissPluginHints();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')window.remoteCloseMenu();});
  const overlay=el('div',undefined,'overlay hidden');overlay.id='mediaOverlay';const sheet=el('section',undefined,'sheet media-sheet'),head=el('div',undefined,'sheet-head'),title=el('h2');title.id='mediaTitle';sheet.setAttribute('role','dialog');sheet.setAttribute('aria-label','첨부 파일 상세 보기');sheet.setAttribute('aria-modal','true');const close=action('✕',closeMedia,'icon');close.setAttribute('aria-label','첨부 상세 보기 닫기');head.append(title,close);const content=el('div');content.id='mediaContent';const save=el('button','저장','primary full');save.id='mediaDownload';sheet.append(head,content,save);overlay.append(sheet);overlay.onclick=e=>{if(e.target===overlay)closeMedia();};$('app').append(overlay);
  setInterval(refreshStatus,3000);configureNativeNotifications();rememberScroll();
}

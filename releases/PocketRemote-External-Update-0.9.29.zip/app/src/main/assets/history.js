const HISTORY_PAGE_SIZE = 60;
const HISTORY_WINDOW_SIZE = 240;
const THREAD_PAGE_SIZE = 45;

// One page in each direction, shared by speculative and visible requests.
// A cached reply never changes the visible window until explicitly consumed.
class HistoryPageReader {
  constructor({ now = Date.now, ttl = 15000, maxBytes = 4 * 1024 * 1024 } = {}) { this.now = now; this.ttl = ttl; this.maxBytes = maxBytes; this.pages = new Map(); }
  bind(socket, thread, generation) {
    if (this.socket !== socket || this.thread !== thread || this.generation !== generation) { this.pages.clear(); this.socket = socket; this.thread = thread; this.generation = generation; }
  }
  read(direction, cursor, fetchPage, consume = false) {
    const key = JSON.stringify([direction, cursor]); let entry = this.pages.get(key);
    if (entry && entry.ready && this.now() - entry.at > this.ttl) { this.pages.delete(key); entry = null; }
    if (!entry) {
      entry = { at: this.now(), ready: false };
      entry.promise = Promise.resolve().then(fetchPage).then(value => {
        entry.ready = true; entry.at = this.now();
        if (JSON.stringify(value).length * 2 > this.maxBytes && this.pages.get(key) === entry) this.pages.delete(key);
        return value;
      }).catch(error => { if (this.pages.get(key) === entry) this.pages.delete(key); throw error; });
      this.pages.set(key, entry);
      while (this.pages.size > 2) this.pages.delete(this.pages.keys().next().value);
    }
    if (!consume) return entry.promise;
    return entry.promise.finally(() => { if (this.pages.get(key) === entry) this.pages.delete(key); });
  }
}
const historyLoadDistance = root => Math.min(1000, Math.max(240, root.clientHeight * 0.75));
const historyWarmDistance = root => Math.max(600, root.clientHeight * 1.75);

// Keep response cursors with each visible page. Text outside this window is
// released; either edge can be fetched again with the opposite direction.
class HistoryWindow {
  constructor() { this.pages = []; }
  reset(page, items = (page.data || []).slice().reverse(), newer = null) {
    this.pages = [{ items: items.slice(-HISTORY_WINDOW_SIZE), older: page.nextCursor || null, newer }];
  }
  get olderCursor() { return this.pages[0]?.older || null; }
  get newerCursor() { return this.pages.at(-1)?.newer || null; }
  get items() { return this.pages.flatMap(page => page.items); }
  accept(page, direction, currentItems, overrides = new Map()) {
    const current = new Map(currentItems.map(entry => [entry.item.id, entry]));
    for (const part of this.pages) part.items = part.items.map(entry => current.get(entry.item.id) || entry);
    const seen = new Set(this.items.map(entry => entry.item.id));
    const items = (direction === 'older' ? (page.data || []).slice().reverse() : page.data || [])
      .filter(entry => !seen.has(entry.item.id)).map(entry => overrides.get(entry.item.id) || entry);
    const next = page.nextCursor || null;
    if (!items.length) {
      const edge = direction === 'older' ? this.pages[0] : this.pages.at(-1);
      if (edge) edge[direction === 'older' ? 'older' : 'newer'] = next;
      return;
    }
    const part = { items, older: direction === 'older' ? next : page.backwardsCursor || null, newer: direction === 'older' ? page.backwardsCursor || null : next };
    if (direction === 'older') this.pages.unshift(part); else this.pages.push(part);
    while (this.pages.length > 1 && this.items.length > HISTORY_WINDOW_SIZE) {
      if (direction === 'older') this.pages.pop(); else this.pages.shift();
    }
  }
}

// Account mutations are opt-in and never part of status polling.
class ResetCreditsController {
  constructor(options) {
    this.options = options; this.count = null; this.accountId = null; this.credits = [];
    this.selectedId = ''; this.armed = false; this.busy = false; this.confirming = false; this.reading = false; this.readAt = 0; this.note = '';
  }
  changed() { this.options.changed?.(this); }
  selected() { return this.credits.find(c => c.id === this.selectedId && c.status === 'available' && (c.expiresAt == null || c.expiresAt * 1000 > Date.now())); }
  hasCredits() { return this.count > 0 && this.credits.some(c => c.status === 'available' && (c.expiresAt == null || c.expiresAt * 1000 > Date.now())); }
  canArm() { return this.options.online() && this.hasCredits() && !this.busy && !this.confirming && !this.reading; }
  canSelect() { return this.armed && this.canArm(); }
  canUse() { return this.options.online() && this.count > 0 && !!this.selected() && this.armed && !this.busy && !this.confirming && !this.reading; }
  disarm() { this.armed = false; this.selectedId = ''; this.options.cancelConfirmation?.(); this.changed(); }
  arm(value) { if (!value || !this.canArm()) { this.disarm(); return; } this.armed = true; this.changed(); }
  select(id) { if (!this.canSelect()) return; this.selectedId = this.credits.some(c => c.id === id && c.status === 'available' && (c.expiresAt == null || c.expiresAt * 1000 > Date.now())) ? id : ''; this.changed(); }
  async refresh(force = false) {
    if (this.reading || (!force && this.readAt && Date.now() - this.readAt < 30000)) return;
    if (!this.options.online()) { this.count = null; this.disarm(); return; }
    this.reading = true; this.changed();
    try {
      const data = await this.options.read(force);
      const summary = data?.rateLimitResetCredits, count = summary?.availableCount;
      this.count = Number.isSafeInteger(count) && count >= 0 ? count : null;
      if (this.accountId !== (data?.accountId || null)) this.disarm();
      this.accountId = data?.accountId || null;
      const oldCredit = this.selected();
      this.credits = Array.isArray(summary?.credits) ? summary.credits.filter(c => typeof c?.id === 'string' && c.id.trim() && c.status === 'available').slice().sort((a, b) => (a.expiresAt ?? Infinity) - (b.expiresAt ?? Infinity)) : [];
      const newCredit = this.selected();
      if (this.selectedId && (!newCredit || oldCredit?.expiresAt !== newCredit.expiresAt)) this.disarm();
      this.readAt = Date.now();
      if (!this.count || !this.credits.some(c => c.expiresAt == null || c.expiresAt * 1000 > Date.now())) this.disarm();
    } catch {
      this.count = null; this.credits = []; this.disarm(); this.readAt = Date.now();
    } finally { this.reading = false; this.changed(); }
  }
  async apply() {
    if (!this.canUse()) return false;
    const accountId = this.accountId, credit = this.selected();
    this.confirming = true; this.changed();
    let confirmed = false;
    try { confirmed = await this.options.confirm(this); }
    catch { this.note = '확인 창을 열지 못했습니다. 리셋권을 사용하지 않았습니다.'; }
    finally { this.confirming = false; this.changed(); }
    if (!confirmed || accountId !== this.accountId || credit.id !== this.selectedId || credit.expiresAt !== this.selected()?.expiresAt || !this.canUse()) { this.disarm(); return false; }
    this.busy = true; this.armed = false; this.selectedId = ''; this.note = '리셋권 사용 결과를 확인하는 중…'; this.changed();
    try {
      const attempts = this.options.getAttempt() || {};
      let attempt = Object.hasOwn(attempts, credit.id) ? attempts[credit.id] : null;
      if (!attempt || attempt.accountId !== accountId || !attempt.idempotencyKey) {
        attempt = { accountId, creditId: credit.id, idempotencyKey: this.options.uuid() };
        if (!this.options.saveAttempt({ ...attempts, [credit.id]: attempt })) throw new Error('사용 시도를 저장하지 못했습니다. 리셋권을 사용하지 않았습니다.');
      }
      const result = await this.options.consume({ idempotencyKey: attempt.idempotencyKey, creditId: credit.id });
      const labels = { reset: '리셋권 1개를 사용했습니다.', alreadyRedeemed: '이 사용 요청은 이미 적용되었습니다.', nothingToReset: '현재 초기화할 수 있는 사용 한도가 없습니다.', noCredit: '사용 가능한 리셋권이 없습니다.' };
      if (!Object.hasOwn(labels, result?.outcome)) throw new Error('사용 결과가 불확실합니다. 자동으로 재전송하지 않습니다.');
      const remaining = { ...(this.options.getAttempt() || {}) }; delete remaining[credit.id];
      this.options.saveAttempt(Object.keys(remaining).length ? remaining : null); this.note = labels[result.outcome];
      await this.refresh(true);
      return true;
    } catch (error) {
      this.note = error.message + ' 잔여 수를 새로 확인해 주세요. 재시도 시 같은 사용 요청을 확인합니다.';
      this.count = null; this.readAt = 0;
      return false;
    } finally { this.busy = false; this.changed(); }
  }
}

const pocketResetCredits = (() => {
  let view = null, controller = null, connection = null, cancel = null, disclosure = null;
  function confirmUse(current) {
    return new Promise(resolve => {
      const dialog = document.createElement('dialog'); dialog.className = 'reset-confirm';
      dialog.setAttribute('aria-labelledby', 'reset-confirm-title'); dialog.setAttribute('aria-describedby', 'reset-confirm-description');
      const title = el('h2', '리셋권을 사용할까요?'); title.id = 'reset-confirm-title';
      const text = el('p', '연결된 PC의 Codex 계정에서 리셋권 1개를 사용합니다. 적용한 뒤에는 되돌릴 수 없습니다.'); text.id = 'reset-confirm-description';
      const credit = current.selected();
      const selected = el('p', credit.title || '선택한 리셋권', 'reset-confirm-selected');
      const expiry = el('p', '만료: ' + expiryLabel(credit.expiresAt), 'reset-confirm-count');
      const remaining = el('p', '현재 보유: ' + current.count + '개', 'reset-confirm-count');
      const actions = el('div', undefined, 'reset-confirm-actions');
      const finish = yes => { if (!dialog.isConnected) return; dialog.close(); dialog.remove(); cancel = null; resolve(yes); };
      const back = action('취소', () => finish(false), 'ghost'); back.autofocus = true;
      const accept = action('1개 사용하기', () => finish(true), 'primary'); actions.append(accept, back);
      dialog.append(title, text, selected, expiry, remaining, actions); document.body.append(dialog);
      dialog.addEventListener('cancel', event => { event.preventDefault(); finish(false); });
      dialog.addEventListener('click', event => { if (event.target === dialog) { const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) finish(false); } });
      cancel = () => finish(false); dialog.showModal(); back.focus();
    });
  }
  function expiryLabel(value) { return value === null ? '만료일 없음' : typeof value === 'number' && Number.isFinite(value) && value > 0 ? new Date(value * 1000).toLocaleString('ko-KR') : '만료일시 정보 없음'; }
  function mount(root) {
    if (!controller || connection !== state.socket) {
      controller?.disarm(); connection = state.socket;
      const socket = state.socket;
      view = el('section', undefined, 'status-section reset-credits'); view.setAttribute('aria-label', '계정 리셋권');
      const title = el('small', '리셋권'), count = el('strong', '조회 중…'), detail = el('p'), list = el('div', undefined, 'reset-credit-list'); list.setAttribute('role', 'radiogroup'); list.setAttribute('aria-label', '사용할 리셋권');
      disclosure = el('details', undefined, 'reset-credit-details');
      const summary = el('summary', undefined, 'reset-credit-summary'), expiry = el('span', undefined, 'reset-credit-expiry'), expiryTime = el('time', '조회 중…'), body = el('div', undefined, 'reset-credit-body');
      summary.setAttribute('role', 'button'); summary.setAttribute('aria-expanded', 'false');
      expiry.append(el('span', '빠른 만료'), expiryTime);
      const chevron = el('span', '⌄', 'reset-credit-chevron'); chevron.setAttribute('aria-hidden', 'true');
      summary.append(count, expiry, chevron); disclosure.append(summary, body);
      const label = el('label', undefined, 'reset-arm'), checkbox = el('input'); checkbox.type = 'checkbox';
      label.append(checkbox, el('span', '리셋권 사용'));
      const use = action('리셋권 1개 사용', () => controller.apply(), 'primary'), refresh = action('잔여 수 새로고침', () => controller.refresh(true), 'ghost');
      const buttons = el('div', undefined, 'reset-credit-actions'); buttons.append(use, refresh);
      const note = el('p', '', 'reset-credit-result'); note.setAttribute('role', 'status');
      body.append(detail, label, list, buttons, note); view.append(title, disclosure);
      controller = new ResetCreditsController({
        online: () => state.socket === socket && state.online && !state.leaving,
        read: force => accountLimits.get(force),
        consume: params => rpc('account/rateLimitResetCredit/consume', params),
        getAttempt: () => saved('remote.resetAttempt'), saveAttempt: value => persist('remote.resetAttempt', value), uuid,
        confirm: confirmUse, cancelConfirmation: () => cancel?.(),
        changed(current) {
          count.textContent = current.count === null ? current.reading ? '조회 중…' : '정보 없음' : '보유 ' + current.count + '개';
          const firstExpiry = current.credits.find(c => typeof c.expiresAt === 'number' && Number.isFinite(c.expiresAt) && c.expiresAt * 1000 > Date.now());
          expiryTime.textContent = firstExpiry ? new Date(firstExpiry.expiresAt * 1000).toLocaleString('ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }) : current.reading && current.count === null ? '조회 중…' : current.credits.length && current.credits.every(c => c.expiresAt === null) ? '만료일 없음' : '정보 없음';
          if (firstExpiry) expiryTime.dateTime = new Date(firstExpiry.expiresAt * 1000).toISOString(); else expiryTime.removeAttribute('datetime');
          detail.textContent = current.count === null ? 'PC 계정에서 잔여 수를 확인할 수 없습니다.' : !current.count ? '사용 가능한 리셋권이 없습니다.' : !current.credits.length ? '리셋권 상세 목록을 제공하지 않아 선택할 수 없습니다.' : current.count > current.credits.length ? '계정에서 제공한 ' + current.credits.length + '개를 표시합니다.' : '';
          detail.classList.toggle('hidden', !detail.textContent);
          const listKey = JSON.stringify(current.credits);
          if (list.dataset.key !== listKey) {
            list.dataset.key = listKey; list.replaceChildren();
            current.credits.forEach((credit, index) => {
              const row = el('label', undefined, 'reset-credit-option'), radio = el('input'); radio.type = 'radio'; radio.name = 'reset-credit'; radio.value = credit.id;
              const text = el('span'), name = el('b', credit.title || '리셋권 ' + (index + 1)), expires = el('span', '만료: ' + expiryLabel(credit.expiresAt));
              text.append(name, expires); row.append(radio, text); radio.onchange = () => current.select(credit.id); list.append(row);
            });
          }
          for (const radio of list.querySelectorAll('input')) { const credit = current.credits.find(c => c.id === radio.value); radio.checked = radio.value === current.selectedId; radio.disabled = !current.canSelect() || (credit.expiresAt != null && credit.expiresAt * 1000 <= Date.now()); }
          checkbox.checked = current.armed; checkbox.disabled = !current.canArm();
          use.disabled = !current.canUse(); use.textContent = current.busy ? '사용 결과 확인 중…' : '리셋권 1개 사용';
          use.classList.toggle('hidden', !current.hasCredits() && !current.busy);
          refresh.disabled = !current.options.online() || current.busy || current.reading || current.confirming;
          note.textContent = current.note;
        }
      });
      const ownController = controller;
      checkbox.onchange = () => ownController.arm(checkbox.checked);
      const ownDisclosure = disclosure;
      disclosure.addEventListener('toggle', () => { summary.setAttribute('aria-expanded', String(ownDisclosure.open)); if (!ownDisclosure.open) ownController.disarm(); });
    }
    if (view) root.append(view);
    controller?.refresh();
  }
  return { mount, close() { controller?.disarm(); if (disclosure) disclosure.open = false; }, refresh() { if (controller && !$('statusOverlay').classList.contains('hidden')) controller.refresh(true); } };
})();

class MessagePress {
  constructor(open, schedule = (fn, ms) => setTimeout(fn, ms), clear = id => clearTimeout(id), feedback = () => {}) { this.open = open; this.schedule = schedule; this.clear = clear; this.feedback = feedback; }
  cancel() { if (this.timer !== undefined) this.clear(this.timer); this.timer = undefined; const p = this.press; this.press = null; if (p) this.feedback(p.target, false); }
  down(id, x, y, target) {
    if (this.press) { this.cancel(); return; } // Two fingers are never a long press.
    this.press = { id, x, y, target };
    this.feedback(target, true);
    this.timer = this.schedule(() => {
      const p = this.press; this.timer = undefined; this.press = null;
      if (p) { this.feedback(p.target, false); this.open(p.target); }
    }, 550);
  }
  move(id, x, y) { if (this.press?.id === id && Math.hypot(x - this.press.x, y - this.press.y) > 10) this.cancel(); }
  up(id) { if (this.press?.id === id) this.cancel(); }
}

async function copyMessageText(text) {
  if (typeof text !== 'string' || !text.length) throw new Error('복사할 메시지 내용이 없습니다.');
  if (window.RemoteNative?.copyText) { window.RemoteNative.copyText(text); return; }
  if (navigator.clipboard?.writeText) {
    try { await navigator.clipboard.writeText(text); return; } catch {} // HTTP browser fallback.
  }
  const focused = document.activeElement, input = document.createElement('textarea');
  input.value = text; input.readOnly = true; input.style.cssText = 'position:fixed;left:-9999px;top:0';
  document.body.append(input);
  try { input.select(); if (!document.execCommand('copy')) throw new Error('클립보드 복사가 허용되지 않았습니다.'); }
  finally { input.remove(); focused?.focus({ preventScroll: true }); }
}

function addMessageCopyRow(root, text) {
  const button = pickerRow(root, '메시지 복사', text ? '작성한 내용 전체를 복사합니다.' : '텍스트가 없는 메시지입니다.', async () => {
    await copyMessageText(text);
    button.querySelector('strong').textContent = '복사됨';
    button.setAttribute('aria-label', '메시지 복사 · 복사됨');
    let status = root.querySelector('.message-copy-status');
    if (!status) { status = el('p', '', 'message-copy-status connection-note'); status.setAttribute('role', 'status'); root.append(status); }
    status.textContent = '메시지를 클립보드에 복사했습니다.';
  }, { icon: '⧉', disabled: !text });
  return button;
}

function clearCopyMenuSelection() {
  const overlay = $('messageCopyOverlay'), selection = window.getSelection();
  if (overlay && (overlay.contains(selection?.anchorNode) || overlay.contains(selection?.focusNode))) selection.removeAllRanges();
}

let messageCopyAnchor = null;

function closeMessageCopy() {
  const overlay = $('messageCopyOverlay');
  if (!overlay || overlay.classList.contains('hidden')) return;
  const restore = overlay.contains(document.activeElement), article = messageCopyAnchor;
  overlay.classList.add('hidden'); messageCopyAnchor = null;
  article?.removeAttribute('data-message-copy-selected'); article?.setAttribute('aria-expanded', 'false');
  if (restore && article?.isConnected) article.focus({ preventScroll: true });
}

function positionMessageCopy() {
  const overlay = $('messageCopyOverlay');
  if (!overlay || overlay.classList.contains('hidden')) return;
  if (!messageCopyAnchor?.isConnected) { closeMessageCopy(); return; }
  const menu = $('messageCopyMenu'), anchor = messageCopyAnchor.getBoundingClientRect();
  const transcript = (messageCopyAnchor.closest('.dot-content') || $('transcript')).getBoundingClientRect(), viewport = window.visualViewport;
  const left = Math.max(transcript.left, viewport?.offsetLeft || 0) + 12;
  const right = Math.min(transcript.right, (viewport?.offsetLeft || 0) + (viewport?.width || window.innerWidth)) - 12;
  const top = Math.max(transcript.top, viewport?.offsetTop || 0) + 8;
  const bottom = Math.min(transcript.bottom, (viewport?.offsetTop || 0) + (viewport?.height || window.innerHeight)) - 8;
  if (anchor.bottom <= top || anchor.top >= bottom || right <= left || bottom <= top) { closeMessageCopy(); return; }
  menu.style.maxWidth = Math.max(0, right - left) + 'px';
  menu.style.maxHeight = Math.max(0, bottom - top) + 'px';
  const bounds = menu.getBoundingClientRect();
  const y = anchor.bottom + 12 + bounds.height <= bottom ? anchor.bottom + 12 : anchor.top - bounds.height - 12;
  menu.style.left = Math.max(left, Math.min(anchor.right - bounds.width, right - bounds.width)) + 'px';
  menu.style.top = Math.max(top, Math.min(y, bottom - bounds.height)) + 'px';
}

function showMessageCopy(article) {
  closeMenus(); messageCopyAnchor = article;
  article.setAttribute('data-message-copy-selected', 'true'); article.setAttribute('aria-expanded', 'true');
  const overlay = $('messageCopyOverlay'), menu = $('messageCopyMenu'), text = article.bodyNode?.remoteText || '';
  const button = el('button', undefined, 'message-copy-button'); button.type = 'button'; button.disabled = !text;
  button.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="4" y="8" width="12" height="13" rx="3"/><path d="M8 8V6a3 3 0 0 1 3-3h7a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3h-2"/></svg>';
  const label = el('span', '복사'); button.append(label); button.setAttribute('aria-label', text ? '메시지 복사' : '텍스트가 없는 메시지');
  const status = el('p', '', 'message-copy-feedback hidden'); status.setAttribute('role', 'status');
  menu.replaceChildren(button, status);
  button.onclick = async () => {
    button.disabled = true;
    try {
      await copyMessageText(text);
      if (overlay.classList.contains('hidden') || menu.firstChild !== button) return;
      closeMessageCopy();
    } catch (e) {
      if (overlay.classList.contains('hidden') || menu.firstChild !== button) return;
      button.disabled = false;
      status.textContent = e.message; status.className = 'message-copy-feedback'; positionMessageCopy();
    }
  };
  overlay.classList.remove('hidden'); positionMessageCopy(); button.focus({ preventScroll: true });
  clearCopyMenuSelection();
}

function initMessageCopy() {
  const root = $('transcript');
  const overlay = el('div', undefined, 'message-copy-overlay hidden'); overlay.id = 'messageCopyOverlay';
  const menu = el('div', undefined, 'message-copy-menu'); menu.id = 'messageCopyMenu';
  menu.setAttribute('role', 'dialog'); menu.setAttribute('aria-label', '메시지 복사'); menu.setAttribute('aria-modal', 'true');
  overlay.append(menu); $('app').append(overlay);
  overlay.addEventListener('pointerdown', e => { if (e.target === overlay) { e.preventDefault(); closeMessageCopy(); } });
  for (const type of ['selectstart', 'dragstart', 'contextmenu']) overlay.addEventListener(type, e => { e.preventDefault(); clearCopyMenuSelection(); });
  document.addEventListener('selectionchange', clearCopyMenuSelection);
  menu.addEventListener('keydown', e => { if (e.key === 'Tab') { e.preventDefault(); menu.querySelector('button')?.focus({ preventScroll: true }); } });
  window.addEventListener('resize', positionMessageCopy);
  window.visualViewport?.addEventListener('resize', positionMessageCopy);
  window.visualViewport?.addEventListener('scroll', positionMessageCopy);
  registerMessageCopyRoot(root);
}

function registerMessageCopyRoot(root) {
  let suppressClick = false;
  const target = e => {
    if (e.target.closest('a,button,input,textarea,select,.media-card')) return null;
    const article = e.target.closest('.item.userMessage');
    return article && root.contains(article) ? { article, thread: state.currentId, profile: connectionStore.activeId } : null;
  };
  const show = p => {
    if (!p?.article.isConnected || state.leaving || p.thread !== state.currentId || p.profile !== connectionStore.activeId) return false;
    showMessageCopy(p.article);
    return !$('messageCopyOverlay').classList.contains('hidden');
  };
  const press = new MessagePress(p => { suppressClick = true; if (show(p)) window.RemoteNative?.messageLongPressFeedback?.(); }, undefined, undefined, (p, down) => {
    if (down) p.article.setAttribute('data-message-pressed', 'true'); else p.article.removeAttribute('data-message-pressed');
  });
  root.addEventListener('pointerdown', e => {
    const p = target(e);
    if (!p || e.button !== 0) { press.cancel(); return; }
    press.down(e.pointerId, e.clientX, e.clientY, p);
  }, { passive: true });
  window.addEventListener('pointerdown', () => { suppressClick = false; }, true);
  window.addEventListener('pointermove', e => press.move(e.pointerId, e.clientX, e.clientY), { passive: true });
  window.addEventListener('pointerup', e => press.up(e.pointerId), { passive: true });
  window.addEventListener('pointercancel', () => press.cancel(), { passive: true });
  window.addEventListener('blur', () => press.cancel());
  root.addEventListener('scroll', () => { press.cancel(); closeMessageCopy(); }, { passive: true });
  document.addEventListener('visibilitychange', () => { if (document.hidden) { press.cancel(); closeMessageCopy(); } });
  window.addEventListener('click', e => { if (suppressClick) { suppressClick = false; e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  root.addEventListener('contextmenu', e => { const p = target(e); if (p) { e.preventDefault(); press.cancel(); show(p); } });
  root.addEventListener('keydown', e => {
    if (!e.target.matches('.item.userMessage')) return;
    if (e.key === 'ContextMenu' || e.key === 'F10' && e.shiftKey || e.key === 'Enter' || e.key === ' ') { e.preventDefault(); press.cancel(); show(target(e)); }
  });
}

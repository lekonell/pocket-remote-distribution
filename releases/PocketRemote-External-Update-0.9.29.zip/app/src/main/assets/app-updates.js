(() => {
  const BASE = 'https://github.com/lekonell/pocket-remote-distribution/';
  const CACHE = 'pocket.appUpdate', INTERVAL = 15 * 60 * 1000, RETRY = 5 * 60 * 1000, MAX_AGE = 7 * 24 * 60 * 60 * 1000;
  const parts = value => typeof value === 'string' && /^[0-9]{1,5}\.[0-9]{1,5}\.[0-9]{1,5}$/.test(value) ? value.split('.').map(Number) : null;
  function valid(release) {
    return !!(parts(release?.version) && Number.isInteger(release.versionCode) && release.versionCode > 0 && release.url === BASE + 'releases/download/v' + release.version + '/PocketRemote-External-' + release.version + '.apk' && release.releaseUrl === BASE + 'releases/latest');
  }
  function available(release, current) {
    const next = parts(release?.version), old = parts(current?.version);
    if (!valid(release) || !next || !old || !Number.isInteger(current.versionCode) || current.versionCode < 1 || release.versionCode <= current.versionCode) return false;
    for (let i = 0; i < 3; i++) if (next[i] !== old[i]) return next[i] > old[i];
    return false;
  }
  globalThis.pocketUpdateUtils = { valid, available };
  if (!globalThis.document) return;
  const link = document.getElementById('appUpdateShortcut');
  if (!link) return;
  let current = { version: document.querySelector('meta[name="pocket-version"]')?.content, versionCode: Number(document.querySelector('meta[name="pocket-version-code"]')?.content) };
  try { if (window.RemoteNative?.appVersion) current = JSON.parse(window.RemoteNative.appVersion()); } catch {}
  let release = null, checkedAt = 0, retryAt = 0, pending = '', timeout;
  function render() {
    const show = available(release, current);
    link.classList.toggle('hidden', !show);
    if (!show) { link.removeAttribute('href'); return; }
    link.href = release.url;
    document.getElementById('appUpdateTitle').textContent = '새 버전 ' + release.version;
    document.getElementById('appUpdateVersion').textContent = '현재 ' + current.version + ' · APK 다운로드';
  }
  try {
    const cache = JSON.parse(localStorage.getItem(CACHE));
    if (valid(cache?.release) && Number.isFinite(cache.checkedAt) && Date.now() >= cache.checkedAt && Date.now() - cache.checkedAt < MAX_AGE) {
      release = cache.release; checkedAt = cache.checkedAt;
    }
  } catch {}
  function receive(result) {
    if (!pending || result?.id !== pending) return;
    pending = ''; clearTimeout(timeout);
    if (result.failed || result.release !== null && !valid(result.release)) { retryAt = Date.now() + RETRY; return; }
    release = result.release; checkedAt = Date.now(); retryAt = 0;
    try { localStorage.setItem(CACHE, JSON.stringify({ release, checkedAt })); } catch {}
    render();
  }
  function check() {
    if (document.visibilityState === 'hidden' || pending || Date.now() < retryAt || checkedAt && Date.now() - checkedAt < INTERVAL || !window.RemoteNative?.checkAppUpdate) return;
    pending = 'update-' + Date.now() + '-' + Math.random().toString(36).slice(2, 10);
    timeout = setTimeout(() => receive({ id: pending, failed: true }), 15000);
    try { window.RemoteNative.checkAppUpdate(pending); } catch { receive({ id: pending, failed: true }); }
  }
  link.addEventListener('click', event => {
    if (!available(release, current)) { event.preventDefault(); return; }
    if (window.RemoteNative?.openExternal) { event.preventDefault(); window.RemoteNative.openExternal(release.url); }
  });
  window.pocketAppUpdates = { check, receive };
  document.addEventListener('visibilitychange', () => { if (document.visibilityState !== 'hidden') check(); });
  window.addEventListener('online', check);
  render(); check();
})();

﻿param([Parameter(Mandatory=$true)][string]$PayloadRoot,[Parameter(Mandatory=$true)][string]$UpdateArchive,[Parameter(Mandatory=$true)][string]$UpdateManifest,[Parameter(Mandatory=$true)][string]$ResultFile)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$NoShellIntegration = $env:REMOTE_INSTALLER_TEST -eq '1'
if ($NoShellIntegration -and !$env:LOCALAPPDATA.StartsWith([IO.Path]::GetTempPath(), [StringComparison]::OrdinalIgnoreCase)) { throw 'Installer tests require an isolated temporary user directory' }
. (Join-Path $PayloadRoot 'bridge\settings.ps1')
. (Join-Path $PayloadRoot 'bridge\setup-host.ps1')
. (Join-Path $PayloadRoot 'bridge\setup-update.ps1')
$channel = (Get-Content -LiteralPath (Join-Path $PayloadRoot 'distribution.json') -Raw -Encoding UTF8 | ConvertFrom-Json).channel
if ($channel -notin @('standard','external')) { throw 'Invalid installation channel' }
$newVersion = (Get-Content -LiteralPath (Join-Path $PayloadRoot 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
$node = Join-Path $PayloadRoot 'tools\node.exe'
& $node (Join-Path $PayloadRoot 'bridge\update-worker.mjs') --verify $UpdateArchive $UpdateManifest *> $null
if ($LASTEXITCODE -ne 0) { throw 'Installation payload verification failed' }
$destination = Join-Path $env:LOCALAPPDATA ('Programs\PocketRemote\' + $channel)
$taskName = if ($channel -eq 'external') { 'PocketRemoteExternal' } else { 'PocketRemoteExternal' }
$task = if (!$NoShellIntegration) { Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue } else { $null }
foreach ($action in $task.Actions) {
    $candidate = [IO.Path]::GetDirectoryName([string]$action.Execute)
    if ([IO.Path]::GetFileName([string]$action.Execute) -eq 'PocketRemoteHost.exe' -and (Test-ExistingPCInstall $candidate)) { $destination = $candidate; break }
}
# Also recognize a manual installation whose startup task was never registered.
$installed = Join-Path (Get-PocketSettingsRoot $PayloadRoot) 'installation.json'
if (!(Test-Path -LiteralPath (Join-Path $destination 'package.json')) -and (Test-Path -LiteralPath $installed)) {
    $previous = Get-Content -LiteralPath $installed -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($previous.channel -eq $channel -and (Test-ExistingPCInstall $previous.root)) { $destination = $previous.root }
}
$existing = Test-Path -LiteralPath (Join-Path $destination 'package.json')
if ($existing -and [version](Get-InstalledPCVersion $destination) -ge [version]$newVersion) {
    Write-Output 'PROGRESS:이미 설치된 버전을 사용합니다. 설정을 유지합니다.'
} elseif ($existing) {
    Write-Output 'PROGRESS:기존 설정을 찾았습니다. 앱을 업데이트한 뒤 원격 연결을 다시 시작합니다.'
    # Migrate using the new edition's directory without altering a busy host.
    Initialize-PocketSettings $destination -DataRoot (Get-PocketSettingsRoot $PayloadRoot)
    $stage = Join-Path $destination ('.updates\' + $newVersion)
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    Copy-Item -LiteralPath $UpdateArchive -Destination (Join-Path $stage 'update.zip') -Force
    Copy-Item -LiteralPath $UpdateManifest -Destination (Join-Path $stage 'manifest.json') -Force
    # Bootstrap only updater code. Never overwrite executable/package before verification.
    foreach ($name in @('distribution.json','UPDATE-PC.ps1','bridge\settings.ps1','bridge\settings.mjs','bridge\setup-host.ps1','bridge\setup-update.ps1','bridge\pc-updates.mjs','bridge\update-worker.mjs','bridge\run-update.ps1','bridge\update-key.mjs')) {
        Copy-Item -LiteralPath (Join-Path $PayloadRoot $name) -Destination (Join-Path $destination $name) -Force
    }
    if (!(Test-Path -LiteralPath (Join-Path $destination 'tools\node.exe'))) {
        New-Item -ItemType Directory -Path (Join-Path $destination 'tools') -Force | Out-Null
        foreach ($name in @('node.exe','NODE-LICENSE.txt','node-runtime.json')) { Copy-Item -LiteralPath (Join-Path $PayloadRoot ('tools\' + $name)) -Destination (Join-Path $destination 'tools') -Force }
    }
    Write-Output 'PROGRESS:앱을 업데이트하고 있습니다. 연결 설정과 페어링은 유지합니다.'
    do {
        & (Join-Path $destination 'UPDATE-PC.ps1') -Archive (Join-Path $stage 'update.zip') -Manifest (Join-Path $stage 'manifest.json') -NodePath $node -Requested
        $updateExit = $LASTEXITCODE
        if ($updateExit -eq 2) { Write-Output 'PROGRESS:설정 마법사를 닫으면 업데이트를 적용합니다.'; Start-Sleep -Seconds 10 }
    } while ($updateExit -eq 2)
    if ($LASTEXITCODE -ne 0) { throw 'Update could not finish. Previous settings are preserved.' }
} else {
    Write-Output 'PROGRESS:앱을 설치하고 있습니다. 필수 실행 환경도 함께 설치합니다.'
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    foreach ($file in Get-ChildItem -LiteralPath $PayloadRoot -Recurse -File) {
        $relative = $file.FullName.Substring($PayloadRoot.Length + 1)
        if ($relative.Split('\') | Where-Object { $_.StartsWith('.') }) { throw 'Private file in installation bundle' }
        $target = Join-Path $destination $relative
        New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $target -Force
    }
    Initialize-PocketSettings $destination
}
New-Item -ItemType Directory -Path (Get-PocketSettingsRoot $PayloadRoot) -Force | Out-Null
[IO.File]::WriteAllText($installed, (@{root=$destination;channel=$channel} | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
# Repair the login shortcut after moving/re-extracting an installation.
if ($task) { & (Join-Path $destination 'INSTALL-AUTOSTART.ps1') *> $null }
$configured = Test-Path -LiteralPath (Get-PocketSetting $destination '.endpoint.json')
if ($configured -and !@(Get-SetupHostProcesses $destination).Count) {
    & (Join-Path $destination 'SETUP-REMOTE.ps1') -Action Start -HostOnly *> $null
    if ($LASTEXITCODE -ne 0) { throw 'The installed host could not start. Open the desktop setup shortcut to check the connection.' }
}
if (!$NoShellIntegration) {
    $shortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) ('Pocket Remote' + $(if($channel -eq 'external'){' External'}) + '.lnk')
    $link = (New-Object -ComObject WScript.Shell).CreateShortcut($shortcut)
    $link.TargetPath = Join-Path $destination 'PocketRemoteSetup.exe'; $link.WorkingDirectory = $destination; $link.Save()
}
[IO.File]::WriteAllText($ResultFile, (@{root=$destination;existing=[bool]$existing;configured=[bool]$configured;version=(Get-InstalledPCVersion $destination)} | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
Write-Output 'PROGRESS:완료되었습니다. 기존 설정을 유지합니다.'

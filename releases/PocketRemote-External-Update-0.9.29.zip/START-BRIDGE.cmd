@echo off
rem Compatibility entry point: start the supervised bridge in the background.
call "%~dp0START-REMOTE.cmd"
exit /b %errorlevel%

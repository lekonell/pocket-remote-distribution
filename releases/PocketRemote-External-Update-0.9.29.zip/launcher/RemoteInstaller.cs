using System;
using System.IO;
using System.IO.Compression;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal sealed class RemoteInstaller : Form
{
    private readonly Label status = new Label();
    private readonly Button done = new Button();
    private bool running;
    private string installedRoot = "";
    [STAThread] private static int Main(string[] args) {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        try {
            if (args.Length == 2 && args[0] == "--extract-fixture" && Environment.GetEnvironmentVariable("REMOTE_INSTALLER_TEST") == "1") {
                var target = Path.GetFullPath(args[1]);
                if (!target.StartsWith(Path.GetFullPath(Path.GetTempPath()), StringComparison.OrdinalIgnoreCase) || Directory.Exists(target)) return 1;
                Extract(target); return 0;
            }
            Application.Run(new RemoteInstaller()); return 0;
        } catch (Exception e) { MessageBox.Show(e.Message, "Pocket Remote 설치", MessageBoxButtons.OK, MessageBoxIcon.Error); return 1; }
    }
    private RemoteInstaller() {
        Text = "Pocket Remote " + InstallerPayload.Version + " · 설치 및 업데이트"; ClientSize = new Size(570, 280); StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Malgun Gothic", 10); BackColor = Color.FromArgb(245, 250, 248); FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
        Controls.Add(new Label { Text = "Pocket Remote", Font = new Font("Segoe UI", 22, FontStyle.Bold), Location = new Point(28, 22), Size = new Size(510, 48) });
        status.Location = new Point(30, 86); status.Size = new Size(510, 112); status.Text = "기존 설치와 설정을 확인합니다…"; Controls.Add(status);
        done.Text = "닫기"; done.Location = new Point(410, 218); done.Size = new Size(130, 38); done.Enabled = false; done.Click += (s,e) => Close(); Controls.Add(done);
        Shown += async (s,e) => await Install();
        FormClosing += (s,e) => { if (running) { e.Cancel = true; WindowState = FormWindowState.Minimized; } };
    }
    private void Report(string value) { if (!IsDisposed) BeginInvoke(new Action(() => status.Text = value)); }
    private async Task Install() {
        running = true;
        try {
            var result = await Task.Run(() => {
                var stage = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PocketRemote", "install-cache", Guid.NewGuid().ToString("N"));
                Extract(stage);
                var shell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
                var resultFile = Path.Combine(stage, "result.json");
                var command = "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File " + Quote(Path.Combine(stage,"runtime","INSTALL-PC.ps1")) + " -PayloadRoot " + Quote(Path.Combine(stage,"runtime")) + " -UpdateArchive " + Quote(Path.Combine(stage,"update.zip")) + " -UpdateManifest " + Quote(Path.Combine(stage,"manifest.json")) + " -ResultFile " + Quote(resultFile);
                using (var process = new Process { StartInfo = new ProcessStartInfo(shell, command) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true, StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 } }) {
                    process.OutputDataReceived += (s,e) => { if (e.Data != null && e.Data.StartsWith("PROGRESS:")) Report(e.Data.Substring(9)); };
                    process.Start(); process.BeginOutputReadLine(); var error = process.StandardError.ReadToEndAsync(); process.WaitForExit();
                    if (process.ExitCode != 0) throw new Exception("설치 또는 업데이트를 완료하지 못했습니다. 기존 설정은 유지됩니다.\n\n" + error.Result.Substring(0, Math.Min(360, error.Result.Length)));
                }
                var installed = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(File.ReadAllText(resultFile));
                // Only this newly generated staging directory is removed.
                try { Directory.Delete(stage, true); } catch { }
                return installed;
            });
            installedRoot = Convert.ToString(result["root"]);
            status.Text = "Pocket Remote " + result["version"] + " 설치가 완료되었습니다.\n연결 설정과 휴대폰 인증은 자동으로 유지합니다.\n바탕 화면의 Pocket Remote로 연결 설정을 열 수 있습니다.";
            if (!Convert.ToBoolean(result["configured"])) Process.Start(new ProcessStartInfo(Path.Combine(installedRoot,"PocketRemoteSetup.exe")) { UseShellExecute = true, WorkingDirectory = installedRoot });
        } catch (Exception e) { status.Text = e.Message; }
        finally { running = false; done.Enabled = true; }
    }
    private static string Quote(string value) { if (value.IndexOfAny(new [] {'"','\r','\n'}) >= 0) throw new ArgumentException("Invalid installation path"); return "\"" + value + "\""; }
    private static void Resource(string name, string target) {
        using (var input = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
        using (var output = File.Create(target)) { if (input == null) throw new InvalidDataException("Missing installation data"); input.CopyTo(output); }
    }
    private static void Extract(string stage) {
        Directory.CreateDirectory(stage);
        var archive = Path.Combine(stage,"runtime.zip"); Resource("runtime.zip",archive); Resource("update.zip",Path.Combine(stage,"update.zip")); Resource("manifest.json",Path.Combine(stage,"manifest.json"));
        using (var stream=File.OpenRead(archive)) using (var hash=SHA256.Create()) {
            if (BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant() != InstallerPayload.Hash) throw new InvalidDataException("Installation archive hash differs");
        }
        var root = Path.Combine(stage,"runtime"); Directory.CreateDirectory(root); long total = 0;
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using (var zip=ZipFile.OpenRead(archive)) foreach (var entry in zip.Entries) {
            if (entry.FullName.EndsWith("/")) continue;
            var name=entry.FullName.Replace('\\','/');
            if (name.Contains(":") || Array.Exists(name.Split('/'), part => part.Length == 0 || part.StartsWith(".")) || !seen.Add(name)) throw new InvalidDataException("Unsafe installation entry");
            total += entry.Length; if (total > 220L*1024*1024 || seen.Count > 3000) throw new InvalidDataException("Installation limit exceeded");
            var target=Path.GetFullPath(Path.Combine(root,name)); if (!target.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Unsafe installation path");
            Directory.CreateDirectory(Path.GetDirectoryName(target)); entry.ExtractToFile(target,false);
        }
        if (!seen.Contains("PocketRemoteSetup.exe") || !seen.Contains("tools/node.exe") || !seen.Contains("INSTALL-PC.ps1")) throw new InvalidDataException("Incomplete installation payload");
    }
}

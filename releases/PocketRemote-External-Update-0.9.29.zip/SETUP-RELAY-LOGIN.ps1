﻿param([Parameter(Mandatory=$true)][string]$RequestFile, [Parameter(Mandatory=$true)][string]$ReceiptFile)
$OutputEncoding = [Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Pocket Remote - SSH 로그인'
try {
    $sessionRoot = [IO.Path]::GetFullPath((Split-Path -Parent $RequestFile))
    $expectedRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.relay-login')) + [IO.Path]::DirectorySeparatorChar
    if (!$sessionRoot.StartsWith($expectedRoot, [StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFullPath((Split-Path -Parent $ReceiptFile)) -ne $sessionRoot) { throw '잘못된 SSH 로그인 요청입니다.' }
    $request = Get-Content -LiteralPath $RequestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Host '선택한 서버 관리자 계정으로 로그인합니다. Pocket Remote가 비밀번호를 저장하지 않습니다.'
    Write-Host '처음 접속하는 서버는 SSH 호스트 키 지문을 확인하고 승인하세요.'
    $ErrorActionPreference = 'Continue'
    & node.exe (Join-Path $PSScriptRoot 'bridge\relay-login.mjs') $RequestFile $ReceiptFile
    $success = $LASTEXITCODE -eq 0
    if (!$success) { Write-Host '로그인 또는 서버 구성에 실패했습니다. 마법사에서 계정과 키를 확인하세요.'; Start-Sleep -Seconds 2 }
} catch {
    exit 1
}

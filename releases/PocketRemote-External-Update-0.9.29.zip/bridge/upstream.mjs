import { settingsPath, migrateSettings } from './settings.mjs';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { WebSocket } from 'ws';

const featureProbes = new Map();
export async function instantSteeringArgs(command, run = promisify(execFile)) {
  if (!featureProbes.has(command)) {
    const probe = run(command, ['features', 'list'], { windowsHide: true, timeout: 3000, maxBuffer: 128 * 1024 }).then(({ stdout }) =>
      /^instant_interrupt\s+(?:under development|beta|stable)\s+(?:true|false)\s*$/m.test(stdout) ? ['-c', 'features.instant_interrupt=true'] : []
    ).catch(() => []);
    if (featureProbes.size >= 12) featureProbes.delete(featureProbes.keys().next().value);
    featureProbes.set(command, probe);
  }
  return featureProbes.get(command);
}

// The desktop app accepts this endpoint too. Keep the native RPC listener on
// loopback; remote devices continue to use the authenticated bridge endpoint.
export function sharedUrl(value) {
  const url = new URL(value);
  if (url.protocol !== 'ws:' || !['127.0.0.1', '[::1]'].includes(url.hostname) || !url.port || url.username || url.password || url.search || url.hash || url.pathname !== '/') {
    throw new Error('Shared App Server must use a plain loopback WebSocket URL with an explicit port.');
  }
  return url.href.replace(/\/$/, '');
}

export function upstreamSettings(root, env = process.env) {
  const file = settingsPath(root, '.shared-server.json');
  const config = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8').replace(/^\uFEFF/, '')) : {};
  const url = env.REMOTE_APP_SERVER_URL || (config.enabled === true ? config.url : '');
  const desktopUrl = env.REMOTE_DESKTOP_PROXY_URL || config.desktopUrl;
  return { mode: url ? 'shared' : 'dedicated', ...(url ? { url: sharedUrl(url), ...(desktopUrl ? { desktopUrl: sharedUrl(desktopUrl) } : {}) } : {}) };
}

export function connectUpstream({ settings, command = process.env.CODEX_BIN || 'codex', cwd = process.cwd(), env = process.env, onOpen, onMessage, onClose, onError, onLog }) {
  let closed = false, stopping = false, peer, buffer = '', timeout, heartbeat;
  const report = error => onError?.(error);
  const receive = text => {
    try { onMessage(JSON.parse(text)); }
    catch (error) { report(new Error('Invalid Codex message: ' + error.message)); }
  };
  const close = () => {
    if (closed) return;
    closed = true; clearTimeout(timeout); clearInterval(heartbeat);
    onClose?.();
  };
  if (settings.mode === 'shared') {
    peer = new WebSocket(sharedUrl(settings.url), { perMessageDeflate: false, maxPayload: 64 * 1024 * 1024 });
    timeout = setTimeout(() => peer.terminate(), 5000);
    peer.on('open', () => {
      clearTimeout(timeout);
      peer.alive = true;
      heartbeat = setInterval(() => {
        if (!peer.alive) { peer.terminate(); return; }
        peer.alive = false; peer.ping();
      }, 10000);
      heartbeat.unref();
      onOpen?.();
    });
    peer.on('message', bytes => receive(bytes.toString()));
    peer.on('pong', () => { peer.alive = true; });
    peer.on('error', report);
    peer.on('close', close);
  } else {
    (async () => {
    const flags = await instantSteeringArgs(command);
    if (stopping) return;
    peer = spawn(command, [...flags, 'app-server', '--stdio'], { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    peer.stdout.setEncoding('utf8');
    peer.stdout.on('data', chunk => {
      buffer += chunk;
      for (;;) {
        const end = buffer.indexOf('\n');
        if (end < 0) break;
        const line = buffer.slice(0, end).trim(); buffer = buffer.slice(end + 1);
        if (line) receive(line);
      }
    });
    peer.stderr.setEncoding('utf8');
    peer.stderr.on('data', chunk => onLog?.(chunk.trim()));
    peer.on('spawn', () => onOpen?.());
    peer.on('error', report);
    peer.on('close', close);
    })().catch(error => { report(error); close(); });
  }
  return {
    send(message) {
      if (closed || stopping) return false;
      try { if (settings.mode === 'shared') {
        if (peer.readyState !== WebSocket.OPEN) return false;
        peer.send(JSON.stringify(message));
      } else {
        if (!peer) return false;
        if (!peer.stdin.writable) return false;
        peer.stdin.write(JSON.stringify(message) + '\n');
      } } catch (error) { report(error); return false; }
      return true;
    },
    close() {
      stopping = true;
      if (settings.mode === 'shared') peer.terminate();
      else peer?.kill();
    }
  };
}

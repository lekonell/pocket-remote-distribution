﻿# Setup may force-stop only the remote host belonging to this installation.
# Shared App Server launchers and official desktop apps are independent roots.
function Test-SetupScript($process, [string]$path) {
    $command = [string]$process.CommandLine
    $pattern = '(?i)(?:^|[\s"])' + [regex]::Escape($path.Replace('/','\')) + '(?:[\s"]|$)'
    return $command.Replace('/','\') -match $pattern
}
function Test-SetupRelativeHost($process) {
    return ([string]$process.CommandLine).Replace('/','\') -match '(?i)(?:^|[\s"])(?:\.\\)?bridge\\host\.mjs(?:[\s"]|$)'
}
function Get-SetupHostProcesses([string]$root, [switch]$IncludeUpdater) {
    $all = @(Get-CimInstance Win32_Process -ErrorAction Stop)
    $owned = @{}
    $launcher = Join-Path $root 'PocketRemoteHost.exe'
    $run = Join-Path $root 'RUN-REMOTE.ps1'
    $hostScript = Join-Path $root 'bridge\host.mjs'
    $bridgeScript = Join-Path $root 'bridge\server.mjs'
    foreach ($process in $all) {
        $isLauncher = [string]::Equals([string]$process.ExecutablePath, $launcher, [StringComparison]::OrdinalIgnoreCase)
        $isShell = $process.Name -in @('powershell.exe','pwsh.exe') -and (Test-SetupScript $process $run)
        $isNode = $process.Name -eq 'node.exe' -and ((Test-SetupScript $process $hostScript) -or (Test-SetupScript $process $bridgeScript))
        $isUpdater = $IncludeUpdater -and $process.Name -eq 'node.exe' -and (Test-SetupScript $process (Join-Path $root 'bridge\update-worker.mjs'))
        if ($isLauncher -or $isShell -or $isNode -or $isUpdater) { $owned[[int]$process.ProcessId] = $process }
    }
    # RUN-REMOTE launches host.mjs with a relative argument. A PID file alone
    # is not proof of ownership: require its absolute-path bridge child too.
    $pidPath = Join-Path $root '.host.pid'
    $recorded = 0
    if (Test-Path -LiteralPath $pidPath -PathType Leaf) { [void][int]::TryParse([IO.File]::ReadAllText($pidPath).Trim(), [ref]$recorded) }
    if ($recorded -gt 0) {
        $parent = $all | Where-Object ProcessId -eq $recorded | Select-Object -First 1
        $child = @($owned.Values | Where-Object { $_.ParentProcessId -eq $recorded -and $_.CreationDate -ge $parent.CreationDate })
        if ($parent -and $parent.Name -eq 'node.exe' -and $child.Count -and (Test-SetupRelativeHost $parent)) { $owned[$recorded] = $parent }
    }
    do {
        $added = $false
        foreach ($process in $all) {
            $parent = $owned[[int]$process.ParentProcessId]
            if (!$owned.ContainsKey([int]$process.ProcessId) -and $parent -and $process.CreationDate -ge $parent.CreationDate) {
                $isRun = $parent.Name -in @('powershell.exe','pwsh.exe') -and (Test-SetupScript $parent $run)
                $isHost = $parent.Name -eq 'node.exe' -and ((Test-SetupScript $parent $hostScript) -or (Test-SetupRelativeHost $parent))
                $isBridge = $parent.Name -eq 'node.exe' -and (Test-SetupScript $parent $bridgeScript)
                $hostChild = $isRun -and $process.Name -eq 'node.exe' -and (Test-SetupRelativeHost $process)
                $sshChild = $isHost -and $process.Name -eq 'ssh.exe'
                $tunnelChild = $isHost -and $process.Name -in @('ngrok.exe','cloudflared.exe') -and [string]::Equals([string]$process.ExecutablePath, (Join-Path $root ('tools\' + $process.Name)), [StringComparison]::OrdinalIgnoreCase)
                $nativeChild = $isBridge -and $process.Name -eq 'codex.exe' -and [string]$process.CommandLine -match '(?i)(?:^|[\s"])app-server(?:[\s"]|$)'
                # Do not walk into arbitrary tools, editors or desktop apps that
                # a standalone task may have launched under its native process.
                if ($hostChild -or $sshChild -or $tunnelChild -or $nativeChild) { $owned[[int]$process.ProcessId] = $process; $added = $true }
            }
        }
    } while ($added)
    return @($owned.Values)
}
function Get-SetupHostTask([string]$root) {
    $task = Get-ScheduledTask -TaskName PocketRemoteExternal -ErrorAction SilentlyContinue
    $launcher = Join-Path $root 'PocketRemoteHost.exe'
    if ($task -and @($task.Actions).Count -gt 0 -and !@($task.Actions | Where-Object { ![string]::Equals([string]$_.Execute, $launcher, [StringComparison]::OrdinalIgnoreCase) }).Count) { return $task }
    return $null
}
function Test-SetupProcessAlive($saved) {
    $current = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $saved.ProcessId) -ErrorAction Stop
    return $current -and $current.CreationDate -eq $saved.CreationDate
}
function Stop-SetupHost([string]$root, [switch]$IncludeUpdater) {
    $owned = @(Get-SetupHostProcesses $root -IncludeUpdater:$IncludeUpdater)
    if (!$owned.Count) { return @{ stopped=$false } }
    $task = Get-SetupHostTask $root
    $taskEnabled = $task -and [bool]$task.Settings.Enabled
    try {
        # Prevent the scheduled restart policy from racing the configuration save.
        if ($taskEnabled) { Disable-ScheduledTask -TaskName PocketRemoteExternal | Out-Null }
        [IO.File]::WriteAllText((Join-Path $root '.stop-request'), 'setup-reconfigure')
        Start-Sleep -Milliseconds 250
        # Capture any children started during the request before freezing parents.
        $byId = @{}; foreach ($process in @($owned + @(Get-SetupHostProcesses $root -IncludeUpdater:$IncludeUpdater))) { $byId[[int]$process.ProcessId] = $process }
        $owned = @($byId.Values)
        $ordered = @($owned | Sort-Object CreationDate)
        foreach ($process in $ordered) {
            if (Test-SetupProcessAlive $process) {
                try { Stop-Process -Id $process.ProcessId -Force -ErrorAction Stop }
                catch { if (Test-SetupProcessAlive $process) { throw '기존 연결 호스트를 종료하지 못했습니다. 해당 설치의 실행 권한을 확인하세요.' } }
            }
        }
        for ($attempt=0; $attempt -lt 30; $attempt++) {
            $remaining = @($owned | Where-Object { Test-SetupProcessAlive $_ })
            if (!$remaining.Count) { break }
            Start-Sleep -Milliseconds 100
        }
        if ($remaining.Count) { throw '기존 연결 호스트의 종료를 확인하지 못했습니다. 기존 설정은 변경하지 않았습니다.' }
        foreach ($name in @('.host.pid','.stop-request')) {
            $path = Join-Path $root $name
            if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force }
        }
        return @{ stopped=$true; processCount=$owned.Count; taskEnabled=[bool]$taskEnabled }
    } catch {
        if ($taskEnabled) { Enable-ScheduledTask -TaskName PocketRemoteExternal -ErrorAction SilentlyContinue | Out-Null }
        throw
    }
}

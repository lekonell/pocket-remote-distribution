import { isIP } from 'node:net';
import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export function normalizeSetup(input) {
  if (!input || typeof input !== 'object') throw Error('설정 값을 확인하세요.');
  const provider = input.provider || 'direct';
  if (!['direct', 'custom', 'ssh', 'ngrok', 'cloudflare'].includes(provider)) throw Error('연결 방식을 선택하세요.');
  const localPort = Number(input.localPort || 4545);
  if (!Number.isInteger(localPort) || localPort < 1024 || localPort > 65535 || [4546, 4549].includes(localPort)) throw Error('브리지 포트는 1024–65535 중 공유 서버·PC 중계와 다른 포트를 사용하세요.');
  const bindAddress = ['direct', 'custom'].includes(provider) ? String(input.bindAddress || '127.0.0.1') : '127.0.0.1';
  if (!isIP(bindAddress)) throw Error('PC 바인딩 주소는 IPv4 또는 IPv6 주소여야 합니다.');
  let endpoint;
  try { endpoint = new URL(String(input.websocketUrl || '').trim()); } catch { throw Error('휴대폰에서 연결할 WS/WSS 주소를 입력하세요.'); }
  if (!['ws:', 'wss:'].includes(endpoint.protocol) || endpoint.username || endpoint.password || endpoint.hash || endpoint.search || !endpoint.pathname.endsWith('/socket')) throw Error('WS/WSS 주소는 /socket 경로로 끝나야 하며 인증 정보·쿼리를 포함하지 않아야 합니다.');
  if (!['direct', 'custom'].includes(provider) && endpoint.protocol !== 'wss:') throw Error('인터넷 터널에는 WSS 주소를 사용하세요.');
  if (provider === 'direct' && endpoint.protocol !== 'ws:') throw Error('직접 연결은 WS입니다. TLS 중계 주소는 기존 WSS/역방향 프록시를 선택하세요.');
  const config = { provider, localPort, bindAddress, websocketUrl: endpoint.toString(), publicUrl: endpoint.toString().replace(/^wss:/, 'https:').replace(/^ws:/, 'http:').replace(/\/socket$/, '') };
  if (provider === 'ngrok' && endpoint.pathname !== '/socket') throw Error('ngrok 고정 주소는 호스트명과 /socket 경로를 사용하세요.');
  if (provider === 'ssh') {
    const sshHost = String(input.sshHost || '').trim(), reversePort = Number(input.reversePort || 14545);
    if (!/^[A-Za-z0-9][A-Za-z0-9_.@-]{0,200}$/.test(sshHost)) throw Error('SSH 별칭 또는 user@host를 입력하세요. 인증은 Windows SSH 설정을 사용합니다.');
    if (!Number.isInteger(reversePort) || reversePort < 1024 || reversePort > 65535) throw Error('SSH 서버 내부 포트를 확인하세요.');
    Object.assign(config, { sshHost, reversePort });
    if (input.sshPort !== undefined && input.sshPort !== '') {
      const sshPort = Number(input.sshPort);
      if (!Number.isInteger(sshPort) || sshPort < 1 || sshPort > 65535) throw Error('SSH 포트를 확인하세요.');
      config.sshPort = sshPort;
    }
    if (input.sshIdentityFile) {
      const sshIdentityFile = String(input.sshIdentityFile);
      if (/[\x00-\x1f"]/.test(sshIdentityFile) || !/^(?:[A-Za-z]:[\\/]|\/)/.test(sshIdentityFile)) throw Error('SSH 키 파일 경로를 확인하세요.');
      config.sshIdentityFile = sshIdentityFile;
    }
    if (/^pc-[a-f0-9]{24}$/.test(input.relayId || '')) config.relayId = input.relayId;
  }
  const name = String(input.name || '').trim(), cwd = String(input.cwd || '').trim();
  if (!name || name.length > 48 || /[\x00-\x1f]/.test(name)) throw Error('PC 이름을 1–48자로 입력하세요.');
  if (!cwd || cwd.length > 1000 || /[\x00-\x1f]/.test(cwd)) throw Error('기본 작업 폴더를 선택하세요.');
  return { config, setup: { name, cwd: resolve(cwd) }, autoStart: !!input.autoStart, sharedDesktop: !!input.sharedDesktop };
}
export async function validateSetup(input) {
  const result = normalizeSetup(input);
  if (!(await stat(result.setup.cwd)).isDirectory()) throw Error('작업 폴더가 존재하지 않습니다.');
  if (result.config.sshIdentityFile && !(await stat(result.config.sshIdentityFile).catch(() => null))?.isFile()) throw Error('SSH 터널 키 파일이 없습니다. 연결을 재설정하기 전에 키를 확인하세요.');
  return result;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  let text = ''; for await (const chunk of process.stdin) { text += chunk; if (text.length > 16384) throw Error('설정 입력이 너무 큽니다.'); }
  try { console.log(JSON.stringify({ ok: true, ...await validateSetup(JSON.parse(text.replace(/^\uFEFF/, ''))) })); }
  catch (e) { console.log(JSON.stringify({ ok: false, error: e.message })); process.exitCode = 1; }
}

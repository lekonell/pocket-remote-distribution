// Native blocking questions use JSON-RPC responses. Async message questions
// use the same typed reply envelope and per-question IDs as the desktop client.
const OPEN = '<send_user_message_question_reply>', CLOSE = '</send_user_message_question_reply>';
export const asyncQuestionId = (itemId, index) => JSON.stringify(['request_user_input_async', itemId, index]);
export function formatQuestionReply(q, answers) {
  return OPEN + '\n' + JSON.stringify(q.questions.map((question, index) => ({
    questionItemId: asyncQuestionId(q.itemId, index), question: question.title || question.question || question.header || '', answer: answers[index].trim()
  }))) + '\n' + CLOSE;
}
export function questionReplyTargets(item) {
  if (!['userMessage', 'steeringUserMessage'].includes(item?.type) || item.type === 'steeringUserMessage' && item.status && item.status !== 'accepted') return [];
  const content = item.content || item.input;
  if (!Array.isArray(content) || content.length !== 1 || content[0]?.type !== 'text') return [];
  const text = content[0].text?.trim();
  if (!text || text.length > 100000 || !text.startsWith(OPEN) || !text.endsWith(CLOSE)) return [];
  try {
    const parsed = JSON.parse(text.slice(OPEN.length, -CLOSE.length)), replies = Array.isArray(parsed) ? parsed : [parsed];
    return replies.flatMap(reply => {
      if (typeof reply.questionItemId !== 'string' || typeof reply.question !== 'string' || typeof reply.answer !== 'string') return [];
      const id = JSON.parse(reply.questionItemId);
      return Array.isArray(id) && id.length === 3 && id[0] === 'request_user_input_async' && typeof id[1] === 'string' && id[1].length <= 200 && Number.isInteger(id[2]) && id[2] >= 0 && id[2] < 8 ? [{ itemId: id[1], index: id[2] }] : [];
    });
  } catch { return []; }
}
export function createNativeQuestionReplies({ requests, send, timeoutMs = 10000 }) {
  const pending = new Map();
  const finish = (key, error) => { const p = pending.get(key); if (!p) return; clearTimeout(p.timer); pending.delete(key); error ? p.reject(error) : p.resolve({ accepted: true, confirmed: true }); };
  return {
    respond(q, params) {
      const key = String(q.requestId), request = requests.get(key);
      if (!request || request.method !== 'item/tool/requestUserInput' || request.params?.threadId !== q.threadId || request.params?.itemId !== q.itemId || request.params?.turnId !== q.turnId) throw Error('질문이 이미 종료되었거나 갱신되었습니다.');
      if (pending.has(key)) return pending.get(key).promise;
      if (params.skip !== true && q.questions.some(question => typeof question.id !== 'string' || !question.id)) throw Error('공식 질문 ID를 확인하지 못했습니다. 질문을 다시 불러오세요.');
      const answers = params.skip === true ? {} : Object.fromEntries(q.questions.map((question, index) => [question.id, { answers: [params.answers[index].trim()] }]));
      let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
      const timer = setTimeout(() => finish(key, Error('Question response timed out; 전송 결과를 다시 확인하세요.')), timeoutMs);
      pending.set(key, { promise, resolve, reject, timer, threadId: q.threadId });
      try { if (!send({ id: q.requestId, result: { answers } })) finish(key, Error('Codex is reconnecting.')); } catch (error) { finish(key, error); }
      return promise;
    },
    onEvent(message) {
      if (message.method === 'serverRequest/resolved') { const p = pending.get(String(message.params?.requestId)); if (p && message.params?.threadId === p.threadId) finish(String(message.params.requestId)); }
      else if (!message.method && message.error) finish(String(message.id), Error(message.error.message || 'Question response rejected'));
    },
    disconnect() { for (const key of pending.keys()) finish(key, Error('Codex connection restarted; 전송 결과를 다시 확인하세요.')); }
  };
}

import { settingsPath, migrateSettings } from './settings.mjs';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

// Sent only after socket authentication or successful pairing.
export function readHostSettings(root, { env = process.env, cwd = process.cwd() } = {}) {
  let setup = {};
  try { setup = JSON.parse(readFileSync(settingsPath(root, '.setup.json'), 'utf8')); } catch {}
  const valid = value => typeof value === 'string' && value.trim() && value.length <= 1000 && !/[\x00-\x1f]/.test(value);
  return {
    hostName: valid(setup?.name) ? setup.name.trim() : env.COMPUTERNAME || 'Desktop',
    defaultCwd: valid(setup?.cwd) ? setup.cwd.trim() : valid(env.REMOTE_CWD) ? env.REMOTE_CWD.trim() : cwd
  };
}

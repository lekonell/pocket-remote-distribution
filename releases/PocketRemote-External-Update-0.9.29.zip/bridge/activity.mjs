import { open, stat } from 'node:fs/promises';
import { resolve } from 'node:path';

// Windows writer locks reject a read while held. Probe without acquiring,
// editing or removing a lock; an uncertain result must keep the idle gate shut.
export function writerLockReader(directory, platform = process.platform) {
  return async path => {
    const id = path?.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.jsonl$/i)?.[1];
    if (!id || platform !== 'win32') return null;
    if (!(await stat(directory)).isDirectory()) throw new Error('Writer lock directory is unavailable');
    let handle;
    try {
      handle = await open(resolve(directory, id + '.lock'), 'r');
      await handle.read(Buffer.alloc(1), 0, 1, 0);
      return false;
    } catch (error) {
      if (error.code === 'ENOENT') return false;
      if (['EBUSY', 'EACCES', 'EPERM'].includes(error.code)) return true;
      throw error;
    } finally { await handle?.close(); }
  };
}

// Read lifecycle markers only. Never copy conversation contents into diagnostics.
export function activityReader({ hasWriter } = {}) {
  const cache = new Map();
  return async path => {
    if (!path?.endsWith('.jsonl')) return null;
    const owned = async active => active === true && hasWriter && await hasWriter(path) === false ? false : active;
    let handle;
    try {
      handle = await open(path, 'r');
      const s = await handle.stat(), old = cache.get(path);
      if (old?.size === s.size && old.mtime === s.mtimeMs) return await owned(old.active);
      let active = null;
      for (let length = Math.min(s.size, 512 * 1024); length > 0; length = Math.min(s.size, length * 2)) {
        const bytes = Buffer.alloc(length); await handle.read(bytes, 0, length, s.size - length);
        const lines = bytes.toString('utf8').split('\n');
        for (let i = lines.length - 1; i >= 0; i--) {
          let row; try { row = JSON.parse(lines[i]); } catch { continue; }
          if (row.type !== 'event_msg') continue;
          const type = row.payload?.type;
          if (type === 'task_started') { active = true; break; }
          if (type === 'task_complete' || type === 'turn_aborted') { active = false; break; }
        }
        if (active !== null || length === s.size || length >= 16 * 1024 * 1024) break;
      }
      cache.set(path, { size: s.size, mtime: s.mtimeMs, active });
      return await owned(active);
    } finally { await handle?.close(); }
  };
}

export async function serverIdle(client, readActivity, watched = []) {
  const seen = new Set();
  let cursor;
  const check = async thread => {
    seen.add(thread.id);
    if (thread.status?.type === 'active') return false;
    const disk = await readActivity(thread.path);
    if (disk === true) return false;
    if (disk === null) {
      const latest = await client.rpc('thread/turns/list', { threadId: thread.id, limit: 1, sortDirection: 'desc', itemsView: 'notLoaded' });
      if (latest.data?.[0]?.status === 'inProgress') return false;
      // A truncated lifecycle marker cannot safely prove a running turn ended.
      if (thread.path && latest.data?.length && latest.data[0].status !== 'completed' && latest.data[0].status !== 'interrupted' && latest.data[0].status !== 'failed') return false;
    }
    return true;
  };
  do {
    const page = await client.rpc('thread/list', { limit: 100, cursor, useStateDbOnly: true, sortKey: 'updated_at', sourceKinds: ['cli', 'vscode', 'exec', 'appServer', 'subAgent', 'subAgentReview', 'subAgentCompact', 'subAgentThreadSpawn', 'subAgentOther', 'unknown'] });
    for (const thread of page.data) if (!await check(thread)) return false;
    cursor = page.nextCursor;
    if (seen.size > 10000) throw new Error('Too many threads to verify idle safely');
  } while (cursor);
  for (const threadId of watched) if (!seen.has(threadId)) {
    const { thread } = await client.rpc('thread/read', { threadId });
    if (!await check(thread)) return false;
  }
  return true;
}

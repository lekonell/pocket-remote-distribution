import { createHash } from 'node:crypto';
import { WebSocket } from 'ws';
import { createDotAvatars } from './dot-avatar.mjs';

const API = 'https://chatgpt.com/backend-api';
const CLOUD = 'https://codex-cloud-backend.chatgpt.com';
const id = value => {
  if (typeof value !== 'string' || !/^[a-zA-Z0-9_~-]{1,160}$/.test(value)) throw new Error('Dot 항목 ID가 올바르지 않습니다.');
  return encodeURIComponent(value);
};
const cursor = value => {
  if (value == null) return undefined;
  if (typeof value !== 'string' || value.length > 4096) throw new Error('Dot 페이지 커서가 올바르지 않습니다.');
  return value;
};
const query = values => new URLSearchParams(Object.entries(values).filter(([, v]) => v != null)).toString();
const visible = m => m && m.metadata?.is_hidden !== true && m.metadata?.hidden !== true && m.metadata?.is_visually_hidden_from_conversation !== true && m.channel !== 'analysis';
const textOf = m => m?.content?.text ?? (m?.content?.parts || []).filter(p => typeof p === 'string').join('\n');

// Project only content that the official messaging view presents to the user.
// Raw analysis, system instructions, authentication widgets and inspector URLs
// are never forwarded to a remote client.
export function dotMessage(m, selfUserId) {
  if (!m || !m.id || !visible(m)) return null;
  let role, text, attachments;
  const explicitRole = m.role || m.author?.role;
  if (m.content?.type === 'message_error' || (explicitRole && !['user','assistant'].includes(explicitRole))) return null;
  if (Array.isArray(m.raw_messages)) {
    role = 'assistant';
    text = m.raw_messages.filter(x => x.author?.role === 'assistant' && visible(x) && ['text', 'multimodal_text'].includes(x.content?.content_type)).map(textOf).filter(Boolean).join('\n\n');
    attachments = m.attachments;
  } else if (explicitRole === 'assistant') {
    role = 'assistant'; text = m.content?.text || m.preview || ''; attachments = m.attachments || m.content?.attachments;
  } else if (explicitRole === 'user' || (!explicitRole && Object.hasOwn(m, 'account_user_id'))) {
    // Personal Dot rooms can encode BOTH peers as role=user. Sender ownership
    // distinguishes a human message from a Dot message in that envelope.
    role = selfUserId && typeof m.account_user_id === 'string' && m.account_user_id ? (m.account_user_id === selfUserId ? 'user' : 'assistant') : 'user';
    text = m.content?.text || ''; attachments = m.content?.attachments;
  } else {
    if (m.content?.type === 'message_error') return null;
    return null;
  }
  if (m.deleted_at) return { id: m.id, role, fromSelf: role === 'user', text: '삭제된 메시지', deleted: true, createdAt: m.created_at, attachments: [] };
  return { id: m.id, role, fromSelf: role === 'user', text, createdAt: m.created_at, updatedAt: m.updated_at, requestId: m.request_id || null,
    attachments: (attachments || []).filter(x => ['file', 'thread', 'link'].includes(x.type)).map(x => ({ type: x.type, fileId: x.file_id, threadId: x.thread_id, name: x.file?.name || x.name || x.title || '첨부 항목', mime: x.file?.mime_type || x.mime_type, ...(x.type === 'link' && /^https:\/\//.test(x.url || '') ? { url: x.url } : {}) })) };
}

export function createDots({ call, emit = () => {}, fetchImpl = fetch, Socket = WebSocket, now = Date.now }) {
  const profiles = new Map(), typing = new Map(), tasks = new Map(), taskReads = new Map(), taskVersions = new Map(), reads = new Map(), cooldowns = new Map(), pending = new Map(), sent = new Map(), fingerprints = new Map(), watchers = new Map();
  const avatars = createDotAvatars({ request, fetchImpl, current });
  let identity = '', generation = 0, listing = null, listedAt = 0, broker = null, brokerTimer, offset, attempt = 0, stopped = false, authPending = null, authVersion = 0;
  function reset() {
    generation++; profiles.clear(); typing.clear(); avatars.reset(); tasks.clear(); taskReads.clear(); taskVersions.clear(); reads.clear(); cooldowns.clear(); sent.clear(); fingerprints.clear(); pending.clear(); listedAt = 0; listing = null;
    clearTimeout(brokerTimer); brokerTimer = null; broker?.terminate(); broker = null; offset = undefined; attempt = 0; watchers.clear();
  }
  async function readAuth() {
    const version=authVersion;
    let a = await call('getAuthStatus', { includeToken: true, refreshToken: false }), c;
    try { c = JSON.parse(Buffer.from(a.authToken.split('.')[1], 'base64url')); } catch { throw new Error('PC 공식 앱에서 ChatGPT 로그인이 필요합니다.'); }
    if (c.exp * 1000 < Date.now() + 60000) {
      a = await call('getAuthStatus', { includeToken: true, refreshToken: true });
      try { c = JSON.parse(Buffer.from(a.authToken.split('.')[1], 'base64url')); } catch { throw new Error('ChatGPT 로그인을 갱신하지 못했습니다.'); }
    }
    if(version!==authVersion||stopped)throw new Error('Dot 계정 연결이 변경되었습니다. 다시 열어주세요.');
    const identityClaims = c['https://api.openai.com/auth'];
    const account = identityClaims?.chatgpt_account_id, user = identityClaims?.chatgpt_user_id || identityClaims?.chatgpt_account_user_id || identityClaims?.account_user_id;
    if (!account || !user || !Number.isFinite(c.exp) || c.exp * 1000 <= Date.now()) throw new Error('PC 공식 앱에서 ChatGPT 로그인이 필요합니다.');
    const key = account + ':' + user;
    if (identity !== key) { reset(); identity = key; }
    return { token: a.authToken, account, user, key, generation };
  }
  async function auth() {
    if (authPending) return authPending;
    const pending = readAuth(); authPending = pending;
    try { return await pending; } finally { if (authPending === pending) authPending = null; }
  }
  function current(a) { if (a.key !== identity || a.generation !== generation || stopped) throw new Error('Dot 계정 연결이 변경되었습니다. 다시 열어주세요.'); }
  function request(a, path, options = {}) {
    current(a);
    if (options.method && options.method !== 'GET') return requestOnce(a, path, options);
    const key = JSON.stringify([a.key, a.generation, !!options.cloud, path]);
    if (reads.has(key)) return reads.get(key);
    const work = requestOnce(a, path, options).finally(() => { if (reads.get(key) === work) reads.delete(key); });
    reads.set(key, work); return work;
  }
  async function requestOnce(a, path, { method = 'GET', body, cloud = false } = {}) {
    current(a);
    const bucket = JSON.stringify([a.key, a.generation, cloud, method, path.split('?')[0]]), cooling = cooldowns.get(bucket);
    if (method === 'GET' && cooling?.retryAt > now()) throw cooling;
    const url = (cloud ? CLOUD : API) + path;
    let r;
    try {
      r = await fetchImpl(url, { method, headers: { Authorization: 'Bearer ' + a.token, 'ChatGPT-Account-Id': a.account,
        originator: 'Codex Pocket Remote', 'User-Agent': 'Codex-Pocket-Remote/0.8.5', Accept: 'application/json', ...(cloud ? { 'X-OpenAI-Product-Sku': 'aeon' } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
        ...(body ? { body: JSON.stringify(body) } : {}), redirect: 'error', signal: AbortSignal.timeout(18000) });
    } catch { throw Object.assign(new Error(method === 'GET' ? 'Dot 서버에 연결하지 못했습니다. 다시 시도하세요.' : '전송 결과를 확인하지 못했습니다. 내역을 확인한 뒤 같은 메시지를 다시 시도하세요.'), { deliveryUnknown: method !== 'GET' }); }
    current(a);
    const isJson = r.headers.get('content-type')?.includes('json');
    let data;
    try { if (isJson) data = await r.json(); else await r.body?.cancel(); } catch { throw Object.assign(new Error('Dot 응답을 읽지 못했습니다.'), { deliveryUnknown: method !== 'GET' }); }
    current(a);
    if (!r.ok) {
      const security = r.status === 403 && /attest|sentinel|integrity|verification/i.test(JSON.stringify(data || {}));
      const challenge = r.status === 403 && (r.headers.get('cf-mitigated') === 'challenge' || !isJson);
      const kind = challenge ? 'securityChallenge' : security ? 'verificationRequired' : r.status === 401 ? 'loginRequired' : r.status === 403 ? 'accessDenied' : 'unavailable';
      const operation = path.startsWith('/tbo') ? 'profiles' : path.startsWith('/messaging/') ? 'messages' : path.startsWith('/celsius/') ? 'realtime' : 'tasks';
      const retryAt = now() + (challenge || security || r.status === 429 ? 60000 : 10000);
      const error = Object.assign(new Error(challenge ? 'Dot 서버의 보안 확인으로 연결이 잠시 지연되고 있습니다.' : security ? 'Dot 전송에 공식 앱의 보안 검증이 필요합니다. 메시지를 복사해 공식 앱에서 보내주세요.' : `Dot 요청이 거절되었습니다 (${r.status}). ${r.status === 401 ? 'PC 공식 앱의 로그인을 확인하세요.' : '잠시 후 다시 시도하세요.'}`), { status: r.status, kind, operation, retryAt, deliveryUnknown: method !== 'GET' && (r.status >= 500 || r.status === 408) });
      if (method === 'GET') { cooldowns.set(bucket, error); while (cooldowns.size > 128) cooldowns.delete(cooldowns.keys().next().value); }
      throw error;
    }
    cooldowns.delete(bucket);
    if (!data || typeof data !== 'object') throw Object.assign(new Error('Dot 서버 응답 형식이 변경되었습니다.'), { deliveryUnknown: method !== 'GET' });
    return data;
  }
  const profile = p => ({ id: p.id, name: p.display_name || 'Dot', roomId: p.messaging_room_id || null, rootThreadId: p.active_root_thread_id || null, paused: !!p.is_paused, status: p.status, avatar: avatars.describe(p), updatedAt: p.updated_at, preview: p.messaging_room_preview?.message_preview?.preview || '' });
  function presence(p) { const expiresAt=typing.get(p.id)||0;return {typing:expiresAt>now(),expiresAt,ttlMs:Math.max(0,expiresAt-now())}; }
  async function list(a, force = false) {
    if (!force && Date.now() - listedAt < 15000) return [...profiles.values()];
    if (listing) return listing;
    const work = (async () => {
      let next, count = 0; const all = new Map(), seen = new Set();
      do {
        const page = await request(a, '/tbo?' + query({ limit: 25, cursor: next }));
        if (!Array.isArray(page.items)) throw new Error('Dot 목록 응답 형식이 변경되었습니다.');
        for (const p of page.items) if (p.aeon_kind === 'orbit') all.set(p.id, profile(p));
        next = page.cursor || null;
        if (next && seen.has(next)) throw new Error('Dot 목록의 페이지가 반복되었습니다.');
        seen.add(next);
      } while (next && ++count < 100);
      if (next) throw new Error('Dot 목록이 너무 큽니다. 공식 앱에서 목록을 확인해주세요.');
      current(a); profiles.clear(); for (const [k, v] of all) profiles.set(k, v); listedAt = Date.now(); return [...all.values()];
    })();
    listing = work; try { return await work; } finally { if (listing === work) listing = null; }
  }
  async function dot(a, dotId) {
    // A confirmed room identity does not expire with the profile list's UI TTL.
    // Re-listing on every message/watch makes an unrelated list failure break chat.
    id(dotId); if (!profiles.has(dotId)) await list(a); const p = profiles.get(dotId);
    if (!p) throw new Error('현재 계정에서 이 Dot를 찾을 수 없습니다.');
    return p;
  }
  async function taskReferences(a, p) {
    const cached = tasks.get(p.id);
    if (cached && Date.now() - cached.at < 15000) return cached.items;
    if (taskReads.has(p.id)) return taskReads.get(p.id);
    const work = readTaskReferences(a, p).finally(() => { if (taskReads.get(p.id) === work) taskReads.delete(p.id); });
    taskReads.set(p.id, work); return work;
  }
  async function readTaskReferences(a, p) {
    const version = taskVersions.get(p.id) || 0;
    let next, pages = 0; const all = new Map(), seen = new Set();
    do {
      const page = await request(a, '/tbo/' + id(p.id) + '/threads?' + query({ limit: 100, include_hidden: false, cursor: next }));
      if (!Array.isArray(page.items)) throw new Error('Dot 작업 목록 응답 형식이 변경되었습니다.');
      for (const t of page.items) if (t.is_user_visible !== false && t.thread_id !== p.rootThreadId) all.set(t.thread_id, t);
      next = page.cursor || null; if (next && seen.has(next)) throw new Error('Dot 작업의 페이지가 반복되었습니다.'); seen.add(next);
    } while (next && ++pages < 100);
    if (next) throw new Error('Dot 작업 목록이 너무 큽니다. 공식 앱에서 확인해주세요.');
    current(a); const result = [...all.values()];
    if ((taskVersions.get(p.id) || 0) === version) tasks.set(p.id, { at: Date.now(), items: result });
    return result;
  }
  async function taskList(a, p) {
    const result = await taskReferences(a, p), out = new Array(result.length);
    // Keep four slots busy; one slow task must not block the next whole batch.
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(4, result.length) }, async () => {
      for (;;) {
        const index = next++; if (index >= result.length) return; const t = result[index];
      try {
        const r = await request(a, '/v1/threads/' + id(t.thread_id), { cloud: true }), h = r.thread;
        if (h?.id !== t.thread_id) throw new Error('작업 응답이 일치하지 않습니다.');
        out[index] = { id: h.id, name: h.name || h.preview || 'Dot 작업', status: h.status?.type || 'unknown', model: h.model, effort: h.reasoningEffort, source: h.threadSource, attachedAt: t.attached_at };
      } catch (e) { out[index] = { id: t.thread_id, name: 'Dot 작업', status: 'unknown', error: e.message, attachedAt: t.attached_at }; }
      }
    }));
    current(a);
    return out;
  }
  async function task(a, p, threadId) {
    id(threadId); const refs = await taskReferences(a, p);
    if (!refs.some(t => t.thread_id === threadId)) throw new Error('이 Dot에 연결된 작업이 아닙니다.');
  }
  function emitUpdate(p, kind = 'messages', details = {}) {
    if (kind !== 'typing') {
      tasks.delete(p.id); taskReads.delete(p.id); taskVersions.set(p.id, (taskVersions.get(p.id) || 0) + 1);
      for (const key of reads.keys()) if (key.includes('/tbo/' + id(p.id) + '/threads?') || p.roomId && key.includes('/messaging/rooms/' + id(p.roomId) + '/')) reads.delete(key);
    }
    emit({ method: 'pocket/dots/changed', params: { dotId: p.id, kind, ...details } });
  }
  async function watch(a, p, owner) {
    watchers.set(owner, { key: a.key, dotId: p.id, expires: Date.now() + 45000 });
    if (!broker && !brokerTimer) connectBroker(a).catch(() => {});
  }
  async function connectBroker(a) {
    if (stopped || !watchers.size) return;
    try {
      const data = await request(a, '/celsius/ws/user'); current(a);
      const url = new URL(data.websocket_url);
      if (url.protocol !== 'wss:' || !(url.hostname === 'chatgpt.com' || url.hostname.endsWith('.chatgpt.com'))) throw new Error('Dot 이벤트 서버 주소가 올바르지 않습니다.');
      if (broker) return;
      const ws = new Socket(url.href, { perMessageDeflate: false, maxPayload: 4 * 1024 * 1024 }); broker = ws;
      ws.on('error', () => {});
      ws.on('open', () => { if (broker !== ws) return; attempt = 0; ws.send(JSON.stringify([{ id: 1, command: { type: 'connect', presence: { type: 'presence', state: 'foreground' } } }, { id: 2, command: { type: 'subscribe', topic_id: 'calpico-chatgpt-messaging', ...(offset ? { offset } : {}) } }])); });
      ws.on('message', bytes => {
        if (broker !== ws || identity !== a.key) return;
        let frames; try { frames = JSON.parse(bytes); } catch { return; }
        for (const frame of Array.isArray(frames) ? frames : []) {
          const frames = frame.reply?.catchups || [frame];
          if (frame.id === 2 && frame.reply?.recovered !== true) for (const p of profiles.values()) emitUpdate(p, 'resync');
          for (const f of frames) {
            if (f.offset) offset = f.offset;
            const payload = f.payload, roomId = payload?.payload?.room_id || payload?.payload?.room?.id;
            if (!roomId) continue;
            const p = [...profiles.values()].find(p => p.roomId === roomId);
            if (p && payload.type === 'calpico-is-responding-heartbeat') {
              // Personal Dot rooms identify both peers as role=user. Never show
              // the human's own typing heartbeat as a Dot response.
              const sender=payload.payload?.source?.account_user_id;
              if(typeof sender!=='string'||sender===a.user)continue;
              typing.set(p.id,payload.payload.typing===false?0:now()+15000);
              emitUpdate(p,'typing',presence(p));
            } else if (p && payload.type?.startsWith('calpico-')) {
              // The add event already contains the visible message. Forward its
              // projection immediately instead of waiting for another cloud GET.
              const message=payload.type==='calpico-message-add'?dotMessage(payload.payload?.message,a.user):null;
              const messageId=payload.type==='calpico-message-update'&&typeof payload.payload?.message_id==='string'?payload.payload.message_id:null;
              emitUpdate(p,'messages',message?{message,scope:createHash('sha256').update(a.key).digest('hex')}:messageId?{messageId}:{});
            }
          }
          if (frame.reply?.last_offset) offset = frame.reply.last_offset;
        }
      });
      ws.on('close', () => { if (broker !== ws) return; broker = null; for(const p of profiles.values())if(typing.has(p.id)){typing.delete(p.id);emitUpdate(p,'typing',presence(p));}if (identity === a.key) scheduleBroker(); });
    } catch (error) { scheduleBroker(Math.max(0, (error.retryAt || 0) - Date.now())); }
  }
  function scheduleBroker(minimumDelay = 0) {
    if (stopped || !watchers.size || brokerTimer) return;
    brokerTimer = setTimeout(async () => { brokerTimer = null; try { await connectBroker(await auth()); } catch { scheduleBroker(); } }, Math.max(minimumDelay, Math.min(30000, 300 * 1.7 ** attempt++)) + Math.random() * 200);
    brokerTimer.unref?.();
  }
  const cleanup = setInterval(() => {
    for (const [k, v] of watchers) if (v.expires < Date.now()) watchers.delete(k);
    if (!watchers.size) { clearTimeout(brokerTimer); brokerTimer = null; const ws = broker; broker = null; ws?.terminate(); }
  }, 15000); cleanup.unref?.();
  return {
    async handle(method, params = {}, owner = 'client') {
      if (method === 'bridge/dots/unwatch') { watchers.delete(owner); return { ok: true }; }
      if (method === 'bridge/dots/access') {
        let a;
        try { a = await auth(); const dots = await list(a, params.refresh === true); current(a); return { allowed: true, scope: createHash('sha256').update(a.key).digest('hex'), dots }; }
        catch (error) {
          const scope = a && a.key === identity && a.generation === generation ? createHash('sha256').update(a.key).digest('hex') : undefined;
          if (scope && profiles.size && ['securityChallenge', 'unavailable'].includes(error.kind)) return { allowed: true, scope, dots: [...profiles.values()], stale: true, retryAt: error.retryAt };
          return { allowed: false, reason: error.kind === 'securityChallenge' ? 'temporarilyUnavailable' : error.status === 403 ? 'denied' : error.status === 401 ? 'loginRequired' : 'unavailable', ...(scope ? { scope } : {}), ...(error.retryAt ? { retryAt: error.retryAt } : {}) };
        }
      }
      const a = await auth();
      if (method === 'bridge/dots/list') return { dots: await list(a, params.refresh === true) };
      const p = await dot(a, params.dotId);
      if (method === 'bridge/dots/watch') { await watch(a, p, owner); return { ok: true, presence: presence(p) }; }
      if (method === 'bridge/dots/avatar') return avatars.read(a,p,params.motion===true);
      if (method === 'bridge/dots/messages') {
        if (!p.roomId) throw new Error('공식 앱에서 이 Dot의 첫 대화를 시작해주세요.');
        const page = await request(a, '/messaging/rooms/' + id(p.roomId) + '/messages?' + query({ limit: 20, before: cursor(params.before), after: cursor(params.after) }));
        if (!Array.isArray(page.items)) throw new Error('Dot 메시지 응답 형식이 변경되었습니다.');
        return { authorshipVersion: 2, presence: presence(p), messages: page.items.map(m => dotMessage(m, a.user)).filter(Boolean), before: page.prev_cursor || (page.items.length === 20 ? page.items[0]?.id : null), after: page.next_cursor || null };
      }
      if (method === 'bridge/dots/tasks') return { tasks: await taskList(a, p) };
      if (method === 'bridge/dots/task/read') {
        await task(a, p, params.threadId);
        const r = await request(a, '/v2/threads/' + id(params.threadId) + '/items?' + query({ limit: 60, sortDirection: 'desc', cursor: cursor(params.cursor) }), { cloud: true });
        if (!Array.isArray(r.data)) throw new Error('Dot 작업 내역 응답 형식이 변경되었습니다.');
        // Tool internals remain collapsed in the mobile view; native visible items
        // carry the same type schema as local work sessions.
        return { data: r.data, nextCursor: r.nextCursor || null };
      }
      if (method === 'bridge/dots/pause' || method === 'bridge/dots/resume') {
        const r = await request(a, '/tbo/' + id(p.id) + '/runtime/' + (method.endsWith('/pause') ? 'pause' : 'resume'), { method: 'POST', body: {} });
        listedAt = 0; emitUpdate(p, 'profile'); return { status: r.status || 'requested' };
      }
      if (method === 'bridge/dots/send') {
        if (!p.roomId) throw new Error('공식 앱에서 이 Dot의 첫 대화를 시작해주세요.');
        if (typeof params.text !== 'string' || !params.text.trim() || params.text.length > 100000 || !/^[0-9a-f-]{36}$/i.test(params.requestId || '')) throw new Error('Dot 메시지 또는 전송 ID가 올바르지 않습니다.');
        let text = params.text;
        if (params.taskId) { await task(a, p, params.taskId); text = `다음 연결 작업에 추가 지시를 적용해주세요. 작업 thread ID: ${params.taskId}\n\n${text}`; }
        const key = a.key + ':' + p.id + ':' + params.requestId, hash = createHash('sha256').update(text).digest('hex'), old = sent.get(key) || pending.get(key);
        if (fingerprints.has(key) && fingerprints.get(key) !== hash) throw new Error('같은 전송 ID에 다른 메시지를 사용할 수 없습니다.');
        if (sent.has(key)) return old.result;
        if (pending.has(key)) return old.promise;
        fingerprints.set(key, hash); while (fingerprints.size > 1024) fingerprints.delete(fingerprints.keys().next().value);
        const promise = (async () => {
          // Normal authenticated request; never fabricate attestation or retry a
          // rejection using another identity. Preserve request ID on uncertain delivery.
          const r = await request(a, '/messaging/rooms/' + id(p.roomId) + '/messages', { method: 'POST', body: { content: { text, attachments: [] }, request_id: params.requestId, idempotency_token: params.requestId } });
          if (!r.id) throw Object.assign(new Error('Dot의 수신 확인을 읽지 못했습니다. 대화 내역을 먼저 확인해주세요.'), { deliveryUnknown: true });
          const result = { message: dotMessage(r, a.user) }; sent.set(key, { hash, result });
          while (sent.size > 512) sent.delete(sent.keys().next().value);
          emitUpdate(p); return result;
        })();
        pending.set(key, { hash, promise }); try { return await promise; } finally { if (pending.get(key)?.promise === promise) pending.delete(key); }
      }
      throw new Error('지원되지 않는 Dot 요청입니다.');
    },
    disconnect(owner) { watchers.delete(owner); },
    invalidateAuth() { authVersion++;authPending=null;identity='';reset(); },
    close() { stopped = true; clearInterval(cleanup); reset(); watchers.clear(); }
  };
}

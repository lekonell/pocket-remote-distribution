import { existsSync, readFileSync, mkdirSync, copyFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

export const settingsFiles = ['.endpoint.json', '.endpoint-secret', '.remote-secret', '.setup.json', '.launcher.json', '.relay.json', '.relay-tunnel.key', '.relay-tunnel.key.pub', '.shared-server.json', '.desktop-shared-backup'];
export function settingsRoot(root, { env = process.env, platform = process.platform } = {}) {
  if (env.REMOTE_DATA_DIR) return resolve(env.REMOTE_DATA_DIR);
  // Unmarked folders remain portable, including isolated test fixtures.
  if (platform !== 'win32' || !existsSync(resolve(root, 'distribution.json'))) return root;
  const { channel } = JSON.parse(readFileSync(resolve(root, 'distribution.json'), 'utf8'));
  if (!['standard', 'external'].includes(channel)) throw Error('Invalid distribution channel');
  if (!env.LOCALAPPDATA) throw Error('Windows user settings directory unavailable');
  return resolve(env.LOCALAPPDATA, 'PocketRemote', channel);
}
export function settingsPath(root, name, options) {
  if (!settingsFiles.includes(name)) throw Error('Unknown persistent setting');
  return resolve(settingsRoot(root, options), name);
}
export function migrateSettings(root, options) {
  const target = settingsRoot(root, options);
  if (target === root) return target;
  mkdirSync(target, { recursive: true, mode: 0o700 });
  for (const name of settingsFiles) {
    const destination = resolve(target, name), source = resolve(root, name);
    if (!existsSync(destination) && existsSync(source)) {
      try { copyFileSync(source, destination, 1); } catch (error) { if (error.code !== 'EEXIST') throw error; }
    }
  }
  // Relocate only the dedicated tunnel key, never arbitrary SSH keys.
  for (const name of ['.endpoint.json', '.relay.json']) {
    const path = resolve(target, name);
    if (!existsSync(path)) continue;
    const text = readFileSync(path, 'utf8').replace(/^\uFEFF/, '');
    const value = JSON.parse(text);
    let changed = false;
    for (const field of ['sshIdentityFile', 'keyFile']) {
      if (value[field] === resolve(root, '.relay-tunnel.key')) { value[field] = resolve(target, '.relay-tunnel.key'); changed = true; }
    }
    if (changed) writeFileSync(path, JSON.stringify(value), { mode: 0o600 });
  }
  return target;
}

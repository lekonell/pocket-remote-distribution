// Runs only inside the user's explicit SSH login console. Password prompts stay
// in OpenSSH; use native argv handling rather than PowerShell 5 quote expansion.
import { spawn } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve, dirname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const request = resolve(process.argv[2] || ''), receipt = resolve(process.argv[3] || '');
if (!request.startsWith(resolve(root, '.relay-login') + sep) || dirname(request) !== dirname(receipt)) throw Error('Invalid login session paths');
try {
  const input = JSON.parse((await readFile(request, 'utf8')).replace(/^\uFEFF/, ''));
  if (!Array.isArray(input.arguments) || input.arguments.some(value => typeof value !== 'string')) throw Error('Invalid SSH arguments');
  const output = await new Promise((done, reject) => {
    const ssh = spawn('ssh', input.arguments, { windowsHide: false, stdio: ['inherit', 'pipe', 'inherit'] });
    let text = '';
    ssh.stdout.on('data', bytes => { text += bytes; if (text.length > 65536) ssh.kill(); });
    ssh.on('error', reject); ssh.on('close', code => done({ ok: code === 0, output: text }));
  });
  await writeFile(receipt, JSON.stringify(output), { mode: 0o600 });
  process.exitCode = output.ok ? 0 : 1;
} catch {
  await writeFile(receipt, '{"ok":false}', { mode: 0o600 }); process.exitCode = 1;
}

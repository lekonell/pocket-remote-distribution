import { isIP } from 'node:net';
export function endpointEnvironment(config, inherited = process.env) {
  const address = ['direct', 'custom'].includes(config.provider) ? config.bindAddress || '127.0.0.1' : '127.0.0.1';
  if (!isIP(address)) throw Error('Invalid bridge bind address');
  const port = Number(config.localPort || 4545);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw Error('Invalid bridge port');
  return { ...inherited, REMOTE_BIND: address, REMOTE_PORT: String(port) };
}

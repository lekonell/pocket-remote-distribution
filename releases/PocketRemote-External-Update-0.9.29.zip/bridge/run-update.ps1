﻿param([Parameter(Mandatory=$true)][string]$Archive,[Parameter(Mandatory=$true)][string]$Manifest,[Parameter(Mandatory=$true)][string]$NodePath,[switch]$Requested)
$ErrorActionPreference='Stop'
$installRoot=Split-Path -Parent $PSScriptRoot
function Quote-UpdatePath([string]$value) {
    if ($value.IndexOfAny([char[]]@('"',"`r","`n")) -ge 0) { throw 'Invalid update path' }
    return '"'+$value+'"'
}
$shell=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
$arguments=@('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',(Quote-UpdatePath (Join-Path $installRoot 'UPDATE-PC.ps1')),'-Archive',(Quote-UpdatePath $Archive),'-Manifest',(Quote-UpdatePath $Manifest),'-NodePath',(Quote-UpdatePath $NodePath))
if ($Requested) { $arguments += '-Requested' }
# Start a separate hidden Windows console. DETACHED_PROCESS does not reliably
# execute PowerShell -File; sharing the Node console can kill the installer
# when it stops its own host/updater. The independent installer must survive.
$installer=Start-Process -FilePath $shell -ArgumentList $arguments -WorkingDirectory $installRoot -WindowStyle Hidden -PassThru
$installer.WaitForExit()
exit $installer.ExitCode

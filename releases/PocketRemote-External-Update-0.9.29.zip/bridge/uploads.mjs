import { mkdir, readFile, writeFile, rename, stat, open, unlink } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, sep } from 'node:path';

export function createUploads(root) {
  const directory = resolve(root, '.uploads');
  const locks = new Map();
  const maxSize = 50 * 1024 * 1024;
  function paths(id) {
    if (typeof id !== 'string' || !/^[a-f0-9-]{32,36}$/i.test(id)) throw new Error('올바르지 않은 파일 ID입니다.');
    const path = resolve(directory, id);
    if (!path.startsWith(directory + sep)) throw new Error('파일 경로를 확인하세요.');
    return { folder: path, metadata: resolve(path, 'metadata.json') };
  }
  async function load(id) {
    const p = paths(id);
    try { return { ...p, data: JSON.parse(await readFile(p.metadata, 'utf8')) }; }
    catch { throw new Error('업로드 파일을 찾을 수 없습니다. 다시 선택하세요.'); }
  }
  async function save(metadata, data) {
    await writeFile(metadata + '.tmp', JSON.stringify(data), { mode: 0o600 });
    await rename(metadata + '.tmp', metadata);
  }
  function descriptor(data) {
    return { id: data.id, name: data.name, mime: data.mime, size: data.size, offset: data.offset, complete: !!data.complete, ...(data.complete ? { path: data.path, sha256: data.sha256 } : {}) };
  }
  async function run(method, params) {
    const { id } = params;
    if (method === 'bridge/file/begin') {
      const p = paths(id);
      if (!Number.isSafeInteger(params.size) || params.size < 0 || params.size > maxSize) throw new Error('파일은 50MB 이하로 선택하세요.');
      const name = String(params.name || 'file').replace(/[\\/<>:"|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '').slice(0, 180) || 'file';
      let existing;
      try { existing = JSON.parse(await readFile(p.metadata, 'utf8')); } catch {}
      if (existing) {
        if (existing.name !== name || existing.size !== params.size) throw new Error('이 파일 ID가 다른 파일에 사용되었습니다.');
        return descriptor(existing);
      }
      await mkdir(p.folder, { recursive: true, mode: 0o700 });
      const path = resolve(p.folder, 'attachment-' + name);
      await writeFile(path, Buffer.alloc(0), { flag: 'wx', mode: 0o600 });
      const data = { id, name, size: params.size, mime: String(params.mime || 'application/octet-stream').slice(0, 160), path, offset: 0, createdAt: Date.now(), complete: false };
      await save(p.metadata, data);
      return descriptor(data);
    }
    const { metadata, data } = await load(id);
    if (method === 'bridge/file/status') return descriptor(data);
    if (method === 'bridge/file/delete') {
      await unlink(data.path); await unlink(metadata); return {};
    }
    if (method === 'bridge/file/chunk') {
      if (!Number.isSafeInteger(params.offset) || params.offset < 0 || typeof params.data !== 'string' || !/^[A-Za-z0-9+/]*={0,2}$/.test(params.data)) throw new Error('파일 조각이 올바르지 않습니다.');
      const bytes = Buffer.from(params.data, 'base64');
      if (!bytes.length || bytes.length > 192 * 1024 || params.offset + bytes.length > data.size) throw new Error('파일 조각의 크기를 확인하세요.');
      if (data.complete) return descriptor(data);
      if (params.offset < data.offset && params.offset + bytes.length <= data.offset) {
        const file = await open(data.path, 'r');
        const stored = Buffer.alloc(bytes.length);
        try { await file.read(stored, 0, stored.length, params.offset); } finally { await file.close(); }
        if (!stored.equals(bytes)) throw new Error('다시 받은 파일 조각이 원본과 다릅니다.');
        return descriptor(data);
      }
      if (params.offset !== data.offset) throw new Error('업로드 위치가 달라졌습니다. 이어 올리기를 다시 시도하세요.');
      const file = await open(data.path, 'r+');
      try { await file.write(bytes, 0, bytes.length, params.offset); await file.sync(); } finally { await file.close(); }
      data.offset += bytes.length;
      await save(metadata, data);
      return descriptor(data);
    }
    if (method === 'bridge/file/finish') {
      if (data.offset !== data.size || (await stat(data.path)).size !== data.size) throw new Error('아직 업로드가 완료되지 않았습니다.');
      if (!data.complete) {
        const hash = createHash('sha256');
        for await (const bytes of createReadStream(data.path)) hash.update(bytes);
        data.sha256 = hash.digest('hex'); data.complete = true; await save(metadata, data);
      }
      return descriptor(data);
    }
    throw new Error('지원되지 않는 파일 작업입니다.');
  }
  return {
    maxSize,
    async handle(method, params) {
      const id = params?.id;
      const previous = locks.get(id) || Promise.resolve();
      const operation = previous.catch(() => {}).then(() => run(method, params || {}));
      locks.set(id, operation);
      try { return await operation; } finally { if (locks.get(id) === operation) locks.delete(id); }
    },
    async resolve(id) {
      const { data } = await load(id);
      if (!data.complete) throw new Error('파일 업로드를 먼저 완료하세요.');
      return descriptor(data);
    }
  };
}

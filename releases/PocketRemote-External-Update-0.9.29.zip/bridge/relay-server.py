#!/usr/bin/env python3
"""Root-only Linux/Nginx relay provisioner. No desktop auth tokens or private keys."""
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import sys
import tempfile
import time

STATE = Path('/var/lib/pocket-remote-relay')
ROUTES = Path('/etc/nginx/pocket-remote.d')
USER = 'pocketremote'
ADDRESS_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

def validate(request):
    identifier = request.get('id', '')
    domain = request.get('domain', '')
    public_key = request.get('publicKey', '').split()
    if not re.fullmatch(r'pc-[a-f0-9]{24}', identifier):
        raise ValueError('Invalid device ID')
    if not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?', domain) or '..' in domain:
        raise ValueError('Invalid TLS domain')
    if len(public_key) != 2 or public_key[0] != 'ssh-ed25519':
        raise ValueError('An Ed25519 public key is required')
    raw = base64.b64decode(public_key[1], validate=True)
    if len(raw) != 51 or raw[:19] != b'\x00\x00\x00\x0bssh-ed25519\x00\x00\x00\x20':
        raise ValueError('Invalid public key')
    port = request.get('adoptPort')
    if port is not None and (type(port) is not int or not 1024 <= port <= 65535):
        raise ValueError('Invalid existing tunnel port')
    return identifier, domain, ' '.join(public_key), port

def allocate(registry, adopted=None):
    occupied = {entry['port'] for entry in registry.values()}
    if adopted is not None:
        if adopted in occupied:
            raise ValueError('This tunnel port is assigned to another PC')
        # Administrator explicitly adopts a running legacy tunnel.
        return adopted
    for port in range(20000, 30000):
        if port in occupied:
            continue
        with socket.socket() as probe:
            try:
                probe.bind(('127.0.0.1', port))
                return port
            except OSError:
                pass
    raise ValueError('No available relay ports')

def address_code(registry, previous=None):
    if previous and re.fullmatch(r'[A-HJ-NP-Z2-9]{8}', previous.get('addressCode', '')):
        return previous['addressCode']
    occupied = {entry.get('addressCode') for entry in registry.values()}
    for _ in range(128):
        code = ''.join(secrets.choice(ADDRESS_ALPHABET) for _ in range(8))
        if code not in occupied:
            return code
    raise ValueError('No available PC address codes')

def route(identifier, domain, port, code=None):
    # This include sits inside an existing TLS server, never creates certificates.
    if code is not None and not re.fullmatch(r'[A-HJ-NP-Z2-9]{8}', code):
        raise ValueError('Invalid PC address code')
    paths = [f'/codex-remote/{identifier}/socket']
    if code:
        paths.append(f'/r/{code.lower()}/socket')
    return f'# Pocket Remote managed route: {identifier}\n' + ''.join(f'''location = {path} {{
    if ($host != "{domain}") {{ return 404; }}
    proxy_pass http://127.0.0.1:{port}/socket;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_buffering off;
    proxy_request_buffering off;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
}}
''' for path in paths)

def authorized(registry):
    lines = ['# Managed by Pocket Remote; public tunnel keys only.']
    for identifier, entry in sorted(registry.items()):
        # permitopen points to an unusable port; no local forwards or server shell.
        lines.append(f'restrict,port-forwarding,permitopen="127.0.0.1:1",permitlisten="127.0.0.1:{entry["port"]}",command="/bin/false" {entry["publicKey"]} {identifier}')
    return '\n'.join(lines) + '\n'

def atomic(path, data, mode=0o600):
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix=path.name + '.')
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

def checked(*arguments):
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=30)
    if result.returncode:
        raise RuntimeError('Server configuration check failed: ' + arguments[0])
    return result.stdout

def provision(request):
    import fcntl
    import grp
    import pwd
    if os.geteuid() != 0:
        raise PermissionError('Server administrator (root or sudo) login is required')
    identifier, domain, public_key, adopted = validate(request)
    snippet = Path(request.get('nginxSnippet', '/etc/nginx/snippets/moda-share.conf'))
    owner = os.environ.get('SUDO_USER') or 'root'
    if owner != 'root':
        policy = json.loads((STATE / 'domains.json').read_text())
        if policy.get(domain) != str(snippet) or adopted is not None:
            raise PermissionError('This account can provision only operator-approved TLS domains and new ports')
    if not re.fullmatch(r'/etc/nginx/(?:snippets|sites-available)/[A-Za-z0-9_.-]+', str(snippet)) or not snippet.is_file():
        raise ValueError('Choose an existing Nginx TLS server include')
    # Refuse to report success for a domain not already served with TLS.
    effective = checked('nginx', '-T')
    if not any(domain in block.split('server_name', 1)[-1].split(';', 1)[0].split() and re.search(r'listen\s+[^;]*443[^;]*ssl', block) for block in effective.split('server {')[1:]):
        raise ValueError('The domain must have an existing Nginx HTTPS server and certificate')
    os.umask(0o077)
    STATE.mkdir(mode=0o700, exist_ok=True)
    ROUTES.mkdir(mode=0o755, exist_ok=True)
    os.chmod(STATE, 0o700)
    with open(STATE / 'registry.lock', 'w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        registry_file = STATE / 'registry.json'
        registry = json.loads(registry_file.read_text()) if registry_file.exists() else {}
        previous = registry.get(identifier)
        if previous and (previous['publicKey'] != public_key or previous['domain'] != domain or (owner != 'root' and previous.get('owner') != owner)):
            raise ValueError('Device identity differs from the existing relay registration')
        if not previous and owner != 'root' and sum(entry.get('owner') == owner for entry in registry.values()) >= 32:
            raise ValueError('This SSH account already has 32 PC endpoints')
        port = previous['port'] if previous else allocate(registry, adopted)
        code = address_code(registry, previous)
        registry = copy.deepcopy(registry)
        registry[identifier] = {'domain': domain, 'port': port, 'publicKey': public_key, 'owner': previous.get('owner', owner) if previous else owner, 'addressCode': code}
        home = STATE / 'tunnel'
        try:
            account = pwd.getpwnam(USER)
            if account.pw_dir != str(home):
                raise ValueError('The tunnel account already exists with a different home')
        except KeyError:
            checked('useradd', '--system', '--user-group', '--home-dir', str(home), '--shell', '/bin/sh', USER)
        # Traversal is needed by sshd, but only root can modify keys or registry.
        os.chmod(STATE, 0o711)
        home.mkdir(mode=0o755, exist_ok=True)
        key_dir = home / '.ssh'
        key_dir.mkdir(mode=0o755, exist_ok=True)
        os.chmod(home, 0o755)
        os.chmod(key_dir, 0o755)
        include = 'include /etc/nginx/pocket-remote.d/*.conf;'
        original = snippet.read_text()
        updated = original if include in original else original + '\n' + include + '\n'
        ssh_config = Path('/etc/ssh/sshd_config')
        ssh_original = ssh_config.read_text()
        ssh_include = 'Include /etc/ssh/pocket-remote-relay.conf'
        if ssh_include not in ssh_original:
            match = re.search(r'^Match\s', ssh_original, re.MULTILINE)
            at = match.start() if match else len(ssh_original)
            ssh_updated = ssh_original[:at].rstrip() + '\n\n' + ssh_include + '\n\n' + ssh_original[at:]
        else:
            ssh_updated = ssh_original
        ssh_policy = '''# Only the dedicated tunnel account is affected.
Match User pocketremote
    AllowTcpForwarding remote
    GatewayPorts no
    PermitOpen none
    PermitTTY no
    AllowAgentForwarding no
    X11Forwarding no
    PasswordAuthentication no
    KbdInteractiveAuthentication no
    ForceCommand /bin/false
Match all
'''
        paths = {snippet: (updated, 0o644), ROUTES / (identifier + '.conf'): (route(identifier, domain, port, code), 0o644), key_dir / 'authorized_keys': (authorized(registry), 0o644), registry_file: (json.dumps(registry, sort_keys=True), 0o600), ssh_config: (ssh_updated, 0o644), Path('/etc/ssh/pocket-remote-relay.conf'): (ssh_policy, 0o644)}
        backups = {path: (path.read_bytes(), path.stat().st_mode & 0o777) if path.exists() else None for path in paths}
        backup_dir = STATE / 'backups' / (str(time.time_ns()) + '-' + identifier)
        backup_dir.mkdir(parents=True, mode=0o700)
        os.chmod(backup_dir.parent, 0o700)
        for index, (path, data) in enumerate(backups.items()):
            if data:
                atomic(backup_dir / (str(index) + '.conf'), data[0].decode(), 0o600)
        atomic(backup_dir / 'paths.json', json.dumps([str(path) for path in backups]), 0o600)
        try:
            for path, (data, mode) in paths.items():
                atomic(path, data, mode)
            checked('nginx', '-t')
            checked('sshd', '-t')
            ssh_service = 'ssh' if subprocess.run(['systemctl', 'is-active', '--quiet', 'ssh']).returncode == 0 else 'sshd'
            checked('systemctl', 'reload', ssh_service)
            checked('systemctl', 'reload', 'nginx')
        except Exception:
            for path, previous_data in backups.items():
                if previous_data:
                    atomic(path, previous_data[0].decode(), previous_data[1])
                elif path.exists():
                    path.unlink()
            # Reload is graceful; valid previous config stays available.
            subprocess.run(['systemctl', 'reload', ssh_service], capture_output=True) if 'ssh_service' in locals() else None
            subprocess.run(['systemctl', 'reload', 'nginx'], capture_output=True)
            raise
        # Install a fixed, root-owned command for operator-authorized SSH users.
        # Its sudo permission cannot execute arbitrary Python or shell commands.
        installer_source = globals().get('_installer_source')
        if owner == 'root' and installer_source:
            try:
                grp.getgrnam('pocketremote-setup')
            except KeyError:
                checked('groupadd', '--system', 'pocketremote-setup')
            domains_file = STATE / 'domains.json'
            domains = json.loads(domains_file.read_text()) if domains_file.exists() else {}
            domains[domain] = str(snippet)
            atomic(domains_file, json.dumps(domains), 0o600)
            atomic(Path('/usr/local/sbin/pocket-remote-provision'), installer_source.decode(), 0o755)
            sudoers = Path('/etc/sudoers.d/pocket-remote-relay')
            atomic(sudoers, '%pocketremote-setup ALL=(root) NOPASSWD: /usr/local/sbin/pocket-remote-provision *\n', 0o440)
            checked('visudo', '-cf', str(sudoers))
    return {'id': identifier, 'domain': domain, 'addressCode': code, 'websocketUrl': f'wss://{domain}/r/{code.lower()}/socket', 'canonicalUrl': f'wss://{domain}/codex-remote/{identifier}/socket', 'reversePort': port, 'sshUser': USER, 'fingerprint': hashlib.sha256(base64.b64decode(public_key.split()[1])).hexdigest()}

def main():
    try:
        request = json.loads(base64.b64decode(sys.argv[1], validate=True))
        print(json.dumps({'ok': True, 'result': provision(request)}))
    except Exception as error:
        print(json.dumps({'ok': False, 'error': str(error)}))
        return 1
    return 0

if __name__ == '__main__':
    sys.exit(main())

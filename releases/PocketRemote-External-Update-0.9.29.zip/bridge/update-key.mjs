// Public release verification key. Private signing material never ships.
export const updatePublicKey = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAyk903WzUobKbLny7pBb2Q2q8V80fEsEXByNacVRVGjE=\n-----END PUBLIC KEY-----\n";

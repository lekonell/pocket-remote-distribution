import http from 'node:http';
import { WebSocket, WebSocketServer } from 'ws';
import { sharedUrl } from './upstream.mjs';
import { createExecutionTracker } from './execution.mjs';

// Transparent local transport. Keep only settings metadata, never message
// bodies or credentials, and observe successful native responses.
export function createDesktopProxy({ listenUrl, upstreamUrl, capture, tracker = createExecutionTracker({ capture }), onError = () => {}, onRequest = () => {}, onEvent = () => {} }) {
  const local = new URL(sharedUrl(listenUrl)), target = sharedUrl(upstreamUrl);
  if (sharedUrl(listenUrl) === target) throw Error('Desktop proxy must use a different port.');
  const server = http.createServer((_, res) => { res.writeHead(404); res.end(); });
  const wss = new WebSocketServer({ noServer: true, perMessageDeflate: false, maxPayload: 64 * 1024 * 1024 });
  const peers = new Set(); let sequence = 0;
  server.on('upgrade', (req, socket, head) => {
    // Browser-originated requests must not reach the uncredentialed local RPC.
    if (req.headers.origin || req.url !== '/') { socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws));
  });
  wss.on('connection', desktop => {
    const native = new WebSocket(target, { perMessageDeflate: false, maxPayload: 64 * 1024 * 1024 });
    const peer = 'desktop:' + ++sequence, queued = []; let bytes = 0, closed = false;
    peers.add(desktop); peers.add(native);
    const terminate = () => { if (closed) return; closed = true; desktop.terminate(); native.terminate(); tracker.disconnect(peer); queued.length = 0; peers.delete(desktop); peers.delete(native); };
    desktop.on('message', (data, binary) => {
      try { const message=JSON.parse(data.toString());tracker.request(peer,message);onRequest(message); } catch { terminate(); return; }
      if (native.readyState === WebSocket.OPEN) native.send(data, { binary });
      else if (native.readyState === WebSocket.CONNECTING) {
        bytes += data.length;
        if (bytes > 8 * 1024 * 1024) { terminate(); return; }
        queued.push([data, binary]);
      }
    });
    native.on('open', () => { for (const [data, binary] of queued) native.send(data, { binary }); queued.length = 0; bytes = 0; });
    native.on('message', (data, binary) => {
      try {
        const message=JSON.parse(data.toString());tracker.receive(peer,message);if(message.method)onEvent(message);
      } catch { terminate(); return; }
      if (desktop.readyState === WebSocket.OPEN) desktop.send(data, { binary });
    });
    desktop.on('error', terminate); native.on('error', terminate);
    desktop.on('close', terminate); native.on('close', terminate);
  });
  server.on('error', onError);
  server.listen(Number(local.port), local.hostname.replace(/[[\]]/g, ''));
  return { close() { for (const peer of peers) peer.terminate(); wss.close(); server.close(); }, server };
}

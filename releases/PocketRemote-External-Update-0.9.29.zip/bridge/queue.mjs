import { readFileSync, existsSync } from 'node:fs';
import { writeFile, rename } from 'node:fs/promises';
import { resolve } from 'node:path';
import { isModelCapacityError, capacityDelay } from './capacity-retry.mjs';

export function createMessageQueue({ root, call, ensureThread, notify, online, coordinator, capacityBackoff = capacityDelay }) {
  const path = resolve(root, '.message-queue.json');
  let entries = [];
  try { if (existsSync(path)) entries = JSON.parse(readFileSync(path, 'utf8')); } catch {}
  for (const entry of entries) if (entry.status === 'dispatching') { entry.status = 'uncertain'; entry.error = 'PC 재시작으로 전달 결과를 확인해야 합니다.'; }
  const active = new Map();
  const timers = new Map();
  const probes = new Map();
  let stopped = false;
  let savePending = Promise.resolve();
  function save() {
    const retained = entries.filter(e => ['queued', 'dispatching', 'failed', 'uncertain'].includes(e.status));
    const receipts = entries.filter(e => !retained.includes(e)).slice(-1000);
    entries = [...retained, ...receipts].sort((a, b) => a.createdAt - b.createdAt);
    const content = JSON.stringify(entries);
    savePending = savePending.catch(() => {}).then(async () => { await writeFile(path + '.tmp', content, { mode: 0o600 }); await rename(path + '.tmp', path); });
    return savePending;
  }
  function current(threadId) { return entries.filter(e => e.threadId === threadId && ['queued', 'dispatching', 'failed', 'uncertain'].includes(e.status)); }
  function publish(threadId) { notify({ method: 'pocket/queue/changed', params: { threadId, entries: current(threadId) } }); }
  function schedule(threadId, delay = 200) {
    if (stopped) return;
    if (!current(threadId).some(e => e.status === 'queued')) return;
    const at = Date.now() + delay, existing = timers.get(threadId);
    // New messages may advance a wakeup, but must never postpone Steering.
    if (existing && existing.at <= at) return;
    clearTimeout(existing?.handle);
    timers.set(threadId, { at, handle: setTimeout(() => {
      timers.delete(threadId); dispatch(threadId).catch(error => console.error('Queue dispatch:', error.message));
    }, delay) });
  }
  async function liveTurn(threadId) {
    if (active.has(threadId)) return active.get(threadId);
    if (!probes.has(threadId)) probes.set(threadId, (async () => {
      try { const turns = await call('thread/turns/list', { threadId, limit: 1, sortDirection: 'desc', itemsView: 'notLoaded' }); return active.get(threadId) || (turns.data?.[0]?.status === 'inProgress' ? turns.data[0].id : ''); }
      catch (error) { if (/not materialized|unavailable before first user message|ephemeral threads|rollout .* is empty/i.test(error.message)) return ''; throw error; }
    })().finally(() => probes.delete(threadId)));
    return probes.get(threadId);
  }
  async function ensureLoaded(threadId) {
    if (ensureThread) return ensureThread(threadId);
    const loaded = await call('thread/loaded/list', {});
    if (!(loaded.data || []).includes(threadId)) await call('thread/resume', { threadId, excludeTurns: true });
  }
  async function dispatch(threadId, forcedEntry = null) {
    if (stopped || !online()) return;
    const entry = forcedEntry || entries.find(e => e.threadId === threadId && e.status === 'queued' && e.mode === 'steer') || entries.find(e => e.threadId === threadId && e.status === 'queued');
    if (!entry || entry.status !== 'queued') return;
    if(!forcedEntry&&entry.retryAt>Date.now()){schedule(threadId,entry.retryAt-Date.now());return;}
    let reserved = false;
    try {
      const turnId = entry.mode === 'steer' && entry.expectedTurnId || active.get(threadId) || await liveTurn(threadId);
      if (stopped || !online() || entry.status !== 'queued') return;
      if (turnId && !forcedEntry && entry.mode !== 'steer') { schedule(threadId, 1200); return; }
      const steering = (!!forcedEntry || entry.mode === 'steer') && !!turnId;
      // Only starting a turn competes with the goal runner. Steering an existing
      // turn must not wait for unrelated history/goal setup or thread/resume.
      if (!steering) {
        reserved = coordinator.acquire(threadId);
        if (!reserved) { schedule(threadId, 100); return { entry }; }
      }
      entry.status = 'dispatching'; await save(); publish(threadId);
      if (!steering || ensureThread) await ensureLoaded(threadId);
      const params = steering ? { threadId, expectedTurnId: turnId, input: entry.input, clientUserMessageId: entry.id } : { threadId, ...entry.settings, input: entry.input, clientUserMessageId: entry.id };
      let result;
      for (let attempt = 0; ; attempt++) {
        try { result = await call(steering ? 'turn/steer' : 'turn/start', params); break; }
        catch (error) {
          // A newly started native turn can briefly precede rollout metadata.
          if (!/rollout .* is empty|unavailable before first user message/i.test(error.message) || attempt >= 5) throw error;
          await new Promise(resolve => setTimeout(resolve, 200 * (attempt + 1)));
        }
      }
      entry.status = 'started'; entry.mode = steering ? 'steer' : 'queue'; entry.turnId = result.turnId || result.turn?.id; entry.error = ''; entry.updatedAt = Date.now();
      delete entry.retryAt;delete entry.capacityAttempts;
      await save(); publish(threadId);
      schedule(threadId, 0);
      return { entry };
    } catch (error) {
      if(isModelCapacityError(error)){
        entry.status='queued';entry.capacityAttempts=(entry.capacityAttempts||0)+1;entry.retryAt=Date.now()+capacityBackoff(entry.capacityAttempts);entry.error='모델 혼잡 · 자동 재시도 대기';
        await save();publish(threadId);schedule(threadId,entry.retryAt-Date.now());return{entry};
      }
      entry.status = /timed out|restarted/i.test(error.message) ? 'uncertain' : 'failed'; entry.error = error.message;
      await save(); publish(threadId);
      if (!forcedEntry) schedule(threadId, 500);
      if (forcedEntry) throw error;
    } finally { if (reserved) coordinator.release(threadId); }
  }
  return {
    hasWaiting(threadId) { return current(threadId).some(e => e.status === 'queued' || e.status === 'dispatching'); },
    onReady() { for (const id of new Set(entries.filter(e => e.status === 'queued').map(e => e.threadId))) schedule(id, 800); },
    onEvent(message) {
      const p = message.params || {};
      if (message.method === 'turn/started') active.set(p.threadId, p.turn.id);
      if (message.method === 'turn/completed') { if (active.get(p.threadId) === p.turn?.id) active.delete(p.threadId); schedule(p.threadId, 0); }
    },
    onOffline() { active.clear(); for (const timer of timers.values()) clearTimeout(timer.handle); timers.clear(); },
    async handle(method, params) {
      const { threadId, id } = params;
      if (method === 'bridge/queue/list') return { entries: current(threadId) };
      if (!threadId || typeof id !== 'string' || !/^[a-zA-Z0-9-]{8,80}$/.test(id)) throw new Error('전송 ID와 대화를 확인하세요.');
      let entry = entries.find(e => e.id === id);
      if (entry && entry.threadId !== threadId) throw new Error('다른 대화에 사용된 메시지 ID입니다.');
      if (method === 'bridge/queue/add') {
        if (entry) return { entry };
        if (!Array.isArray(params.input) || !params.input.length || JSON.stringify(params.input).length > 800000) throw new Error('메시지 내용을 확인하세요.');
        const settings = {};
        for (const key of ['cwd', 'model', 'effort', 'serviceTierForTurn', 'sandboxPolicy', 'approvalPolicy', 'summary']) if (params.settings?.[key] !== undefined) settings[key] = params.settings[key];
        entry = { id, threadId, text: String(params.text || ''), input: params.input, settings, attachments: params.attachments || [], mentions: params.mentions || [], status: 'queued', mode: params.mode === 'steer' ? 'steer' : 'queue', createdAt: Date.now() };
        if (entry.mode === 'steer' && typeof params.expectedTurnId === 'string' && params.expectedTurnId.length <= 200) entry.expectedTurnId = params.expectedTurnId;
        entries.push(entry); await save(); publish(threadId); schedule(threadId, entry.mode === 'steer' ? 0 : 200); return { entry };
      }
      if (!entry) throw new Error('대기열에서 메시지를 찾을 수 없습니다.');
      if (method === 'bridge/queue/get') return { entry };
      if (entry.status === 'dispatching' || entry.status === 'started') throw new Error('이미 작업에 전달된 메시지입니다.');
      if (method === 'bridge/queue/cancel') { entry.status = 'cancelled'; await save(); publish(threadId); return {}; }
      if (method === 'bridge/queue/update') {
        if (entry.status !== 'queued') throw new Error('대기 중인 메시지만 편집할 수 있습니다.');
        if (!Array.isArray(params.input) || !params.input.length || JSON.stringify(params.input).length > 800000) throw new Error('메시지 내용을 확인하세요.');
        entry.input = params.input; entry.text = String(params.text || ''); await save(); publish(threadId); return { entry };
      }
      if (method === 'bridge/queue/retry') { entry.status = 'queued'; entry.error = ''; delete entry.expectedTurnId;delete entry.retryAt;delete entry.capacityAttempts; await save(); publish(threadId); schedule(threadId, entry.mode === 'steer' ? 0 : 200); return { entry }; }
      if (method === 'bridge/queue/steer') {
        if (entry.status !== 'queued') throw new Error('대기 중인 메시지만 Steering으로 전환할 수 있습니다.');
        if (!online()) throw new Error('PC가 재연결 중입니다. 연결 후 다시 시도하세요.');
        entry.mode = 'steer'; delete entry.expectedTurnId;
        await save(); publish(threadId);
        return await dispatch(threadId, entry);
      }
      throw new Error('지원되지 않는 대기열 작업입니다.');
    },
    stop() { stopped = true; for (const timer of timers.values()) clearTimeout(timer.handle); timers.clear(); }
  };
}

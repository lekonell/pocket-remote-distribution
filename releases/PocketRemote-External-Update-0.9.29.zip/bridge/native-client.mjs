import { randomUUID } from 'node:crypto';
import { WebSocket } from 'ws';
import { sharedUrl } from './upstream.mjs';

// Administrative probes never resume a thread, execute tools or answer requests.
export async function nativeClient(url, name = 'pocket_remote_probe') {
  const ws = new WebSocket(sharedUrl(url), { perMessageDeflate: false });
  const pending = new Map();
  const opened = new Promise((resolve, reject) => {
    const timer = setTimeout(() => { ws.terminate(); reject(new Error('App Server connection timed out')); }, 5000);
    ws.once('open', () => { clearTimeout(timer); resolve(); });
    ws.once('error', () => { clearTimeout(timer); reject(new Error('App Server is unavailable')); });
  });
  ws.on('error', () => {});
  ws.on('close', () => { for (const p of pending.values()) { clearTimeout(p.timer); p.reject(new Error('App Server disconnected')); } pending.clear(); });
  ws.on('message', data => {
    const m = JSON.parse(data), p = !m.method && pending.get(m.id);
    if (!p) return;
    clearTimeout(p.timer); pending.delete(m.id);
    m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result);
  });
  const rpc = (method, params = {}) => new Promise((resolve, reject) => {
    const id = 'probe:' + randomUUID(), timer = setTimeout(() => { pending.delete(id); reject(new Error(method + ' timed out')); }, 8000);
    pending.set(id, { resolve, reject, timer });
    if (ws.readyState !== WebSocket.OPEN) { clearTimeout(timer); pending.delete(id); reject(new Error('App Server disconnected')); return; }
    ws.send(JSON.stringify({ id, method, params }));
  });
  try {
    await opened;
    await rpc('initialize', { clientInfo: { name, version: '1' }, capabilities: { experimentalApi: true } });
    ws.send(JSON.stringify({ method: 'initialized', params: {} }));
    return { rpc, close: () => ws.terminate() };
  } catch (error) { ws.terminate(); throw error; }
}

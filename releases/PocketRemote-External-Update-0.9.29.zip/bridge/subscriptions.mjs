// A thread can be loaded by the desktop without this bridge being subscribed.
// Track subscriptions per connection rather than using the global loaded list.
export function createSubscriptions(call) {
  const subscribed = new Set(), wanted = new Set(), pending = new Map();
  let generation = 0;
  return {
    observe(request, response) {
      if (response.error || !['thread/start', 'thread/resume', 'thread/fork'].includes(request?.method)) return;
      const id = response.result?.thread?.id || request.params?.threadId;
      if (id) { subscribed.add(id); wanted.add(id); }
    },
    closed(id) { subscribed.delete(id); wanted.delete(id); },
    reset() { generation++; subscribed.clear(); pending.clear(); },
    async ensure(threadId) {
      wanted.add(threadId);
      if (subscribed.has(threadId)) return;
      if (!pending.has(threadId)) {
        const revision = generation;
        const task = call('thread/resume', { threadId, excludeTurns: true }).then(() => {
          if (revision === generation) subscribed.add(threadId);
        }).finally(() => { if (pending.get(threadId) === task) pending.delete(threadId); });
        pending.set(threadId, task);
      }
      return pending.get(threadId);
    },
    async restore() {
      return Promise.allSettled([...wanted].map(id => this.ensure(id)));
    }
  };
}

import { existsSync, readFileSync } from 'node:fs';
import { open, writeFile, rename } from 'node:fs/promises';
import { resolve } from 'node:path';
import { isSubagentThread } from './thread-source.mjs';
import { isModelCapacityError } from './capacity-retry.mjs';

export function createNotifications({ root, call, emit, online, answer }) {
  const file = resolve(root, '.notifications.json');
  let stored = { watches: {}, notices: [] };
  try { if (existsSync(file)) stored = JSON.parse(readFileSync(file, 'utf8')); } catch {}
  const watches = stored.watches || {}, notices = stored.notices || [];
  for(const w of Object.values(watches))for(const q of Object.values(w.questions||{}))if(q.status==='answering')q.status='uncertain';
  const tails = new Map(), executionContexts = new Map(), executionReads = new Map(), metadataReads = new Map(), listMetadata = new Map(), usage = new Map(), polling = new Set(), completing = new Set(), observedDisk = new Map();
  let writing = Promise.resolve(), stateKey = '', rateCache, rateAt = 0, ratePending, rateGeneration = 0, sweeping = false;
  const save = () => {
    const data = JSON.stringify({ watches, notices: notices.slice(-120) });
    writing = writing.catch(() => {}).then(async () => { await writeFile(file + '.tmp', data, { mode: 0o600 }); await rename(file + '.tmp', file); });
    return writing;
  };
  const active = () => Object.entries(watches).filter(([,w]) => w.active && w.subagent === false).map(([threadId,w]) => ({ threadId, turnId: w.turnId, title: w.title || 'Codex 작업', progress: w.progress || '작업 중' }));
  function publish() {
    const items = active(), key = JSON.stringify(items);
    if (key === stateKey) return; stateKey = key;
    emit({ method: 'pocket/notifications/state', params: { active: items } });
  }
  function record(id) {
    if (!watches[id]) {
      if (Object.keys(watches).length >= 64) {
        const old = Object.keys(watches).filter(k => !watches[k].active).sort((a,b) => (watches[a].viewedAt || 0) - (watches[b].viewedAt || 0))[0];
        if (old) { delete watches[old]; observedDisk.delete(old); usage.delete(old); }
      }
      watches[id] = { initialized: false, viewedAt: Date.now(), progress: '작업 중' };
    }
    return watches[id];
  }
  function question(id, turnId, itemId, questions, requestId = null, answered = false) {
    if (!Array.isArray(questions) || !questions.length || !itemId) return;
    const w = record(id); w.questions ||= {};
    const existing = w.questions[itemId];
    if (existing) {
      // A history prompt can arrive before its live native request, or the
      // request can be replayed with a new ID after a shared WS reconnect.
      if (requestId !== null && (existing.requestId !== requestId || existing.turnId !== turnId)) {
        existing.requestId = requestId; existing.turnId = turnId; existing.questions = questions.slice(0,8); existing.status = 'pending';delete existing.resolutionKind;
        save().catch(()=>{}); emit({method:'pocket/notifications/question',params:{...existing,subagent:w.subagent!==false}});
      }
      return;
    }
    const value = { id:'question:'+id+':'+itemId,kind:'question',threadId:id,turnId,itemId,requestId,title:w.title||'Codex 작업',questions:questions.slice(0,8),summary:questions.map(q=>q.title||q.question).join('\n').slice(0,4000),createdAt:Date.now(),status:answered?'answered':'pending' };
    w.questions[itemId]=value;
    const keys=Object.keys(w.questions);while(keys.length>24)delete w.questions[keys.shift()];
    save().catch(()=>{}); if(!answered)emit({method:'pocket/notifications/question',params:{...value,subagent:w.subagent!==false}});
  }
  function resolveQuestion(w, q) {
    if (!['pending','answering','uncertain'].includes(q.status)) return;
    q.status=q.resolutionKind==='skip'?'skipped':'answered'; emit({method:'pocket/notifications/questionResolved',params:{id:q.id,threadId:q.threadId,itemId:q.itemId,status:q.status}});save().catch(()=>{});
  }
  function inspectReply(w,item){
    for(const target of questionReplyTargets(item)){
      const q=w.questions?.[target.itemId];if(!q||q.requestId!==null||target.index>=q.questions.length)continue;
      q.resolvedIndexes=[...new Set([...(q.resolvedIndexes||[]),target.index])];
      if(q.resolvedIndexes.length===q.questions.length)resolveQuestion(w,q);
    }
  }
  function inspectItems(id, entries) {
    const w=record(id);
    const chronological=entries.slice().reverse();let lastUser=-1;
    chronological.forEach((entry,index)=>{if(entry.item?.type==='userMessage')lastUser=index;});
    // Older history is quiet; current-turn questions require a matching reply.
    for(const [index,entry] of chronological.entries()){
      const item=entry.item||{};
      inspectReply(w,item);
      if(item.questions?.length)question(id,entry.turnId,item.id,item.questions,null,index<lastUser&&!(w.active&&w.turnId===entry.turnId));
    }
  }
  async function tail(path) {
    if (!path?.endsWith('.jsonl')) return {};
    let handle;
    try {
      handle = await open(path, 'r'); const stat = await handle.stat(), previous = tails.get(path);
      if (previous?.size === stat.size && previous.mtime === stat.mtimeMs) return previous.view;
      const size = Math.min(stat.size, 512 * 1024), buffer = Buffer.alloc(size);
      await handle.read(buffer, 0, size, stat.size - size);
      const view = { execution: previous?.view.execution || null };
      for (const line of buffer.toString('utf8').split('\n')) {
        let row; try { row = JSON.parse(line); } catch { continue; }
        if (row.type === 'turn_context') {
          const p = row.payload || {};
          const same = view.execution?.turnId === p.turn_id ? view.execution : null;
          view.execution = { turnId: p.turn_id, model: p.model || same?.model || null, serviceTier: Object.hasOwn(p, 'service_tier') ? p.service_tier : same?.serviceTier ?? null, speedKnown: Object.hasOwn(p, 'service_tier') || !!same?.speedKnown };
          continue;
        }
        if (row.type !== 'event_msg') continue;
        const p = row.payload || {};
        // thread_settings_applied configures subsequent turns. It is not
        // per-turn telemetry, even when it appears during an active turn.
        if (p.type === 'token_count' && p.info) view.context = { used: p.info.last_token_usage?.total_tokens, limit: p.info.model_context_window };
        if (p.type === 'task_started') { view.turnId = p.turn_id; view.active = true; view.progress = '생각 중'; view.summary = ''; if (view.execution?.turnId !== p.turn_id) view.execution = null; }
        if (p.type === 'exec_command_begin') view.progress = '명령 실행';
        if (p.type === 'mcp_tool_call_begin') view.progress = '도구 사용';
        if (p.type === 'agent_message') view.summary = String(p.message || '').slice(-6000);
        if (p.type === 'task_complete') { view.turnId = p.turn_id || view.turnId; view.active = false; view.status = 'completed'; view.summary = p.last_agent_message || view.summary; }
        if (p.type === 'turn_aborted') { view.turnId = p.turn_id || view.turnId; view.active = false; view.status = 'interrupted'; }
        if(p.type==='item_completed') {
          const item=p.item||{};
          if(item.type==='UserMessage')for(const target of questionReplyTargets({type:'userMessage',content:item.content?.map(c=>({...c,type:c.type==='Text'?'text':c.type}))})){
            for(const q of view.questions||[])if(q.itemId===target.itemId)q.resolvedIndexes=[...new Set([...(q.resolvedIndexes||[]),target.index])];
            if(view.questions)view.questions=view.questions.filter(q=>(q.resolvedIndexes?.length||0)<q.questions.length);
          }
          if(item.type==='AgentMessage'&&item.questions?.length){view.questions||=[];view.questions.push({turnId:p.turn_id,itemId:item.id,questions:item.questions});}
          if(item.type==='AgentMessage'&&item.phase!=='commentary')view.summary=(item.content||[]).map(c=>c.text||'').join('\n').slice(-6000);
          if(item.type==='CommandExecution')view.progress='명령 실행';
          if(item.type==='McpToolCall')view.progress='도구 사용';
        }
      }
      tails.set(path, { size: stat.size, mtime: stat.mtimeMs, view });
      while (tails.size > 64) tails.delete(tails.keys().next().value);
      return view;
    } catch { return {}; } finally { await handle?.close().catch(() => {}); }
  }
  async function metadata(id, w) {
    if (w.subagent !== undefined && w.path && Date.now() - (w.metaAt || 0) < 60000) return;
    let pending=metadataReads.get(id);
    if(!pending){pending=call('thread/read',{threadId:id,includeTurns:false}).finally(()=>{if(metadataReads.get(id)===pending)metadataReads.delete(id);});metadataReads.set(id,pending);}
    const { thread } = await pending;
    const previous = w.subagent; w.subagent = isSubagentThread(thread);
    w.title = String(thread.name || thread.preview || 'Codex 작업').slice(0,180); w.cwd = thread.cwd; w.model = thread.model; w.path = thread.path; w.metaAt = Date.now();
    if (previous !== w.subagent) for (const q of Object.values(w.questions || {})) if (q.status === 'pending') emit({method:'pocket/notifications/question',params:{...q,subagent:w.subagent}});
  }
  // A long turn can put its turn_context outside the live 512 KiB tail.
  // Search backwards once per turn, without loading conversation bodies in memory.
  async function executionContext(path, turnId) {
    const key=path+':'+turnId;
    if(executionReads.has(key))return executionReads.get(key);
    const pending=scanExecutionContext(path,turnId).finally(()=>{if(executionReads.get(key)===pending)executionReads.delete(key);});
    executionReads.set(key,pending);return pending;
  }
  async function scanExecutionContext(path, turnId) {
    if (!path?.endsWith('.jsonl')) return null;
    const key = path + ':' + turnId, cached = executionContexts.get(key);
    if (cached && (cached.value?.speedKnown || Date.now() - cached.at < 2000)) return cached.value;
    let handle, value = null, started = false;
    try {
      handle = await open(path, 'r'); const { size } = await handle.stat();
      let end = size, suffix = '', scanned = 0;
      while (end > 0 && scanned < 64 * 1024 * 1024) {
        const length = Math.min(end, 256 * 1024), buffer = Buffer.alloc(length); end -= length; scanned += length;
        await handle.read(buffer, 0, length, end);
        const lines = (buffer.toString('utf8') + suffix).split('\n');
        suffix = end > 0 ? lines.shift().slice(0, 256 * 1024) : '';
        for (let index = lines.length - 1; index >= 0; index--) {
          if (!/"(?:turn_context|task_started|thread_settings_applied)"/.test(lines[index])) continue;
          let row; try { row = JSON.parse(lines[index]); } catch { continue; }
          const p = row.payload || {};
          if (row.type === 'turn_context' && p.turn_id === turnId && !value) {
            value = { turnId, model: p.model || null, serviceTier: p.service_tier ?? null, speedKnown: Object.hasOwn(p, 'service_tier') };
            if (value.speedKnown) break;
          }
          if (row.type === 'event_msg' && p.type === 'task_started' && p.turn_id === turnId) started = true;
          // Only defaults applied BEFORE this turn started can be inherited.
          // Settings applied later configure the next turn, not this one.
          if (started && row.type === 'event_msg' && p.type === 'thread_settings_applied' && Object.hasOwn(p.thread_settings || {}, 'service_tier')) {
            value = { turnId, model: value?.model || p.thread_settings.model || null, serviceTier: p.thread_settings.service_tier, speedKnown: true };
            break;
          }
        }
        if (value?.speedKnown) break;
      }
    } catch {} finally { await handle?.close().catch(() => {}); }
    executionContexts.set(key, { value, at: Date.now() });
    while (executionContexts.size > 128) executionContexts.delete(executionContexts.keys().next().value);
    return value;
  }
  async function readExecution(id, turnId, w) {
    if (!turnId) return null;
    const own = watches[id]?.execution?.turnId === turnId ? watches[id].execution : null;
    if (own?.speedKnown && own.model) return { ...own };
    const disk = await tail(w.path);
    const live = disk.execution?.turnId === turnId ? disk.execution : null;
    const context = live?.speedKnown ? live : await executionContext(w.path, turnId) || live;
    return { turnId, model: context?.model || own?.model || w.model || null, serviceTier: own?.speedKnown ? own.serviceTier : context?.serviceTier ?? null, speedKnown: !!(context?.speedKnown || own?.speedKnown) };
  }
  async function listedActivity(id) {
    // Listing a conversation does not subscribe it to push notifications.
    const w = watches[id] || listMetadata.get(id) || {};
    await metadata(id, w);
    listMetadata.delete(id); listMetadata.set(id, w);
    while (listMetadata.size > 64) listMetadata.delete(listMetadata.keys().next().value);
    if (w.subagent !== false) return null;
    const disk = await tail(w.path);
    if(disk.turnId&&disk.active!==undefined&&(!w.nativeTurn||w.nativeTurn===disk.turnId)){
      const isActive=!!(w.retry&&w.retry.status!=='loginRequired')||disk.active;
      return{threadId:id,turnId:disk.turnId,active:!!isActive,execution:isActive?await readExecution(id,disk.turnId,w):null};
    }
    const page = await call('thread/turns/list', { threadId: id, limit: 1, sortDirection: 'desc', itemsView: 'notLoaded' });
    const native = page.data?.[0];
    const own = native?.id && native.id === w.nativeTurn;
    const turnId = own ? native.id : disk.turnId || native?.id;
    const isActive = !!(w.retry&&w.retry.status!=='loginRequired') || (own ? native.status === 'inProgress' : disk.active ?? (native?.status === 'inProgress'));
    return { threadId: id, turnId, active: !!isActive, execution: isActive ? await readExecution(id, turnId, w) : null };
  }
  function plain(text) {
    return String(text || '').replace(/```[^\n]*\n/g, '').replace(/```/g, '').replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/^#{1,6}\s+/gm, '').replace(/\*\*|__|~~/g, '').trim().slice(0,4000);
  }
  async function complete(id, turn, w, summary) {
    if(turn.status==='failed'&&isModelCapacityError(turn.error))return;
    if (w.subagent === undefined) await metadata(id, w);
    if (w.subagent !== false) return;
    const key = id + ':' + turn.id;
    if (notices.some(n => n.id === key) || completing.has(key)) return;
    completing.add(key);
    try {
    if (!summary) {
      try { const page = await call('thread/turns/list', { threadId: id, limit: 1, sortDirection: 'desc', itemsView: 'full' });
        const t = page.data?.find(t => t.id === turn.id);
        const messages = t?.items?.filter(i => i.type === 'agentMessage' && i.phase !== 'commentary') || [];
        summary = messages.at(-1)?.text;
      } catch {}
    }
    const notice = { id: key, threadId: id, turnId: turn.id, title: w.title || 'Codex 작업', status: turn.status || 'completed', summary: plain(summary || turn.error?.message || (turn.status === 'interrupted' ? '작업이 중단되었습니다.' : turn.status === 'failed' ? '작업을 완료하지 못했습니다.' : '작업이 완료되었습니다.')), createdAt: Date.now() };
    notices.push(notice); while (notices.length > 120) notices.shift();
    await save(); emit({ method: 'pocket/notifications/completed', params: notice });
    } finally { completing.delete(key); }
  }
  async function poll(id, force = false) {
    const w = watches[id]; if (!w || !online() || polling.has(id)) return;
    if (!force && Date.now() - (w.polledAt || 0) < (w.active || Date.now() - (w.viewedAt || 0) < 12 * 3600000 ? 2500 : 20000)) return;
    polling.add(id); w.polledAt = Date.now();
    try {
      await metadata(id,w);
      const disk = await tail(w.path), previousDisk = observedDisk.get(id);
      // Native events already update our state. For external writers the file's
      // size/mtime changes immediately; unchanged files need only periodic
      // upstream reconciliation, not one RPC per watched thread every 2.5s.
      if (!force && w.initialized && disk.turnId && previousDisk?.view === disk && Date.now() - previousDisk.checkedAt < 30000) return;
      const page = await call('thread/turns/list', { threadId: id, limit: 1, sortDirection: 'desc', itemsView: 'notLoaded' });
      observedDisk.set(id, { view: disk, checkedAt: Date.now() });
      const t = page.data?.[0];
      const own = t?.id && t.id === w.nativeTurn;
      const turnId = own?t.id:disk.turnId || t?.id, isActive = !!(w.retry&&w.retry.status!=='loginRequired') || (own?t.status==='inProgress':disk.active ?? (t?.status === 'inProgress'));
      if (disk.context) w.context = disk.context;
      const previousId = w.turnId, wasActive = w.active, initialized = w.initialized;
      w.turnId = turnId; w.active = !!isActive; w.progress = w.retry ? w.progress : disk.progress || w.progress || '작업 중'; w.initialized = true;
      if(disk.questions){
        const ids=new Set(disk.questions.map(q=>q.itemId));
        for(const q of Object.values(w.questions||{}))if(q.requestId===null&&!ids.has(q.itemId))resolveQuestion(w,q);
        for(const q of disk.questions)question(id,q.turnId,q.itemId,q.questions);
      }
      if (initialized && turnId && !isActive && (previousId !== turnId || wasActive)) await complete(id, { ...(t || {}), id: turnId, status: disk.status || t?.status }, w, disk.summary);
      if (previousId !== turnId || wasActive !== w.active || !initialized) await save();
      publish();
    } catch {} finally { polling.delete(id); }
  }
  const timer = setInterval(async () => {
    if (!online() || sweeping) return;
    sweeping = true;
    try {
    const ids = Object.keys(watches).sort((a,b) => (watches[b].viewedAt || 0) - (watches[a].viewedAt || 0));
    for (let at=0; at<ids.length; at+=4) await Promise.allSettled(ids.slice(at,at+4).map(id => poll(id)));
    } finally { sweeping = false; }
  }, 2500); timer.unref();
  return {
    inspectItems,
    observeThreads(threads) {
      for(const thread of threads||[]){
        if(!thread?.id||!thread.path)continue;
        const w=watches[thread.id]||listMetadata.get(thread.id)||{};
        w.path=thread.path;w.model=thread.model||w.model;w.cwd=thread.cwd;w.title=String(thread.name||thread.preview||'Codex 작업').slice(0,180);
        const previous=w.subagent;w.subagent=isSubagentThread(thread);w.metaAt=Date.now();
        if(watches[thread.id]&&previous!==w.subagent)for(const q of Object.values(w.questions||{}))if(q.status==='pending')emit({method:'pocket/notifications/question',params:{...q,subagent:w.subagent}});
        if(!watches[thread.id]){listMetadata.delete(thread.id);listMetadata.set(thread.id,w);}
      }
      while(listMetadata.size>64)listMetadata.delete(listMetadata.keys().next().value);
    },
    captureExecution(id, turnId, settings) {
      if (!turnId) return;
      const w = record(id), tier = settings.serviceTierForTurn ?? settings.serviceTier, previous = w.execution?.turnId === turnId ? w.execution : null;
      const known = tier !== undefined && tier !== null;
      w.execution = { turnId, model: settings.model || previous?.model || null, serviceTier: known ? tier : previous?.serviceTier ?? null, speedKnown: known || !!previous?.speedKnown };
      emit({ method: 'pocket/execution/changed', params: { threadId: id, execution: w.execution } });
      save().catch(() => {});
    },
    async currentExecution(id, turnId) {
      if (!turnId) return null;
      const w = record(id);
      try { await metadata(id, w); } catch {}
      return readExecution(id, turnId, w);
    },
    onReady() { observedDisk.clear(); for (const w of Object.values(watches)) w.metaAt = 0; },
    onEvent(message) {
      const p = message.params || {}, id = p.threadId || p.thread?.id;
      if (message.method === 'account/updated') { rateGeneration++; rateCache = null; rateAt = 0; ratePending = null; return; }
      if (message.method === 'account/rateLimits/updated') { rateGeneration++; rateCache = p; rateAt = Date.now(); ratePending = null; return; }
      if(message.method==='pocket/retry/changed'&&id){const w=record(id);w.retry=p.retry;w.active=!!p.retry&&p.retry.status!=='loginRequired';if(w.active)w.progress=p.retry.status==='checking'?'재시도 전송 결과 확인 중':'모델 혼잡 · 자동 재시도 대기';metadata(id,w).then(()=>{publish();return save();}).catch(()=>{});publish();return;}
      if(message.method==='serverRequest/resolved') {for(const w of Object.values(watches))for(const q of Object.values(w.questions||{}))if(q.requestId!==null&&String(q.requestId)===String(p.requestId))resolveQuestion(w,q);return;}
      if (!id) return;
      if (message.method === 'thread/tokenUsage/updated') { usage.set(id,p.tokenUsage); return; }
      if (message.method === 'thread/name/updated' && watches[id]) { watches[id].title = p.threadName || p.name || watches[id].title; save().catch(() => {}); publish(); }
      if (message.method === 'thread/archived' && watches[id]) { delete watches[id]; observedDisk.delete(id); usage.delete(id); save().catch(() => {}); publish(); return; }
      if (message.method === 'turn/started') {
        const w = record(id); w.turnId = p.turn.id; w.nativeTurn=p.turn.id; w.active = true; w.initialized = true; w.progress = '생각 중'; w.reply = ''; w.replyTurn = p.turn.id;
        metadata(id,w).then(() => { publish(); return save(); }).catch(() => {}); publish();
      }
      const w = watches[id]; if (!w) return;
      if(message.method==='item/tool/requestUserInput')question(id,p.turnId,p.itemId,p.questions,message.id);
      if (message.method === 'item/started') {
        w.progress = ({ commandExecution: '명령 실행', fileChange: '파일 변경', webSearch: '웹 검색', mcpToolCall: '도구 사용', agentMessage: '답변 작성', reasoning: '생각 중' })[p.item?.type] || w.progress; publish();
      }
      if (message.method === 'item/completed' && p.item?.type === 'agentMessage' && p.item.phase !== 'commentary') { w.reply = p.item.text; w.replyTurn = p.turnId; }
      if(message.method==='item/completed'&&p.item?.questions?.length)question(id,p.turnId,p.item.id,p.item.questions);
      if(['item/completed','item/started'].includes(message.method)&&p.item)inspectReply(w,p.item);
      if (message.method === 'turn/completed') {
        w.active = false; w.turnId = p.turn.id;
        const messages = p.turn.items?.filter(i => i.type === 'agentMessage' && i.phase !== 'commentary') || [];
        complete(id,p.turn,w,messages.at(-1)?.text || (w.replyTurn === p.turn.id ? w.reply : '')).catch(() => {}); publish();
      }
    },
    async currentTurn(id, fallback) {
      const w = watches[id]; if (!w) return fallback;
      if(fallback?.id===w.nativeTurn)return fallback;
      const disk = await tail(w.path);
      if (disk.active !== undefined && disk.turnId) return { id: disk.turnId, status: disk.active ? 'inProgress' : disk.status || 'completed' };
      return fallback;
    },
    async handle(method, params = {}) {
      if (method === 'bridge/notifications/list') {
        const running = params.activityOnly===true?[]:active();
        if (params.includeExecution === true) await Promise.all(running.map(async entry => { entry.execution = await this.currentExecution(entry.threadId, entry.turnId); }));
        const activity = [];
        if (params.threadIds !== undefined) {
          if (!Array.isArray(params.threadIds) || params.threadIds.length > 64 || params.threadIds.some(id => typeof id !== 'string' || !id || id.length > 100)) throw Error('Invalid activity thread IDs');
          const ids = [...new Set(params.threadIds)];
          for (let at = 0; at < ids.length; at += 4) {
            const results = await Promise.allSettled(ids.slice(at, at + 4).map(listedActivity));
            for (const result of results) if (result.status === 'fulfilled' && result.value) activity.push(result.value);
          }
        }
        return { active: running, activity, notices: params.activityOnly===true?[]:[...notices.slice(-80).filter(n=>watches[n.threadId]?.subagent===false),...Object.values(watches).filter(w=>w.subagent===false).flatMap(w=>Object.values(w.questions||{})).filter(q=>q.status==='pending')] };
      }
      const id = params.threadId;
      if (typeof id !== 'string' || !id || id.length > 100) throw new Error('대화를 먼저 선택하세요.');
      const w = record(id); w.viewedAt = Date.now();
      if(method==='bridge/question/list')return {questions:Object.values(w.questions||{})};
      if(method==='bridge/question/answer'){
        const q=w.questions?.[params.itemId];if(!q)throw new Error('질문이 갱신되었습니다. 대화를 다시 확인하세요.');
        if(['answered','skipped'].includes(q.status))return {accepted:true,status:q.status};
        if(q.status==='answering')throw new Error('답변을 전달 중입니다.');
        if(q.status==='uncertain'){
          try{const page=await call('thread/turns/list',{threadId:id,limit:1,sortDirection:'desc',itemsView:'full'});if(q.answerId&&page.data?.some(t=>t.items?.some(i=>i.type==='userMessage'&&i.clientId===q.answerId))){q.status='answering';resolveQuestion(w,q);return {accepted:true,status:'answered'};}}catch{}
          throw new Error('이전 답변의 전송 결과를 대화에서 확인하세요. 중복 전송은 보류했습니다.');
        }
        if(params.skip!==true&&(!Array.isArray(params.answers)||params.answers.length!==q.questions.length||params.answers.some(a=>typeof a!=='string'||!a.trim()||a.length>8000)))throw new Error('각 질문에 답변을 입력하세요.');
        q.status='answering';q.answerId=params.answerId;q.resolutionKind=params.skip===true?'skip':'answer';await save();
        try {const result=await answer(q,params);resolveQuestion(w,q);return {...result,status:q.status};}
        catch(e){q.status=/timed out|restarted|reconnecting/i.test(e.message)?'uncertain':'pending';await save();throw e;}
      }
      if (method === 'bridge/notifications/watch') { await poll(id,true); await save(); return { watching: true }; }
      if (method !== 'bridge/status/read') throw new Error('지원되지 않는 상태 요청입니다.');
      await metadata(id,w); const disk = await tail(w.path), tokens = usage.get(id);
      const context = tokens ? { used: tokens.last?.totalTokens, limit: tokens.modelContextWindow } : disk.context || w.context || null;
      if (Date.now()-rateAt>60000) {
        if (!ratePending) { const generation = rateGeneration; const pending = call('account/rateLimits/read',{}).then(r => { if(generation===rateGeneration){rateCache = r; rateAt=Date.now();} }).catch(() => {}).finally(() => { if(ratePending===pending)ratePending=null; }); ratePending=pending; }
        await ratePending;
      }
      const buckets = Object.values(rateCache?.rateLimitsByLimitId || {});
      const rate = buckets.find(b => b.normalModelSlug === w.model) || rateCache?.rateLimits;
      const weekly = [rate?.primary,rate?.secondary].find(v => v?.windowDurationMins === 10080) || null;
      const isActive = disk.active ?? !!w.active, turnId = disk.turnId || w.turnId;
      const creditInfo = rate?.credits || rateCache?.rateLimits?.credits;
      const credits = creditInfo && typeof creditInfo === 'object' ? { hasCredits: creditInfo.hasCredits === true, unlimited: creditInfo.unlimited === true, balance: typeof creditInfo.balance === 'string' || typeof creditInfo.balance === 'number' ? String(creditInfo.balance) : null } : null;
      return { threadId: id, cwd: w.cwd || '', title: w.title, active: isActive, execution: isActive ? await this.currentExecution(id, turnId) : null, context: Number.isFinite(context?.used) && Number.isFinite(context?.limit) && context.limit > 0 ? context : null, weekly, credits };
    },
    stop() { clearInterval(timer); }
  };
}
import { questionReplyTargets } from './question-replies.mjs';

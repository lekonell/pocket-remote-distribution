import { spawn } from 'node:child_process';
import { readFile, writeFile, open, unlink } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { fetchRelease, newerVersion, stageRelease, verifyStaged, pcIdle, saveUpdateState, installedVersion } from './pc-updates.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
if (args[0] === '--verify') { await verifyStaged(args[1], args[2]); process.exit(0); }
if (args[0] === '--idle') { if (!await pcIdle(root)) process.exit(2); process.exit(0); }
if (args[0] === '--idle-root') { if (!await pcIdle(resolve(args[1]))) process.exit(2); process.exit(0); }
if (args[0] === '--newer') { process.exit(newerVersion(args[1], args[2]) ? 0 : 3); }
const checkNow = args.includes('--check-now');
const manualOnly = process.env.REMOTE_AUTO_UPDATE === '0';
if (process.platform !== 'win32' || (process.env.REMOTE_AUTO_UPDATE === '0' && !checkNow)) process.exit(0);
const requestPath = resolve(root, '.pc-update-request');
if (checkNow) await writeFile(requestPath, String(Date.now()));
const pause = async ms => {
  const until = Date.now() + ms;
  while (Date.now() < until) {
    if (parent > 0) { try { process.kill(parent, 0); } catch { return; } }
    if (await readFile(requestPath).then(() => true, () => false)) return;
    await new Promise(done => setTimeout(done, Math.min(1000, until - Date.now())));
  }
};
// Let the previous installer exit and release its lock after starting the host.
if (!checkNow) await new Promise(done => setTimeout(done, 15000));
const lockPath = resolve(root, '.pc-updater.lock');
let lock;
try { lock = await open(lockPath, 'wx'); }
catch (error) {
  if (error.code !== 'EEXIST') throw error;
  const pid = Number(await readFile(lockPath, 'utf8').catch(() => 0));
  if (pid > 0) { try { process.kill(pid, 0); process.exit(0); } catch {} }
  await unlink(lockPath); lock = await open(lockPath, 'wx');
}
await lock.writeFile(String(process.pid));
const cleanup = async () => { await lock.close(); await unlink(lockPath).catch(() => {}); };
process.on('SIGTERM', () => cleanup().finally(() => process.exit(0)));
const parentIndex = args.indexOf('--parent');
const parent = parentIndex < 0 ? 0 : Number(args[parentIndex + 1]);
let staged, current, idleSince = 0, requestedApply = checkNow;
try {
  for (;;) {
    if (parent > 0) { try { process.kill(parent, 0); } catch { break; } }
    try {
      const requested = await readFile(requestPath).then(async () => { await unlink(requestPath).catch(() => {}); return true; }, () => false);
      requestedApply ||= requested;
      if (!staged) {
        current = await installedVersion(root);
        if (requested) await saveUpdateState(root, { status: 'checking', version: current });
        const envelope = await fetchRelease();
        if (!newerVersion(envelope.release.version, current)) { requestedApply=false;await saveUpdateState(root, { status: 'current', version: current }); if (manualOnly) break; await pause(6 * 3600000); continue; }
        const previous = JSON.parse(await readFile(resolve(root, '.pc-update.json'), 'utf8').catch(() => '{}'));
        requestedApply ||= previous.applyMode === 'manual' && previous.availableVersion === envelope.release.version && ['waiting-for-idle','waiting-for-wizard-close','downloading','applying'].includes(previous.status);
        if (!requestedApply && previous.availableVersion === envelope.release.version && previous.retryAfter > Date.now()) { await pause(6 * 3600000); continue; }
        await saveUpdateState(root, { status: 'downloading', version: current, availableVersion: envelope.release.version, applyMode: requestedApply ? 'manual' : 'automatic' });
        staged = await stageRelease(root, envelope);
        await saveUpdateState(root, { status: 'waiting-for-idle', version: current, availableVersion: staged.release.version, applyMode: requestedApply ? 'manual' : 'automatic' });
      }
      if (requested && staged) await saveUpdateState(root, { status: 'waiting-for-idle', version: current, availableVersion: staged.release.version, applyMode: 'manual' });
      if (requestedApply || await pcIdle(root)) {
        idleSince ||= Date.now();
        if (requestedApply || Date.now() - idleSince >= 15000) {
          // The external installer rechecks activity and validates staged bytes
          // before stopping this installation's host. Shared native roots stay up.
          const shell = resolve(process.env.WINDIR, 'System32/WindowsPowerShell/v1.0/powershell.exe');
          await saveUpdateState(root, { status: 'applying', version: current, availableVersion: staged.release.version, applyMode: requestedApply ? 'manual' : 'automatic' });
          const child = spawn(shell, ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', resolve(root, 'bridge/run-update.ps1'), '-Archive', staged.archive, '-Manifest', staged.manifest, '-NodePath', process.execPath, ...(requestedApply ? ['-Requested'] : [])], { cwd: root, windowsHide: true, stdio: 'ignore' });
          const result = await new Promise((done, reject) => { child.once('exit', done); child.once('error', reject); });
          if (result === 2) { idleSince = 0; await pause(15000); continue; }
          const completion=JSON.parse(await readFile(resolve(root,'.pc-update.json'),'utf8').catch(()=>'{}'));
          if(result!==0||!(['installed','current'].includes(completion.status)&&(completion.availableVersion||completion.version)===staged.release.version)){
            if(completion.status!=='failed')await saveUpdateState(root,{status:'failed',version:current,availableVersion:staged.release.version,applyMode:requestedApply?'manual':'automatic',error:'업데이트 실행이 완료되지 않았습니다. 트레이에서 다시 업데이트를 요청해 주세요.',retryAfter:Date.now()+86400000});
          }
          break;
        }
      } else idleSince = 0;
      await pause(15000);
    } catch (error) {
      idleSince = 0; staged = null;
      const reason = /signature|hash|metadata|payload|Untrusted/i.test(error.message) ? '업데이트 파일 검증에 실패했습니다.' : /Installed PC version/i.test(error.message) ? '설치된 버전을 확인하지 못했습니다.' : '업데이트 서버에 연결하지 못했습니다. 인터넷·프록시·방화벽을 확인하세요.';
      await saveUpdateState(root, { status: 'retry-later', error: reason + ' 기존 설정과 연결은 유지됩니다.' });
      if (manualOnly) break;
      await pause(6 * 3600000);
    }
  }
} finally { await cleanup(); }

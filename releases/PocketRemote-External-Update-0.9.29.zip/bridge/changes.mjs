import { createHash } from 'node:crypto';
import { win32, posix } from 'node:path';

const hash = text => createHash('sha256').update(text).digest('hex').slice(0, 24);
function gitPath(value) {
  value = String(value || '').split('\t')[0].trim();
  if (value.startsWith('"')) {
    const bytes = []; const inner = value.slice(1, value.lastIndexOf('"'));
    for (let i = 0; i < inner.length;) {
      const octal = inner.slice(i).match(/^\\([0-7]{3})/);
      if (octal) { bytes.push(parseInt(octal[1], 8)); i += 4; }
      else if (inner[i] === '\\' && i + 1 < inner.length) { bytes.push(...Buffer.from(({ n: '\n', t: '\t', r: '\r' })[inner[i + 1]] || inner[i + 1])); i += 2; }
      else { const char = String.fromCodePoint(inner.codePointAt(i)); bytes.push(...Buffer.from(char)); i += char.length; }
    }
    value = Buffer.from(bytes).toString('utf8');
  }
  return value.replace(/^[ab]\//, '');
}
export function parseUnifiedDiff(diff) {
  const parts = String(diff || '').split(/(?=^diff --git )/m).filter(Boolean), files = [];
  for (const part of parts) {
    const before = part.match(/^--- (.+)$/m), after = part.match(/^\+\+\+ (.+)$/m);
    const move = part.match(/^rename to (.+)$/m), from = part.match(/^rename from (.+)$/m);
    let path = after && after[1] !== '/dev/null' ? gitPath(after[1]) : before ? gitPath(before[1]) : move ? gitPath(move[1]) : '';
    if (!path) { const header = part.match(/^diff --git (?:"(?:[^"\\]|\\.)*"|.+?) ("(?:[^"\\]|\\.)*"|b\/.+)$/m); if (header) path = gitPath(header[1]); }
    if (!path || path === '/dev/null') continue;
    const kind = after?.[1] === '/dev/null' ? 'delete' : before?.[1] === '/dev/null' ? 'add' : 'update';
    files.push({ path, previousPath: from ? gitPath(from[1]) : before && gitPath(before[1]) !== path && before[1] !== '/dev/null' ? gitPath(before[1]) : '', kind, diff: part });
  }
  return files;
}
export function diffRows(diff) {
  let old = 0, next = 0, inHunk = false; const rows = [];
  for (const line of String(diff || '').split('\n')) {
    const h = line.match(/^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@(.*)/);
    if (h) { old = Number(h[1]); next = Number(h[2]); inHunk = true; rows.push({ type: 'hunk', text: line, old, next }); continue; }
    if (!inHunk) { if (/Binary files|GIT binary patch|rename (?:from|to)|new file mode|deleted file mode/.test(line)) rows.push({ type: 'note', text: line }); continue; }
    if (line.startsWith('+')) rows.push({ type: 'add', text: line.slice(1), old: null, next: next++ });
    else if (line.startsWith('-')) rows.push({ type: 'delete', text: line.slice(1), old: old++, next: null });
    else if (line.startsWith(' ')) rows.push({ type: 'context', text: line.slice(1), old: old++, next: next++ });
    else if (line.startsWith('\\')) rows.push({ type: 'note', text: '파일 끝에 줄바꿈 없음' });
  }
  return rows;
}
function normalize(change) {
  const kind = change.kind?.type || change.kind || 'update', move = change.kind?.move_path;
  let diff = String(change.diff || '');
  if (!/^@@ /m.test(diff) && ['add', 'delete'].includes(kind) && diff && !/Binary files|GIT binary patch/.test(diff)) {
    const lines = diff.replace(/\n$/, '').split('\n'); diff = `@@ -${kind === 'add' ? '0,0' : '1,' + lines.length} +${kind === 'delete' ? '0,0' : '1,' + lines.length} @@\n` + lines.map(l => (kind === 'add' ? '+' : '-') + l).join('\n');
  }
  return { path: move || change.path, previousPath: move ? change.path : change.previousPath || '', kind, diff };
}

export function createChanges({ pager, agents, repository, defaultScope = 'latest-turn' }) {
  const sessions = new Map(), scans = new Map();
  const snapshots = new Map(), latestScans = new Map();
  function session(id) {
    if (!sessions.has(id)) sessions.set(id, { operations: new Map(), aggregates: new Map(), cursor: null, started: false, complete: false, warning: '', cwd: '' });
    // One root can have dozens of children. Keep the whole inspected family.
    while (sessions.size > 256) sessions.delete(sessions.keys().next().value);
    return sessions.get(id);
  }
  function observe(id, entries) {
    const s = session(id);
    for (const e of entries || []) if (e.item?.type === 'fileChange' && e.item.status !== 'failed' && e.item.status !== 'declined') {
      s.operations.set(e.item.id, { turnId: e.turnId, changes: (e.item.changes || []).map(normalize) });
    }
  }
  async function scan(id) {
    if (scans.has(id)) return scans.get(id);
    const task = (async () => {
      const s = session(id);
      if (!s.cwd && pager.metadata) { try { s.cwd = (await pager.metadata(id)).cwd || ''; } catch {} }
      if (s.complete) return;
      for (let i = 0; i < 4; i++) {
        try {
          const page = await pager.list({ threadId: id, limit: 100, sortDirection: 'desc', ...(s.cursor ? { cursor: s.cursor } : {}) });
          observe(id, page.data); s.started = true;
          if (!page.nextCursor || page.nextCursor === s.cursor) { s.complete = true; s.cursor = null; break; }
          s.cursor = page.nextCursor;
          const size = JSON.stringify([...s.operations.values()]).length + JSON.stringify([...s.aggregates.values()]).length;
          if (size > 20 * 1024 * 1024) { s.warning = '변경 기록이 커서 일부 이전 변경은 별도 대화 내역에서 확인하세요.'; s.complete = true; break; }
        } catch (e) {
          if (/not materialized|rollout .* is empty|unavailable before first user message/i.test(e.message)) s.complete = true;
          else s.warning = e.message;
          break;
        }
      }
    })().finally(() => scans.delete(id));
    scans.set(id, task); return task;
  }
  function files(ids, selectedTurn = null) {
    const result = new Map();
    for (const id of ids) {
      const s = session(id), operations = [...s.operations.values()].filter(o => !s.aggregates.has(o.turnId));
      operations.push(...[...s.aggregates].map(([turnId, changes]) => ({ turnId, changes })));
      for (const op of operations.filter(o => selectedTurn === null || o.turnId === selectedTurn)) for (const c of op.changes) {
        const raw = String(c.path || '').replace(/\\/g, '/'); if (!raw) continue;
        const path = s.cwd ? (/^[A-Za-z]:/.test(s.cwd) ? win32 : posix).resolve(s.cwd, raw).replace(/\\/g, '/') : raw;
        const key = /^[A-Za-z]:/.test(path) ? path.toLowerCase() : path;
        if (!result.has(key)) result.set(key, { id: hash(key), path, previousPath: c.previousPath, patches: [], additions: 0, deletions: 0 });
        const f = result.get(key), rows = diffRows(c.diff);
        f.additions += rows.filter(r => r.type === 'add').length; f.deletions += rows.filter(r => r.type === 'delete').length;
        f.patches.push({ threadId: id, turnId: op.turnId, diff: c.diff, kind: c.kind });
      }
    }
    return [...result.values()].sort((a, b) => a.path.localeCompare(b.path));
  }
  const roots = new Map();
  async function inspectFamily(threadId) {
    let list = { agents: [] };
    try { list = await agents.handle('bridge/agents/list', { threadId }); } catch {}
    const ids = [...new Set([threadId, ...(agents.relatedIds?.(threadId) || list.agents.map(a => a.id))])];
    roots.set(threadId, ids);
    while (roots.size > 32) roots.delete(roots.keys().next().value);
    // Refresh every family member's head, while retaining unfinished older cursors.
    for (let i = 0; i < ids.length; i += 4) await Promise.allSettled(ids.slice(i, i + 4).map(async id => {
      const s = session(id);
      if (s.started) { try { observe(id, (await pager.list({ threadId: id, limit: 100, sortDirection: 'desc' })).data); } catch {} }
      await scan(id);
    }));
    return ids;
  }
  return {
    observe,
    onEvent(message) {
      const p = message.params || {};
      if (!p.threadId) return;
      if (p.item) observe(p.threadId, [{ turnId: p.turnId, item: p.item }]);
      if (message.method === 'item/fileChange/patchUpdated') observe(p.threadId, [{ turnId: p.turnId, item: { id: p.itemId, type: 'fileChange', changes: p.changes } }]);
      if (message.method === 'turn/diff/updated') session(p.threadId).aggregates.set(p.turnId, parseUnifiedDiff(p.diff).map(normalize));
    },
    async handle(method, p) {
      if (typeof p.threadId !== 'string' || !p.threadId || p.threadId.length > 100) throw Error('대화를 먼저 선택하세요.');
      if (method === 'bridge/changes/list') {
        if (p.view === 'review') {
          if (!['unstaged', 'staged', 'latest-turn'].includes(p.scope)) throw Error('변경 파일 조회 범위를 선택하세요.');
          const s = session(p.threadId);
          if (pager.metadata) s.cwd = (await pager.metadata(p.threadId)).cwd || '';
          let snapshot;
          if (p.scope !== 'latest-turn') {
            try {
              if (!repository) throw Error('이 PC에서 Git 변경 조회를 지원하지 않습니다.');
              snapshot = { ...await repository.list(s.cwd, { scope: p.scope }), available: true };
            } catch (error) {
              // Never substitute a historical sum for current Git state.
              snapshot = { scope: p.scope, files: [], available: false, warning: error.message, note: '현재 Git 변경을 확인하지 못했습니다. 최근 턴을 선택하면 이 대화의 마지막 작업 기록을 볼 수 있습니다.' };
            }
          } else {
            const latest = await pager.latest(p.threadId), turnId = latest?.id;
            let scan = latestScans.get(p.threadId);
            if (!scan || scan.turnId !== turnId) { scan = { turnId, cursor: null, complete: false, started: false }; latestScans.set(p.threadId, scan); }
            if (turnId && !s.aggregates.has(turnId)) {
              if (scan.started) observe(p.threadId, (await pager.list({ threadId: p.threadId, turnId, limit: 100, sortDirection: 'desc' })).data);
              for (let i = 0; i < 4 && !scan.complete; i++) {
                const page = await pager.list({ threadId: p.threadId, turnId, limit: 100, sortDirection: 'desc', ...(scan.cursor ? { cursor: scan.cursor } : {}) });
                observe(p.threadId, page.data); scan.started = true;
                if (!page.nextCursor || page.nextCursor === scan.cursor) { scan.complete = true; scan.cursor = null; break; }
                scan.cursor = page.nextCursor;
              }
            }
            snapshot = { scope: 'latest-turn', files: turnId ? files([p.threadId], turnId) : [], available: true, scanning: !!turnId && !s.aggregates.has(turnId) && !scan.complete,
              scopeLabel: '최근 턴 · 이 대화의 마지막 작업', note: '최근 턴의 기록만 표시합니다. 최신 통합 diff가 있으면 개별 패치를 대체합니다.', turnId };
            while (latestScans.size > 32) latestScans.delete(latestScans.keys().next().value);
          }
          snapshots.set(p.threadId + '\0' + p.scope, snapshot); while (snapshots.size > 96) snapshots.delete(snapshots.keys().next().value);
          const all = snapshot.files;
          return { ...snapshot, reviewPolicy: 1, files: all.map(({ patches, repo, base, relativePath, untracked, binary, ...f }) => ({ ...f, patchCount: patches?.length || 1, version: f.version || hash(JSON.stringify(patches)) })), additions: all.reduce((n,f) => n + f.additions, 0), deletions: all.reduce((n,f) => n + f.deletions, 0) };
        }
        if (p.view === 'session' || (p.scope !== 'history' && defaultScope !== 'history')) {
          const s = session(p.threadId);
          if (pager.metadata) s.cwd = (await pager.metadata(p.threadId)).cwd || '';
          let snapshot;
          if (repository) {
            try {
              if (p.scope === 'working-tree') snapshot = await repository.list(s.cwd);
              else {
                const ids = await inspectFamily(p.threadId), recorded = files(ids);
                const pathKey = path => /^[A-Za-z]:/.test(path) ? path.toLowerCase() : path;
                const paths = new Set(recorded.map(f => pathKey(f.path)));
                const git = await repository.list(s.cwd);
                snapshot = { ...git, files: git.files.filter(f => paths.has(pathKey(f.path)) ||
                  (f.previousPath && paths.has(pathKey((/^[A-Za-z]:/.test(git.repo) ? win32 : posix).resolve(git.repo, f.previousPath).replace(/\\/g, '/'))))),
                  scope: 'session-working-tree', scopeLabel: '이 대화의 현재 변경 · 커밋되지 않은 순변경량',
                  note: '이 대화와 연결된 서브 에이전트의 변경 기록에 있는 파일만 표시합니다.',
                  scanning: ids.some(id => !session(id).complete), warning: ids.map(id => session(id).warning).filter(Boolean).join('\n') };
              }
            } catch {}
          }
          if (!snapshot) {
            const latest = pager.latest ? await pager.latest(p.threadId) : null;
            const page = await pager.list({ threadId: p.threadId, ...(latest?.id ? { turnId: latest.id } : {}), limit: 100, sortDirection: 'desc' });
            observe(p.threadId, page.data);
            const turnId = latest?.id || page.data?.[0]?.turnId;
            let cursor = page.nextCursor, count = 1;
            while (turnId && cursor && count++ < 40) {
              const next = await pager.list({ threadId: p.threadId, turnId, cursor, limit: 100, sortDirection: 'desc' });
              observe(p.threadId, next.data);
              if (next.nextCursor === cursor) break;
              cursor = next.nextCursor;
            }
            snapshot = { files: turnId ? files([p.threadId], turnId) : [], scope: 'latest-turn', scopeLabel: '최근 작업의 변경 기록',
              note: 'Git 순변경량을 사용할 수 없어 최근 턴의 파일 기록을 표시합니다.', scanning: !!cursor,
              warning: repository ? '현재 Git 변경을 읽지 못해 최근 작업 기록을 표시합니다.' : '' };
          }
          snapshots.set(p.threadId, snapshot); while (snapshots.size > 32) snapshots.delete(snapshots.keys().next().value);
          const all = snapshot.files;
          return { ...snapshot, files: all.map(({ patches, repo, base, relativePath, untracked, binary, ...f }) => ({ ...f, patchCount: f.patchCount || patches?.length || 1, version: f.version || hash(JSON.stringify(patches)) })), additions: all.reduce((n, f) => n + f.additions, 0), deletions: all.reduce((n, f) => n + f.deletions, 0) };
        }
        const ids = await inspectFamily(p.threadId);
        // A previous working-tree snapshot must never serve a history read.
        snapshots.delete(p.threadId);
        const all = files(ids);
        return { files: all.map(({ patches, ...f }) => ({ ...f, patchCount: patches.length, version: hash(JSON.stringify(patches)) })), additions: all.reduce((n, f) => n + f.additions, 0), deletions: all.reduce((n, f) => n + f.deletions, 0), scanning: ids.some(id => !session(id).complete), warning: ids.map(id => session(id).warning).filter(Boolean).join('\n') };
      }
      if (method !== 'bridge/changes/read') throw Error('지원되지 않는 변경 조회입니다.');
      const snapshot = snapshots.get(p.view === 'review' ? p.threadId + '\0' + p.scope : p.threadId);
      const f = (snapshot?.files || (p.view === 'review' ? [] : files(roots.get(p.threadId) || [p.threadId]))).find(f => f.id === p.fileId);
      if (!f) throw Error('변경된 파일 목록을 다시 확인하세요.');
      if (['working-tree', 'session-working-tree', 'unstaged', 'staged'].includes(snapshot?.scope) && !f.patches) f.patches = await repository.read(f);
      const version = hash(JSON.stringify([f.patches, !!p.changesOnly])); let offset = 0;
      if (p.cursor) { const match = String(p.cursor).match(/^([a-f0-9]{24}):(\d+)$/); if (!match || match[1] !== version) throw Error('파일이 다시 변경되었습니다. 새 변경 보기로 최신 내용을 확인하세요.'); offset = Number(match[2]); }
      const rows = f.patches.flatMap((patch, i) => [{ type: 'patch', text: `변경 ${i + 1} · ${patch.kind === 'add' ? '추가' : patch.kind === 'delete' ? '삭제' : patch.kind === 'repository' ? '중첩 저장소' : '수정'}`, threadId: patch.threadId, turnId: patch.turnId }, ...(patch.note ? [{ type: 'note', text: patch.note }] : []), ...diffRows(patch.diff)]).filter(row => !p.changesOnly || row.type !== 'context');
      if (!Number.isSafeInteger(offset) || offset < 0 || offset > rows.length) throw Error('잘못된 변경 위치입니다.');
      const page = []; let bytes = 0, at = offset, truncated = false;
      while (at < rows.length && page.length < 240) {
        const row = { ...rows[at] };
        if (row.text.length > 16000) { row.text = row.text.slice(0, 16000) + ' … [긴 줄 생략]'; truncated = true; }
        const size = Buffer.byteLength(JSON.stringify(row));
        if (page.length && bytes + size > 192 * 1024) break;
        page.push(row); bytes += size; at++;
      }
      return { fileId: f.id, path: f.path, rows: page, truncated, nextCursor: at < rows.length ? version + ':' + at : null, binary: f.patches.some(p => /Binary files|GIT binary patch/.test(p.diff)), empty: rows.every(r => r.type === 'patch') };
    }
  };
}

import qrcode from 'qrcode-generator';
export function pairingLink({ url, code, name = '' }) {
  const endpoint = new URL(url);
  if (!['ws:', 'wss:'].includes(endpoint.protocol) || endpoint.username || endpoint.password || endpoint.hash || !endpoint.pathname.endsWith('/socket') || !/^[A-HJ-NP-Z2-9]{8}$/.test(code)) throw Error('Invalid pairing information');
  const link = new URL('pocketremote://pair');
  link.searchParams.set('url', endpoint.href); link.searchParams.set('code', code); link.searchParams.set('name', String(name || '').slice(0, 48));
  return link.href;
}
export function pairingQR(values) {
  const qr = qrcode(0, 'M'); qr.addData(pairingLink(values)); qr.make(); return qr.createDataURL(5, 20);
}
if (process.argv[1]?.endsWith('pairing-qr.mjs')) {
  let text = ''; for await (const chunk of process.stdin) { text += chunk; if (text.length > 4096) throw Error('Pairing input too large'); }
  console.log(pairingQR(JSON.parse(text.replace(/^\uFEFF/, ''))));
}

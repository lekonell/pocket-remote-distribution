// Native metadata identifies background threads; nicknames are not identities.
export function subagentSource(thread = {}) {
  let source = thread.source;
  if (typeof source === 'string' && source.startsWith('{')) { try { source = JSON.parse(source); } catch {} }
  return source?.subAgent ?? source?.subagent ?? null;
}
export function agentParent(thread = {}) {
  return thread.parentThreadId || subagentSource(thread)?.thread_spawn?.parent_thread_id || null;
}
export function isSubagentThread(thread = {}) {
  return !!agentParent(thread) || subagentSource(thread) !== null || /^subAgent/.test(thread.source || '');
}
export function isInternalAgent(thread = {}) {
  return ['review', 'compact', 'memory_consolidation'].includes(subagentSource(thread)) || ['subAgentReview', 'subAgentCompact'].includes(thread.source);
}

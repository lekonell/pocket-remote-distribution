"""Package one Windows installer with a checksum-verified official Node LTS runtime."""
import argparse, hashlib, io, json, os, subprocess, urllib.request, zipfile
from pathlib import Path

def fetch(url):
    with urllib.request.urlopen(url, timeout=90) as response: return response.read()

def node_runtime(cache):
    cache.mkdir(parents=True,exist_ok=True)
    record=cache/'runtime.json'
    if record.exists():
        value=json.loads(record.read_text()); archive=cache/value['archive']
        if archive.exists() and hashlib.sha256(archive.read_bytes()).hexdigest()==value['sha256']: return value,archive.read_bytes()
    releases=json.loads(fetch('https://nodejs.org/dist/index.json'))
    version=next(r['version'] for r in releases if r.get('lts') and r['version'].startswith('v24.'))
    name=f'node-{version}-win-x64.zip';base=f'https://nodejs.org/dist/{version}/'
    expected=next(line.split()[0] for line in fetch(base+'SHASUMS256.txt').decode().splitlines() if line.split()[-1]==name)
    data=fetch(base+name)
    if hashlib.sha256(data).hexdigest()!=expected: raise ValueError('Official Node runtime hash differs')
    (cache/name).write_bytes(data);value={'version':version,'archive':name,'sha256':expected,'source':base+name}
    record.write_text(json.dumps(value,indent=2),encoding='utf-8');return value,data

def build(runtime,update,manifest,output,cache):
    value,data=node_runtime(cache)
    bundle=output.parent/(output.stem+'.payload.zip')
    with zipfile.ZipFile(runtime) as source,zipfile.ZipFile(io.BytesIO(data)) as node,zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as target:
        for item in source.infolist():
            if not item.is_dir(): target.writestr(item.filename,source.read(item))
        prefix=f"node-{value['version']}-win-x64/"
        target.writestr('tools/node.exe',node.read(prefix+'node.exe'))
        target.writestr('tools/NODE-LICENSE.txt',node.read(prefix+'LICENSE'))
        target.writestr('tools/node-runtime.json',json.dumps(value,indent=2))
    with zipfile.ZipFile(runtime) as source: package=json.loads(source.read('package.json'))
    generated=output.parent/(output.stem+'.cs')
    generated.write_text('internal static class InstallerPayload { public const string Version='+json.dumps(package['version'])+'; public const string Hash="'+hashlib.sha256(bundle.read_bytes()).hexdigest()+'"; }',encoding='utf-8')
    project=Path(__file__).resolve().parents[1]
    compiler=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
    subprocess.run([str(compiler),'/nologo','/target:winexe','/optimize+','/platform:anycpu','/reference:System.Windows.Forms.dll','/reference:System.Drawing.dll','/reference:System.Web.Extensions.dll','/reference:System.IO.Compression.dll','/reference:System.IO.Compression.FileSystem.dll','/out:'+str(output),'/resource:'+str(bundle)+',runtime.zip','/resource:'+str(update)+',update.zip','/resource:'+str(manifest)+',manifest.json',str(project/'launcher/RemoteInstaller.cs'),str(generated)],check=True)
    print(json.dumps({'installer':output.name,'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'runtime':value['version']}))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['runtime','update','manifest','output']: p.add_argument(name,type=Path)
    p.add_argument('--cache',type=Path,default=Path(__file__).resolve().parents[1]/'build/node-runtime');args=p.parse_args()
    build(args.runtime.resolve(),args.update.resolve(),args.manifest.resolve(),args.output.resolve(),args.cache.resolve())

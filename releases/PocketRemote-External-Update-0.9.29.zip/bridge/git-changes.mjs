import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';

const run = promisify(execFile);
const hash = value => createHash('sha256').update(value).digest('hex').slice(0, 24);
const options = cwd => ({ cwd, windowsHide: true, timeout: 8000, maxBuffer: 24 * 1024 * 1024, env: { ...process.env, GIT_OPTIONAL_LOCKS: '0', GIT_TERMINAL_PROMPT: '0' } });
async function git(cwd, args, allowDiffExit = false) {
  try { return (await run('git', ['-c', 'core.quotepath=false', ...args], options(cwd))).stdout; }
  catch (e) { if (allowDiffExit && e.code === 1 && typeof e.stdout === 'string') return e.stdout; throw e; }
}
async function stamp(path) { try { const s = await stat(path); return [s.size, s.mtimeMs, s.ctimeMs]; } catch { return null; } }
export function parseNumstat(value) {
  const parts = value.split('\0'), files = [];
  for (let i = 0; i < parts.length; i++) {
    if (!parts[i]) continue;
    const match = parts[i].match(/^([^\t]+)\t([^\t]+)\t([\s\S]*)$/);
    if (!match) throw Error('Git 변경 목록을 해석하지 못했습니다.');
    let path = match[3], previousPath = '';
    if (!path) { previousPath = parts[++i]; path = parts[++i]; }
    if (!path) throw Error('Git 파일 경로가 없습니다.');
    files.push({ path, previousPath, additions: Number(match[1]) || 0, deletions: Number(match[2]) || 0, binary: match[1] === '-' });
  }
  return files;
}

// Read-only, bounded snapshots. Nothing stages, refreshes or changes the index.
export function createGitChanges({ cacheMs = 1200 } = {}) {
  const cache = new Map(), pending = new Map();
  async function inspect(cwd, scope) {
    const started = Date.now();
    const repo = (await git(cwd, ['rev-parse', '--show-toplevel'])).trim();
    let base = '';
    try { base = (await git(repo, ['rev-parse', '--verify', 'HEAD'])).trim(); } catch {}
    const untracked = scope === 'staged' ? [] : (await git(repo, ['ls-files', '--others', '--exclude-standard', '-z'])).split('\0').filter(Boolean);
    const args = ['diff', '--no-ext-diff', '--no-textconv', '--find-renames', '--numstat', '-z', ...(scope === 'staged' ? ['--cached'] : scope === 'working-tree' && base ? [base] : []), '--'];
    let records = scope !== 'working-tree' || base ? parseNumstat(await git(repo, args)) : [];
    if (!base && scope === 'working-tree') untracked.push(...(await git(repo, ['ls-files', '-z'])).split('\0').filter(Boolean));
    if (untracked.length + records.length > 2000) throw Error('현재 변경 파일이 2,000개를 넘어 Git 목록을 읽지 못했습니다.');
    for (const path of new Set(untracked)) {
      if (Date.now() - started > 12000) throw Error('Git 현재 변경 조회 시간이 초과되었습니다.');
      const entry = await stat(resolve(repo, path));
      if (entry.isDirectory()) { records.push({ path, previousPath: '', additions: 0, deletions: 0, untracked: true, nestedRepository: true }); continue; }
      const patch = await git(repo, ['diff', '--no-index', '--no-ext-diff', '--no-textconv', '--numstat', '-z', '--', '/dev/null', path], true);
      const row = parseNumstat(patch)[0];
      if (row) records.push({ ...row, path, previousPath: '', untracked: true });
    }
    const index = (await git(repo, ['rev-parse', '--git-path', 'index'])).trim();
    const indexStamp = await stamp(resolve(repo, index));
    const files = await Promise.all(records.map(async f => {
      const path = resolve(repo, f.path).replace(/\\/g, '/'), key = process.platform === 'win32' ? path.toLowerCase() : path;
      return { ...f, id: hash(key), path, relativePath: f.path, repo, base, scope, patchCount: 1,
        version: hash(JSON.stringify([scope, base, indexStamp, f, await stamp(path)])) };
    }));
    return { repo, files: files.sort((a, b) => a.path.localeCompare(b.path)), scope,
      scopeLabel: scope === 'unstaged' ? '미스테이징 변경 · 작업 폴더와 Git 인덱스 비교' : scope === 'staged' ? '스테이징 변경 · Git 인덱스와 HEAD 비교' : '현재 Git 변경 · 커밋되지 않은 순변경량',
      note: scope === 'working-tree' ? '추적 파일·새 파일의 현재 변경입니다. 같은 저장소의 직접 수정도 포함합니다.' : '선택한 저장소의 현재 변경입니다. 사용자와 다른 대화의 직접 수정도 포함합니다.', scanning: false, warning: '' };
  }
  return {
    async list(cwd, { scope = 'working-tree' } = {}) {
      if (!cwd) throw Error('작업 폴더가 없습니다.');
      if (!['working-tree', 'unstaged', 'staged'].includes(scope)) throw Error('지원되지 않는 Git 변경 범위입니다.');
      const directory = resolve(cwd), key = scope + ':' + directory, old = cache.get(key);
      if (old && Date.now() - old.time < cacheMs) return old.value;
      if (pending.has(key)) return pending.get(key);
      const task = inspect(directory, scope).then(value => { cache.set(key, { value, time: Date.now() }); while (cache.size > 32) cache.delete(cache.keys().next().value); return value; }).finally(() => pending.delete(key));
      pending.set(key, task); return task;
    },
    async read(file) {
      if (file.nestedRepository) return [{ kind: 'repository', diff: '', note: '중첩 Git 저장소 폴더입니다. 내부 파일 변경은 해당 저장소의 대화에서 확인하세요.' }];
      const diff = file.untracked
        ? await git(file.repo, ['diff', '--no-index', '--no-ext-diff', '--no-textconv', '--unified=3', '--', '/dev/null', file.relativePath], true)
        : await git(file.repo, ['diff', '--no-ext-diff', '--no-textconv', '--find-renames', '--unified=3', ...(file.scope === 'staged' ? ['--cached', ...(file.base ? [file.base] : [])] : file.scope === 'unstaged' ? [] : file.base ? [file.base] : []), '--', ...new Set([file.relativePath, file.previousPath].filter(Boolean))]);
      return [{ kind: file.untracked ? 'add' : 'update', diff }];
    }
  };
}

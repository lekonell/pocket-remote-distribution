// Seek actual visible items on the PC. Native turn summaries omit Steering
// messages, so they cannot establish which user message is adjacent.
export function createMessageNavigator({ pager, now = Date.now }) {
  const cache=new Map(),pending=new Map(),versions=new Map();
  let bytes=0,generation=0;
  function invalidate(threadId){
    versions.set(threadId,(versions.get(threadId)||0)+1);
    for(const[key,value]of cache)if(value.threadId===threadId){cache.delete(key);bytes-=value.bytes;}
    while(versions.size>256)versions.delete(versions.keys().next().value);
  }
  async function seek(p,known){
    let cursor=p.cursor,direction=p.direction;
    const seen=new Set();
    if(!cursor&&direction==='newer'&&typeof p.anchor?.itemId==='string'&&typeof p.anchor?.turnId==='string'){
      try {
        let probe=await pager.list({threadId:p.threadId,turnId:p.anchor.turnId,cursor:{type:'item',itemId:p.anchor.itemId},limit:1,sortDirection:'asc'});
        if(!probe.backwardsCursor)probe=await pager.list({threadId:p.threadId,turnId:p.anchor.turnId,cursor:{type:'item',itemId:p.anchor.itemId},limit:1,sortDirection:'desc'});
        cursor=probe.backwardsCursor;
      }catch(error){
        if(!/not supported|unsupported|unknown|not found|invalid|anchor|not materialized/i.test(error.message))throw error;
      }
    }
    if(!cursor&&direction==='newer'){
      const page=await pager.list({threadId:p.threadId,limit:90,sortDirection:'desc'}),target=[...(page.data||[])].reverse().find(e=>e.item.type==='userMessage'&&!known.has(e.item.id));
      return target?{targetId:target.item.id,page,direction:'older',atLatest:true}:{targetId:null};
    }
    for(let n=0;cursor&&n<80&&!seen.has(cursor);n++){
      seen.add(cursor);
      const page=await pager.list({threadId:p.threadId,cursor,limit:90,sortDirection:direction==='older'?'desc':'asc'});
      const target=page.data?.find(e=>e.item.type==='userMessage'&&!known.has(e.item.id));
      if(target)return{targetId:target.item.id,page,direction,atLatest:direction==='newer'&&!page.nextCursor};
      const next=page.nextCursor||null;if(!next||next===cursor)return{targetId:null};cursor=next;
    }
    return cursor?{continuation:cursor}:{targetId:null};
  }
  return {
    reset(){generation++;cache.clear();pending.clear();versions.clear();bytes=0;},
    onEvent(message){const p=message.params||{};if(message.method==='turn/started'||p.item?.type==='userMessage'||['thread/deleted','thread/compacted'].includes(message.method))invalidate(p.threadId);},
    async handle(p={}){
      if(typeof p.threadId!=='string'||!p.threadId||p.threadId.length>100||!['older','newer'].includes(p.direction))throw Error('Select a conversation and message direction');
      if(p.cursor!=null&&(typeof p.cursor!=='string'||p.cursor.length>16384))throw Error('Invalid message navigation cursor');
      const knownIds=Array.isArray(p.knownIds)?p.knownIds.filter(x=>typeof x==='string'&&x.length<=256).slice(0,240):[],known=new Set(knownIds);
      const version=versions.get(p.threadId)||0,key=JSON.stringify([generation,version,p.threadId,p.direction,p.cursor,p.anchor,knownIds]);
      const saved=cache.get(key);if(saved&&now()-saved.at<15000)return saved.result;
      if(pending.has(key))return pending.get(key);
      const expected=generation,work=seek(p,known).then(result=>{
        const size=JSON.stringify(result).length*2;
        if(expected===generation&&version===(versions.get(p.threadId)||0)&&size<=2*1024*1024){
          const old=cache.get(key);if(old)bytes-=old.bytes;
          cache.set(key,{threadId:p.threadId,result,bytes:size,at:now()});bytes+=size;
          while(cache.size>32||bytes>8*1024*1024){const first=cache.keys().next().value;bytes-=cache.get(first).bytes;cache.delete(first);}
        }
        return result;
      }).finally(()=>{if(pending.get(key)===work)pending.delete(key);});
      pending.set(key,work);return work;
    }
  };
}

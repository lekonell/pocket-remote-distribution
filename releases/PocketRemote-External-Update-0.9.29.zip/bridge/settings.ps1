﻿# Configuration lives outside the replaceable program directory.
$PocketSettingsFiles = @('.endpoint.json','.endpoint-secret','.remote-secret','.setup.json','.launcher.json','.relay.json','.relay-tunnel.key','.relay-tunnel.key.pub','.shared-server.json','.desktop-shared-backup')
function Get-PocketSettingsRoot([string]$InstallRoot) {
    if ($env:REMOTE_DATA_DIR) { return [IO.Path]::GetFullPath($env:REMOTE_DATA_DIR) }
    $marker = Join-Path $InstallRoot 'distribution.json'
    if (!(Test-Path -LiteralPath $marker)) { return $InstallRoot }
    $channel = (Get-Content -LiteralPath $marker -Raw -Encoding UTF8 | ConvertFrom-Json).channel
    if ($channel -notin @('standard','external')) { throw 'Invalid distribution channel' }
    return Join-Path $env:LOCALAPPDATA ('PocketRemote\' + $channel)
}
function Get-PocketSetting([string]$InstallRoot, [string]$Name) {
    if ($Name -notin $PocketSettingsFiles) { throw 'Unknown persistent setting' }
    return Join-Path (Get-PocketSettingsRoot $InstallRoot) $Name
}
function Initialize-PocketSettings([string]$InstallRoot, [string]$DataRoot='') {
    $destination = if ($DataRoot) { $DataRoot } else { Get-PocketSettingsRoot $InstallRoot }
    if ([string]::Equals($destination.TrimEnd('\'), $InstallRoot.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { return }
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($id in @([Security.Principal.WindowsIdentity]::GetCurrent().User, [Security.Principal.SecurityIdentifier]::new('S-1-5-18'))) {
        $rule = [Security.AccessControl.FileSystemAccessRule]::new($id, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
    }
    [IO.Directory]::SetAccessControl($destination, $acl)
    foreach ($name in $PocketSettingsFiles) {
        $source = Join-Path $InstallRoot $name; $target = Join-Path $destination $name
        if ((Test-Path -LiteralPath $source -PathType Leaf) -and !(Test-Path -LiteralPath $target)) { Copy-Item -LiteralPath $source -Destination $target }
    }
    foreach ($name in @('.endpoint.json','.relay.json')) {
        $target = Join-Path $destination $name
        if (!(Test-Path -LiteralPath $target)) { continue }
        $value = Get-Content -LiteralPath $target -Raw -Encoding UTF8 | ConvertFrom-Json
        $changed = $false
        foreach ($field in @('sshIdentityFile','keyFile')) {
            if ($value.$field -eq (Join-Path $InstallRoot '.relay-tunnel.key')) { $value.$field = Join-Path $destination '.relay-tunnel.key'; $changed = $true }
        }
        if ($changed) { [IO.File]::WriteAllText($target, ($value | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false)) }
    }
}

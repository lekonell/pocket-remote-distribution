import { createHash } from 'node:crypto';

const imageHost = host => host === 'oaistatic.com' || host.endsWith('.oaistatic.com') || host === 'oaiusercontent.com' || host.endsWith('.oaiusercontent.com');
export function dotAvatarUrl(value) {
  try { const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.hash&&(!u.port||u.port==='443')&&imageHost(u.hostname)?u.href:null; } catch { return null; }
}
const fingerprint = p => createHash('sha256').update(JSON.stringify([p.avatar_type,p.avatar_id,p.avatar,p.avatar_manifest,p.color,String(p.avatar_url||'').split('?')[0]])).digest('hex');

// Sources come only from the authenticated Dot profile/catalog. No client URL,
// signed URL or bearer token crosses the mobile RPC boundary.
export function createDotAvatars({ request, fetchImpl, current }) {
  const sources=new Map(),cache=new Map(),pending=new Map();let bytes=0;
  function describe(p) {
    const version=fingerprint(p);sources.set(p.id,{...p,version});
    return {version,type:p.avatar_type||'default',color:/^#[a-f0-9]{6}$/i.test(p.color||'')?p.color:({green:'#75b8a2',blue:'#82a7d3',purple:'#ad96c8',pink:'#dca0b5',orange:'#dbad79',gray:'#a9b1ba'})[p.color]||'#8ab9b2'};
  }
  async function image(a, value, limit) {
    let url=dotAvatarUrl(value);if(!url)return null;
    for(let hop=0;hop<4;hop++){
      current(a);const response=await fetchImpl(url,{method:'GET',redirect:'manual',signal:AbortSignal.timeout(15000),headers:{Accept:'image/avif,image/webp,image/png,image/jpeg,image/gif'}});
      if([301,302,303,307,308].includes(response.status)){const next=dotAvatarUrl(new URL(response.headers.get('location')||'',url).href);await response.body?.cancel();if(!next)return null;url=next;continue;}
      const mime=(response.headers.get('content-type')||'').split(';')[0].toLowerCase();
      if(!response.ok||!/^image\/(png|jpeg|webp|gif|avif)$/.test(mime)||Number(response.headers.get('content-length')||0)>limit){await response.body?.cancel();return null;}
      let size=0;const parts=[];for await(const part of response.body){size+=part.length;if(size>limit)throw Error('Dot avatar exceeds the image limit');parts.push(part);}
      current(a);return 'data:'+mime+';base64,'+Buffer.concat(parts).toString('base64');
    }
    return null;
  }
  async function snapshot(a,p){
    const direct=await image(a,p.avatar_url,512*1024);if(direct)return direct;
    const pointer=p.avatar_manifest?.snapshot?.asset_pointer, file=typeof pointer==='string'?pointer.replace(/^(?:file-service|sediment):\/\//,''):'';
    if(!/^[a-zA-Z0-9_-]{1,200}$/.test(file))return null;
    const result=await request(a,'/files/download/'+encodeURIComponent(file));return image(a,result.download_url,512*1024);
  }
  async function sheet(a,p){
    const petId=p.avatar_manifest?.pet_id;if(p.avatar_type!=='codex-pet'||typeof petId!=='string'||!petId.startsWith('pet_'))return null;
    let cursor;const seen=new Set();
    for(let page=0;page<20;page++){
      const result=await request(a,'/pets?'+new URLSearchParams({limit:'20',...(cursor?{cursor}:{})}));
      const pet=result.pets?.find(pet=>pet.id===petId);if(pet)return image(a,pet.spritesheet_url,4*1024*1024);
      if(!result.cursor||seen.has(result.cursor))return null;cursor=result.cursor;seen.add(cursor);
    }
    return null;
  }
  return {
    describe,
    reset(){sources.clear();cache.clear();pending.clear();bytes=0;},
    async read(a,p,motion=false){
      const source=sources.get(p.id);if(!source)return {version:p.avatar?.version};
      const key=JSON.stringify([a.key,a.generation,p.id,source.version,!!motion]);if(cache.has(key))return cache.get(key);if(pending.has(key))return pending.get(key);
      const work=(async()=>{
        const data=motion?await sheet(a,source):await snapshot(a,source);current(a);
        const result={version:source.version,...(motion?{sheet:data}:{image:data})};
        if(data){cache.set(key,result);bytes+=data.length;while(cache.size>16||bytes>16*1024*1024){const first=cache.keys().next().value,v=cache.get(first);bytes-=(v.image||v.sheet||'').length;cache.delete(first);}}
        return result;
      })().finally(()=>{if(pending.get(key)===work)pending.delete(key);});pending.set(key,work);return work;
    }
  };
}

import { WebSocket } from 'ws';
let text = ''; for await (const chunk of process.stdin) { text += chunk; if (text.length > 2048) throw Error('Input too large'); }
try {
  const { url } = JSON.parse(text.replace(/^\uFEFF/, '')), endpoint = new URL(url);
  if (!['ws:', 'wss:'].includes(endpoint.protocol) || endpoint.username || endpoint.password || endpoint.hash || !endpoint.pathname.endsWith('/socket')) throw Error('WS/WSS 주소를 확인하세요.');
  await new Promise((resolve, reject) => {
    const ws = new WebSocket(endpoint, ['codex-pair'], { handshakeTimeout: 8000, rejectUnauthorized: true });
    ws.once('error', reject); ws.once('open', () => { ws.close(); resolve(); });
  });
  console.log(JSON.stringify({ ok: true, reachable: true, message: 'PC에서 WS/WSS 경로에 연결했습니다. 휴대폰의 LAN·VPN·LTE 연결은 휴대폰에서 최종 확인하세요.' }));
} catch { console.log(JSON.stringify({ ok: false, error: '연결할 수 없습니다. PC 주소·포트·방화벽·VPN·터널 또는 TLS 인증서를 확인하세요.' })); process.exitCode = 1; }

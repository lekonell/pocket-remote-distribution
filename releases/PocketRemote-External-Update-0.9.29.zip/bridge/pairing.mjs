import { randomInt, timingSafeEqual } from 'node:crypto';

const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function createPairing({ secret, now = Date.now, ttl = 5 * 60 * 1000, maxAttempts = 10 }) {
  let ticket = null, windowStart = 0, attempts = 0;
  return {
    issue() {
      const code = Array.from({ length: 8 }, () => alphabet[randomInt(alphabet.length)]).join('');
      ticket = { code, expiresAt: now() + ttl };
      // Issuing replaces the old code, but never resets the global guess limit.
      return { ...ticket };
    },
    redeem(value) {
      const time = now();
      if (time - windowStart >= ttl) { windowStart = time; attempts = 0; }
      if (++attempts > maxAttempts) throw Error('페어링 시도가 많습니다. 잠시 후 새 코드를 발급해 주세요.');
      const code = String(value || '').toUpperCase();
      const valid = ticket && ticket.expiresAt > time && /^[A-Z2-9]{8}$/.test(code)
        && timingSafeEqual(Buffer.from(code), Buffer.from(ticket.code));
      if (!valid) throw Error('코드가 잘못되었거나 만료되었습니다. PC에서 새 코드를 발급해 주세요.');
      ticket = null;
      return { token: secret };
    },
    matches(value) {
      const a = Buffer.from(String(value || '')), b = Buffer.from(secret);
      return a.length === b.length && timingSafeEqual(a, b);
    }
  };
}

// Pairing sockets never join the session/event channel or accept native RPC.
export function attachPairingSocket(socket, pairing, { name = '', cwd = '' } = {}) {
  const deadline = setTimeout(() => socket.close(1008, 'Pairing timeout'), 10000);
  socket.once('close', () => clearTimeout(deadline));
  socket.once('message', bytes => {
    clearTimeout(deadline);
    try {
      const data = JSON.parse(bytes.toString());
      if (data.type !== 'pair') throw Error('페어링 요청을 확인하세요.');
      socket.send(JSON.stringify({ type: 'paired', ...pairing.redeem(data.code), name, cwd }));
      socket.close(1000);
    } catch (e) { socket.send(JSON.stringify({ type: 'pairingError', message: e.message })); socket.close(1008); }
  });
}

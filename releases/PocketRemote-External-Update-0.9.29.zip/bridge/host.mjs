import { settingsPath, migrateSettings } from './settings.mjs';
import { spawn } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, appendFileSync, readdirSync, statSync, unlinkSync, renameSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { endpointEnvironment } from './endpoint.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
migrateSettings(root);
const configFile = settingsPath(root, '.endpoint.json');
const config = existsSync(configFile) ? JSON.parse(readFileSync(configFile, 'utf8').replace(/^\uFEFF/, '')) : {};
const quiet = process.argv.includes('--quiet');
const children = new Set();
let stopping = false;
const logFile = resolve(root, '.host.log');
const log = text => {
  if (existsSync(logFile) && statSync(logFile).size > 5 * 1024 * 1024) { try { renameSync(logFile, logFile + '.1'); } catch {} }
  appendFileSync(logFile, new Date().toISOString() + ' ' + String(text).slice(0, 3000) + '\n');
  if (!quiet) console.log(text);
};
const env = endpointEnvironment(config);
if (config.provider === 'ssh' && (!/^[A-Za-z0-9][A-Za-z0-9_.@:-]*$/.test(config.sshHost || '') || !Number.isInteger(config.reversePort) || config.reversePort < 1024 || config.reversePort > 65535)) throw new Error('SSH endpoint configuration is incomplete.');
const sshOptions = [];
if (config.provider === 'ssh') {
  if (config.sshPort !== undefined) {
    if (!Number.isInteger(config.sshPort) || config.sshPort < 1 || config.sshPort > 65535) throw Error('Invalid SSH port');
    sshOptions.push('-p', String(config.sshPort));
  }
  if (config.sshIdentityFile) {
    if (!existsSync(config.sshIdentityFile) || /[\x00-\x1f"]/.test(config.sshIdentityFile)) throw Error('SSH tunnel key is unavailable');
    sshOptions.push('-i', config.sshIdentityFile, '-o', 'IdentitiesOnly=yes');
  }
}
if (config.provider === 'ngrok' && !config.publicUrl?.startsWith('https://')) throw new Error('A fixed HTTPS ngrok URL is required.');
try {
  const health = await fetch(`http://127.0.0.1:${env.REMOTE_PORT}/health`, { signal: AbortSignal.timeout(2000) });
  if (health.ok) throw new Error('A bridge is already running. Stop it before starting the supervised host.');
} catch (error) { if (error.message.startsWith('A bridge is already')) throw error; }
try { unlinkSync(resolve(root, '.stop-request')); } catch {}
if (!env.CODEX_BIN) {
  const codexRoot = resolve(process.env.LOCALAPPDATA, 'OpenAI/Codex/bin');
  if (existsSync(codexRoot)) {
    const candidates = readdirSync(codexRoot).map(x => resolve(codexRoot, x, 'codex.exe')).filter(existsSync);
    candidates.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs);
    if (candidates.length) env.CODEX_BIN = candidates[0];
  }
}
function supervise(name, executable, args, childEnv = env) {
  if (stopping) return;
  const child = spawn(executable, args, { cwd: root, env: childEnv, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  children.add(child);
  let buffer = '';
  for (const stream of [child.stdout, child.stderr]) {
    stream.setEncoding('utf8');
    stream.on('data', chunk => {
      buffer += chunk;
      let end;
      while ((end = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, end).trim(); buffer = buffer.slice(end + 1);
        if (!line.startsWith('Pairing token:')) log(`[${name}] ${line}`);
      }
    });
  }
  child.on('error', error => log(`[${name}] ${error.message}`));
  child.on('close', code => {
    children.delete(child);
    if (!stopping) { log(`[${name}] stopped (${code}); restarting in 2 seconds.`); setTimeout(() => supervise(name, executable, args, childEnv), 2000); }
  });
}
const port = env.REMOTE_PORT;
supervise('bridge', process.execPath, [resolve(root, 'bridge/server.mjs')]);
if (config.provider === 'ssh') {
  supervise('ssh', 'ssh', ['-NT', ...sshOptions, '-o', 'BatchMode=yes', '-o', 'ExitOnForwardFailure=yes', '-o', 'ServerAliveInterval=10', '-o', 'ServerAliveCountMax=2', '-o', 'ConnectTimeout=10', '-R', `127.0.0.1:${config.reversePort}:127.0.0.1:${port}`, config.sshHost]);
} else if (config.provider === 'ngrok') {
  supervise('ngrok', resolve(root, 'tools/ngrok.exe'), ['http', `http://127.0.0.1:${port}`, '--url', config.publicUrl, '--inspect=false', '--log=stdout']);
} else if (config.provider === 'cloudflare') {
  supervise('cloudflare', resolve(root, 'tools/cloudflared.exe'), ['tunnel', '--no-autoupdate', 'run']);
} else if (['direct', 'custom'].includes(config.provider)) log('Direct/custom endpoint configured; bridge binding ' + env.REMOTE_BIND + ':' + port + '.');
else log('No fixed endpoint configured. The bridge is available on loopback only.');
writeFileSync(resolve(root, '.host.pid'), String(process.pid));
if (process.platform === 'win32' && process.env.REMOTE_AUTO_UPDATE !== '0') {
  const updater = spawn(process.execPath, [resolve(root, 'bridge/update-worker.mjs'), '--parent', String(process.pid)], { cwd: root, windowsHide: true, stdio: 'ignore' });
  children.add(updater);
  updater.on('error', () => log('Automatic update worker could not start; current host remains available.'));
  updater.on('close', () => children.delete(updater));
}
setTimeout(() => {
  const secretPath = settingsPath(root, '.remote-secret');
  if (!quiet && existsSync(secretPath)) console.log(`Pairing token (keep private): ${readFileSync(secretPath, 'utf8').trim()}`);
  if (config.websocketUrl) log(`Android endpoint: ${config.websocketUrl}`);
}, 1500);
function stop() {
  stopping = true;
  for (const child of children) child.kill();
  for (const name of ['.host.pid', '.stop-request']) try { unlinkSync(resolve(root, name)); } catch {}
  setTimeout(() => process.exit(), 300).unref();
}
setInterval(() => { if (existsSync(resolve(root, '.stop-request'))) stop(); }, 1000);
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

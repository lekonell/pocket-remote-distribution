import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { writeFile, rename } from 'node:fs/promises';
import { resolve } from 'node:path';
import { isSubagentThread } from './thread-source.mjs';

export function isModelCapacityError(error) {
  if(['usageLimitExceeded','rateLimitExceeded','sessionBudgetExceeded','unauthorized','badRequest','misalignmentPolicyViolation','cyberPolicy'].includes(error?.codexErrorInfo))return false;
  return error?.codexErrorInfo === 'serverOverloaded' || error?.data?.codexErrorInfo === 'serverOverloaded' || /(?:selected\s+model|model)\s+(?:is\s+)?(?:currently\s+)?at\s+capacity|model.{0,30}capacity|server\s+(?:is\s+)?overloaded/i.test(error?.message || '');
}
export const capacityDelay = attempts => Math.min(60000, 10000 * 2 ** Math.min(6, Math.max(0, attempts - 1)));
// Store fingerprints, not objectives. Native timestamps have second precision;
// explicit requests/events are still authoritative even when hashes are equal.
const goalStamp = goal => goal && createHash('sha256').update(JSON.stringify([
  goal.createdAt, goal.objective, goal.tokenBudget ?? null, goal.status,
  goal.updatedAt, goal.tokensUsed, goal.timeUsedSeconds
])).digest('hex');
const goalIdentity = goal => goal && createHash('sha256').update(JSON.stringify([
  goal.createdAt, goal.objective, goal.tokenBudget ?? null
])).digest('hex');

// Continue only an explicitly failed capacity turn. No user input is replayed.
// A missing reply to a start request is reconciled by reads, never resubmitted.
export function createCapacityRetry({ root, call, ensureThread, coordinator, online, notify, hasQueued = () => false, isGoalYielded = () => false, getScope, clock = { now: Date.now, set: setTimeout, clear: clearTimeout } }) {
  const path = resolve(root, '.capacity-retries.json'), jobs = new Map(), native = new Map(), timers = new Map(), busy = new Map(), attempts = new Map(), revisions = new Map(), capturing = new Map(), latest = new Map(), ended = new Map();
  const goalPauses = new Map(), suppressed = new Map(), intents = new Map();
  let stopped = false, writing = Promise.resolve();
  try {
    const data = JSON.parse(readFileSync(path, 'utf8'));
    for (const [id, turnId] of data.version === 2 ? data.suppressed || [] : []) if (typeof id === 'string' && typeof turnId === 'string' && suppressed.size < 512) suppressed.set(id, turnId);
    for (const job of [1,2].includes(data.version) ? data.jobs || [] : []) if (typeof job.threadId === 'string' && typeof job.turnId === 'string' && typeof job.scope === 'string' && /^[a-f0-9]{64}$/.test(job.scope) && Number.isFinite(job.nextRetryAt)) {
      if (jobs.size >= 128) break;
      job.status = job.status === 'dispatching' ? 'checking' : job.status;
      // A manual pause may have occurred while the bridge was unavailable.
      // Replayed terminal events or persisted timestamps cannot authorize it.
      delete job.goalPause;
      job.allowGoalPause = false;
      jobs.set(job.threadId, job); attempts.set(job.threadId, job.attempts || 1);
    }
  } catch {}
  const scope = getScope || (async () => {
    const auth = await call('getAuthStatus', { includeToken: true, refreshToken: false });
    if (!auth.authToken) throw Error('PC 공식 앱의 로그인을 확인해주세요.');
    let identity = auth.authToken;
    try { const claims=JSON.parse(Buffer.from(auth.authToken.split('.')[1],'base64url')),a=claims['https://api.openai.com/auth'];if(a?.chatgpt_account_id&&a?.chatgpt_user_id)identity=a.chatgpt_account_id+':'+a.chatgpt_user_id; } catch {}
    return createHash('sha256').update(identity).digest('hex');
  });
  function save() {
    const data=JSON.stringify({version:2,jobs:[...jobs.values()],suppressed:[...suppressed]});
    writing=writing.catch(()=>{}).then(async()=>{await writeFile(path+'.tmp',data,{mode:0o600});await rename(path+'.tmp',path);});return writing;
  }
  const visible = job => job && { threadId:job.threadId,turnId:job.turnId,attempts:job.attempts,status:job.status,nextRetryAt:job.nextRetryAt,reason:job.reason||'capacity' };
  function publish(id) { notify({method:'pocket/retry/changed',params:{threadId:id,retry:visible(jobs.get(id)||native.get(id))||null}}); }
  function cancel(id, explicit = false) {
    revisions.set(id,(revisions.get(id)||0)+1);capturing.delete(id);
    if(explicit&&busy.has(id))busy.get(id).cancelled=true;
    const existed=jobs.delete(id)||native.has(id);native.delete(id);clock.clear(timers.get(id));timers.delete(id);
    if(explicit)attempts.delete(id);
    if(existed){save().catch(()=>{});publish(id);}
  }
  function supersede(id, kind) {
    goalPauses.delete(id);
    suppressed.delete(id); suppressed.set(id, latest.get(id) || jobs.get(id)?.turnId || capturing.get(id) || '*');
    intents.delete(id); intents.set(id, { kind });
    while (suppressed.size > 512) suppressed.delete(suppressed.keys().next().value);
    while (intents.size > 512) intents.delete(intents.keys().next().value);
    cancel(id, kind !== 'supersede'); attempts.delete(id);
    save().catch(()=>{});
  }
  function schedule(id, delay) {
    clock.clear(timers.get(id));timers.delete(id);
    const job=jobs.get(id);if(stopped||!job||!online())return;
    timers.set(id,clock.set(()=>{timers.delete(id);run(id).catch(()=>{});},delay??Math.max(0,job.nextRetryAt-clock.now())));
  }
  async function capture(id, turn) {
    if (suppressed.get(id) === '*' || suppressed.get(id) === turn.id) return;
    if(jobs.get(id)?.turnId===turn.id||capturing.get(id)===turn.id)return;
    const revision=revisions.get(id)||0;capturing.set(id,turn.id);
    try {
      const key=await scope();if(stopped||(revisions.get(id)||0)!==revision)return;
      const count=(attempts.get(id)||0)+1;attempts.set(id,count);
      jobs.set(id,{threadId:id,turnId:turn.id,scope:key,attempts:count,nextRetryAt:clock.now()+capacityDelay(count),status:'waiting',
        ...(goalPauses.get(id)?.turnId === turn.id ? { goalPause: goalPauses.get(id) } : {})});
      await save();publish(id);schedule(id);
    } catch { if(!stopped&&(revisions.get(id)||0)===revision)notify({method:'pocket/retry/changed',params:{threadId:id,retry:{threadId:id,turnId:turn.id,status:'loginRequired',reason:'login',nextRetryAt:null}}}); }
    finally { if(capturing.get(id)===turn.id)capturing.delete(id); }
  }
  async function run(id) {
    const job=jobs.get(id);if(stopped||!online()||!job||busy.has(id))return;
    if(hasQueued(id)||!coordinator.acquire(id)){schedule(id,1000);return;}
    busy.set(id,job);
    try {
      if(await scope()!==job.scope){supersede(id,'stop');return;}
      const {thread}=await call('thread/read',{threadId:id,includeTurns:false});
      if(jobs.get(id)!==job)return;
      if(!thread||thread.archived||isSubagentThread(thread)){cancel(id);return;}
      const page=await call('thread/turns/list',{threadId:id,limit:1,sortDirection:'desc',itemsView:'notLoaded'}),last=page.data?.[0];
      if(jobs.get(id)!==job)return;
      if(last?.id!==job.turnId||last?.status!=='failed'||!isModelCapacityError(last.error)){cancel(id);return;}
      if(job.status==='checking'){job.nextRetryAt=clock.now()+10000;await save();publish(id);schedule(id);return;}
      let goal;
      try {({goal}=await call('thread/goal/get',{threadId:id}));} catch(e) {if(!/-32601|unknown method|unsupported|not supported|no goal|goal not found/i.test(String(e.code)+' '+e.message))throw e;}
      if(jobs.get(id)!==job)return;
      const capacityPaused = goal?.status === 'paused' && job.goalPause?.turnId === job.turnId && job.goalPause.stamp === goalStamp(goal);
      if(goal&&((goal.status==='paused'&&!capacityPaused&&!isGoalYielded(id))||['usageLimited','budgetLimited','complete'].includes(goal.status)||goal.tokenBudget!=null&&goal.tokensUsed>=goal.tokenBudget)){supersede(id,'pause');return;}
      if(ensureThread)await ensureThread(id);
      if(jobs.get(id)!==job||stopped||!online())return;
      job.status='dispatching';await save();publish(id);
      if(jobs.get(id)!==job)return;
      const resumeGoal = goal && !isGoalYielded(id) && ['paused','blocked','active'].includes(goal.status);
      job.resumingGoal = !!resumeGoal; job.goalIdentity = goalIdentity(goal);
      const result=resumeGoal?await call('thread/goal/set',{threadId:id,status:'active',origin:'automatic'}):await call('turn/start',{threadId:id,input:[],turnTrigger:'capacity_retry_automatic'});
      if(job.cancelled) {
        // Native goal/set has no compare-and-set or turn receipt. If a user
        // pause races its acknowledgement, reassert that intent only for this
        // same goal, never for a subsequently replaced goal or new instruction.
        const intent = intents.get(id);
        if (resumeGoal && ['pause','stop'].includes(intent?.kind)) {
          const current = (await call('thread/goal/get',{threadId:id})).goal;
          if (intents.get(id) === intent && current?.status === 'active' && goalIdentity(current) === job.goalIdentity) {
            await call('thread/goal/set',{threadId:id,status:'paused',origin:'user'});
          }
        }
        const turnId = result.turn?.id || job.startedTurnId;
        const currentIntent=intents.get(id);
        if(turnId && currentIntent && currentIntent.kind !== 'supersede' && (currentIntent===intent||['pause','stop'].includes(currentIntent.kind)))await call('turn/interrupt',{threadId:id,turnId});
      }
      if(jobs.get(id)===job){cancel(id);if(result.turn?.id)attempts.set(id,job.attempts);}
    } catch(error) {
      if(jobs.get(id)!==job)return;
      if(isModelCapacityError(error)) {job.attempts++;attempts.set(id,job.attempts);job.status='waiting';job.reason='capacity';job.nextRetryAt=clock.now()+capacityDelay(job.attempts);}
      else if(/timed out|timeout|restarted|reconnecting/i.test(error.message)) {job.status='checking';job.reason='receipt';job.nextRetryAt=clock.now()+10000;}
      else if(/active writer|not loaded|writer/i.test(error.message)){job.status='waiting';job.reason='writer';job.nextRetryAt=clock.now()+60000;}
      else {cancel(id,true);return;}
      await save();publish(id);schedule(id);
    } finally {busy.delete(id);coordinator.release(id);}
  }
  return {
    list:()=>[...jobs.values(),...native.values()].map(visible),
    hasWaiting:id=>jobs.has(id)||capturing.has(id)||native.has(id),
    onReady(){for(const id of jobs.keys())schedule(id);},
    onOffline(){for(const timer of timers.values())clock.clear(timer);timers.clear();native.clear();goalPauses.clear();for(const job of jobs.values()){delete job.goalPause;job.allowGoalPause=false;}},
    onEvent(message){
      const p=message.params||{},id=p.threadId||p.thread?.id;
      if(message.method==='account/updated'){for(const id of new Set([...jobs.keys(),...native.keys(),...capturing.keys()]))supersede(id,'stop');goalPauses.clear();return;}
      if(!id)return;
      if(message.method==='error'&&p.willRetry===true&&ended.get(id)!==p.turnId&&suppressed.get(id)!=='*'&&suppressed.get(id)!==p.turnId&&isModelCapacityError(p.error)){native.set(id,{threadId:id,turnId:p.turnId,status:'native',reason:'capacity',nextRetryAt:null});publish(id);}
      if(message.method==='turn/started'&&latest.get(id)!==p.turn?.id){
        const running=busy.get(id);if(running?.resumingGoal)running.startedTurnId=p.turn?.id;
        latest.set(id,p.turn?.id);ended.delete(id);goalPauses.delete(id);if(suppressed.get(id)!==p.turn?.id)suppressed.delete(id);
        cancel(id);if(!running){attempts.delete(id);intents.delete(id);}
      }
      if(message.method==='turn/completed'){
        if(latest.has(id)&&latest.get(id)!==p.turn?.id)return;
        ended.set(id,p.turn?.id);
        native.delete(id);
        if(p.turn?.status==='failed'&&isModelCapacityError(p.turn.error))capture(id,p.turn).catch(()=>{});
        else {cancel(id);attempts.delete(id);}
      }
      if(message.method==='thread/goal/updated'&&p.goal){
        if(typeof p.turnId==='string'&&latest.has(id)&&latest.get(id)!==p.turnId)return;
        if(p.goal.status==='paused') {
          const turnId=p.turnId, job=jobs.get(id);
          // Queue yielding can emit an unlinked pause after it superseded a
          // submitted continuation. It must not interrupt that accepted turn.
          if(!turnId&&busy.has(id)&&intents.get(id)?.kind==='supersede'){cancel(id);return;}
          // A native lifecycle mutation links its originating turn. User/API
          // edits use null; time proximity to a capacity error is not proof.
          if(typeof turnId==='string' && (!latest.has(id)||latest.get(id)===turnId) && suppressed.get(id)!=='*' && suppressed.get(id)!==turnId && !isGoalYielded(id)) {
            const pause={turnId,stamp:goalStamp(p.goal)};goalPauses.set(id,pause);
            while(goalPauses.size>512)goalPauses.delete(goalPauses.keys().next().value);
            if(job?.turnId===turnId&&job.allowGoalPause!==false){job.goalPause=pause;save().catch(()=>{});}
          } else supersede(id,'pause');
        } else if(['complete','usageLimited','budgetLimited'].includes(p.goal.status))supersede(id,'stop');
        else if(!p.turnId&&(jobs.has(id)||capturing.has(id))&&!busy.get(id)?.resumingGoal)supersede(id,'supersede');
      }
      if(['thread/archived','thread/deleted','thread/goal/cleared'].includes(message.method))supersede(id,'clear');
    },
    observeRequest(message){
      const p=message.params||{},method=message.method;
      const pause=method==='bridge/goal/pause'||method==='thread/goal/set'&&p.status==='paused';
      const clear=['thread/archive','thread/delete','bridge/goal/clear','thread/goal/clear'].includes(method);
      if(p.threadId&&(pause||clear||method==='turn/interrupt'||['thread/settings/update','bridge/goal/save','bridge/goal/resume','thread/goal/set','turn/start','thread/queue/start','bridge/queue/add'].includes(method)))supersede(p.threadId,pause?'pause':clear?'clear':method==='turn/interrupt'?'stop':'supersede');
    },
    async handle(method,params={}){if(method==='bridge/retry/list')return{retries:this.list()};if(method!=='bridge/retry/cancel'||typeof params.threadId!=='string')throw Error('재시도할 대화를 확인하세요.');supersede(params.threadId,'stop');await writing;return{cancelled:true};},
    stop(){stopped=true;for(const timer of timers.values())clock.clear(timer);timers.clear();},
    settled:()=>writing
  };
}

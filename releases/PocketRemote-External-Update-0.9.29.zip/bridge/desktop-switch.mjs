import { settingsPath, migrateSettings } from './settings.mjs';
import { readFile, writeFile, rename } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { homedir } from 'node:os';
import { nativeClient } from './native-client.mjs';
import { activityReader, serverIdle, writerLockReader } from './activity.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'), file = resolve(root, '.desktop-switch.json');
const request = JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, ''));
const shared = JSON.parse((await readFile(settingsPath(root, '.shared-server.json'), 'utf8')).replace(/^\uFEFF/, ''));
const pause = ms => new Promise(r => setTimeout(r, ms));
const readActivity = activityReader({ hasWriter: writerLockReader(resolve(process.env.CODEX_HOME || resolve(homedir(), '.codex'), 'thread-writer-locks')) });
async function save(status, extra = {}) {
  Object.assign(request, { status, workerPid: process.pid, updatedAt: new Date().toISOString() }, extra);
  await writeFile(file + '.tmp', JSON.stringify(request), { mode: 0o600 }); await rename(file + '.tmp', file);
}
async function localIdle() {
  for (const [name, waiting] of [['.message-queue.json', x => x.some(e => ['queued','dispatching'].includes(e.status))], ['.goal-runners.json', x => x.version === 2 ? Object.keys(x.holds || {}).length > 0 : Object.values(x).some(e => e.enabled)]]) {
    let data;
    try { data = JSON.parse(await readFile(resolve(root, name), 'utf8')); } catch (e) { if (e.code === 'ENOENT') continue; throw e; }
    if (waiting(data)) return false;
  }
  return true;
}
let client, idleSince = 0;
await save('waiting-for-idle');
try {
  for (;;) {
    if ((JSON.parse(await readFile(file, 'utf8'))).requestedAt !== request.requestedAt) break;
    try {
      client ||= await nativeClient(shared.url, 'pocket_remote_transition');
      if (await localIdle() && await serverIdle(client, readActivity, request.watchedThreads)) {
        idleSince ||= Date.now();
        if (Date.now() - idleSince >= 15000) break;
      } else idleSince = 0;
    } catch { idleSince = 0; client?.close(); client = null; }
    await pause(3000);
  }
  if ((JSON.parse(await readFile(file, 'utf8'))).requestedAt !== request.requestedAt) process.exit(0);
  if (!await localIdle() || !await serverIdle(client, readActivity, request.watchedThreads)) throw new Error('Activity changed before transition');
  await save('applying'); client.close(); client = null;
  await promisify(execFile)(request.shellPath, ['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',resolve(root,'APPLY-SHARED-DESKTOP.ps1')], { windowsHide: true, timeout: 45000 });
  let online = !request.bridgePid;
  const expectedMode = request.action === 'restore' ? 'dedicated' : 'shared';
  const endpoint = JSON.parse((await readFile(settingsPath(root, '.endpoint.json'), 'utf8').catch(() => '{}')).replace(/^\uFEFF/, ''));
  for (let i = 0; i < 60 && !online; i++) {
    await pause(500);
    try { const health = await (await fetch('http://127.0.0.1:' + (endpoint.localPort || 4545) + '/health', { signal: AbortSignal.timeout(1500) })).json(); online = health.online && health.upstream === expectedMode && (!shared.desktopUrl || request.action === 'restore' || health.desktopProxy); } catch {}
  }
  if (!online) throw new Error('Configuration applied but bridge did not reconnect; inspect .host.log');
  await save('applied', { appliedAt: new Date().toISOString(), bridgeShared: !!request.bridgePid && expectedMode === 'shared' });
} catch (error) { await save('failed', { error: error.message }); process.exitCode = 1; }
finally { client?.close(); }

import { readFileSync } from 'node:fs';
import { writeFile, rename } from 'node:fs/promises';
import { resolve } from 'node:path';

export function firstInstructionTitle(input = []) {
  const text = input.filter(x => x.type === 'text').map(x => x.text || '').join(' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[`*_#]+/g, '').replace(/^\s*\/goal\s*/i, '')
    .replace(/\s+/g, ' ').trim();
  if (!text) return input.some(x => ['image', 'localImage', 'file'].includes(x.type)) ? '첨부 파일 작업' : '';
  const characters = [...text];
  return characters.length > 60 ? characters.slice(0, 59).join('') + '…' : text;
}

// Naming is metadata work, never an extra model turn. Native or manually
// assigned names win over the first-instruction fallback.
export function createThreadTitles({ root, call, online }) {
  const path = resolve(root, '.thread-titles.json');
  let records = {}, saving = Promise.resolve(), stopped = false;
  try { records = JSON.parse(readFileSync(path, 'utf8')); } catch {}
  const pending = new Map(), timers = new Map();
  function save() {
    const ids = Object.keys(records);
    for (const id of ids.slice(0, Math.max(0, ids.length - 2000))) if (records[id].status === 'done') delete records[id];
    const content = JSON.stringify(records);
    saving = saving.catch(() => {}).then(async () => { await writeFile(path + '.tmp', content, { mode: 0o600 }); await rename(path + '.tmp', path); });
    return saving;
  }
  function named(id) {
    if (!records[id]) return;
    records[id] = { status: 'done' }; clearTimeout(timers.get(id)); timers.delete(id);
    save().catch(() => {});
  }
  function apply(id) {
    const record = records[id];
    if (stopped || !online() || record?.status !== 'pending' || !record.title || pending.has(id)) return;
    const valid = () => !stopped && online() && records[id] === record && record.status === 'pending';
    const work = (async () => {
      try {
        const { thread } = await call('thread/read', { threadId: id, includeTurns: false });
        if (!valid()) return;
        if (thread?.name?.trim()) { named(id); return; }
        await call('thread/name/set', { threadId: id, name: record.title });
        if (valid()) named(id);
      } catch {
        if (valid() && (record.attempts || 0) < 3) {
          record.attempts = (record.attempts || 0) + 1;
          timers.set(id, setTimeout(() => { timers.delete(id); apply(id); }, 5000));
        }
      }
    })().finally(() => pending.delete(id));
    pending.set(id, work);
  }
  function propose(id, input) {
    const record = records[id];
    if (record?.status !== 'pending' || record.title) return;
    const title = firstInstructionTitle(input); if (!title) return;
    record.title = title;
    save().then(() => apply(id)).catch(() => {});
  }
  return {
    observe(request, response) {
      if (response.error) return;
      const p = request?.params || {};
      if (request?.method === 'thread/start') {
        const thread = response.result?.thread;
        if (!thread?.id || thread.ephemeral || thread.name?.trim()) return;
        records[thread.id] = { status: 'pending' }; save().catch(() => {});
      } else if (request?.method === 'turn/start') propose(p.threadId, p.input || []);
      else if (request?.method === 'thread/goal/set' && p.objective) propose(p.threadId, [{ type: 'text', text: p.objective }]);
    },
    onRequest(message) { if (message.method === 'thread/name/set') named(message.params?.threadId); },
    onEvent(message) {
      const p = message.params || {};
      if (message.method === 'thread/name/updated' && (p.threadName || p.name)) named(p.threadId);
      if (message.method === 'item/started' && p.item?.type === 'userMessage') propose(p.threadId, p.item.content || []);
    },
    onReady() { for (const id of Object.keys(records)) apply(id); },
    stop() { stopped = true; for (const timer of timers.values()) clearTimeout(timer); timers.clear(); }
  };
}

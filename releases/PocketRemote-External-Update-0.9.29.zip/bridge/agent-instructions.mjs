import {open,stat} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {agentParent,subagentSource} from './thread-source.mjs';

const marker=Buffer.from('"agent_message"'),MAX_LINE=1024*1024;
const millis=value=>{const n=typeof value==='number'||/^\d+(?:\.\d+)?$/.test(String(value))?Number(value):Date.parse(value);return Number.isFinite(n)&&n>0?(n<1e11?n*1000:n):0;};
export function agentInstruction(item,thread,timestamp){
 const path=subagentSource(thread)?.thread_spawn?.agent_path,parent=path?.slice(0,path.lastIndexOf('/'));
 if(item?.type!=='agent_message'||!path||!agentParent(thread)||item.recipient!==path||![parent,'/root'].includes(item.author))return null;
 const at=millis(timestamp);if(!at||at+1000<millis(thread.createdAt))return null;
 const text=(item.content||[]).filter(p=>p.type==='input_text'&&typeof p.text==='string').map(p=>p.text).join('\n');
 if(!text||Buffer.byteLength(text)>256*1024||typeof item.id!=='string')return null;
 return {turnId:item.internal_chat_message_metadata_passthrough?.turn_id||'',startedAtMs:at,completedAtMs:at,item:{id:item.id,type:'agentInstruction',text,sender:item.author==='/root'?'루트':item.author.split('/').at(-1).replace(/[_-]+/g,' '),source:'parentAgent'}};
}
// Scan only explicitly typed, public inter-agent input. Never interpret message
// roles, compaction summaries, raw reasoning or encrypted content as instructions.
async function scan(path,start,end,receive,skipFirst=false,valid=()=>true){
 if(end<start)return start;
 let carry=Buffer.alloc(0),dropping=skipFirst,position=start,complete=start;
 for await(const chunk of createReadStream(path,{start,end,highWaterMark:256*1024})){
  if(!valid())break;
  const bytes=carry.length?Buffer.concat([carry,chunk]):chunk,base=position-carry.length;let from=0,to;
  while((to=bytes.indexOf(10,from))>=0){
   const line=bytes.subarray(from,to);
   if(!dropping&&line.length<=MAX_LINE&&line.includes(marker))try{const row=JSON.parse(line.toString('utf8'));if(row.type==='response_item')receive(row.payload,row.timestamp);}catch{}
   dropping=false;from=to+1;complete=base+from;
  }
  carry=bytes.subarray(from);if(carry.length>MAX_LINE){carry=Buffer.alloc(0);dropping=true;}
  position+=chunk.length;
 }
 return complete;
}
export function createAgentInstructions({changed=()=>{}}={}){
 const records=new Map(),pending=new Map();let generation=0,closed=false;
 function trim(r){
  while(r.items.size>5000||r.bytes>4*1024*1024){const id=r.items.keys().next().value;r.bytes-=r.items.get(id).bytes;r.items.delete(id);}
  while(records.size>16||[...records.values()].reduce((n,v)=>n+v.bytes,0)>8*1024*1024){const id=records.keys().next().value;if(id===r.thread.id&&records.size===1)break;records.delete(id);}
 }
 function receive(r,item,at){const entry=agentInstruction(item,r.thread,at);if(!entry)return;const text=JSON.stringify(entry),old=r.items.get(entry.item.id);if(old?.text===text)return;r.bytes-=old?.bytes||0;r.items.set(entry.item.id,{entry,text,bytes:Buffer.byteLength(text)});r.bytes+=Buffer.byteLength(text);trim(r);}
 async function verified(thread){
  if(!thread.path?.endsWith('.jsonl')||!subagentSource(thread)?.thread_spawn?.agent_path)return null;
  const handle=await open(thread.path,'r');try{
   const bytes=Buffer.alloc(256*1024),read=await handle.read(bytes,0,bytes.length,0),end=bytes.indexOf(10,0);
   if(end<0||end>=read.bytesRead)return null;
   const first=JSON.parse(bytes.subarray(0,end).toString('utf8'));
   if(first.type!=='session_meta'||first.payload?.id!==thread.id||subagentSource({source:first.payload?.source})?.thread_spawn?.agent_path!==subagentSource(thread).thread_spawn.agent_path)return null;
   return await handle.stat();
  }finally{await handle.close();}
 }
 async function read(thread){
  if(closed)return{instructions:[],loading:false};
  if(pending.has(thread.id))return pending.get(thread.id);
  const epoch=generation,work=(async()=>{
   let r=records.get(thread.id),s;
   try{
    s=await stat(thread.path);
    if(!r||r.path!==thread.path||r.birth!==s.birthtimeMs||s.size<r.offset){
     s=await verified(thread);if(!s||epoch!==generation||closed)return{instructions:[],loading:false};
     r={thread,path:thread.path,birth:s.birthtimeMs,offset:0,items:new Map(),bytes:0,loading:true};records.set(thread.id,r);
     r.offset=await scan(r.path,Math.max(0,s.size-1024*1024),s.size-1,(i,t)=>receive(r,i,t),s.size>1024*1024);
     const record=r,end=s.size-1;
     // Show the recent tail first; build the small text index asynchronously.
     r.fullScan=scan(r.path,0,end,(i,t)=>{if(epoch===generation&&records.get(thread.id)===record)receive(record,i,t);},false,()=>epoch===generation&&records.get(thread.id)===record&&!closed).then(()=>{
      if(epoch===generation&&records.get(thread.id)===record){record.loading=false;changed(thread.id);}
     }).catch(()=>{record.loading=false;}).finally(()=>{record.fullScan=null;});
    }else if(s.size>r.offset){r.offset=await scan(r.path,r.offset,s.size-1,(i,t)=>receive(r,i,t));}
    if(epoch!==generation||closed)return{instructions:[],loading:false};
    return{instructions:[...r.items.values()].map(x=>x.entry).sort((a,b)=>a.startedAtMs-b.startedAtMs||a.item.id.localeCompare(b.item.id)),loading:r.loading};
   }catch{return{instructions:[],loading:false,unavailable:true};}
  })().finally(()=>{if(pending.get(thread.id)===work)pending.delete(thread.id);});
  pending.set(thread.id,work);return work;
 }
 return{
  read,
  observe(threadId,item,timestamp){const r=records.get(threadId);if(r){receive(r,item,timestamp);changed(threadId);}},
  reset(){generation++;records.clear();pending.clear();},
  close(){closed=true;this.reset();}
 };
}

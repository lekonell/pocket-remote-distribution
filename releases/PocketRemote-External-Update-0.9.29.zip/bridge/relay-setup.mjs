import { settingsPath, migrateSettings } from './settings.mjs';
import { spawn } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { readFile, writeFile, rename, mkdir, stat } from 'node:fs/promises';
import { homedir } from 'node:os';
import { resolve, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

async function run(executable, args, timeout = 15000) {
  return new Promise((accept, reject) => {
    const child = spawn(executable, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '', error = '', settled = false;
    const finish = (failure, value) => { if (settled) return; settled = true; clearTimeout(timer); failure ? reject(failure) : accept(value); };
    const timer = setTimeout(() => { child.kill(); finish(Error('SSH 응답 시간이 초과되었습니다.')); }, timeout);
    child.stdout.on('data', b => { output += b; if (output.length > 65536) child.kill(); });
    child.stderr.on('data', b => { error = (error + b).slice(-4000); });
    child.on('error', () => finish(Error('Windows OpenSSH 클라이언트를 설치하세요.')));
    child.on('close', code => finish(null, { code, output, error }));
  });
}
export function relayInput(input) {
  const sshHost = String(input.sshHost || '').trim(), domain = String(input.domain || '').trim().toLowerCase();
  const sshPort = Number(input.sshPort || 22), identityFile = String(input.identityFile || '').trim();
  const nginxSnippet = String(input.nginxSnippet || '').trim();
  if (!/^[A-Za-z0-9][A-Za-z0-9_.@-]{0,200}$/.test(sshHost)) throw Error('SSH 별칭 또는 user@host를 입력하세요.');
  if (!Number.isInteger(sshPort) || sshPort < 1 || sshPort > 65535) throw Error('SSH 포트를 확인하세요.');
  if (!/^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$/.test(domain) || domain.includes('..')) throw Error('TLS 인증서가 설정된 서버 도메인을 입력하세요.');
  if (!/^\/etc\/nginx\/(snippets|sites-available)\/[A-Za-z0-9_.-]+$/.test(nginxSnippet)) throw Error('기존 Nginx TLS 서버의 설정 파일을 지정하세요.');
  if (identityFile && (!isAbsolute(identityFile) || /[\x00-\x1f"]/.test(identityFile))) throw Error('SSH 키 파일의 전체 경로를 선택하세요.');
  return { sshHost, sshPort, identityFile, domain, nginxSnippet, sudo: input.sudo === true };
}
export function adminArgs(input, interactive = false) {
  const v = relayInput(input);
  const args = ['-p', String(v.sshPort), '-o', 'ConnectTimeout=10', '-o', 'ServerAliveInterval=10', '-o', 'ServerAliveCountMax=2'];
  if (!interactive) args.push('-o', 'BatchMode=yes');
  if (v.identityFile) args.push('-i', v.identityFile, '-o', 'IdentitiesOnly=yes');
  return [...args, v.sshHost];
}
export async function discoverSSH() {
  const aliases = new Set(), keyFiles = [], directory = resolve(homedir(), '.ssh');
  try {
    const config = await readFile(resolve(directory, 'config'), 'utf8');
    for (const line of config.split(/\r?\n/)) {
      const match = line.match(/^\s*Host\s+(.+)$/i);
      if (match) for (const alias of match[1].split(/\s+/)) if (/^[A-Za-z0-9][A-Za-z0-9_.-]{0,100}$/.test(alias)) aliases.add(alias);
    }
  } catch {}
  for (const name of ['id_ed25519', 'id_rsa', 'id_ecdsa']) try { const path = resolve(directory, name); if ((await stat(path)).isFile()) keyFiles.push(path); } catch {}
  const profiles = [];
  for (const alias of [...aliases].slice(0, 32)) {
    const result = await run('ssh', ['-G', alias]).catch(() => null);
    if (!result || result.code) continue;
    const fields = Object.fromEntries(result.output.split(/\r?\n/).map(line => { const at = line.indexOf(' '); return [line.slice(0, at), line.slice(at + 1)]; }));
    profiles.push({ alias, hostname: fields.hostname, user: fields.user, port: Number(fields.port) || 22 });
  }
  return { profiles, keyFiles }; // Never read private key bytes or auth files.
}
async function identity(root) {
  const path = settingsPath(root, '.relay.json');
  let value; try { value = JSON.parse(await readFile(path, 'utf8')); } catch {}
  const keyFile = settingsPath(root, '.relay-tunnel.key');
  if (!value) {
    await mkdir(root, { recursive: true });
    if ((await stat(keyFile).catch(() => null))?.isFile()) {
      if (!(await stat(keyFile + '.pub').catch(() => null))?.isFile()) throw Error('기존 터널 키의 공개 키 파일이 없습니다. 기존 개인 키를 덮어쓰지 않습니다.');
    } else {
      const generated = await run('ssh-keygen', ['-q', '-t', 'ed25519', '-N', '', '-C', 'PocketRemote-tunnel', '-f', keyFile]);
      if (generated.code) throw Error('전용 SSH 키 생성에 실패했습니다. 기존 키를 지우지 말고 설정을 확인하세요.');
    }
    if (process.platform === 'win32') {
      const principal = `${process.env.USERDOMAIN}\\${process.env.USERNAME}`;
      const acl = await run('icacls', [keyFile, '/inheritance:r', '/grant:r', `${principal}:(F)`]);
      if (acl.code) throw Error('SSH 키를 현재 Windows 사용자로 보호하지 못했습니다.');
    }
    value = { id: 'pc-' + randomBytes(12).toString('hex') };
    await writeFile(path, JSON.stringify(value), { mode: 0o600 });
  }
  const publicKey = (await readFile(keyFile + '.pub', 'utf8')).trim().split(/\s+/).slice(0, 2).join(' ');
  return { ...value, keyFile, publicKey };
}
export async function prepareRelay(root, input) {
  const v = relayInput(input), device = await identity(root);
  if (v.identityFile && !(await stat(v.identityFile)).isFile()) throw Error('SSH 키 파일이 없습니다.');
  const request = { id: device.id, domain: v.domain, publicKey: device.publicKey, nginxSnippet: v.nginxSnippet };
  if (input.adoptPort !== undefined) request.adoptPort = Number(input.adoptPort);
  const source = await readFile(new URL('./relay-server.py', import.meta.url));
  const program = `import base64;_installer_source=base64.b64decode('${source.toString('base64')}');exec(compile(_installer_source,'<pocket-remote-relay>','exec'))`;
  const encoded = Buffer.from(JSON.stringify(request)).toString('base64');
  const command = v.sudo ? `sudo -n /usr/local/sbin/pocket-remote-provision '${encoded}'` : `python3 -c "${program}" '${encoded}'`;
  return { ...device, admin: v, args: [...adminArgs(v), command], interactiveArgs: [...adminArgs(v, true), command] };
}
export function relayResponse(result, id, domain) {
  const r = result, canonicalUrl = `wss://${domain}/codex-remote/${id}/socket`;
  const short = r?.addressCode && /^[A-HJ-NP-Z2-9]{8}$/.test(r.addressCode);
  const expected = short ? `wss://${domain}/r/${r.addressCode.toLowerCase()}/socket` : canonicalUrl;
  if (!r || r.id !== id || r.domain !== domain || (r.addressCode && !short) || r.websocketUrl !== expected || (r.canonicalUrl && r.canonicalUrl !== canonicalUrl) || r.sshUser !== 'pocketremote' || !Number.isInteger(r.reversePort) || r.reversePort < 1024 || r.reversePort > 65535) throw Error('서버의 연결 정보가 요청과 다릅니다.');
  return { ...r, canonicalUrl, addressCode: short ? r.addressCode : '' };
}
export async function finishRelay(root, prepared, text) {
  let result; try { result = JSON.parse(text.trim().replace(/^\uFEFF/, '')); } catch { throw Error('서버 구성 응답을 읽지 못했습니다. Python 3·Nginx·관리자 권한을 확인하세요.'); }
  if (!result.ok) throw Error(result.error || '서버 설정을 적용하지 못했습니다.');
  const v = prepared.admin, r = relayResponse(result.result, prepared.id, v.domain);
  const resolved = await run('ssh', ['-G', ...adminArgs(v)]);
  const hostname = resolved.output.match(/^hostname (.+)$/m)?.[1]?.trim();
  if (!hostname || !/^[A-Za-z0-9][A-Za-z0-9_.-]{0,200}$/.test(hostname)) throw Error('SSH 서버 주소를 확인할 수 없습니다.');
  const fields = { websocketUrl: r.websocketUrl, canonicalUrl: r.canonicalUrl, addressCode: r.addressCode, sshHost: `${r.sshUser}@${hostname}`, sshPort: v.sshPort, sshIdentityFile: prepared.keyFile, reversePort: r.reversePort, relayId: prepared.id };
  // Save the result for reuse, but Apply remains the point that changes the running host.
  const path = settingsPath(root, '.relay.json');
  await writeFile(path + '.tmp', JSON.stringify({ id: prepared.id, ...fields, admin: v }), { mode: 0o600 }); await rename(path + '.tmp', path);
  return { ...fields, message: '서버에 PC 전용 WSS 경로를 구성했습니다. 다음 단계에서 PC 연결에 적용하세요.' };
}
export async function provisionRelay(root, input) {
  const prepared = await prepareRelay(root, input);
  const result = await run('ssh', prepared.args, 90000);
  if (result.code && !result.output.trim().startsWith('{')) return { loginRequired: true, message: '저장된 SSH 인증으로 연결하지 못했습니다. SSH 로그인으로 진행하거나 관리자 키를 선택하세요.' };
  return finishRelay(root, prepared, result.output);
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    let text = ''; for await (const chunk of process.stdin) { text += chunk; if (text.length > 16384) throw Error('설정 입력이 너무 큽니다.'); }
    const input = text.trim() ? JSON.parse(text.replace(/^\uFEFF/, '')) : {};
    const root = process.cwd(); migrateSettings(root);
    const result = process.argv[2] === 'discover' ? await discoverSSH() : process.argv[2] === 'prepare' ? await prepareRelay(root, input) : process.argv[2] === 'finish' ? await finishRelay(root, input.prepared, input.output) : await provisionRelay(root, input);
    console.log(JSON.stringify({ ok: true, result }));
  } catch (error) { console.log(JSON.stringify({ ok: false, error: error.message })); process.exitCode = 1; }
}

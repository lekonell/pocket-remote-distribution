// Observe accepted native settings without retaining input or credentials.
// One observer is shared by the desktop proxy and the mobile RPC transport.
export function createExecutionTracker({ capture }) {
  const settings = new Map(), goals = new Map(), turns = new Map(), pending = new Map();
  let revision = 0;
  const tracked = new Set(['thread/start', 'thread/resume', 'thread/fork', 'thread/settings/update', 'thread/goal/get', 'thread/goal/set', 'thread/goal/clear', 'thread/queue/start', 'turn/start', 'turn/settings/update']);
  const key = (peer, id) => JSON.stringify([peer, id]);
  function put(map, id, value) { map.delete(id); map.set(id, value); while (map.size > 512) map.delete(map.keys().next().value); }
  function selected(value = {}) {
    const result = {};
    if (typeof value.model === 'string' && value.model) result.model = value.model;
    else if (typeof value.collaborationMode?.settings?.model === 'string') result.model = value.collaborationMode.settings.model;
    for (const field of ['serviceTier', 'serviceTierForTurn']) if (Object.hasOwn(value, field) && (value[field] === null || typeof value[field] === 'string')) result[field] = value[field];
    return result;
  }
  function defaults(id, value) {
    const next = { ...settings.get(id), ...selected(value) };
    delete next.serviceTierForTurn;
    put(settings, id, { ...next, revision: ++revision });
  }
  function publish(id, turnId, value) {
    const previous = turns.get(id), same = previous?.id === turnId ? previous.execution : null;
    const execution = { ...same, ...value };
    put(turns, id, { id: turnId, execution });
    if (!same || JSON.stringify(same) !== JSON.stringify(execution)) capture(id, turnId, execution);
  }
  function startSettings(base, chosen = {}) {
    const value = {};
    if (chosen.model || base?.model) value.model = chosen.model || base.model;
    // Per-turn null means inherit. Thread null explicitly clears the tier.
    const tier = chosen.serviceTierForTurn ?? (Object.hasOwn(chosen, 'serviceTier') ? chosen.serviceTier : base?.serviceTier);
    if (tier !== undefined) value.serviceTierForTurn = tier === null ? 'default' : tier;
    return value;
  }
  return {
    request(peer, message) {
      if (message.id === undefined || !tracked.has(message.method)) return;
      const p = message.params || {};
      pending.set(key(peer, message.id), { peer, method: message.method, threadId: p.threadId, turnId: p.turnId, status: p.status, selected: selected(p), inherited: { ...settings.get(p.threadId) }, goalRevision: goals.get(p.threadId)?.revision, previousTurn: turns.get(p.threadId)?.id });
      if (pending.size > 1024) throw Error('Too many pending settings requests');
    },
    cancel(peer, id) { pending.delete(key(peer, id)); },
    disconnect(peer) {
      for (const [id, request] of pending) if (request.peer === peer) pending.delete(id);
      // Defaults may have changed while a transport was unavailable.
      settings.clear(); goals.clear();
    },
    receive(peer, message) {
      const p = message.params || {}, id = p.threadId;
      if (message.method === 'thread/settings/updated' && id) defaults(id, p.threadSettings);
      if (message.method === 'thread/goal/updated' && id) put(goals, id, { active: p.goal?.status === 'active', revision: ++revision });
      if (message.method === 'thread/goal/cleared' && id) put(goals, id, { active: false, revision: ++revision });
      if (message.method === 'turn/started' && id && p.turn?.id) {
        if (turns.get(id)?.id === p.turn.id) return;
        put(turns, id, { id: p.turn.id });
        const requests = [...pending.values()].filter(r => r.threadId === id);
        if (requests.some(r => ['turn/start', 'thread/queue/start'].includes(r.method))) return;
        const goalStart = requests.find(r => r.method === 'thread/goal/set' && r.status !== 'paused');
        // A goal continuation inherits defaults at this new turn's start,
        // never defaults changed later during that turn.
        if (goals.get(id)?.active || goalStart) publish(id, p.turn.id, startSettings(goalStart?.inherited || settings.get(id)));
      }
      if (message.method || message.id === undefined) return;
      const request = pending.get(key(peer, message.id));
      if (!request) return;
      pending.delete(key(peer, message.id));
      if (message.error) return;
      const r = message.result || {}, canonical = ['thread/start', 'thread/resume', 'thread/fork'].includes(request.method);
      const threadId = canonical ? r.thread?.id || request.threadId : request.threadId || r.thread?.id;
      if (!threadId) return;
      const defaultsCurrent = canonical && threadId !== request.threadId ? !settings.has(threadId) : settings.get(threadId)?.revision === request.inherited.revision;
      if (defaultsCurrent && ['thread/start', 'thread/resume', 'thread/fork', 'thread/settings/update'].includes(request.method)) defaults(threadId, { ...request.selected, ...selected(r.threadSettings || r) });
      if (goals.get(threadId)?.revision === request.goalRevision && ['thread/goal/get', 'thread/goal/set', 'thread/goal/clear'].includes(request.method)) put(goals, threadId, { active: r.goal?.status === 'active', revision: ++revision });
      if (['turn/start', 'thread/queue/start'].includes(request.method) && r.turn?.id && request.previousTurn !== r.turn.id) {
        const current = turns.get(threadId)?.id;
        if (!current || current === request.previousTurn || current === r.turn.id) publish(threadId, r.turn.id, startSettings(request.inherited, request.selected));
      }
      if (defaultsCurrent && request.method === 'turn/start') defaults(threadId, request.selected);
      if (request.method === 'turn/settings/update' && r.status === 'applied' && request.turnId && (!turns.get(threadId) || turns.get(threadId).id === request.turnId)) {
        const changed = {};
        if (request.selected.model) changed.model = request.selected.model;
        if (Object.hasOwn(request.selected, 'serviceTier')) changed.serviceTierForTurn = request.selected.serviceTier ?? 'default';
        if (Object.keys(changed).length) publish(threadId, request.turnId, changed);
      }
    }
  };
}

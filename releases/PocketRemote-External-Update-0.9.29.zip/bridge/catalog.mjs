export async function loadCatalog(call, { cwd, threadId } = {}) {
  const entries = await Promise.allSettled([
    call('plugin/installed', { ...(cwd ? { cwds: [cwd] } : {}) }),
    call('skills/list', { ...(cwd ? { cwds: [cwd] } : {}) }),
    call('app/list', { limit: 100, ...(threadId ? { threadId } : {}) }),
    call('app/installed', { ...(threadId ? { threadId } : {}) })
  ]);
  const warnings = [];
  function result(index, title) {
    if (entries[index].status === 'fulfilled') return entries[index].value;
    warnings.push(title + ' 목록을 읽지 못했습니다.'); return {};
  }
  const installed = result(0, '플러그인');
  const skillList = result(1, '스킬');
  const appList = result(2, '앱');
  const appRuntime = result(3, '앱 연결');
  const skills = (skillList.data || []).flatMap(group => group.skills || []).map(s => ({ kind: 'skill', name: s.name, label: s.interface?.displayName || s.name, description: s.interface?.shortDescription || s.shortDescription || s.description, path: s.path, pluginId: s.pluginId, enabled: s.enabled }));
  const plugins = (installed.marketplaces || []).flatMap(m => (m.plugins || []).filter(p => p.installed).map(p => ({ kind: 'plugin', id: p.id, name: p.name, label: p.interface?.displayName || p.name, description: p.interface?.shortDescription || '', enabled: p.enabled && p.availability !== 'DISABLED_BY_ADMIN', skills: skills.filter(s => s.pluginId === p.id) })));
  const runtime = new Map((appRuntime.apps || []).map(app => [app.id, app]));
  const apps = (appList.data || []).filter(app => app.isAccessible).map(app => ({ kind: 'app', id: app.id, name: app.name, label: app.name, description: app.description || '', path: 'app://' + app.id, enabled: app.isEnabled && runtime.get(app.id)?.callable === true }));
  return { plugins, skills, apps, warnings };
}

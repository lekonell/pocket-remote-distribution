// Release operator utility. The private key stays on the build PC, outside Git.
import { readFile, writeFile } from 'node:fs/promises';
import { createHash, sign, createPublicKey } from 'node:crypto';
import { resolve } from 'node:path';
import { updatePublicKey } from './update-key.mjs';
import { verifyRelease } from './pc-updates.mjs';

const [archive, metadata, output] = process.argv.slice(2);
if (!output) throw Error('Usage: node bridge/sign-update.mjs archive metadata output');
const privateKey = await readFile(process.env.PC_UPDATE_SIGNING_KEY || resolve('.pc-update-signing.key'));
if (createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }) !== updatePublicKey) throw Error('Signing key differs from the client pinned key');
const release = JSON.parse((await readFile(metadata, 'utf8')).replace(/^\uFEFF/, ''));
const bytes = await readFile(archive);
if (release.bytes !== bytes.length || release.sha256 !== createHash('sha256').update(bytes).digest('hex')) throw Error('Archive differs from update metadata');
const envelope = { release, signature: sign(null, Buffer.from(JSON.stringify(release)), privateKey).toString('base64') };
verifyRelease(envelope);
await writeFile(output, JSON.stringify(envelope, null, 2) + '\n');
console.log(JSON.stringify({ version: release.version, files: Object.keys(release.files).length, signed: true }));

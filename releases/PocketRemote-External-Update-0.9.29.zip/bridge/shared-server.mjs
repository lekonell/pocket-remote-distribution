import { settingsPath, migrateSettings } from './settings.mjs';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile, writeFile, rename, unlink, readdir, stat } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import net from 'node:net';
import { sharedUrl, instantSteeringArgs } from './upstream.mjs';
import { nativeClient } from './native-client.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const config = JSON.parse((await readFile(settingsPath(root, '.shared-server.json'), 'utf8')).replace(/^\uFEFF/, ''));
if (!config.prepared && !config.enabled) process.exit(0);
const url = sharedUrl(config.url), address = new URL(url);
const lockFile = resolve(root, '.shared-server.lock'), record = resolve(root, '.shared-server-runtime.json');
const lockValue = JSON.stringify({ pid: process.pid, nonce: randomUUID() });
let child, stopping = false;
const pause = ms => new Promise(r => setTimeout(r, ms));
async function save(status, extra = {}) {
  await writeFile(record + '.tmp', JSON.stringify({ managerPid: process.pid, nativePid: child?.pid || null, url, status, updatedAt: new Date().toISOString(), ...extra }), { mode: 0o600 });
  await rename(record + '.tmp', record);
}
async function takeLock() {
  for (let i = 0; i < 2; i++) {
    try { await writeFile(lockFile, lockValue, { flag: 'wx', mode: 0o600 }); return; }
    catch (error) {
      if (error.code !== 'EEXIST') throw error;
      const old = JSON.parse(await readFile(lockFile, 'utf8'));
      try { process.kill(old.pid, 0); throw new Error('Shared server manager is already running'); }
      catch (error) { if (error.code !== 'ESRCH') throw error; }
      await unlink(lockFile);
    }
  }
  throw new Error('Shared server lock could not be acquired');
}
async function binary() {
  if (process.env.CODEX_BIN) return resolve(process.env.CODEX_BIN);
  const directory = resolve(process.env.LOCALAPPDATA, 'OpenAI/Codex/bin'), candidates = [];
  for (const name of await readdir(directory)) {
    const path = resolve(directory, name, 'codex.exe');
    try { candidates.push({ path, time: (await stat(path)).mtimeMs }); } catch {}
  }
  candidates.sort((a, b) => b.time - a.time);
  if (!candidates.length) throw new Error('Install and sign in to the official Codex desktop app first');
  return candidates[0].path;
}
async function portAvailable() {
  const probe = net.createServer();
  await new Promise((res, rej) => { probe.once('error', rej); probe.listen(Number(address.port), address.hostname.replace(/[[\]]/g, ''), res); });
  await new Promise(r => probe.close(r));
}
function stop() { stopping = true; child?.kill(); }
process.on('SIGTERM', stop); process.on('SIGINT', stop);
await takeLock();
try {
  while (!stopping) {
    let executable, version;
    try {
      await portAvailable(); // Never adopt a listener with unknown ownership.
      executable = await binary();
      version = (await promisify(execFile)(executable, ['--version'], { windowsHide: true, timeout: 10000 })).stdout.trim();
      const steeringFlags = await instantSteeringArgs(executable);
      child = spawn(executable, [...steeringFlags, '-c', 'features.code_mode_host=true', '-c', 'plugins.codex-app-tools@openai-bundled.mcp_servers.codex_app.enabled=true', 'app-server', '--analytics-default-enabled', '--listen', url], {
        cwd: root, windowsHide: true, stdio: ['ignore', 'ignore', 'ignore'],
        env: { ...process.env, CODEX_INTERNAL_ORIGINATOR_OVERRIDE: 'codex_desktop' }
      });
      const exited = new Promise(r => { child.once('error', r); child.once('close', r); });
      await save('starting', { executable, version });
      let connected = false;
      for (let i = 0; i < 40 && !stopping && child.exitCode === null; i++) {
        try { const c = await nativeClient(url); c.close(); connected = true; break; } catch { await pause(250); }
      }
      if (connected) await save('ready', { executable, version });
      else { child.kill(); throw new Error('Shared App Server did not initialize'); }
      await exited;
      if (!stopping) await save('reconnecting', { executable, version });
    } catch (error) {
      if (child?.exitCode === null) child.kill();
      if (!stopping) await save('error', { error: error.code === 'EADDRINUSE' ? 'Port is occupied by another process; choose another port.' : error.message });
    }
    if (!stopping) await pause(2000);
  }
} finally {
  child?.kill();
  await save('stopped');
  if (await readFile(lockFile, 'utf8').catch(() => '') === lockValue) await unlink(lockFile);
}

@echo off
if not exist "%~dp0.endpoint.json" (
    if exist "%~dp0PocketRemoteSetup.exe" start "" "%~dp0PocketRemoteSetup.exe"
    exit /b 0
)
rem Prefer double-clicking PocketRemoteHost.exe: it never creates a console.
if not exist "%~dp0PocketRemoteHost.exe" powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0BUILD-LAUNCHER.ps1" >nul 2>nul
if not exist "%~dp0PocketRemoteHost.exe" exit /b 1
start "" "%~dp0PocketRemoteHost.exe"
exit /b 0

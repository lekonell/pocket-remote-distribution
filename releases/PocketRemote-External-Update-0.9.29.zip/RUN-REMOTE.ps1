﻿param([switch]$Quiet, [string]$NodePath = 'node.exe')
. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (Test-Path -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint-secret')) {
    $protected = Get-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint-secret') -Raw
    $secure = ConvertTo-SecureString $protected
    $credential = [System.Net.NetworkCredential]::new('', $secure)
    $profile = Get-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint.json') -Raw | ConvertFrom-Json
    if ($profile.provider -eq 'ngrok') { $env:NGROK_AUTHTOKEN = $credential.Password }
    if ($profile.provider -eq 'cloudflare') { $env:TUNNEL_TOKEN = $credential.Password }
}
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class RemotePower {
    [DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint flags);
}
'@
[RemotePower]::SetThreadExecutionState([uint32]2147483649) | Out-Null
$hostExitCode = 0
try {
    if ($Quiet) { & $NodePath '.\bridge\host.mjs' --quiet } else { & $NodePath '.\bridge\host.mjs' }
    $hostExitCode = $LASTEXITCODE
} finally { [RemotePower]::SetThreadExecutionState([uint32]2147483648) | Out-Null }
exit $hostExitCode

﻿param([ValidateSet('Check','Apply','Start','Pair','Test','InstallNode','Firewall','UpdateExisting','RelayDiscover','RelayProvision','RelayLogin')][string]$Action = 'Check', [switch]$HostOnly)
. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
$ErrorActionPreference = 'Stop'
$OutputEncoding = [Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = [Text.UTF8Encoding]::new($false)
Set-Location -LiteralPath $PSScriptRoot
. (Join-Path $PSScriptRoot 'bridge\setup-host.ps1')
. (Join-Path $PSScriptRoot 'bridge\setup-update.ps1')
function Read-Json($name) { $path = if ($name -in $PocketSettingsFiles) { Get-PocketSetting $PSScriptRoot $name } else { Join-Path $PSScriptRoot $name }; if (Test-Path -LiteralPath $path) { return Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json }; return $null }
function Find-Node {
    $bundled = Join-Path $PSScriptRoot 'tools\node.exe'
    if (Test-Path -LiteralPath $bundled) { return $bundled }
    $found = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($found) { return $found.Source }
    $candidate = Join-Path $env:ProgramFiles 'nodejs\node.exe'
    if (Test-Path -LiteralPath $candidate) { return $candidate }
    return $null
}
function Save-Json($name, $value) {
    $path = Get-PocketSetting $PSScriptRoot $name
    [IO.File]::WriteAllText($path + '.tmp', ($value | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath ($path + '.tmp') -Destination $path -Force
}
function Local-Health($port) {
    try { return Invoke-RestMethod -Uri ('http://127.0.0.1:' + $port + '/health') -TimeoutSec 2 } catch { return $null }
}
function Invoke-RelaySetup([string]$operation, $values) {
    if (!$node) { throw 'Node.js를 먼저 설치하세요.' }
    $text = if ($values) { $values | ConvertTo-Json -Depth 12 -Compress } else { '{}' }
    $reply = ($text | & $node (Join-Path $PSScriptRoot 'bridge\relay-setup.mjs') $operation) | ConvertFrom-Json
    if (!$reply.ok) { throw $reply.error }
    return $reply.result
}
function Assert-Owned-Port($port) {
    $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
    foreach ($listener in $listeners) {
        $process = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $listener.OwningProcess)
        if (!$process -or $process.Name -ne 'node.exe' -or !(Test-SetupScript $process (Join-Path $PSScriptRoot 'bridge\server.mjs'))) { throw '이 포트는 다른 프로그램이 사용 중입니다. 다른 브리지 포트를 선택하세요.' }
    }
}
function Start-ConfiguredHost($hostPort, $nodePath) {
    Assert-Owned-Port $hostPort
    if (!(Local-Health $hostPort)) {
        if (!$nodePath) { throw 'Node.js를 먼저 설치하세요.' }
        $shell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        Save-Json '.launcher.json' @{ shellPath=$shell; nodePath=$nodePath }
        Start-Process -FilePath (Join-Path $PSScriptRoot 'PocketRemoteHost.exe') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden | Out-Null
    }
    $startupWatch = [Diagnostics.Stopwatch]::StartNew()
    do {
        if (Local-Health $hostPort) {
            Assert-Owned-Port $hostPort
            Start-Sleep -Milliseconds 150
            if (Local-Health $hostPort) { return }
        }
        Start-Sleep -Milliseconds 250
    } while ($startupWatch.Elapsed.TotalSeconds -lt 15)
    throw '호스트가 시작되지 않았습니다. 포트와 필수 프로그램을 확인하세요.'
}
try {
    $node = Find-Node
    $inputData = if ($Action -in @('Apply','Test','Firewall','UpdateExisting','RelayProvision','RelayLogin')) { [Console]::In.ReadToEnd() | ConvertFrom-Json } else { $null }
    $endpoint = Read-Json '.endpoint.json'
    $port = if ($endpoint.localPort) { [int]$endpoint.localPort } else { 4545 }
    $result = @{}
    if ($Action -eq 'Check') {
        $package = Get-AppxPackage -Name 'OpenAI.Codex' | Select-Object -First 1
        $version = if ($node) { (& $node --version 2>$null | Out-String).Trim() } else { '' }
        $addresses = @(Get-NetIPAddress -ErrorAction SilentlyContinue | Where-Object { $_.AddressState -eq 'Preferred' -and $_.IPAddress -notmatch '^(127\.|169\.254\.|::1$|fe80:)' } | ForEach-Object { @{ address=$_.IPAddress; interface=$_.InterfaceAlias } })
        $shared = Read-Json '.shared-server.json'; $transition = Read-Json '.desktop-switch.json'
        $setup = Read-Json '.setup.json'; $health = Local-Health $port
        $installedRoot = Find-ExistingPCInstall $PSScriptRoot
        $runtime = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
        $cli = @(Get-ChildItem -LiteralPath $runtime -Filter codex.exe -Recurse -ErrorAction SilentlyContinue).Count -gt 0
        $task = Get-ScheduledTask -TaskName PocketRemoteExternal -ErrorAction SilentlyContinue
        $result = @{ node=[bool]$node; nodeVersion=$version; nodeSupported=($version -match '^v(2[0-9]|[3-9][0-9])\.'); desktop=[bool]$package; cli=$cli; git=[bool](Get-Command git.exe -ErrorAction SilentlyContinue); addresses=$addresses; name=if($setup.name){$setup.name}else{$env:COMPUTERNAME}; cwd=if($setup.cwd){$setup.cwd}else{[Environment]::GetFolderPath('MyDocuments')}; endpoint=$endpoint; shared=[bool]$shared.enabled; switchStatus=$transition.status; autoStart=[bool]($task -and @($task.Actions | Where-Object { $_.Execute -eq (Join-Path $PSScriptRoot 'PocketRemoteHost.exe') }).Count); online=[bool]$health.online; root=$PSScriptRoot }
        $result.installedRoot = $installedRoot
        $result.installedVersion = if ($installedRoot) { Get-InstalledPCVersion $installedRoot } else { '' }
        $relay = Read-Json '.relay.json'
        $result.relay = @{ websocketUrl=$relay.websocketUrl; canonicalUrl=$relay.canonicalUrl; admin=@{ sshHost=$relay.admin.sshHost; sshPort=$relay.admin.sshPort; domain=$relay.admin.domain; identityFile=$relay.admin.identityFile; nginxSnippet=$relay.admin.nginxSnippet; sudo=[bool]$relay.admin.sudo } }
    } elseif ($Action -eq 'RelayDiscover') {
        $result = Invoke-RelaySetup 'discover' $null
    } elseif ($Action -eq 'RelayProvision') {
        $result = Invoke-RelaySetup 'provision' $inputData
    } elseif ($Action -eq 'RelayLogin') {
        $prepared = Invoke-RelaySetup 'prepare' $inputData
        $loginRoot = Join-Path $PSScriptRoot '.relay-login'
        $sessionRoot = Join-Path $loginRoot ([Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $sessionRoot -Force | Out-Null
        $requestFile = Join-Path $sessionRoot 'request.json'
        $receiptFile = Join-Path $sessionRoot 'receipt.json'
        try {
            [IO.File]::WriteAllText($requestFile, (@{ arguments=$prepared.interactiveArgs } | ConvertTo-Json -Depth 8 -Compress), [Text.UTF8Encoding]::new($false))
            $shell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $login = Start-Process -FilePath $shell -ArgumentList @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File', ('"' + (Join-Path $PSScriptRoot 'SETUP-RELAY-LOGIN.ps1') + '"'), '-RequestFile', ('"' + $requestFile + '"'), '-ReceiptFile', ('"' + $receiptFile + '"')) -WindowStyle Normal -PassThru
            $login.WaitForExit()
            if (!(Test-Path -LiteralPath $receiptFile -PathType Leaf)) { throw 'SSH 로그인을 완료하지 않았습니다. 기존 연결 설정은 유지됩니다.' }
            $receipt = Get-Content -LiteralPath $receiptFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if (!$receipt.ok) { throw 'SSH 인증 또는 서버 구성을 완료하지 못했습니다. 관리자 계정·키·서버 권한을 확인하세요.' }
            $result = Invoke-RelaySetup 'finish' @{ prepared=@{ id=$prepared.id; keyFile=$prepared.keyFile; admin=$prepared.admin }; output=$receipt.output }
        } finally {
            foreach ($path in @($requestFile, $receiptFile)) { if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force } }
            if (Test-Path -LiteralPath $sessionRoot) { Remove-Item -LiteralPath $sessionRoot -Force }
        }
    } elseif ($Action -eq 'UpdateExisting') {
        $result = Install-PCUpdateBootstrap $PSScriptRoot ([string]$inputData.installRoot)
    } elseif ($Action -eq 'InstallNode') {
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (!$winget) { throw 'winget이 없습니다. Node.js 공식 다운로드 페이지에서 LTS를 설치해 주세요.' }
        & $winget.Source install --id OpenJS.NodeJS.LTS --exact --silent --accept-package-agreements --accept-source-agreements *> $null
        if ($LASTEXITCODE -ne 0) { throw 'Node.js 설치를 완료하지 못했습니다. 공식 다운로드 페이지에서 설치해 주세요.' }
        $result = @{ message='Node.js 설치가 완료되었습니다. 환경을 다시 확인하세요.' }
    } elseif ($Action -eq 'Apply') {
        if (!$node) { throw 'Node.js를 먼저 설치하세요.' }
        $validated = ($inputData | ConvertTo-Json -Depth 8 -Compress) | & $node (Join-Path $PSScriptRoot 'bridge\setup-config.mjs')
        $normalized = $validated | ConvertFrom-Json
        if (!$normalized.ok) { throw $normalized.error }
        $config = $normalized.config
        # Finish validation before interrupting an existing connection.
        Assert-Owned-Port $config.localPort
        $existingTask = Get-ScheduledTask -TaskName PocketRemoteExternal -ErrorAction SilentlyContinue
        $ownTask = Get-SetupHostTask $PSScriptRoot
        if ($normalized.autoStart -and $existingTask -and !$ownTask -and !(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'distribution.json'))) { throw '다른 설치 폴더의 자동 실행이 등록되어 있습니다. 그 설치 폴더에서 재설정하세요.' }
        if (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'PocketRemoteHost.exe') -PathType Leaf)) { throw 'PC 패키지 전체를 압축 해제한 뒤 마법사를 실행하세요.' }
        $protectedToken = $null
        if ($config.provider -in @('ngrok','cloudflare')) {
            $binary = if($config.provider -eq 'ngrok'){'ngrok.exe'}else{'cloudflared.exe'}
            if (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot ('tools\' + $binary)) -PathType Leaf)) { throw ('tools\' + $binary + '를 먼저 준비하세요.') }
            if ($inputData.tunnelToken) {
                $secure = ConvertTo-SecureString -String $inputData.tunnelToken -AsPlainText -Force
                $protectedToken = $secure | ConvertFrom-SecureString
            } elseif (!(Test-Path -LiteralPath (Get-PocketSetting $PSScriptRoot '.endpoint-secret') -PathType Leaf)) { throw '터널 서비스 토큰을 입력하세요.' }
        }
        $old = [ordered]@{ provider=$endpoint.provider; localPort=$port; bindAddress=if($endpoint.bindAddress){$endpoint.bindAddress}else{'127.0.0.1'}; websocketUrl=$endpoint.websocketUrl; sshHost=$endpoint.sshHost; reversePort=$endpoint.reversePort; sshPort=$endpoint.sshPort; sshIdentityFile=$endpoint.sshIdentityFile }
        $next = [ordered]@{ provider=$config.provider; localPort=$config.localPort; bindAddress=$config.bindAddress; websocketUrl=$config.websocketUrl; sshHost=$config.sshHost; reversePort=$config.reversePort; sshPort=$config.sshPort; sshIdentityFile=$config.sshIdentityFile }
        $restartNeeded = !$endpoint -or !(Local-Health $port) -or $protectedToken -or (($old | ConvertTo-Json -Compress) -ne ($next | ConvertTo-Json -Compress))
        $previous = @{}
        foreach ($name in @('.endpoint.json','.setup.json','.endpoint-secret')) {
            $path = Get-PocketSetting $PSScriptRoot $name
            $previous[$name] = if (Test-Path -LiteralPath $path -PathType Leaf) { [IO.File]::ReadAllBytes($path) } else { $null }
        }
        $taskXml = if ($ownTask) { Export-ScheduledTask -TaskName PocketRemoteExternal } else { $null }
        $taskWasEnabled = $ownTask -and [bool]$ownTask.Settings.Enabled
        $stopped = $null
        $restartAttempted = $false
        try {
            if ($restartNeeded) { $restartAttempted = $true; $stopped = Stop-SetupHost $PSScriptRoot }
            $normalized.setup | Add-Member -NotePropertyName sharedDesktop -NotePropertyValue ([bool]$normalized.sharedDesktop) -Force
            if ($protectedToken) { [IO.File]::WriteAllText((Get-PocketSetting $PSScriptRoot '.endpoint-secret'), $protectedToken, [Text.UTF8Encoding]::new($false)) }
            Save-Json '.endpoint.json' $config; Save-Json '.setup.json' $normalized.setup
            $env:PATH = (Split-Path -Parent $node) + ';' + $env:PATH
            if ($normalized.autoStart) { & (Join-Path $PSScriptRoot 'INSTALL-AUTOSTART.ps1') *> $null }
            elseif (Get-SetupHostTask $PSScriptRoot) { Disable-ScheduledTask -TaskName PocketRemoteExternal | Out-Null }
            if ($stopped.stopped) { Start-ConfiguredHost $config.localPort $node }
        } catch {
            $failure = $_.Exception.Message
            try {
                if ($stopped.stopped) { Stop-SetupHost $PSScriptRoot | Out-Null }
                foreach ($name in $previous.Keys) {
                    $path = Get-PocketSetting $PSScriptRoot $name
                    if ($null -ne $previous[$name]) { [IO.File]::WriteAllBytes($path, [byte[]]$previous[$name]) }
                    elseif (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force }
                }
                if ($taskXml) {
                    Register-ScheduledTask -TaskName PocketRemoteExternal -Xml $taskXml -Force | Out-Null
                    if ($taskWasEnabled) { Enable-ScheduledTask -TaskName PocketRemoteExternal | Out-Null }
                    else { Disable-ScheduledTask -TaskName PocketRemoteExternal | Out-Null }
                } elseif (Get-SetupHostTask $PSScriptRoot) { Unregister-ScheduledTask -TaskName PocketRemoteExternal -Confirm:$false | Out-Null }
                if ($restartAttempted -and $endpoint) { Start-ConfiguredHost $port $node }
            } catch { throw ($failure + ' 기존 설정의 자동 복구를 완료하지 못했습니다. 마법사에서 연결 설정을 확인하고 다시 적용하세요.') }
            throw ($failure + $(if ($stopped.stopped) { ' 기존 설정을 복구하고 이전 연결 호스트를 다시 실행했습니다.' } else { ' 기존 연결 설정은 유지됩니다.' }))
        }
        $result = @{ message=if($stopped.stopped){'기존 연결 호스트를 종료하고 새 설정으로 다시 실행했습니다. 공유 연결 전환은 모든 작업이 유휴 상태가 된 뒤 적용됩니다.'}else{'설정을 저장했습니다. 공유 연결 전환은 모든 작업이 유휴 상태가 된 뒤 적용됩니다.'}; websocketUrl=$config.websocketUrl; hostRestarted=[bool]$stopped.stopped }
    } elseif ($Action -eq 'Start') {
        if (!$endpoint) { throw '연결 설정을 먼저 저장하세요.' }
        Start-ConfiguredHost $port $node
        # Also enable automatic updates when an older host is still running.
        $updater = Join-Path $PSScriptRoot 'bridge\update-worker.mjs'
        $hostIdFile = Join-Path $PSScriptRoot '.host.pid'
        if ($env:REMOTE_AUTO_UPDATE -ne '0' -and (Test-Path -LiteralPath $updater) -and (Test-Path -LiteralPath $hostIdFile)) {
            $hostId = [int][IO.File]::ReadAllText($hostIdFile).Trim()
            Start-Process -FilePath $node -ArgumentList @(('"' + $updater + '"'), '--parent', $hostId) -WorkingDirectory $PSScriptRoot -WindowStyle Hidden | Out-Null
        }
        $savedSetup = Read-Json '.setup.json'
        if ($savedSetup.sharedDesktop -and !$HostOnly) {
            $env:PATH = (Split-Path -Parent $node) + ';' + $env:PATH
            & (Join-Path $PSScriptRoot 'ENABLE-SHARED-DESKTOP.ps1') *> $null
        }
        $sharedConfig = Read-Json '.shared-server.json'; $transition = Read-Json '.desktop-switch.json'
        $sharedStatus = if ($transition.status -in @('prepared','waiting-for-idle','applying')) { '공식 앱 공유 연결은 작업 종료 후 적용 대기 중' } elseif ($sharedConfig.enabled) { '공식 앱 공유 연결 사용 중' } else { '독립 연결' }
        $result = @{ message='백그라운드 호스트가 실행 중입니다.'; sharedStatus=$sharedStatus }
    } elseif ($Action -eq 'Pair') {
        Assert-Owned-Port $port
        if (!(Local-Health $port)) { throw '호스트를 먼저 시작하세요.' }
        $token = (Get-Content -LiteralPath (Get-PocketSetting $PSScriptRoot '.remote-secret') -Raw -Encoding UTF8).Trim()
        $result = Invoke-RestMethod -Method Post -Uri ('http://127.0.0.1:' + $port + '/pairing') -Headers @{Authorization='Bearer ' + $token} -TimeoutSec 5
        $saved = Read-Json '.setup.json'
        try {
            $qr = (@{url=$endpoint.websocketUrl;code=$result.code;name=$saved.name} | ConvertTo-Json -Compress) | & $node (Join-Path $PSScriptRoot 'bridge\pairing-qr.mjs')
            if ($LASTEXITCODE -eq 0) { $result | Add-Member -NotePropertyName qrData -NotePropertyValue ([string]$qr) }
        } catch { } # Legacy bootstrap installations can still pair manually.
    } elseif ($Action -eq 'Test') {
        if (!$node) { throw 'Node.js를 먼저 설치하세요.' }
        $resultText = ($inputData | ConvertTo-Json -Compress) | & $node (Join-Path $PSScriptRoot 'bridge\setup-test.mjs')
        $result = $resultText | ConvertFrom-Json
        if (!$result.ok) { throw $result.error }
    } elseif ($Action -eq 'Firewall') {
        $rulePort = [int]$inputData.localPort
        if ($rulePort -lt 1024 -or $rulePort -gt 65535) { throw '방화벽 포트를 확인하세요.' }
        $scope = [string]$inputData.remoteAddress
        if (!$scope) { $scope = 'LocalSubnet' }
        if ($scope -ne 'LocalSubnet' -and $scope -notmatch '^[a-fA-F0-9:.,/]+$') { throw '신뢰할 VPN 클라이언트 IP 또는 CIDR을 입력하세요.' }
        New-NetFirewallRule -DisplayName ('Pocket Remote LAN/VPN ' + $rulePort) -Direction Inbound -Action Allow -Protocol TCP -LocalPort $rulePort -RemoteAddress $scope -Profile Any | Out-Null
        $result = @{ message='선택한 내부망/VPN 범위의 인바운드 규칙을 추가했습니다.' }
    }
    @{ok=$true; result=$result} | ConvertTo-Json -Depth 10 -Compress
} catch {
    @{ok=$false; error=$_.Exception.Message} | ConvertTo-Json -Compress
    exit 1
}

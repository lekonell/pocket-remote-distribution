﻿. (Join-Path $PSScriptRoot 'bridge\settings.ps1')
Initialize-PocketSettings $PSScriptRoot
# Restore the original desktop environment after running work has completed.
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (!(Test-Path -LiteralPath (Get-PocketSetting $root '.desktop-shared-backup'))) { throw 'Shared desktop mode has not been activated; there is no saved desktop environment to restore.' }
$package = Get-AppxPackage -Name 'OpenAI.Codex' | Select-Object -First 1
if (!$package) { throw 'The official desktop package is unavailable.' }
$desktopPath = Join-Path $package.InstallLocation 'app\ChatGPT.exe'
$desktop = @(Get-CimInstance Win32_Process -Filter "Name = 'ChatGPT.exe'" | Where-Object { $_.ExecutablePath -eq $desktopPath -and $_.CommandLine -notmatch '--type=' })
if ($desktop.Count -gt 1) { throw 'Multiple desktop processes were found.' }
$hostPid = if (Test-Path -LiteralPath (Join-Path $root '.host.pid')) { [int](Get-Content -LiteralPath (Join-Path $root '.host.pid') -Raw) } else { 0 }
$bridge = @(Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" | Where-Object { $_.ParentProcessId -eq $hostPid -and $_.CommandLine.Contains((Join-Path $root 'bridge/server.mjs')) })
if ($bridge.Count -gt 1) { throw 'Multiple bridges were found.' }
$request = @{ action='restore'; status='prepared'; requestedAt=[DateTime]::UtcNow.ToString('o'); desktopPath=$desktopPath; desktopPid=if($desktop.Count){$desktop[0].ProcessId}else{0}; hostPid=$hostPid; bridgePid=if($bridge.Count){$bridge[0].ProcessId}else{0}; watchedThreads=@(); shellPath=(Get-Process -Id $PID).Path; workerPid=0 }
if ($env:CODEX_THREAD_ID) { $request.watchedThreads=@($env:CODEX_THREAD_ID) }
$request | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root '.desktop-switch.json') -Encoding UTF8
$worker = Start-Process -FilePath (Get-Command node.exe).Source -ArgumentList ('"' + (Join-Path $root 'bridge\desktop-switch.mjs') + '"') -WorkingDirectory $root -WindowStyle Hidden -PassThru
Write-Host ('Restore worker PID ' + $worker.Id + ' is waiting for all work to be idle.')

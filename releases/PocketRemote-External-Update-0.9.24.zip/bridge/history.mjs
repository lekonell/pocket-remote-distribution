import { Buffer } from 'node:buffer';

const prefix = 'pocket-history:';
const unsupported = error => /not supported yet|method not found|unsupported.method/i.test(error.message);

// Legacy stores expose turn pages but may not expose item pages. Split a turn
// on the PC so a mobile client still receives a bounded number of entries.
export function createItemPager(call) {
  const cache = new Map();
  const loading = new Map(), nativeLoading = new Map(), unsupportedUntil = new Map();
  let cacheBytes = 0;
  function invalidate(threadId, latestOnly = false) {
    for (const [key, value] of cache) if (value.threadId === threadId && (!latestOnly || !value.cursor)) {
      cache.delete(key); cacheBytes -= value.bytes;
    }
    for (const [key, value] of loading) if (value.threadId === threadId && (!latestOnly || !value.cursor)) loading.delete(key);
    for (const [key, value] of nativeLoading) if (value.threadId === threadId && (!latestOnly || !value.cursor)) nativeLoading.delete(key);
  }
  async function turnPage(threadId, cursor, direction) {
    const key = JSON.stringify([threadId, cursor, direction]);
    const found = cache.get(key);
    if (found && Date.now() - found.time < 30000) return found.page;
    if (found) { cache.delete(key); cacheBytes -= found.bytes; }
    if (loading.has(key)) return loading.get(key).promise;
    const flight = { threadId, cursor };
    flight.promise = (async () => {
      const page = await call('thread/turns/list', { threadId, limit: 1, itemsView: 'full', sortDirection: direction, ...(cursor ? { cursor } : {}) });
      const bytes = Buffer.byteLength(JSON.stringify(page));
      if (loading.get(key) === flight && bytes <= 20 * 1024 * 1024) {
        cache.set(key, { threadId, cursor, page, bytes, time: Date.now() }); cacheBytes += bytes;
        while (cache.size > 8 || cacheBytes > 20 * 1024 * 1024) {
          const oldest = cache.keys().next().value;
          cacheBytes -= cache.get(oldest).bytes; cache.delete(oldest);
        }
      }
      return page;
    })().finally(() => { if (loading.get(key) === flight) loading.delete(key); });
    loading.set(key, flight);
    return flight.promise;
  }
  async function fallback(params) {
    const threadId = params.threadId;
    const direction = params.sortDirection === 'asc' ? 'asc' : 'desc';
    const limit = Math.min(100, Math.max(1, Math.floor(Number(params.limit) || 60)));
    let cursor = null;
    let afterId = null;
    if (params.cursor) {
      let decoded;
      try { decoded = JSON.parse(Buffer.from(params.cursor.slice(prefix.length), 'base64url').toString('utf8')); }
      catch { throw new Error('Invalid history cursor'); }
      if (decoded.threadId !== threadId || decoded.direction !== direction || (decoded.cursor !== null && typeof decoded.cursor !== 'string')) throw new Error('History cursor does not match the thread');
      cursor = decoded.cursor; afterId = decoded.afterId;
    }
    const data = [];
    let nextCursor = null;
    let backwardsCursor = null;
    for (let pageCount = 0; pageCount < 50 && data.length < limit; pageCount++) {
      let page;
      try { page = await turnPage(threadId, cursor, direction); }
      catch (error) { if (/not materialized|unavailable before first user message/i.test(error.message)) break; throw error; }
      nextCursor = null;
      const turn = page.data?.[0];
      const items = turn ? [...(turn.items || [])] : [];
      if (direction === 'desc') items.reverse();
      const anchor = afterId ? items.findIndex(item => item.id === afterId) : -1;
      const offset = anchor < 0 ? 0 : anchor + 1;
      const selected = params.turnId && turn?.id !== params.turnId ? [] : items.slice(offset, offset + limit - data.length);
      if (selected.length && !backwardsCursor && page.backwardsCursor) {
        // The turn API's reverse cursor includes this turn again. Resume after
        // the first selected item in the opposite order, including long turns.
        backwardsCursor = prefix + Buffer.from(JSON.stringify({ threadId, direction: direction === 'desc' ? 'asc' : 'desc', cursor: page.backwardsCursor, afterId: selected[0].id })).toString('base64url');
      }
      for (const item of selected) data.push({ turnId: turn.id, item, startedAtMs: null, completedAtMs: null });
      if (selected.length && offset + selected.length < items.length) {
        nextCursor = prefix + Buffer.from(JSON.stringify({ threadId, direction, cursor, afterId: selected.at(-1).id })).toString('base64url');
        break;
      }
      cursor = page.nextCursor || null; afterId = null;
      if (!cursor) break;
      nextCursor = prefix + Buffer.from(JSON.stringify({ threadId, direction, cursor, afterId: null })).toString('base64url');
    }
    return { data, nextCursor, backwardsCursor };
  }
  return {
    invalidate,
    reset() { cache.clear(); loading.clear(); nativeLoading.clear(); unsupportedUntil.clear(); cacheBytes = 0; },
    async list(params) {
      if (params.cursor?.startsWith(prefix)) return fallback(params);
      if (!params.cursor && (unsupportedUntil.get(params.threadId) || 0) > Date.now()) return fallback(params);
      const key = JSON.stringify(Object.keys(params).sort().map(name => [name, params[name]]));
      if (nativeLoading.has(key)) return nativeLoading.get(key).promise;
      const flight = { threadId: params.threadId, cursor: params.cursor };
      flight.promise = Promise.resolve().then(() => call('thread/items/list', params)).catch(error => {
        if (!unsupported(error)) throw error;
        unsupportedUntil.set(params.threadId, Date.now() + 60000);
        while (unsupportedUntil.size > 256) unsupportedUntil.delete(unsupportedUntil.keys().next().value);
        return fallback(params);
      }).finally(() => { if (nativeLoading.get(key) === flight) nativeLoading.delete(key); });
      nativeLoading.set(key, flight);
      return flight.promise;
    }
  };
}

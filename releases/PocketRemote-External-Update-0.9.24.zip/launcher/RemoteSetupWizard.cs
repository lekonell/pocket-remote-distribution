using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

[assembly: AssemblyTitle("Pocket Remote Setup")]
[assembly: AssemblyVersion("0.9.24.0")]

internal sealed class RemoteSetupWizard : Form
{
    private readonly string root;
    private readonly bool preview;
    private readonly JavaScriptSerializer json = new JavaScriptSerializer();
    private readonly Color ink = Color.FromArgb(29, 64, 62), mint = Color.FromArgb(224, 241, 234), accent = Color.FromArgb(36, 106, 88);
    private readonly Panel main = new Panel(), side = new Panel();
    private readonly List<Panel> pages = new List<Panel>();
    private readonly Label status = new Label(), checks = new Label(), pairCode = new Label(), pairExpiry = new Label(), pairAddress = new Label();
    private readonly PictureBox pairingImage = new PictureBox { SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.White };
    private readonly Button next = new Button(), back = new Button();
    private readonly TextBox name = new TextBox(), folder = new TextBox(), endpoint = new TextBox(), port = new TextBox(), sshHost = new TextBox(), reversePort = new TextBox(), tunnelToken = new TextBox();
    private readonly ComboBox provider = new ComboBox(), bind = new ComboBox();
    private readonly CheckBox autoStart = new CheckBox(), shared = new CheckBox();
    private readonly string[] providerIds = { "direct", "custom", "ssh", "ngrok", "cloudflare" };
    private readonly string[] stepNames = { "환경 확인", "연결 설정", "적용 및 실행", "휴대폰 페어링" };
    private Panel sshFields, tokenFields;
    private Label networkHint;
    private bool busy, loading, configured;
    private int step;
    private long expiresAt;
    private string sharedStatus = "";
    private string existingRoot = "";
    private string sshPortValue = "", sshIdentityValue = "", relayId = "";
    private string mobileAddressUrl = "", canonicalAddressUrl = "";
    private Dictionary<string, object> relayAdmin = new Dictionary<string, object>();
    private Label addressCaption, addressHint;
    private string relayPreviewPath = "";
    private Button existingUpdate;
    private readonly Timer countdown = new Timer();

    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        var rootArg = Array.FindIndex(args, x => x == "--root");
        string root = rootArg >= 0 && rootArg + 1 < args.Length ? Path.GetFullPath(args[rootArg + 1]) : AppDomain.CurrentDomain.BaseDirectory;
        bool preview = args.Contains("--render-preview") || args.Contains("--self-test");
        try
        {
            using (var wizard = new RemoteSetupWizard(root, preview))
            {
                if (args.Contains("--self-test"))
                {
                    wizard.SeedPreview();
                    if (!wizard.Values().ContainsKey("websocketUrl") || wizard.pages.Count != 4) return 1;
                    for (int i = 0; i < 4; i++) wizard.ShowStep(i);
                    return 0;
                }
                int render = Array.FindIndex(args, x => x == "--render-preview");
                if (render >= 0)
                {
                    if (args.Contains("--relay")) { wizard.relayPreviewPath = Path.GetFullPath(args[render + 1]); wizard.ConfigureRelay().GetAwaiter().GetResult(); return 0; }
                    wizard.SeedPreview(); if (args.Contains("--short-address")) wizard.endpoint.Text = "wss://remote.example.com/r/q2w3e4r5/socket";
                    int qrPreview = Array.FindIndex(args, x => x == "--qr-preview");
                    if (qrPreview >= 0 && qrPreview + 1 < args.Length) { using (var sample = Image.FromFile(args[qrPreview + 1])) wizard.SetPairingImage(sample); }
                    wizard.ShowStep(args.Contains("--pairing") ? 3 : args.Contains("--apply") ? 2 : args.Contains("--environment") ? 0 : 1);
                    wizard.ShowInTaskbar = false; wizard.Opacity = 0; wizard.StartPosition = FormStartPosition.Manual; wizard.Location = new Point(-32000, -32000);
                    wizard.Show(); Application.DoEvents(); wizard.PerformLayout();
                    using (var bitmap = new Bitmap(wizard.Width, wizard.Height)) { wizard.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size)); bitmap.Save(Path.GetFullPath(args[render + 1]), ImageFormat.Png); }
                    return 0;
                }
                if (!File.Exists(Path.Combine(root, "SETUP-REMOTE.ps1"))) throw new Exception("PC ZIP을 폴더에 모두 압축 해제한 뒤 PocketRemoteSetup.exe를 실행하세요.");
                Application.Run(wizard);
            }
            return 0;
        }
        catch (Exception e) { if (!preview) MessageBox.Show(e.Message, "Pocket Remote 설정", MessageBoxButtons.OK, MessageBoxIcon.Information); return 1; }
    }

    private RemoteSetupWizard(string directory, bool renderOnly)
    {
        root = directory; preview = renderOnly;
        Text = "Pocket Remote · PC 연결 설정"; ClientSize = new Size(1040, 760); MinimumSize = new Size(990, 730); StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Malgun Gothic", 10); ForeColor = ink; BackColor = Color.FromArgb(247, 250, 248); AutoScaleMode = AutoScaleMode.Font;
        side.Dock = DockStyle.Left; side.Width = 192; side.BackColor = mint; Controls.Add(side);
        var brand = new Label { Text = ">_\nPocket\nRemote", Font = new Font("Segoe UI", 27, FontStyle.Bold), ForeColor = ink, Location = new Point(24, 28), Size = new Size(162, 164) }; side.Controls.Add(brand);
        for (int i = 0; i < stepNames.Length; i++) side.Controls.Add(new Label { Name = "step" + i, Text = (i + 1) + "  " + stepNames[i], Location = new Point(22, 230 + i * 61), Size = new Size(167, 46), Font = new Font(Font, FontStyle.Regular), TextAlign = ContentAlignment.MiddleLeft });
        side.Controls.Add(new Label { Text = "창 없이\n백그라운드에서\n조용히 동작합니다.", Location = new Point(24, 602), Size = new Size(155, 88), ForeColor = Color.FromArgb(75, 111, 102) });
        main.Dock = DockStyle.Fill; main.Padding = new Padding(28, 23, 28, 16); Controls.Add(main); main.BringToFront();
        var footer = new Panel { Dock = DockStyle.Bottom, Height = 100 }; main.Controls.Add(footer);
        status.Dock = DockStyle.Top; status.Height = 56; status.AutoEllipsis = true; status.ForeColor = Color.FromArgb(72, 98, 92); footer.Controls.Add(status);
        back.Text = "이전"; back.Size = new Size(90, 38); back.Location = new Point(0, 58); back.Click += (s, e) => { if (!busy && step > 0) ShowStep(step - 1); }; footer.Controls.Add(back);
        next.Text = "다음"; next.Size = new Size(232, 38); next.Anchor = AnchorStyles.Right | AnchorStyles.Bottom; next.Location = new Point(536, 58); StyleButton(next, true); next.Click += Next; footer.Controls.Add(next);
        footer.Resize += (s, e) => next.Left = footer.ClientSize.Width - next.Width;
        BuildEnvironment(); BuildNetwork(); BuildApply(); BuildPairing(); ShowStep(0);
        countdown.Interval = 1000; countdown.Tick += (s, e) => UpdateExpiry(); countdown.Start();
        FormClosed += (s, e) => countdown.Dispose();
        if (!preview) Shown += async (s, e) => await CheckEnvironment();
    }

    private Panel Page(string title, string description)
    {
        var panel = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Visible = false }; main.Controls.Add(panel); panel.BringToFront();
        panel.Controls.Add(new Label { Text = title, Location = new Point(0, 4), Size = new Size(720, 53), Font = new Font("Malgun Gothic", 23, FontStyle.Bold), ForeColor = ink });
        panel.Controls.Add(new Label { Text = description, Location = new Point(0, 61), Size = new Size(714, 55), ForeColor = Color.FromArgb(82, 111, 102) });
        pages.Add(panel); return panel;
    }
    private Label Caption(Panel panel, string text, int x, int y, int width) { var label = new Label { Text = text, Location = new Point(x, y), Size = new Size(width, 24), Font = new Font(Font, FontStyle.Bold) }; panel.Controls.Add(label); return label; }
    private void Field(Panel panel, Control input, string label, int x, int y, int width)
    {
        Caption(panel, label, x, y, width); input.Location = new Point(x, y + 28); input.Size = new Size(width, 34); input.Anchor = AnchorStyles.Top | AnchorStyles.Left; input.BackColor = Color.White; panel.Controls.Add(input);
    }
    private void StyleButton(Button button, bool primary)
    {
        button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderSize = primary ? 0 : 1; button.FlatAppearance.BorderColor = Color.FromArgb(182, 210, 196);
        button.BackColor = primary ? accent : Color.White; button.ForeColor = primary ? Color.White : ink; button.Cursor = Cursors.Hand;
    }
    private Button Button(Panel panel, string text, int x, int y, int width, EventHandler click)
    {
        var button = new Button { Text = text, Location = new Point(x, y), Size = new Size(width, 38) }; StyleButton(button, false); button.Click += click; panel.Controls.Add(button); return button;
    }
    private void BuildEnvironment()
    {
        var panel = Page("PC 연결을 준비합니다", "필수 프로그램을 확인하고, 작업 폴더와 연결 방식을 고르면\n마법사가 호스트 실행·자동 시작·휴대폰 페어링을 이어서 안내합니다.");
        checks.Location = new Point(0, 145); checks.Size = new Size(704, 210); checks.BackColor = Color.White; checks.Padding = new Padding(18); checks.Text = "환경을 확인하고 있습니다…"; panel.Controls.Add(checks);
        Button(panel, "환경 다시 확인", 0, 377, 157, async (s, e) => await CheckEnvironment());
        Button(panel, "Node.js LTS 설치", 173, 377, 175, async (s, e) => { if (await Operation("InstallNode", null)) await CheckEnvironment(); });
        Button(panel, "Node 공식 다운로드", 364, 377, 176, (s, e) => Open("https://nodejs.org/en/download"));
        Button(panel, "공식 앱 설치·로그인", 0, 431, 225, (s, e) => Open("https://learn.chatgpt.com/docs/windows/windows-app"));
        existingUpdate = Button(panel, "기존 설정 유지하며 업데이트", 0, 489, 322, async (s, e) => await UpgradeExisting());
        panel.Controls.Add(new Label { Text = "기존 버전은 위 버튼으로 설정·페어링을 유지하며 업데이트할 수 있습니다.\n자동 실행 등록을 찾지 못하면 기존 설치 폴더를 직접 선택합니다.\n신규 PC 설치는 다음 단계에서 연결을 설정하세요.", Location = new Point(0, 543), Size = new Size(711, 69), ForeColor = Color.FromArgb(82, 111, 102) });
    }
    private void BuildNetwork()
    {
        var panel = Page("어디에서 연결하시나요?", "내부망·VPN은 PC에 직접 연결할 수 있습니다. 외부 인터넷은 기존 WSS 주소나\n보안 터널을 사용하세요. 휴대폰에서 도달할 수 있는 PC 주소를 지정합니다.");
        Field(panel, name, "PC 이름", 0, 129, 226);
        Field(panel, folder, "기본 작업 폴더", 249, 129, 367);
        Button(panel, "찾기", 627, 157, 74, (s, e) => { using (var dialog = new FolderBrowserDialog { Description = "기본 작업 폴더", SelectedPath = folder.Text, ShowNewFolderButton = true }) if (dialog.ShowDialog(this) == DialogResult.OK) folder.Text = dialog.SelectedPath; });
        provider.DropDownStyle = ComboBoxStyle.DropDownList; provider.Items.AddRange(new object[] { "내부망 / VPN 직접 연결", "기존 WSS / 역방향 프록시", "SSH 역터널 + 기존 WSS", "ngrok 고정 WSS", "Cloudflare Tunnel" });
        Field(panel, provider, "연결 방식", 0, 210, 701);
        Field(panel, bind, "PC 수신 주소 (LAN / VPN 인터페이스)", 0, 291, 497); Field(panel, port, "브리지 포트", 520, 291, 181); port.Text = "4545";
        Field(panel, endpoint, "휴대폰 연결 주소", 0, 372, 701);
        networkHint = new Label { Location = new Point(0, 445), Size = new Size(701, 53), ForeColor = Color.FromArgb(82, 111, 102) }; panel.Controls.Add(networkHint);
        sshFields = new Panel { Location = new Point(0, 501), Size = new Size(701, 79) }; panel.Controls.Add(sshFields); Field(sshFields, sshHost, "SSH 별칭 / user@host", 0, 0, 475); Field(sshFields, reversePort, "서버 내부 포트", 498, 0, 203); reversePort.Text = "14545";
        Button(panel, "SSH 서버에서 PC 전용 WSS 자동 구성…", 0, 588, 419, async (s, e) => await ConfigureRelay());
        tokenFields = new Panel { Location = new Point(0, 501), Size = new Size(701, 79) }; panel.Controls.Add(tokenFields); tunnelToken.UseSystemPasswordChar = true; Field(tokenFields, tunnelToken, "터널 서비스 토큰 (기존 설정을 유지할 때는 비워 두기)", 0, 0, 701);
        provider.SelectedIndexChanged += (s, e) => ModeChanged();
        bind.TextChanged += (s, e) => { if (!loading && provider.SelectedIndex == 0) DirectAddress(); };
        port.TextChanged += (s, e) => { if (!loading && provider.SelectedIndex == 0) DirectAddress(); };
        provider.SelectedIndex = 0;
    }
    private void BuildApply()
    {
        var panel = Page("설정을 적용합니다", "연결 설정을 바꾸면 기존 호스트를 자동 종료하고 새 설정으로 다시 실행합니다.\n모바일 연결은 잠시 끊기며 실행은 계속 백그라운드에서 유지됩니다.");
        autoStart.Text = "Windows 로그인 시 자동 실행"; autoStart.Checked = true; autoStart.Location = new Point(5, 151); autoStart.Size = new Size(696, 37); panel.Controls.Add(autoStart);
        shared.Text = "공식 PC 앱과 같은 App Server 사용"; shared.Checked = true; shared.Location = new Point(5, 204); shared.Size = new Size(696, 37); panel.Controls.Add(shared);
        panel.Controls.Add(new Label { Text = "네트워크 재설정은 이 설치의 호스트·브리지·터널만 종료합니다.\n공유 서버와 공식 PC 앱은 유지합니다. 공유 연결을 쓰지 않는 작업은 중단될 수 있습니다.\n공식 앱의 첫 공유 연결 전환은 작업을 마친 뒤 적용합니다.", Location = new Point(8, 251), Size = new Size(691, 96), ForeColor = Color.FromArgb(82, 111, 102) });
        Button(panel, "LAN / VPN 방화벽 허용…", 0, 365, 268, Firewall);
        panel.Controls.Add(new Label { Text = "직접 연결이 방화벽에 막힌 경우에만 사용하세요. 허용할 내부망 또는 VPN\n클라이언트 IP 대역을 지정하며 Windows 관리자 승인이 필요합니다.\n기존 WSS·터널은 외부 인바운드 포트 개방이 필요하지 않습니다.", Location = new Point(0, 421), Size = new Size(705, 94), ForeColor = Color.FromArgb(82, 111, 102) });
    }
    private void BuildPairing()
    {
        var panel = Page("휴대폰을 연결하세요", "휴대폰 앱 → 연결 대상 추가 → QR코드 스캔 → 이 PC에 연결\n같은 Wi-Fi 또는 같은 VPN에 연결되어 있어야 합니다.");
        pairingImage.Location = new Point(460, 137); pairingImage.Size = new Size(235, 235); panel.Controls.Add(pairingImage);
        addressCaption = Caption(panel, "PC 주소 코드 또는 연결 주소", 0, 133, 430); pairAddress.Location = new Point(0, 171); pairAddress.Size = new Size(430, 67); pairAddress.BackColor = Color.White; pairAddress.Padding = new Padding(12); pairAddress.AutoEllipsis = true; panel.Controls.Add(pairAddress);
        Button(panel, "주소 복사", 0, 249, 132, (s, e) => Copy(pairAddress.Text));
        Button(panel, "전체 주소 복사", 145, 249, 140, (s, e) => Copy(PairingUrl()));
        addressHint = new Label { Location = new Point(0, 287), Size = new Size(430, 40), ForeColor = Color.FromArgb(82, 111, 102) }; panel.Controls.Add(addressHint);
        Caption(panel, "8자리 페어링 코드 · 연결 승인용", 0, 324, 430);
        pairCode.Text = "--------"; pairCode.Location = new Point(0, 351); pairCode.Size = new Size(430, 65); pairCode.Font = new Font("Consolas", 31, FontStyle.Bold); pairCode.TextAlign = ContentAlignment.MiddleCenter; pairCode.BackColor = mint; panel.Controls.Add(pairCode);
        pairExpiry.Location = new Point(0, 421); pairExpiry.Size = new Size(701, 27); pairExpiry.TextAlign = ContentAlignment.MiddleCenter; panel.Controls.Add(pairExpiry);
        Button(panel, "코드 복사", 156, 464, 133, (s, e) => { if (expiresAt > Now()) Copy(pairCode.Text); });
        Button(panel, "새 코드 발급", 308, 464, 154, async (s, e) => await IssueCode());
        Button(panel, "연결 경로 테스트", 478, 464, 192, async (s, e) => await Operation("Test", new Dictionary<string, object> { { "url", endpoint.Text.Trim() } }));
        panel.Controls.Add(new Label { Text = "PC에서 경로 테스트가 성공해도 휴대폰의 네트워크 경로는 다를 수 있습니다.\n내부망·VPN 연결은 휴대폰도 해당 네트워크에 연결한 상태에서 확인하세요.\n외부에서는 WSS와 유효한 TLS 인증서를 사용하세요.", Location = new Point(0, 521), Size = new Size(707, 78), ForeColor = Color.FromArgb(82, 111, 102) });
    }
    private void ModeChanged()
    {
        bool direct = provider.SelectedIndex == 0, custom = provider.SelectedIndex == 1;
        bind.Enabled = direct || custom; sshFields.Visible = provider.SelectedIndex == 2; tokenFields.Visible = provider.SelectedIndex >= 3;
        if (!direct && !custom) bind.Text = "127.0.0.1";
        networkHint.Text = direct ? "예: ws://192.168.0.10:4545/socket 또는 VPN IP. WS 자체는 암호화하지 않습니다.\nTLS를 쓰려면 기존 WSS/프록시 방식을 선택하세요. IPv6 주소도 입력할 수 있습니다."
            : custom ? "TLS 인증서와 프록시를 이미 설정한 WSS 주소를 사용합니다.\n프록시가 같은 PC면 127.0.0.1, 다른 내부망/VPN 장비면 해당 수신 주소를 선택하세요."
            : provider.SelectedIndex == 2 ? "아래 자동 구성에서 SSH 인증과 서버 TLS 도메인을 선택하세요.\nPC별 WSS 경로·내부 포트·전용 터널 키를 만들고 주소를 자동 반영합니다."
            : "서비스의 고정 주소를 입력하세요. 실행 파일은 tools/ 폴더에 준비해야 합니다.\n서비스 토큰은 Windows 사용자 DPAPI로 보호하여 저장합니다.";
        if (!loading && direct) DirectAddress();
    }
    private void DirectAddress()
    {
        string address = bind.Text.Trim(); if (address == "0.0.0.0" || address == "::" || address.Length == 0) return;
        if (address.Contains(":")) address = "[" + address.Trim('[', ']') + "]";
        endpoint.Text = "ws://" + address + ":" + port.Text.Trim() + "/socket";
    }
    private Dictionary<string, object> Values()
    {
        return new Dictionary<string, object> { { "name", name.Text.Trim() }, { "cwd", folder.Text.Trim() }, { "provider", providerIds[Math.Max(0, provider.SelectedIndex)] }, { "bindAddress", bind.Text.Trim() }, { "localPort", port.Text.Trim() }, { "websocketUrl", endpoint.Text.Trim() }, { "sshHost", sshHost.Text.Trim() }, { "reversePort", reversePort.Text.Trim() }, { "sshPort", sshPortValue }, { "sshIdentityFile", sshIdentityValue }, { "relayId", relayId }, { "tunnelToken", tunnelToken.Text }, { "autoStart", autoStart.Checked }, { "sharedDesktop", shared.Checked } };
    }
    private void ShowStep(int value)
    {
        step = value; for (int i = 0; i < pages.Count; i++) { pages[i].Visible = i == step; var label = side.Controls["step" + i] as Label; label.Font = new Font(Font, i == step ? FontStyle.Bold : FontStyle.Regular); label.ForeColor = i == step ? accent : Color.FromArgb(88, 115, 104); }
        pages[step].BringToFront(); back.Enabled = step > 0; next.Text = step == 3 ? "완료" : step == 2 ? "설정 적용 및 연결 재시작" : "다음";
        if (step == 3) {
            string url = PairingUrl(), code = MobileAddressCode(url);
            pairAddress.Text = code.Length > 0 ? code : url;
            pairAddress.Font = code.Length > 0 ? new Font("Consolas", 28, FontStyle.Bold) : Font;
            addressCaption.Text = code.Length > 0 ? "PC 주소 코드 · 만료되지 않음" : "PC 연결 주소";
            addressHint.Text = code.Length > 0 ? "앱의 PC 주소 칸에 이 8자리만 입력하세요.\n아래 페어링 코드는 별도로 입력합니다." : "다른 서버·LAN·VPN은 전체 주소를 입력합니다.\n아래 페어링 코드는 별도로 입력합니다.";
        }
    }
    private string PairingUrl() { return endpoint.Text.Trim() == canonicalAddressUrl && mobileAddressUrl.Length > 0 ? mobileAddressUrl : endpoint.Text.Trim(); }
    private static string MobileAddressCode(string value) {
        Uri url;
        if (!Uri.TryCreate(value, UriKind.Absolute, out url) || url.Scheme != "wss" || true || !url.IsDefaultPort || url.UserInfo.Length > 0 || url.Query.Length > 0 || url.Fragment.Length > 0) return "";
        var match = System.Text.RegularExpressions.Regex.Match(url.AbsolutePath, "^/r/([a-hj-np-z2-9]{8})/socket$");
        return match.Success ? match.Groups[1].Value.ToUpperInvariant() : "";
    }
    private async void Next(object sender, EventArgs e)
    {
        if (busy) return;
        if (step == 3) { Close(); return; }
        if (step == 2)
        {
            if (!await Operation("Apply", Values())) return;
            configured = true; if (!await Operation("Start", null)) return;
            ShowStep(3); await IssueCode(); return;
        }
        if (step == 1)
        {
            Uri address; int localPort;
            if (String.IsNullOrWhiteSpace(name.Text) || !Directory.Exists(folder.Text)) { status.Text = "PC 이름과 존재하는 작업 폴더를 선택하세요."; return; }
            if (!Uri.TryCreate(endpoint.Text.Trim(), UriKind.Absolute, out address) || !(address.Scheme == "ws" || address.Scheme == "wss") || !address.AbsolutePath.EndsWith("/socket") || !int.TryParse(port.Text, out localPort)) { status.Text = "PC 연결 주소와 브리지 포트를 확인하세요."; return; }
        }
        ShowStep(step + 1);
    }
    private async Task CheckEnvironment()
    {
        if (busy) return;
        SetBusy(true, "PC 환경을 확인하고 있습니다…");
        try
        {
            var info = await Task.Run(() => Invoke("Check", null));
            existingRoot = Str(info, "installedRoot");
            existingUpdate.Text = existingRoot.Length > 0 ? "기존 " + Str(info, "installedVersion") + " 설정 유지하며 업데이트" : "기존 설치 폴더 선택하여 업데이트";
            bool ready = Bool(info, "nodeSupported") && Bool(info, "desktop") && Bool(info, "cli");
            checks.Text = Mark(Bool(info, "nodeSupported")) + " Node.js 20 이상 (LTS 권장)  " + Str(info, "nodeVersion") + "\n\n" + Mark(Bool(info, "desktop")) + " 공식 Windows 앱 설치\n\n" + Mark(Bool(info, "cli")) + " Codex 실행 환경   ·   " + Mark(Bool(info, "git")) + " Git (파일 순변경 집계)";
            if (!configured)
            {
                loading = true; name.Text = Str(info, "name"); folder.Text = Str(info, "cwd");
                bind.Items.Clear(); bind.Items.Add("127.0.0.1");
                object addresses;
                if (info.TryGetValue("addresses", out addresses)) foreach (var item in addresses as object[] ?? new object[0]) { var row = item as Dictionary<string, object>; if (row != null) bind.Items.Add(Str(row, "address")); }
                bind.Items.Add("0.0.0.0"); bind.Items.Add("::");
                var config = Dict(info, "endpoint");
                var relay = Dict(info, "relay"); mobileAddressUrl = Str(relay, "websocketUrl"); canonicalAddressUrl = Str(relay, "canonicalUrl");
                relayAdmin = Dict(relay, "admin");
                if (config.Count > 0)
                {
                    provider.SelectedIndex = Math.Max(0, Array.IndexOf(providerIds, Str(config, "provider"))); endpoint.Text = Str(config, "websocketUrl"); bind.Text = Str(config, "bindAddress"); if (bind.Text.Length == 0) bind.Text = "127.0.0.1";
                    port.Text = Str(config, "localPort"); sshHost.Text = Str(config, "sshHost"); reversePort.Text = Str(config, "reversePort"); if (reversePort.Text.Length == 0) reversePort.Text = "14545";
                    sshPortValue = Str(config, "sshPort"); sshIdentityValue = Str(config, "sshIdentityFile"); relayId = Str(config, "relayId");
                }
                else { bind.SelectedIndex = bind.Items.Count > 3 ? 1 : 0; DirectAddress(); }
                autoStart.Checked = config.Count == 0 || Bool(info, "autoStart"); shared.Checked = config.Count == 0 || Bool(info, "shared"); loading = false; ModeChanged();
            }
            status.Text = ready ? "필수 환경이 준비되었습니다. 연결 설정을 계속하세요." : "Node.js 설치와 공식 앱 로그인·첫 실행을 마친 뒤 환경을 다시 확인하세요.";
            next.Enabled = ready || step > 0;
        }
        catch (Exception e) { status.Text = e.Message; next.Enabled = false; }
        finally { busy = false; main.Enabled = true; back.Enabled = step > 0; }
    }
    private async Task<bool> Operation(string action, Dictionary<string, object> values)
    {
        if (busy) return false;
        SetBusy(true, action == "Test" ? "연결 경로를 확인하고 있습니다…" : action == "Apply" ? "설정을 확인하고 연결 호스트를 재설정하고 있습니다…" : "설정을 진행하고 있습니다…");
        try { var result = await Task.Run(() => Invoke(action, values)); status.Text = Str(result, "message"); if (action == "Start") sharedStatus = Str(result, "sharedStatus"); return true; }
        catch (Exception e) { status.Text = e.Message; return false; }
        finally { SetBusy(false, null); }
    }
    private async Task ConfigureRelay()
    {
        if (busy) return;
        Dictionary<string, object> discovered;
        SetBusy(true, "Windows의 SSH 별칭과 키 경로를 확인하고 있습니다…");
        try { discovered = preview ? new Dictionary<string, object>() : await Task.Run(() => Invoke("RelayDiscover", null)); }
        catch (Exception e) { status.Text = e.Message; return; }
        finally { SetBusy(false, null); }
        using (var dialog = new Form { Text = "PC 전용 WSS · SSH 서버 자동 구성", ClientSize = new Size(736, 690), StartPosition = FormStartPosition.CenterParent, Font = Font, ForeColor = ink, BackColor = BackColor, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false })
        {
            var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24) }; dialog.Controls.Add(panel);
            var hint = new Label { Text = "서버 관리자 SSH 인증으로 Nginx 경로를 등록합니다.\n자동 터널은 이 PC 전용 키로 연결하며 관리자 비밀번호를 저장하지 않습니다.", Location = new Point(24, 19), Size = new Size(686, 57) }; panel.Controls.Add(hint);
            var server = new ComboBox { DropDownStyle = ComboBoxStyle.DropDown };
            TextBox sshPort = new TextBox { Text = Str(relayAdmin, "sshPort").Length > 0 ? Str(relayAdmin, "sshPort") : "22" }, domain = new TextBox { Text = Str(relayAdmin, "domain") }, key = new TextBox { Text = Str(relayAdmin, "identityFile") }, snippet = new TextBox { Text = Str(relayAdmin, "nginxSnippet") };
            Field(panel, server, "관리자 SSH (예: user@server.example.com)", 24, 92, 472); Field(panel, sshPort, "SSH 포트", 520, 92, 190);
            Field(panel, domain, "TLS 도메인 (예: remote.example.com)", 24, 178, 686);
            Field(panel, key, "관리자 SSH 키 파일 (비우면 Windows SSH 설정 사용)", 24, 264, 539);
            Button(panel, "키 선택…", 577, 290, 133, (s, e) => { using (var file = new OpenFileDialog { Title = "서버 관리자 SSH 키 선택", Filter = "SSH 키|*.*", CheckFileExists = true }) { if (file.ShowDialog(dialog) == DialogResult.OK) key.Text = file.FileName; } });
            Field(panel, snippet, "Nginx TLS 설정 파일 (예: /etc/nginx/snippets/remote.conf)", 24, 350, 686);
            var sudo = new CheckBox { Checked = Bool(relayAdmin, "sudo"), Text = "서버에서 허용된 WSS 구성 권한 사용 (root 계정은 체크 해제)", Location = new Point(24, 426), Size = new Size(686, 31) }; panel.Controls.Add(sudo);
            var progress = new Label { Text = "기존 TLS 인증서가 필요합니다. 서버 구성 후 PC 설정 적용 단계로 돌아옵니다.", Location = new Point(24, 470), Size = new Size(686, 74), AutoEllipsis = true }; panel.Controls.Add(progress);
            var automatic = Button(panel, "저장된 SSH 인증으로 자동 구성", 24, 558, 352, (s, e) => {});
            var login = Button(panel, "SSH 로그인 창으로 진행…", 393, 558, 317, (s, e) => {});
            var close = Button(panel, "닫기", 577, 623, 133, (s, e) => dialog.Close());
            object profiles;
            var options = discovered.TryGetValue("profiles", out profiles) ? profiles as object[] ?? new object[0] : new object[0];
            foreach (var item in options) { var profile = item as Dictionary<string, object>; if (profile != null) server.Items.Add(Str(profile, "alias")); }
            server.Text = Str(relayAdmin, "sshHost").Length > 0 ? Str(relayAdmin, "sshHost") : sshHost.Text.Length > 0 && !sshHost.Text.StartsWith("pocketremote@") ? sshHost.Text : "";
            Action selectProfile = () => { foreach (var item in options) { var profile = item as Dictionary<string, object>; if (profile != null && Str(profile, "alias") == server.Text) { sshPort.Text = Str(profile, "port"); sudo.Checked = Str(profile, "user") != "root"; } } };
            server.SelectedIndexChanged += (s, e) => selectProfile(); selectProfile();
            bool configuring = false; dialog.FormClosing += (s, e) => { if (configuring) e.Cancel = true; };
            Func<string, Task> configure = async action => {
                automatic.Enabled = login.Enabled = close.Enabled = false; server.Enabled = sshPort.Enabled = domain.Enabled = key.Enabled = snippet.Enabled = sudo.Enabled = false;
                configuring = true;
                progress.Text = action == "RelayLogin" ? "SSH 창에서 서버의 호스트 키와 로그인 정보를 확인하세요…" : "서버 인증과 PC 전용 경로를 구성하고 있습니다…";
                try {
                    var values = new Dictionary<string, object> { { "sshHost", server.Text.Trim() }, { "sshPort", sshPort.Text.Trim() }, { "identityFile", key.Text.Trim() }, { "domain", domain.Text.Trim() }, { "nginxSnippet", snippet.Text.Trim() }, { "sudo", sudo.Checked } };
                    var result = await Task.Run(() => Invoke(action, values));
                    if (Bool(result, "loginRequired")) { progress.Text = Str(result, "message"); return; }
                    sshPortValue = Str(result, "sshPort"); sshIdentityValue = Str(result, "sshIdentityFile"); relayId = Str(result, "relayId");
                    mobileAddressUrl = Str(result, "websocketUrl"); canonicalAddressUrl = Str(result, "canonicalUrl");
                    provider.SelectedIndex = 2; sshHost.Text = Str(result, "sshHost"); reversePort.Text = Str(result, "reversePort"); endpoint.Text = Str(result, "websocketUrl");
                    status.Text = Str(result, "message"); configuring = false; dialog.Close();
                } catch (Exception e) { progress.Text = e.Message; }
                finally { configuring = false; if (!dialog.IsDisposed) { automatic.Enabled = login.Enabled = close.Enabled = true; server.Enabled = sshPort.Enabled = domain.Enabled = key.Enabled = snippet.Enabled = sudo.Enabled = true; } }
            };
            automatic.Click += async (s, e) => await configure("RelayProvision"); login.Click += async (s, e) => await configure("RelayLogin");
            if (preview && relayPreviewPath.Length > 0) {
                dialog.ShowInTaskbar = false; dialog.Opacity = 0; dialog.StartPosition = FormStartPosition.Manual; dialog.Location = new Point(-32000, -32000); dialog.Show(); Application.DoEvents(); dialog.PerformLayout();
                using (var bitmap = new Bitmap(dialog.Width, dialog.Height)) { dialog.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size)); bitmap.Save(relayPreviewPath, ImageFormat.Png); }
            } else dialog.ShowDialog(this);
        }
    }
    private async Task UpgradeExisting()
    {
        if (busy || preview) return;
        string target = existingRoot;
        if (target.Length == 0)
        {
            using (var dialog = new FolderBrowserDialog { Description = "0.8.5 등 기존 Pocket Remote 설치 폴더", ShowNewFolderButton = false })
            { if (dialog.ShowDialog(this) != DialogResult.OK) return; target = dialog.SelectedPath; }
        }
        await Operation("UpdateExisting", new Dictionary<string, object> { { "installRoot", target } });
    }
    private async Task IssueCode()
    {
        if (busy) return; SetBusy(true, "8자리 페어링 코드를 발급하고 있습니다…");
        try { var result = await Task.Run(() => Invoke("Pair", null)); pairCode.Text = Str(result, "code"); expiresAt = Convert.ToInt64(result["expiresAt"]); UpdateExpiry(); status.Text = "휴대폰 앱에서 QR코드를 스캔하고 연결하세요. " + sharedStatus;
            var data = Str(result, "qrData"); if (data.Length < 100000 && data.StartsWith("data:image/gif;base64,")) { using (var stream = new MemoryStream(Convert.FromBase64String(data.Substring(data.IndexOf(',') + 1)))) using (var sample = Image.FromStream(stream)) SetPairingImage(sample); }
        }
        catch (Exception e) { status.Text = e.Message; pairCode.Text = "--------"; expiresAt = 0; UpdateExpiry(); }
        finally { SetBusy(false, null); }
    }
    private Dictionary<string, object> Invoke(string action, Dictionary<string, object> values)
    {
        var shell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
        var start = new ProcessStartInfo { FileName = shell, Arguments = "-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File " + Quote(Path.Combine(root, "SETUP-REMOTE.ps1")) + " -Action " + action, WorkingDirectory = root, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 };
        using (var process = Process.Start(start))
        {
            var output = process.StandardOutput.ReadToEndAsync(); var error = process.StandardError.ReadToEndAsync();
            if (values != null) process.StandardInput.Write(json.Serialize(values)); process.StandardInput.Close();
            process.WaitForExit(); string text = output.Result; error.Wait();
            Dictionary<string, object> result;
            try { result = json.Deserialize<Dictionary<string, object>>(text.Trim()); } catch { throw new Exception("설정을 완료하지 못했습니다. PC 패키지와 필수 프로그램을 확인하세요."); }
            if (!Bool(result, "ok")) throw new Exception(Str(result, "error"));
            return Dict(result, "result");
        }
    }
    private async void Firewall(object sender, EventArgs e)
    {
        if (busy) return;
        using (var dialog = new Form { Text = "허용할 LAN / VPN 범위", ClientSize = new Size(480, 172), StartPosition = FormStartPosition.CenterParent, Font = Font, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false })
        {
            var label = new Label { Text = "LocalSubnet 또는 VPN 클라이언트 IP / CIDR을 입력하세요.", Location = new Point(16, 14), Size = new Size(451, 35) }; dialog.Controls.Add(label);
            var scope = new TextBox { Text = "LocalSubnet", Location = new Point(16, 59), Size = new Size(446, 30) }; dialog.Controls.Add(scope);
            var allow = new Button { Text = "Windows 권한으로 허용", Location = new Point(243, 112), Size = new Size(218, 36), DialogResult = DialogResult.OK }; StyleButton(allow, true); dialog.Controls.Add(allow); dialog.AcceptButton = allow;
            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            int rulePort; if (!int.TryParse(port.Text, out rulePort) || rulePort < 1024 || rulePort > 65535 || !System.Text.RegularExpressions.Regex.IsMatch(scope.Text, "^(LocalSubnet|[a-fA-F0-9:.,/]+)$")) { status.Text = "허용할 IP 범위와 포트를 확인하세요."; return; }
            SetBusy(true, "Windows 방화벽 권한 승인을 기다리고 있습니다…");
            try
            {
                int exit = await Task.Run(() => { using (var process = Process.Start(new ProcessStartInfo { FileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe"), Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File " + Quote(Path.Combine(root, "SETUP-FIREWALL.ps1")) + " -Port " + rulePort + " -RemoteAddress " + Quote(scope.Text), UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden, WorkingDirectory = root })) { process.WaitForExit(); return process.ExitCode; } });
                status.Text = exit == 0 ? "선택한 LAN/VPN 범위의 방화벽 규칙을 적용했습니다." : "방화벽 규칙을 적용하지 못했습니다. 포트와 관리자 권한을 확인하세요.";
            }
            catch { status.Text = "방화벽 허용을 완료하지 않았습니다. 기존 설정은 유지됩니다."; }
            finally { SetBusy(false, null); }
        }
    }
    private void SetBusy(bool value, string message) { busy = value; main.Enabled = !value; if (message != null) status.Text = message; }
    private void UpdateExpiry() { long left = Math.Max(0, (expiresAt - Now()) / 1000); pairExpiry.Text = expiresAt == 0 ? "새 코드를 발급해 주세요." : left == 0 ? "코드가 만료되었습니다. 새 코드를 발급해 주세요." : "유효시간 " + (left / 60) + ":" + (left % 60).ToString("00") + " · 1회 사용"; if (left == 0) pairCode.ForeColor = Color.Gray; else pairCode.ForeColor = ink; }
    private static long Now() { return (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalMilliseconds; }
    private void Copy(string value) { try { Clipboard.SetText(value); status.Text = "복사했습니다."; } catch { status.Text = "클립보드에 복사하지 못했습니다. 표시된 내용을 직접 입력하세요."; } }
    private static void Open(string url) { try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch { } }
    private static string Quote(string value) { if (value.IndexOfAny(new[] { '"', '\r', '\n' }) >= 0) throw new ArgumentException("잘못된 경로입니다."); return "\"" + value + "\""; }
    private static string Mark(bool value) { return value ? "✓" : "○"; }
    private static string Str(Dictionary<string, object> d, string key) { object value; return d.TryGetValue(key, out value) && value != null ? Convert.ToString(value) : ""; }
    private static bool Bool(Dictionary<string, object> d, string key) { object value; return d.TryGetValue(key, out value) && value is bool && (bool)value; }
    private static Dictionary<string, object> Dict(Dictionary<string, object> d, string key) { object value; return d.TryGetValue(key, out value) && value is Dictionary<string, object> ? (Dictionary<string, object>)value : new Dictionary<string, object>(); }
    private void SeedPreview() { name.Text = "집 PC"; folder.Text = "C:\\Projects"; bind.Items.Add("192.168.0.10"); bind.SelectedIndex = 0; provider.SelectedIndex = 0; endpoint.Text = "ws://192.168.0.10:4545/socket"; checks.Text = "✓ Node.js 22 이상   v24.13.0\n\n✓ 공식 Windows 앱 설치\n\n✓ Codex 실행 환경   ·   ✓ Git (파일 순변경 집계)"; pairCode.Text = "M7QK8R2X"; expiresAt = Now() + 300000; UpdateExpiry(); status.Text = "표시 검증용 합성 환경 · 실제 PC 설정을 변경하지 않습니다."; }
    private void SetPairingImage(Image image) { var old = pairingImage.Image; pairingImage.Image = new Bitmap(image); if (old != null) old.Dispose(); }
    protected override bool ShowWithoutActivation { get { return preview; } }
}

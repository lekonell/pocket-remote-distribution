// All session panel state is scoped to both desktop profile and thread.
const sessionUI = { records: new Map(), busy: new Set(), rootLookup: null, panel: null, selected: '', revision: 0 };
sessionUI.contexts=new Map();sessionUI.contextFlights=new Map();sessionUI.contextRevision=0;
const agentStatusLabel = status => ({ starting: '시작 준비', running: '작업 중', idle: '대기 중', completed: '완료', interrupted: '중단됨', failed: '오류', stopped: '종료됨', unavailable: '확인 불가' })[status] || '대기 중';
const agentPathName = path => String(path || '').split('/').filter(Boolean).at(-1)?.replace(/[_-]+/g, ' ') || '서브 에이전트';
const agentRecentWindow = 24 * 60 * 60 * 1000;
function agentActivityTime(...values) {
  return Math.max(0, ...values.map(value => {
    if (value == null || value === '') return 0;
    const n = typeof value === 'number' || /^\d+(?:\.\d+)?$/.test(String(value)) ? Number(value) : Date.parse(value);
    return Number.isFinite(n) && n > 0 ? (n < 1e11 ? n * 1000 : n) : 0;
  }));
}
function recentSessionAgents(agents, now = Date.now()) {
  return agents.filter(a => {
    if (['running', 'starting'].includes(a.status)) return true;
    const at = agentActivityTime(a.lastActivityAt, a.updatedAt, a.createdAt);
    return !at || now - at < 3 * 24 * 60 * 60 * 1000;
  });
}
function showAgentChip(agents, now = Date.now()) {
  if (!agents.length) return false;
  if (agents.some(a => ['running', 'starting'].includes(a.status))) return true;
  const times = agents.map(a => agentActivityTime(a.lastActivityAt, a.updatedAt, a.createdAt));
  // Preserve access when an old PC cannot supply any activity date.
  return times.some(at => !at) || now - Math.max(...times) <= agentRecentWindow;
}
async function fillLegacyAgentActivity(record, threadId) {
  if (!record.agents.some(a => !agentActivityTime(a.lastActivityAt)) || Date.now() - (record.activityCheckedAt || 0) < 60000) return;
  record.activityCheckedAt = Date.now();
  try {
    let cursor; const seen = new Set();
    for (let page = 0; page < 20; page++) {
      const result = await rpc('thread/list', { ancestorThreadId: threadId, useStateDbOnly: true, sourceKinds: ['subAgent', 'subAgentThreadSpawn', 'subAgentOther'], limit: 100, sortKey: 'created_at', ...(cursor ? { cursor } : {}) });
      for (const t of result.data || []) {
        const agent = record.agents.find(a => a.id === t.id);
        if (agent) agent.lastActivityAt = agentActivityTime(agent.lastActivityAt, t.updatedAt, t.createdAt);
      }
      if (!record.agents.some(a => !agentActivityTime(a.lastActivityAt)) || !result.nextCursor || seen.has(result.nextCursor)) break;
      cursor = result.nextCursor; seen.add(cursor);
    }
  } catch {}
}
function sessionScope(id = state.currentId) { return connectionStore.activeId + ':' + id; }
function agentThreadSource(thread = {}) {
  let source=thread?.source;
  if(typeof source==='string'&&source.startsWith('{'))try{source=JSON.parse(source);}catch{}
  return source;
}
function agentParentThreadId(thread = {}) {
  const source=agentThreadSource(thread),agent=source?.subAgent??source?.subagent;
  return thread?.parentThreadId||agent?.thread_spawn?.parent_thread_id||'';
}
function rememberedAgentRoot(id = state.currentId) {
  const root=saved('remote.agentRoot.'+id);
  return typeof root==='string'&&root&&root!==id&&root.length<=100?root:'';
}
function isSubagentConversation(thread = state.current) {
  if(!thread?.id)return false;
  const source=agentThreadSource(thread);
  return !!(agentParentThreadId(thread)||source?.subAgent!=null||source?.subagent!=null||typeof source==='string'&&source.startsWith('subAgent')||rememberedAgentRoot(thread.id));
}
async function resolveAgentRoot(thread = state.current) {
  const known=rememberedAgentRoot(thread?.id);if(known)return known;
  const scope=sessionScope(),socket=state.socket,epoch=state.epoch,seen=new Set();let current=thread;
  const valid=()=>scope===sessionScope()&&socket===state.socket&&epoch===state.epoch&&!state.leaving;
  for(let depth=0;depth<32&&current?.id;depth++){
    if(!valid())return '';
    if(seen.has(current.id))throw Error('대화 연결 정보를 다시 확인해 주세요.');seen.add(current.id);
    const cached=rememberedAgentRoot(current.id),parent=agentParentThreadId(current);
    if(cached||!parent&&!isSubagentConversation(current)){
      const root=cached||current.id;
      for(const id of seen)if(id!==root)persist('remote.agentRoot.'+id,root);
      return root;
    }
    if(!parent)throw Error('루트 대화 정보를 확인하지 못했습니다. PC 연결을 확인하고 다시 눌러주세요.');
    const listed=state.threads.find(t=>t.id===parent),metadata=listed||saved('remote.meta.'+parent);
    if(listed||metadata&&(Object.hasOwn(metadata,'source')||Object.hasOwn(metadata,'parentThreadId')))current=metadata;
    else{
      if(!state.online)throw Error('PC에 연결한 뒤 루트 대화를 확인할 수 있습니다.');
      const result=await rpc('thread/read',{threadId:parent,includeTurns:false});if(!valid())return '';
      current=result.thread;if(current?.id!==parent)throw Error('루트 대화 정보를 다시 확인해 주세요.');
    }
  }
  throw Error('루트 대화 연결 정보를 다시 확인해 주세요.');
}
async function openAgentConversation(id,scope = sessionScope()) {
  if(scope!==sessionScope()||state.leaving)return;
  const root=isSubagentConversation()?await resolveAgentRoot():state.currentId;
  if(scope!==sessionScope()||state.leaving||!root||id===state.currentId)return;
  let focus;
  if(state.online&&state.serverCapabilities?.agentHistoryFocus){
    const detail=await rpc('bridge/agents/read',{threadId:state.currentId,agentId:id,focus:true});
    if(scope!==sessionScope()||state.leaving)return;
    focus={page:detail.focusPage,fromOlder:detail.focusFromOlder,itemId:detail.focusItemId,report:detail.reportedResult};
  }
  persist('remote.agentRoot.'+id,root);
  closePicker();await openThread(id,true,null,focus);
}
function conversationTitle(thread=state.current){
  if(!isSubagentConversation(thread))return thread?.name||thread?.preview||'새 대화';
  const context=sessionUI.contexts.get(sessionScope(thread.id))||saved('remote.agentContext.'+thread.id);
  if(context?.title)return context.title;
  const source=agentThreadSource(thread),spawn=(source?.subAgent??source?.subagent)?.thread_spawn;
  const name=spawn?.agent_path?agentPathName(spawn.agent_path):thread.agentNickname||thread.name||'서브 에이전트';
  const parent=state.threads?.find(t=>t.id===agentParentThreadId(thread))||saved('remote.meta.'+agentParentThreadId(thread));
  return [name,parent?.name||thread.agentNickname].filter(Boolean).join(' · ');
}
async function refreshAgentConversation(force=false){
  if(!state.subagentView||!state.online||document.hidden||!state.serverCapabilities?.agentConversationContext)return;
  const scope=sessionScope(),id=state.currentId,socket=state.socket,epoch=state.epoch,revision=sessionUI.contextRevision;
  if(sessionUI.contextFlights.has(scope))return sessionUI.contextFlights.get(scope);
  const old=sessionUI.contexts.get(scope);if(!force&&old?.socket===socket&&Date.now()-old.at<2000)return;
  const valid=()=>scope===sessionScope()&&socket===state.socket&&epoch===state.epoch&&revision===sessionUI.contextRevision&&!state.leaving;
  const work=rpc('bridge/agents/context',{threadId:id}).then(result=>{
    if(!valid())return;
    sessionUI.contexts.set(scope,{...result,socket,at:Date.now()});while(sessionUI.contexts.size>16)sessionUI.contexts.delete(sessionUI.contexts.keys().next().value);
    if(result.title)persist('remote.agentContext.'+id,{title:result.title,name:result.name,rootTitle:result.rootTitle,rootThreadId:result.rootThreadId,nickname:result.nickname});
    $('threadTitle').textContent=conversationTitle();$('threadTitle').title=[result.title,result.nickname].filter(Boolean).join(' · ');
    if(!document.hidden&&!globalThis.userMessageNavigation?.busy){
      const root=$('transcript'),top=root.getBoundingClientRect().top,anchor=[...root.children].find(n=>n.getBoundingClientRect().bottom>top),offset=anchor?.getBoundingClientRect().top,pinned=root.scrollHeight-root.scrollTop-root.clientHeight<150;
      renderTranscript();if(!pinned&&anchor?.isConnected)root.scrollTop+=anchor.getBoundingClientRect().top-offset;
    }
    if(result.loading)setTimeout(()=>{if(valid())refreshAgentConversation(true);},1000);
  }).catch(()=>{}).finally(()=>{if(sessionUI.contextFlights.get(scope)===work)sessionUI.contextFlights.delete(scope);});
  sessionUI.contextFlights.set(scope,work);return work;
}
function agentConversationEntries(entries){
  if(!state.subagentView)return entries;
  const time=e=>agentActivityTime(e.startedAtMs)||agentActivityTime(e.completedAtMs),context=sessionUI.contexts.get(sessionScope()),dates=entries.map(time).filter(Boolean),ids=new Set(entries.map(e=>e.item.id));
  if(!context?.instructions?.length||!dates.length)return entries;
  const low=Math.min(...dates),high=Math.max(...entries.map(e=>agentActivityTime(e.startedAtMs,e.completedAtMs)));
  const instructions=context.instructions.filter(e=>!ids.has(e.item.id)&&(!state.historyWindow?.olderCursor||e.startedAtMs>=low)&&(!state.historyMode||!state.historyWindow?.newerCursor||e.startedAtMs<=high));
  const result=[];let index=0;
  for(const entry of entries){const at=time(entry);while(index<instructions.length&&at&&instructions[index].startedAtMs<=at)result.push(instructions[index++]);result.push(entry);}
  result.push(...instructions.slice(index));return result;
}
function renderSubagentNavigation() {
  const bar=$('agentReturnBar'),button=$('returnToRootButton');if(!bar||!button)return;
  state.subagentView=isSubagentConversation();
  $('chatView').classList.toggle('subagent-conversation',state.subagentView);
  bar.classList.toggle('hidden',!state.subagentView);if(!state.subagentView){$('threadTitle').title=conversationTitle();return;}
  $('threadTitle').textContent=conversationTitle();refreshAgentConversation();
  const scope=sessionScope(),root=rememberedAgentRoot(),socket=state.socket,epoch=state.epoch;
  let lookup=sessionUI.rootLookup;
  if(!root&&(lookup?.scope!==scope||lookup.socket!==socket||lookup.epoch!==epoch)){
    lookup={scope,socket,epoch,pending:true,error:''};sessionUI.rootLookup=lookup;
    resolveAgentRoot().then(()=>{},e=>{lookup.error=e.message;}).finally(()=>{
      lookup.pending=false;if(scope===sessionScope()&&sessionUI.rootLookup===lookup)renderSubagentNavigation();
    });
  }
  button.textContent=!root&&lookup?.pending?'루트 대화 확인 중…':'‹ 루트 대화로 돌아가기';
  button.disabled=!root&&!!lookup?.pending;
  $('agentReturnNote').textContent=root?'':lookup?.error||'';
  button.onclick=async()=>{
    const origin=sessionScope(),profile=connectionStore.activeId;
    button.disabled=true;
    try{
      const target=rememberedAgentRoot()||await resolveAgentRoot();
      if(!target||origin!==sessionScope()||profile!==connectionStore.activeId||state.leaving)return;
      closeMenus();await openThread(target);
    }catch(e){if(origin===sessionScope())$('agentReturnNote').textContent=e.message;}
    finally{if(origin===sessionScope())button.disabled=false;}
  };
}
function sessionRecord(id = state.currentId) {
  const key = sessionScope(id);
  if (!sessionUI.records.has(key)) sessionUI.records.set(key, { agents: [], nextCursor: null, warning: '' });
  while (sessionUI.records.size > 40) sessionUI.records.delete(sessionUI.records.keys().next().value);
  return sessionUI.records.get(key);
}
function capturePanelScroll(scroller) {
  const top = scroller.scrollTop, bounds = scroller.getBoundingClientRect(), edge = bounds.top;
  const cards = [...scroller.querySelectorAll('.agent-card,.changed-file')];
  const visible = n => { const r = n.getBoundingClientRect(); return r.bottom > edge && r.top < bounds.bottom; };
  const anchor = cards.find(n => n.querySelector('.agent-heading[aria-expanded="true"]') && visible(n)) || cards.find(visible);
  const offset = anchor?.getBoundingClientRect().top;
  return () => {
    if (anchor?.isConnected) scroller.scrollTop += anchor.getBoundingClientRect().top - offset;
    else scroller.scrollTop = top;
  };
}
function preservePanelScroll(scroller, change) {
  const restore = capturePanelScroll(scroller); change(); restore();
}
function syncPanelChildren(root, nodes) {
  let at = root.firstChild;
  for (const node of nodes) { if (at !== node) root.insertBefore(node, at); at = node.nextSibling; }
  while (at) { const next = at.nextSibling; at.remove(); at = next; }
}
function semanticItem(item, entry) {
  const status = ({ inProgress: '진행 중', completed: '완료', failed: '실패', declined: '거절됨' })[item.status] || '';
  switch (item.type) {
    case 'agentInstruction': return {label:(item.sender||'루트')+'에서 받은 지시',text:item.text};
    case 'contextCompaction': return { label: '', text: entry.liveComplete === false ? '문맥 압축 중…' : '컨텍스트 압축됨', compact: true };
    case 'subAgentActivity': return { label: '', text: '♙ ' + agentPathName(item.agentPath) + '의 ' + ({ started: '작업 시작됨', interacted: '작업에 추가 지시 전달됨', interrupted: '작업 중단됨', completed: '작업 완료됨' })[item.kind], compact: true, agentId: item.agentThreadId };
    case 'collabAgentToolCall': return { label: '서브 에이전트', text: ({ spawnAgent: '새 작업 시작', sendInput: '추가 지시 전달', sendMessage: '메시지 전달', followupTask: '후속 작업 지시', interruptAgent: '작업 중단', listAgents: '작업 목록 확인', wait: '작업 완료 대기', closeAgent: '작업 종료', resumeAgent: '작업 재개' })[item.tool] || '작업 연결', agentId: item.receiverThreadIds?.[0] };
    case 'enteredReviewMode': return { label: '검토 시작', text: item.review || '변경 사항을 검토합니다.', compact: true };
    case 'exitedReviewMode': return { label: '검토 완료', text: item.review || '변경 사항 검토를 마쳤습니다.', compact: true };
    case 'hookPrompt': return { label: '자동화 지시', text: (item.fragments || []).map(f => f.text || f.prompt || '').filter(Boolean).join('\n') || '설정된 자동화 지시가 적용되었습니다.' };
    case 'sleep': return { label: '대기', text: status || '다음 작업을 기다리는 중', compact: true };
    case 'fileChange': return { label: '파일 변경', text: (item.changes || []).map(c => c.path + ' · ' + ({ add: '추가', delete: '삭제', update: '수정' })[c.kind?.type || c.kind]).join('\n') || '파일 변경' };
    case 'mcpToolCall': return { label: '도구', text: [item.server, item.tool, status].filter(Boolean).join(' · ') };
    case 'dynamicToolCall': return { label: '도구', text: [item.namespace, item.tool, status].filter(Boolean).join(' · ') };
    default: return null;
  }
}
function renderSemanticItem(article, entry) {
  const semantic = semanticItem(entry.item, entry);
  article.classList.toggle('semantic-event', !!semantic?.compact);
  article.kindNode.textContent = semantic?.label ?? article.kindNode.textContent;
  if (semantic?.compact && !semantic.agentId) article.bodyNode.textContent = semantic.text;
  if (!semantic?.agentId) return;
  article.bodyNode.replaceChildren(action(semantic.text + ' ›', () => agentPanel(semantic.agentId), 'agent-event-button'));
}
function renderSessionChips() {
  const root = $('sessionBar'); if (!root) return;
  const record = sessionRecord();
  const changes = typeof changesRecord === 'function' ? changesRecord() : null;
  const agents = recentSessionAgents(record.agents), showAgents = showAgentChip(agents);
  const key = JSON.stringify([sessionScope(), showAgents, agents.map(a => [a.id, a.status]), changes && [changes.mode, changes.files.length, changes.additions, changes.deletions, changes.scanning, changes.available, changes.supported]]);
  if (root.remoteKey === key) return;
  root.remoteKey = key;
  root.replaceChildren();
  if (showAgents) {
    const running = agents.filter(a => ['running', 'starting'].includes(a.status)).length;
    root.append(action('♙ 에이전트 ' + agents.length + (running ? ' · ' + running + ' 작업 중' : ''), () => agentPanel(), 'session-chip'));
  }
  if (typeof renderChangesChip === 'function') renderChangesChip(root);
  root.classList.toggle('hidden', !root.children.length);
}
async function refreshSessionAgents(more = false) {
  if (!state.currentId || !state.online || document.hidden || globalThis.pocketDots?.ui.open) return;
  const id = state.currentId, scope = sessionScope(id), record = sessionRecord(id);
  if (sessionUI.busy.has(scope)) return;
  sessionUI.busy.add(scope);
  try {
    const result = await rpc('bridge/agents/list', { threadId: id, ...(more && record.nextCursor ? { cursor: record.nextCursor } : {}) });
    if (scope !== sessionScope()) return;
    const agents = more ? [...record.agents, ...result.agents] : result.agents || [];
    const previous = new Map(record.agents.map(a => [a.id, a]));
    record.agents = [...new Map(agents.map(a => [a.id, { ...a, lastActivityAt: agentActivityTime(a.lastActivityAt, previous.get(a.id)?.lastActivityAt) }])).values()]; record.nextCursor = result.nextCursor; record.warning = result.warning || '';
    await fillLegacyAgentActivity(record, id);
    if (scope !== sessionScope()) return;
    renderSessionChips();
    if (sessionUI.panel === scope && !$('pickerOverlay').classList.contains('hidden')) await drawAgentPanel();
  } catch (e) { if (sessionUI.panel === scope) $('pickerSubtitle').textContent = e.message; }
  finally { sessionUI.busy.delete(scope); }
}
async function agentPanel(id = '') {
  picker('서브 에이전트', '각 작업의 진행 상황을 실시간으로 확인합니다.');
  sessionUI.panel = sessionScope(); sessionUI.selected = id;
  await refreshSessionAgents();
  if (sessionUI.panel === sessionScope() && !$('pickerOverlay').classList.contains('hidden')) await drawAgentPanel();
}
async function drawAgentPanel() {
  const scope = sessionScope(), record = sessionRecord(), root = $('pickerContent');
  if (sessionUI.panel !== scope) return;
  const restoreScroll = capturePanelScroll(root.closest('.sheet'));
  if (root.agentScope !== scope || !root.agentControls?.isConnected) {
    root.replaceChildren(); root.agentScope = scope; root.agentNodes = new Map();
    const controls = el('label', '정렬 ', 'agent-sort'), select = el('select'); select.setAttribute('aria-label', '서브 에이전트 정렬');
    for (const [value, text] of [['status', '상태순'], ['name', '이름순'], ['original', '생성순']]) { const option = el('option', text); option.value = value; select.append(option); }
    select.value = saved('remote.agentSort') || 'status';
    select.onchange = () => { persist('remote.agentSort', select.value); drawAgentPanel(); root.closest('.sheet').scrollTop = 0; };
    controls.append(select); root.agentControls = controls; root.agentSort = select; root.agentNote = el('p', undefined, 'muted'); root.agentMore = action('작업 더 보기', () => refreshSessionAgents(true), 'ghost full');
  }
  const rank = { running: 0, starting: 1, failed: 2, idle: 3, interrupted: 4, completed: 5, stopped: 6, unavailable: 7 };
  const agents = recentSessionAgents(record.agents);
  if (root.agentSort.value === 'status') agents.sort((a, b) => (rank[a.status] ?? 3) - (rank[b.status] ?? 3));
  if (root.agentSort.value === 'name') agents.sort((a, b) => a.name.localeCompare(b.name, 'ko'));
  const nodes = [root.agentControls];
  root.agentNote.textContent = record.warning || (!agents.length ? '이 세션에는 서브 에이전트 작업이 없습니다.' : '');
  if (root.agentNote.textContent) nodes.push(root.agentNote);
  for (const agent of agents) {
    let section = root.agentNodes.get(agent.id);
    if (!section) {
      section = el('section', undefined, 'agent-card'); section.dataset.agentId = agent.id;
      const head = action('', () => { sessionUI.selected = sessionUI.selected === agent.id ? '' : agent.id; drawAgentPanel(); }, 'agent-heading');
      section.titleNode = el('strong'); section.stateNode = el('span'); section.arrowNode = el('span'); head.append(section.titleNode, section.stateNode, section.arrowNode);
      section.headNode = head; section.taskNode = el('p', undefined, 'agent-task'); section.detailsNode = el('div', undefined, 'agent-details');
      section.append(head, section.taskNode, section.detailsNode); root.agentNodes.set(agent.id, section);
    }
    const selected = sessionUI.selected === agent.id;
    section.dataset.status = agent.status; section.titleNode.textContent = agent.name;
    section.stateNode.textContent = agentStatusLabel(agent.status); section.stateNode.className = 'agent-state ' + agent.status;
    section.headNode.setAttribute('aria-expanded', String(selected)); section.arrowNode.textContent = selected ? '⌃' : '⌄';
    section.taskNode.textContent = agent.task || ''; section.taskNode.classList.toggle('hidden', !agent.task); section.detailsNode.classList.toggle('hidden', !selected);
    nodes.push(section);
  }
  if (record.nextCursor) nodes.push(root.agentMore);
  syncPanelChildren(root, nodes); restoreScroll();
  const wanted = new Set(agents.map(a => a.id)); for (const id of root.agentNodes.keys()) if (!wanted.has(id)) root.agentNodes.delete(id);
  const selected = root.agentNodes.get(sessionUI.selected);
  if (selected) refreshAgentDetails(selected, scope);
}
async function refreshAgentDetails(section, scope) {
  if (section.detailBusy) return;
  const selected = section.dataset.agentId, details = section.detailsNode; section.detailBusy = true;
  if (!section.detailParts) {
    const plan = el('div'), planText = el('div'), progress = el('div', undefined, 'agent-progress');
    const result = el('details'), resultBody = el('div'), error = el('p', undefined, 'inline-error'); result.append(el('summary', '결과 보기'), resultBody);
    const open = action('대화 내역 열기 ›', () => openAgentConversation(selected,scope), 'ghost full');
    section.detailParts = { plan, planText, progress, result, resultBody, error, open };
    details.append(plan, planText, progress, result, error, open);
    progress.textContent = '진행 상황을 확인하는 중…';
  }
  try {
    const { agent: a } = await rpc('bridge/agents/read', { threadId: state.currentId, agentId: selected });
    if (scope !== sessionScope() || sessionUI.panel !== scope || sessionUI.selected !== selected || !details.isConnected) return;
    const parts = section.detailParts;
    preservePanelScroll(details.closest('.sheet'), () => {
      parts.error.textContent = '';
      const planKey = JSON.stringify(a.plan || []);
      if (parts.plan.remoteKey !== planKey) { parts.plan.remoteKey = planKey; parts.plan.replaceChildren(...(a.plan || []).map(step => el('div', (({ completed: '✓ ', inProgress: '● ', pending: '○ ' })[step.status] || '○ ') + step.step, 'agent-plan ' + step.status))); }
      for (const [node, text] of [[parts.planText, a.planText], [parts.progress, a.progressText], [parts.resultBody, a.result !== a.progressText ? a.result : '']]) {
        const value = text || ''; if (node.remoteText === value) continue;
        const top = node.scrollTop, left = node.scrollLeft; node.remoteText = value; renderMarkdown(node, value); node.scrollTop = top; node.scrollLeft = left;
      }
      parts.result.classList.toggle('hidden', !parts.resultBody.remoteText);
    });
  } catch (e) { if (scope === sessionScope() && details.isConnected) section.detailParts.error.textContent = e.message; }
  finally { section.detailBusy = false; }
}
function sessionEvent(method, p) {
  if(method==='account/updated'){sessionUI.contextRevision++;sessionUI.contexts.clear();sessionUI.contextFlights.clear();}
  if(method==='pocket/agents/contextChanged'&&p.threadId===state.currentId)refreshAgentConversation(true);
  if (p.item?.type === 'subAgentActivity' || p.item?.type === 'collabAgentToolCall') {
    const record = sessionRecord(p.threadId), item = p.item;
    for (const id of item.type === 'subAgentActivity' ? [item.agentThreadId] : item.receiverThreadIds || []) {
      let a = record.agents.find(a => a.id === id);
      if (!a) { a = { id, name: agentPathName(item.agentPath), status: 'running', task: item.prompt || '' }; record.agents.push(a); }
      if (item.kind) a.status = ({ started: 'running', interrupted: 'interrupted', completed: 'completed' })[item.kind] || a.status;
      a.lastActivityAt = agentActivityTime(a.lastActivityAt, p.timestamp, Date.now());
    }
    if (p.threadId === state.currentId) renderSessionChips();
  }
  if (p.item || ['turn/started', 'turn/completed', 'turn/plan/updated'].includes(method)) {
    for (const [scope, record] of sessionUI.records) {
      if (!scope.startsWith(connectionStore.activeId + ':')) continue;
      const a = record.agents.find(a => a.id === p.threadId);
      if (!a) continue;
      a.lastActivityAt = agentActivityTime(a.lastActivityAt, p.timestamp, Date.now());
      if (method === 'turn/started') a.status = 'running';
      if (method === 'turn/completed') a.status = p.turn?.status === 'failed' ? 'failed' : p.turn?.status === 'interrupted' ? 'interrupted' : 'completed';
    }
    renderSessionChips();
  }
  if (method === 'turn/plan/updated' && p.threadId === state.currentId) scheduleRender();
}
document.addEventListener('DOMContentLoaded', () => {
  setInterval(() => { refreshSessionAgents(); if (!document.hidden) {renderSessionChips();refreshAgentConversation();} }, 5000);
  renderSessionChips();
});

const feature = { attachments: [], mentions: [], files: new Map(), uploads: new Map(), queues: new Map(), goals: new Map(), hashes: new Map(), queueHashes: new Map(), syncing: false, catalog: null, theme: 'system' };
const el = (tag, text, className) => { const n = document.createElement(tag); if (text !== undefined) n.textContent = text; if (className) n.className = className; return n; };
function action(label, fn, className = 'ghost') { const b = el('button', label, className); b.onclick = async () => { try { await fn(); } catch (e) { banner(e.message); } }; return b; }
function closePicker() { $('pickerOverlay').classList.add('hidden'); if (typeof sessionUI !== 'undefined') sessionUI.panel = null; }
function picker(title, subtitle = '') { closeMenus(); if (typeof sessionUI !== 'undefined') sessionUI.panel = null; $('pickerTitle').textContent = title; $('pickerSubtitle').textContent = subtitle; $('pickerContent').replaceChildren(); $('pickerOverlay').classList.remove('hidden'); return $('pickerContent'); }
function pickerRow(root, title, description, fn, { checked = false, disabled = false, icon = '', danger = false } = {}) {
  const b = action('', fn, 'picker-row' + (danger ? ' danger' : ''));
  b.disabled = disabled; const body = el('span', undefined, 'row-body'); body.append(el('strong', title)); if (description) body.append(el('small', description));
  b.append(el('span', icon, 'row-icon'), body, el('span', checked ? '✓' : '', 'row-check')); root.append(b); return b;
}
function selectValue(id, value) { $(id).value = value; $(id).dispatchEvent(new Event('change')); renderControlPills(); }
const efforts = { none: '없음', minimal: '최소', low: 'Low', medium: 'Medium', high: 'High', xhigh: 'Extra High', max: 'Max', ultra: 'Ultra' };
function renderControlPills() {
  const model = state.models.find(x => x.model === $('modelSelect').value);
  $('modelButton').textContent = [model?.displayName || '모델 선택', efforts[$('effortSelect').value] || '', $('speedSelect').value === 'fast' ? 'Fast' : ''].filter(Boolean).join(' · ') + ' ⌄';
  const full = $('permissionSelect').value === 'danger-full-access';
  $('permissionButton').textContent = full ? '⚠' : '◇'; $('permissionButton').classList.toggle('full-access', full);
  $('permissionButton').setAttribute('aria-label', '권한: ' + $('permissionSelect').selectedOptions[0]?.textContent);
  const hasInput = !!$('messageInput').value.trim() || feature.attachments.length || feature.mentions.length;
  const stop = !!(state.activeTurn || state.retries?.has(state.currentId)) && !hasInput;
  $('sendButton').textContent = stop ? '■' : '↑'; $('sendButton').classList.toggle('stop', stop);
  const steer = $('followupSelect').value === 'steer';
  $('sendButton').setAttribute('aria-label', stop ? '작업 중단' : steer ? '현재 작업에 지시 보내기' : '다음 작업에 지시 보내기');
  const mode = $('sendModeButton'), label = steer ? '현재 작업에 지시' : '다음 작업에 지시';
  $('sendModeLabel').textContent = label;
  mode.classList.toggle('steering', steer); mode.setAttribute('aria-pressed', String(steer));
  mode.setAttribute('aria-label', label + ' · 눌러서 ' + (steer ? '다음 작업에 지시' : '현재 작업에 지시') + '로 전환');
  // Always allow returning to Queue if an older host loses Steering capability.
  mode.disabled = !steer && !state.serverCapabilities.steeringSend;
  mode.title = mode.disabled ? '이 PC의 Pocket Remote 업데이트 필요' : steer ? '진행 중 작업에 바로 전달 · 누르면 다음 작업으로 변경' : '현재 작업이 끝난 뒤 실행 · 누르면 현재 작업으로 변경';
  document.body.classList.toggle('online', state.online);
}
function modelPicker() {
  const root = picker('모델 · 추론 · 속도', 'PC에서 제공하는 모델');
  for (const m of state.models) pickerRow(root, m.displayName || m.model, m.description || '', () => { selectValue('modelSelect', m.model); modelPicker(); }, { checked: m.model === $('modelSelect').value });
  root.append(el('div', '추론 단계', 'picker-subtitle'));
  const group = el('div', undefined, 'option-chips');
  for (const o of $('effortSelect').options) group.append(action(efforts[o.value] || o.value, () => { selectValue('effortSelect', o.value); modelPicker(); }, 'pill' + (o.selected ? ' selected' : '')));
  root.append(group, el('div', '속도', 'picker-subtitle'));
  const fast = modelFastTier(state.models.find(x => x.model === $('modelSelect').value));
  for (const o of $('speedSelect').options) pickerRow(root, o.textContent, o.disabled ? '현재 모델에서 제공되지 않습니다.' : o.value === 'fast' ? fast?.description || '더 빠른 처리' : '기본 처리 속도', () => { selectValue('speedSelect', o.value); modelPicker(); }, { checked: o.selected, disabled: o.disabled });
  if (state.activeTurn) root.append(el('p', '속도 변경은 다음 새 턴부터 적용됩니다. 진행 중인 턴의 속도는 바뀌지 않습니다.'));
}
function permissionPicker() {
  const root = picker('권한 설정', '다음 메시지부터 적용');
  const descriptions = { 'read-only': '파일 확인과 읽기 작업', 'workspace-write': '작업 폴더 안에서 파일 수정', 'danger-full-access': 'PC 파일·명령·네트워크 전체 액세스' };
  for (const o of $('permissionSelect').options) pickerRow(root, o.textContent, descriptions[o.value], () => { selectValue('permissionSelect', o.value); permissionPicker(); }, { checked: o.selected, icon: o.value === 'danger-full-access' ? '⚠' : '◇', danger: o.value === 'danger-full-access' });
  root.append(el('div', '작업 승인', 'picker-subtitle'));
  for (const o of $('approvalSelect').options) pickerRow(root, o.textContent, '', () => { selectValue('approvalSelect', o.value); permissionPicker(); }, { checked: o.selected });
}
function saveAssets() { if (state.currentId) persist('remote.assets.' + state.currentId, { attachments: feature.attachments, mentions: feature.mentions }); }
function restoreAssets(id) {
  const assets = saved('remote.assets.' + id) || {};
  feature.attachments = (assets.attachments || []).map(a => feature.uploads.get(a.id) || a); feature.mentions = assets.mentions || [];
  for (const a of feature.attachments) if (!a.complete && !feature.files.has(a.id)) { a.uploading = false; a.status = '파일 다시 선택 필요'; a.error = true; }
  renderAssets();
}
function renderAssets() {
  const tray = $('attachmentTray'); tray.replaceChildren(); tray.classList.toggle('hidden', !feature.attachments.length);
  for (const a of feature.attachments) {
    const card = el('div', undefined, 'attachment'); card.append(el('span', '▤', 'file-icon'));
    const info = el('div', undefined, 'file-info'); info.append(el('strong', a.name), el('small', a.complete ? (a.size / 1024 / 1024).toFixed(1) + ' MB · 준비됨' : a.status || '올리는 중…'));
    if (!a.complete && !a.error) { const p = el('progress'); p.max = a.size || 1; p.value = a.offset || 0; info.append(p); }
    card.append(info);
    if (a.error && feature.files.has(a.id)) card.append(action('↻', () => uploadFile(a, feature.files.get(a.id)), ''));
    card.append(action('✕', async () => { a.cancelled = true; feature.attachments = feature.attachments.filter(x => x !== a); saveAssets(); renderAssets(); if (!a.complete && state.online) await rpc('bridge/file/delete', { id: a.id }).catch(() => {}); feature.files.delete(a.id); }, ''));
    tray.append(card);
  }
  const mentions = $('mentionTray'); mentions.replaceChildren(); mentions.classList.toggle('hidden', !feature.mentions.length);
  for (const m of feature.mentions) { const c = el('span', m.label || m.name, 'mention-chip'); c.append(action('✕', () => { feature.mentions = feature.mentions.filter(x => x !== m); saveAssets(); renderAssets(); }, '')); mentions.append(c); }
  renderControlPills();
}
function readChunk(blob) { return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(',')[1]); reader.onerror = () => reject(new Error('파일을 읽지 못했습니다. 다시 선택하세요.')); reader.readAsDataURL(blob); }); }
async function waitConnection(a) { while (!state.online && !a.cancelled) { a.status = '재연결 후 이어 올리기'; renderAssets(); await new Promise(r => setTimeout(r, 500)); } }
async function uploadFile(a, file) {
  if (a.uploading) return;
  a.uploading = true; a.error = false;
  const threadId = a.threadId;
  try {
    await waitConnection(a); if (a.cancelled) return;
    let result = await rpc('bridge/file/begin', { id: a.id, name: a.name, size: a.size, mime: a.mime });
    a.offset = result.offset; a.status = '올리는 중…';
    while (a.offset < a.size && !a.cancelled) {
      await waitConnection(a); if (a.cancelled) break;
      const data = await readChunk(file.slice(a.offset, Math.min(a.offset + 192 * 1024, a.size)));
      try { result = await rpc('bridge/file/chunk', { id: a.id, offset: a.offset, data }); }
      catch (error) { if (!state.online || /restarted|재시작|위치가 달라/i.test(error.message)) { await waitConnection(a); result = await rpc('bridge/file/status', { id: a.id }); } else throw error; }
      a.offset = result.offset; a.status = Math.floor(100 * a.offset / Math.max(1, a.size)) + '% · 올리는 중';
      if (state.currentId === threadId) { saveAssets(); renderAssets(); }
    }
    if (!a.cancelled) { Object.assign(a, await rpc('bridge/file/finish', { id: a.id })); feature.files.delete(a.id); }
  } catch (error) { a.error = true; a.status = error.message; }
  finally {
    a.uploading = false;
    if (a.cancelled && state.online) rpc('bridge/file/delete', { id: a.id }).catch(() => {});
    if (state.currentId === threadId) { saveAssets(); renderAssets(); }
    else { const assets = saved('remote.assets.' + threadId) || {}; assets.attachments = (assets.attachments || []).map(x => x.id === a.id ? a : x); persist('remote.assets.' + threadId, assets); }
  }
}
async function chooseFiles(files) {
  if (!state.currentId) await newThread(); if (!state.currentId) return;
  for (const file of files) {
    if (feature.attachments.length >= 8) { banner('한 메시지에는 파일을 최대 8개 첨부할 수 있습니다.'); break; }
    if (file.size > 50 * 1024 * 1024) { banner(file.name + ': 파일은 50MB 이하로 선택하세요.'); continue; }
    const a = { id: uuid(), threadId: state.currentId, name: file.name, size: file.size, mime: file.type || 'application/octet-stream', offset: 0, complete: false };
    feature.files.set(a.id, file); feature.uploads.set(a.id, a); feature.attachments.push(a); saveAssets(); renderAssets(); uploadFile(a, file);
  }
}
function buildUserInputs(entry) {
  const attachments = entry.attachments || [], mentions = entry.mentions || [];
  let text = entry.text || '';
  if (mentions.length) text += '\n\n[사용 지시]\n' + mentions.map(m => m.kind === 'plugin' ? '설치된 ' + m.name + ' 플러그인의 기능을 사용하세요.' : '$' + m.name + ' 기능을 사용하세요.').join('\n');
  if (attachments.length) text += '\n\n[첨부 파일: PC에 업로드됨]\n' + attachments.map(a => JSON.stringify(a.name) + ': ' + a.path).join('\n');
  const input = [{ type: 'text', text: text || '첨부한 내용을 확인하세요.' }];
  for (const a of attachments) if (/\.(png|jpe?g|webp|gif)$/i.test(a.name)) input.push({ type: 'localImage', path: a.path });
  for (const m of mentions) if (m.kind === 'skill') input.push({ type: 'skill', name: m.name, path: m.path }); else if (m.kind === 'app') input.push({ type: 'mention', name: m.name, path: m.path });
  return input;
}
function displayUserText(text) {
  const open='<send_user_message_question_reply>',close='</send_user_message_question_reply>',trimmed=text.trim();
  if(trimmed.startsWith(open)&&trimmed.endsWith(close)&&trimmed.length<=100000){
    try{
      const parsed=JSON.parse(trimmed.slice(open.length,-close.length)),replies=Array.isArray(parsed)?parsed:[parsed];
      if(replies.length&&replies.every(r=>typeof r.questionItemId==='string'&&typeof r.question==='string'&&typeof r.answer==='string'&&JSON.parse(r.questionItemId)?.[0]==='request_user_input_async'))return replies.map(r=>r.question+'\n답변: '+r.answer).join('\n\n');
    }catch{}
  }
  const marker = '\n\n[첨부 파일: PC에 업로드됨]\n', at = text.indexOf(marker);
  if (at < 0) return text;
  const files = text.slice(at + marker.length).split('\n').map(line => {
    const match = line.match(/^("(?:[^"\\]|\\.)*"): /); if (!match) return line;
    try { return '▤ ' + JSON.parse(match[1]); } catch { return line; }
  });
  return text.slice(0, at) + '\n\n' + files.join('\n');
}
function settingsSnapshot(entry = null) {
  if (entry) return { cwd: entry.cwd, model: entry.model || null, effort: entry.effort || null, serviceTierForTurn: entry.serviceTierForTurn ?? serviceTierForSpeed(entry.speed, state.models.find(x => x.model === entry.model)), sandboxPolicy: entry.sandboxPolicy, approvalPolicy: entry.approvalPolicy || 'on-request', summary: 'concise' };
  return { cwd: state.cwd, model: $('modelSelect').value || null, effort: $('effortSelect').value || null, serviceTierForTurn: serviceTierForSpeed($('speedSelect').value, state.models.find(x => x.model === $('modelSelect').value)), sandboxPolicy: sandboxPolicy(), approvalPolicy: $('approvalSelect').value, summary: 'concise' };
}
async function catalogPicker() {
  const root = picker('플러그인 · 앱 · 스킬', 'PC에 설치되거나 연결된 기능'); root.append(el('p', '목록을 읽는 중…'));
  const catalog = await readPluginCatalog(true);
  if ($('pickerTitle').textContent !== '플러그인 · 앱 · 스킬') return;
  let tab = 'plugins', query = '';
  function draw() {
    root.replaceChildren(); const tabs = el('div', undefined, 'catalog-tabs');
    for (const [key, title] of [['plugins', '플러그인'], ['apps', '앱'], ['skills', '스킬']]) tabs.append(action(title, () => { tab = key; draw(); }, key === tab ? 'active' : ''));
    const search = el('input', undefined, 'picker-search'); search.placeholder = '기능 검색'; search.value = query;
    const list = el('div'); search.oninput = () => { query = search.value.toLowerCase(); drawList(list); }; root.append(tabs, search, list); drawList(list);
    for (const warning of catalog.warnings || []) root.append(el('p', warning));
  }
  function drawList(list) {
    list.replaceChildren(); const all = (catalog[tab] || []).filter(m => (m.label + ' ' + m.name + ' ' + m.description).toLowerCase().includes(query));
    if (!all.length) list.append(el('p', '표시할 기능이 없습니다.'));
    for (const m of all) pickerRow(list, m.label || m.name, m.enabled ? m.description : 'PC에서 활성화하거나 연결해야 사용할 수 있습니다.', async () => {
      if (!state.currentId) await newThread(); if (!state.currentId) return;
      const key = x => x.kind + ':' + (x.id || x.path || x.name);
      if (!feature.mentions.some(x => key(x) === key(m))) feature.mentions.push({ kind: m.kind, id: m.id, name: m.name, label: m.label, path: m.path });
      saveAssets(); renderAssets(); closePicker(); $('messageInput').focus();
    }, { disabled: !m.enabled, icon: m.kind === 'app' ? '▦' : '◇' });
  }
  draw();
}
function addPicker() {
  const root = picker('추가', '메시지에 필요한 기능');
  pickerRow(root, '파일 업로드', '사진 · 문서 · 동영상 · 코드 / 파일당 50MB', () => { closePicker(); $('filePicker').click(); }, { icon: '▤' });
  pickerRow(root, '플러그인 · 앱 · 스킬', '설치된 기능 사용 지시', catalogPicker, { icon: '◇' });
  pickerRow(root, '목표 설정', '/goal · 완료 조건과 토큰 예산', () => { closePicker(); goalEditor(); }, { icon: '◎' });
}
async function loadFeatureThread(id) {
  if (!state.online || !id) return;
  const socket=state.socket,valid=()=>!state.leaving&&state.socket===socket;
  const work = [
    rpc('bridge/queue/list', { threadId: id }).then(result=>{if(!valid())return;feature.queues.set(id,result.entries||[]);if(state.currentId===id)renderOutbox();}),
    rpc('bridge/goal/get', { threadId: id }).then(result=>{if(!valid())return;feature.goals.set(id,result);if(state.currentId===id)renderGoal();}),
    rpc('bridge/question/list', { threadId: id }).then(result=>{if(!valid())return;for(const q of result.questions||[])v03.questionStates.set(id+':'+q.itemId,q);renderQuestionAttention();if(id===state.currentId){scheduleRender();renderApprovals();}})
  ];
  if(state.currentId===id){refreshSessionAgents();refreshChanges();}
  await Promise.allSettled(work);
}
const goalLabels = { active: '진행 중', paused: '일시정지', complete: '완료', blocked: '입력 필요', usageLimited: '사용 한도', budgetLimited: '예산 도달' };
function goalWorkTime(goal, now = Date.now()) {
  let seconds = goal?.timeUsedSeconds;
  if (typeof seconds !== 'number' || !Number.isFinite(seconds) || seconds < 0) return null;
  // The native goal snapshot accounts through updatedAt (Unix seconds).
  // Derive elapsed time from that anchor; never accumulate interval ticks.
  if (goal.status === 'active' && typeof goal.updatedAt === 'number' && Number.isFinite(goal.updatedAt) && goal.updatedAt > 0 && Number.isFinite(now)) seconds += Math.max(0, now / 1000 - goal.updatedAt);
  const total = Math.floor(seconds), hours = Math.floor(total / 3600);
  const days = Math.floor(hours / 24), hour = days ? String(hours % 24).padStart(2, '0') : hours;
  return (days ? days + '일 ' : '') + (hours ? hour + ':' : '') + String(Math.floor(total / 60) % 60).padStart(2, '0') + ':' + String(total % 60).padStart(2, '0');
}
function updateGoalMeters(goal) {
  const time = goalWorkTime(goal), label = time === null ? '작업 시간 정보 없음' : '누적 작업 시간 ' + time;
  const compact = $('goalTime'), detail = $('goalWorkTime'), tokens = $('goalTokens');
  if (compact) { if (compact.textContent !== (time ?? '—')) compact.textContent = time ?? '—'; compact.title = label; compact.setAttribute('aria-label', label); }
  if (detail) { const text = time === null ? '작업 시간 정보 없음' : '작업 시간 ' + time; if (detail.textContent !== text) detail.textContent = text; detail.title = '공식 서버의 누적 시간과 진행 중 경과 시간'; }
  if (tokens) { const text = (goal.tokensUsed || 0).toLocaleString() + (goal.tokenBudget ? ' / ' + goal.tokenBudget.toLocaleString() : '') + ' 토큰'; if (tokens.textContent !== text) tokens.textContent = text; }
}
let goalClockTimer = null;
function refreshGoalClock() {
  const goal = feature.goals.get(state.currentId)?.goal;
  const visible = !document.hidden && !$('chatView').classList.contains('hidden');
  $('goalCard')?.classList.toggle('goal-suspended', !visible);
  refreshGoalEmphasis();
  const ticking = visible && goal?.status === 'active' && goalWorkTime(goal) !== null && typeof goal.updatedAt === 'number' && Number.isFinite(goal.updatedAt) && goal.updatedAt > 0;
  if (!ticking && goalClockTimer !== null) { clearInterval(goalClockTimer); goalClockTimer = null; }
  if (visible && goal) updateGoalMeters(goal);
  if (ticking && goalClockTimer === null) goalClockTimer = setInterval(refreshGoalClock, 1000);
}
function goalProgressAnimationEnabled(){return saved('remote.goalProgressAnimation')!==false;}
function goalEmphasisRunning(goal,collapsed){return goal?.status==='active'&&collapsed&&state.online&&!!state.activeTurn&&!state.retries?.has(state.currentId);}
function refreshGoalEmphasis(){
  const card=$('goalCard');
  const running=goalEmphasisRunning(feature.goals.get(state.currentId)?.goal,card?.classList.contains('collapsed'));
  card?.classList.toggle('goal-running',running);
  card?.classList.toggle('goal-animating',running&&goalProgressAnimationEnabled()&&!document.hidden&&!$('chatView').classList.contains('hidden'));
}
function renderGoal() {
  const record = feature.goals.get(state.currentId), goal = record?.goal, card = $('goalCard');
  const collapsed = saved('remote.goalCollapsed.' + state.currentId) !== false;
  const key = state.currentId + ':' + JSON.stringify([goal?.objective, goal?.status, goal?.tokenBudget, record?.runnerError, collapsed]);
  if (card.remoteKey === key) { refreshGoalClock(); return; } card.remoteKey = key;
  const oldScroll = $('goalDetails')?.scrollTop || 0;
  card.replaceChildren(); card.classList.toggle('hidden', !goal);
  card.classList.toggle('goal-running', goalEmphasisRunning(goal,collapsed));
  $('chatView').classList.toggle('has-goal', !!goal);
  if (!goal) { refreshGoalClock(); return; }
  card.classList.toggle('collapsed', collapsed);
  const heading = action('', () => { persist('remote.goalCollapsed.' + state.currentId, !collapsed); renderGoal(); }, 'goal-toggle');
  heading.setAttribute('aria-label', (collapsed ? '목표 펼치기' : '목표 접기') + ' · ' + (goalLabels[goal.status] || goal.status)); heading.setAttribute('aria-expanded', String(!collapsed)); heading.setAttribute('aria-controls', 'goalDetails');
  heading.title = (goalLabels[goal.status] || goal.status) + ' · ' + goal.objective;
  const compactTime = el('span', undefined, 'goal-time'); compactTime.id = 'goalTime';
  heading.append(el('span', '◎', 'goal-icon'), el('strong', '목표: ' + goal.objective), compactTime, el('span', collapsed ? '⌄' : '⌃', 'goal-chevron'));
  heading.firstChild.setAttribute('aria-hidden','true');
  const summary = el('div', undefined, 'goal-summary-row'); summary.append(heading);
  const details = el('div', undefined, 'goal-details'); details.id = 'goalDetails'; details.classList.toggle('hidden', collapsed);
  const title = el('div', undefined, 'goal-heading');
  title.append(el('strong', '목표'), el('span', goalLabels[goal.status] || goal.status, 'goal-badge ' + goal.status));
  const tokens = el('span', undefined, 'goal-meter'); tokens.id = 'goalTokens'; title.append(tokens);
  const workTime = el('span', undefined, 'goal-work-time'); workTime.id = 'goalWorkTime';
  const controls = el('div', undefined, 'goal-actions');
  controls.append(action('수정', () => goalEditor()), action(goal.status === 'active' ? '일시정지' : '계속', async () => {
    const result = await rpc('bridge/goal/' + (goal.status === 'active' ? 'pause' : 'resume'), { threadId: state.currentId, settings: settingsSnapshot() }); feature.goals.set(state.currentId, { ...record, ...result }); renderGoal();
  }), action('지우기', async () => { await rpc('bridge/goal/clear', { threadId: state.currentId }); feature.goals.delete(state.currentId); renderGoal(); }));
  details.append(title, workTime, el('p', goal.objective), controls); if (record.runnerError) details.append(el('p', record.runnerError, 'failed'));
  const frame=el('div',undefined,'goal-detail-frame');frame.classList.toggle('hidden',collapsed);frame.append(details);
  card.append(frame, summary); refreshGoalClock(); details.scrollTop = oldScroll;
}
async function goalEditor(objective) {
  if (!state.currentId) await newThread(); if (!state.currentId) return;
  const goal = feature.goals.get(state.currentId)?.goal;
  $('goalObjective').value = objective ?? goal?.objective ?? ''; $('goalBudget').value = goal?.tokenBudget || '';
  $('goalError').classList.add('hidden'); $('saveGoal').textContent = goal?.status === 'paused' ? '목표 저장 · 일시정지 유지' : '목표 저장하고 시작';
  closeMenus();
  $('goalOverlay').classList.remove('hidden');
}
async function saveGoal() {
  const button = $('saveGoal'); button.disabled = true;
  try {
    if (feature.attachments.some(a => !a.complete)) throw new Error('파일 업로드를 먼저 완료하세요.');
    const budget = $('goalBudget').value.trim(); const id = state.currentId;
    const result = await rpc('bridge/goal/save', { threadId: id, objective: $('goalObjective').value.trim(), tokenBudget: budget ? Number(budget) : null, status: feature.goals.get(id)?.goal?.status === 'paused' ? 'paused' : 'active', settings: settingsSnapshot(), inputExtras: feature.attachments.length || feature.mentions.length ? buildUserInputs({ text: '', attachments: feature.attachments, mentions: feature.mentions }) : [] });
    feature.goals.set(id, { ...result, managed: true }); feature.attachments = []; feature.mentions = []; saveAssets(); renderAssets(); renderGoal(); $('goalOverlay').classList.add('hidden');
  } catch (error) { $('goalError').textContent = error.message; $('goalError').classList.remove('hidden'); } finally { button.disabled = false; }
}
function featureEvent(method, p) {
  if (method === 'pocket/queue/changed') { feature.queues.set(p.threadId, p.entries || []); if (p.threadId === state.currentId) renderOutbox(); }
  if (method === 'thread/goal/updated') { feature.goals.set(p.threadId, { ...feature.goals.get(p.threadId), goal: p.goal }); if (p.threadId === state.currentId) renderGoal(); }
  if (method === 'thread/goal/cleared') { feature.goals.delete(p.threadId); if (p.threadId === state.currentId) renderGoal(); }
  if (method === 'pocket/goal/state') { const record = feature.goals.get(p.threadId); if (record) record.runnerError = p.error; if (p.threadId === state.currentId) renderGoal(); }
}
async function syncActiveThread() {
  const id = state.currentId;
  if (!id || !state.online || document.hidden || globalThis.pocketDots?.ui.open || state.openingThread || feature.syncing || state.current?.ephemeral || globalThis.userMessageNavigation?.busy) return;
  feature.syncing = true;
  const token = loadToken, revision = state.revision, turnVersion = state.turnVersions.get(id) || 0;
  try {
    const result = await rpc('bridge/sync/read', { threadId: id, hash: feature.hashes.get(id) || '', queueHash: feature.queueHashes.get(id) || '' });
    if (token !== loadToken || globalThis.userMessageNavigation?.busy) return;
    feature.hashes.set(id, result.hash); feature.queueHashes.set(id, result.queueHash);
    if (result.queue) feature.queues.set(id, result.queue); renderOutbox();
    if (result.goalState) { feature.goals.set(id, result.goalState); renderGoal(); }
    if (result.statusKnown && (state.turnVersions.get(id) || 0) === turnVersion) { state.activeTurn = result.activeTurn; if (result.activeTurn) state.activeTurns.set(id, result.activeTurn); else state.activeTurns.delete(id); if (result.execution) state.executions.set(id, result.execution); renderStatus(); }
    if (result.changed && result.page) {
      const changed = new Map([...state.items, ...featureLiveEntries()].filter(x => (state.itemVersions.get(x.item.id) || 0) > revision || x.liveComplete === false && x.turnId === state.activeTurn).map(x => [x.item.id, x]));
      const latest = (result.page.data || []).slice().reverse().map(x => changed.get(x.item.id) || x);
      const latestIds = new Set(latest.map(x => x.item.id)); latest.push(...[...changed.values()].filter(x => !latestIds.has(x.item.id)));
      if (state.historyMode) {
        const byId = new Map(latest.map(x => [x.item.id, x])); state.items = state.items.map(x => byId.get(x.item.id) || x);
        for (const x of latest) state.liveItems.set(x.item.id, x); while (state.liveItems.size > HISTORY_WINDOW_SIZE) state.liveItems.delete(state.liveItems.keys().next().value);
        $('latestItems').classList.remove('hidden');
      } else { state.items = latest.slice(-HISTORY_WINDOW_SIZE); resetHistoryWindow(result.page); persist('remote.cache.' + id, cachedItems(state.items)); }
      scheduleRender();
    }
  } catch (error) { if (!/not materialized|thread not loaded|ephemeral|rollout .* is empty/i.test(error.message) && state.online) console.debug('Sync: ' + error.message); }
  finally { feature.syncing = false; }
}
function featureLiveEntries() { return [...state.liveItems.values()]; }
function renderQueueRows() {
  const box = $('outboxBox');
  const remote = feature.queues.get(state.currentId) || [];
  const all = [...remote.map(e => ({ ...e, remote: true })), ...state.outbox.filter(e => e.threadId === state.currentId && !remote.some(r => r.id === e.id.slice(2)))];
  const key = state.currentId + ':' + JSON.stringify(all); if (box.remoteKey === key) return; box.remoteKey = key; box.replaceChildren();
  box.classList.toggle('hidden', !all.length);
  for (const entry of all) {
    const row = el('div', undefined, 'queue-pill'); const status = entry.retryAt ? '모델 혼잡 · 자동 재시도' : ({ queued: entry.mode === 'steer' || entry.followup === 'steer' ? 'Steering' : 'Queue', sending: 'PC에 전달 중', dispatching: '실행 준비', failed: '전송 실패', uncertain: '결과 확인 필요' })[entry.status] || entry.status;
    const text = el('span', '☷ ' + status + ' · ' + (entry.text || '첨부 파일').slice(0, 100), 'queue-text'); row.append(text, action('⋯', () => queueMenu(entry), 'icon small')); box.append(row);
  }
}
function editSheet(title, value, save) {
  const root = picker(title); const input = el('textarea'); input.rows = 5; input.value = value; const error = el('p', '', 'inline-error hidden');
  root.append(input, error, action('저장', async () => { try { if (!input.value.trim()) throw new Error('메시지를 입력하세요.'); await save(input.value.trim()); closePicker(); } catch (e) { error.textContent = e.message; error.classList.remove('hidden'); } }, 'primary full'));
}
function queueMenu(entry) {
  const root = picker(entry.status === 'failed' ? '전송 실패한 메시지' : '대기 메시지');
  addMessageCopyRow(root, entry.text || '');
  const queued = entry.status === 'queued';
  pickerRow(root, '메시지 편집', '', () => editSheet('메시지 편집', entry.text, async text => {
    if (entry.remote) await rpc('bridge/queue/update', { threadId: entry.threadId, id: entry.id, text, input: buildUserInputs({ ...entry, text }) });
    else { const local = state.outbox.find(e => e.id === entry.id); if (!local || local.status !== 'queued') throw new Error('메시지가 이미 전달되었습니다.'); local.text = text; saveOutbox(); renderOutbox(); }
  }), { disabled: !queued, icon: '✎' });
  pickerRow(root, '대신 스티어링으로 보내기', '진행 중 작업에 즉시 지시 · 작업이 끝났으면 새 턴 실행', async () => {
    if (!state.online) throw new Error('PC 연결 후 다시 시도하세요.');
    if (!entry.remote) { await flushOutbox(); const remote = await rpc('bridge/queue/get', { threadId: entry.threadId, id: entry.id.slice(2) }); if (remote.entry.status !== 'queued') throw new Error('이미 작업에 전달된 메시지입니다.'); }
    await rpc('bridge/queue/steer', { threadId: entry.threadId, id: entry.remote ? entry.id : entry.id.slice(2) }); closePicker();
  }, { disabled: !queued, icon: '↪' });
  if (['failed', 'uncertain'].includes(entry.status)) pickerRow(root, '다시 보내기', entry.status === 'uncertain' ? '현재 대화에 이미 전달됐는지 확인한 후 선택하세요.' : entry.error || '', async () => {
    if (entry.remote) await rpc('bridge/queue/retry', { threadId: entry.threadId, id: entry.id });
    else { const local = state.outbox.find(e => e.id === entry.id); local.status = 'queued'; local.error = ''; saveOutbox(); flushOutbox(); } closePicker();
  }, { icon: '↻' });
  pickerRow(root, '메시지 취소', '', async () => {
    if (entry.remote) await rpc('bridge/queue/cancel', { threadId: entry.threadId, id: entry.id });
    else { if (entry.status === 'sending') throw new Error('PC 전달이 끝난 뒤 취소하세요.'); state.outbox = state.outbox.filter(x => x.id !== entry.id); saveOutbox(); renderOutbox(); } closePicker();
  }, { disabled: ['sending', 'dispatching'].includes(entry.status), icon: '⌫', danger: true });
}
const themeOptions=[
  ['system','시스템'],['light','라이트'],['dark','다크'],['midnight','미드나이트'],
  ['pastel-mint','민트','#cde4d1'],['pastel-lavender','라벤더','#e0d1ed'],['pastel-sky','하늘','#cedfec'],
  ['pastel-peach','피치','#efd8bf'],['pastel-rose','로즈','#eccedd'],['pastel-lemon','레몬','#e5dfad'],['pastel-sage','세이지','#d7e3bf'],['pastel-aqua','아쿠아','#c6e2e3']
];
function applyTheme(value = feature.theme) {
  if(!themeOptions.some(t=>t[0]===value))value='system';
  feature.theme = value; persist('remote.theme', value);
  const systemDark = window.RemoteNative?.systemDark ? window.RemoteNative.systemDark() : matchMedia('(prefers-color-scheme: dark)').matches;
  const actual = value === 'system' ? systemDark ? 'dark' : 'light' : value;
  document.documentElement.dataset.theme = actual;
  const color = getComputedStyle(document.documentElement).getPropertyValue('--bg').trim(); document.querySelector('meta[name="theme-color"]').content = color;
  window.RemoteNative?.setTheme(color, actual !== 'dark' && actual !== 'midnight');
  const root = $('themeChoices'); root.replaceChildren();
  for(const [label,options]of [['기본',themeOptions.slice(0,4)],['파스텔',themeOptions.slice(4)]]){
    const group=el('div',undefined,'theme-group');group.setAttribute('role','group');group.setAttribute('aria-label',label+' 테마');root.append(el('small',label,'theme-category'),group);
    for(const [key,name,preview]of options){
      const b=action('',()=>{applyTheme(key);root.querySelector('[data-theme-choice="'+key+'"]').focus({preventScroll:true});},'theme-choice'+(value===key?' active':''));
      b.dataset.themeChoice=key;b.setAttribute('aria-pressed',String(value===key));
      const swatch=el('span','','theme-swatch '+key);swatch.setAttribute('aria-hidden','true');if(preview)swatch.style.background=preview;
      const check=el('span',value===key?'✓':'','theme-check');check.setAttribute('aria-hidden','true');b.append(swatch,el('span',name),check);group.append(b);
    }
  }
}
function commandAction(text) {
  const match = text.match(/^\/(goal|plugins|model|theme)(?:\s+(.*))?$/s); if (!match) return false;
  if (match[1] === 'goal') goalEditor(match[2]); if (match[1] === 'plugins') catalogPicker().catch(e => banner(e.message)); if (match[1] === 'model') modelPicker(); if (match[1] === 'theme') $('settingsButton').onclick();
  $('messageInput').value = ''; persist('remote.draft.' + state.currentId, ''); $('commandHints').classList.add('hidden'); renderControlPills(); return true;
}
function inputChanged() {
  const input = $('messageInput'); input.style.height = 'auto'; input.style.height = Math.min(144, Math.max(43, input.scrollHeight)) + 'px';
  renderControlPills(); const hints = $('commandHints'); hints.replaceChildren(); hints.classList.add('hidden'); hints.classList.remove('plugin-hints');
  hints.style.bottom=($('app').getBoundingClientRect().bottom-$('composer').getBoundingClientRect().top+8)+'px';
  if (renderPluginHints()) return;
  const text = input.value.trim(); const show = /^\/[a-z]*$/i.test(text); hints.classList.toggle('hidden', !show);
  hints.style.bottom=($('app').getBoundingClientRect().bottom-$('composer').getBoundingClientRect().top+8)+'px';
  if (show) for (const [key, title] of [['goal', '목표 설정'], ['plugins', '플러그인 · 앱 · 스킬'], ['model', '모델 · 추론 · 속도'], ['theme', '앱 테마']]) if (('/' + key).startsWith(text)) hints.append(action('/' + key + '  ' + title, () => commandAction('/' + key), ''));
}
function inlineMarkdown(parent, text) {
  const pattern = /(`[^`\n]+`|\*\*[^*\n]+\*\*|\[[^\]\n]+\]\(https?:\/\/[^\s)]+\))/g;
  let at = 0;
  for (const m of text.matchAll(pattern)) {
    parent.append(document.createTextNode(text.slice(at, m.index))); const value = m[0];
    if (value.startsWith('`')) parent.append(el('code', value.slice(1, -1)));
    else if (value.startsWith('**')) parent.append(el('strong', value.slice(2, -2)));
    else { const link = value.match(/^\[([^\]]+)\]\((.*)\)$/); const a = el('a', link[1]); a.href = link[2]; a.rel = 'noopener noreferrer'; a.target = '_blank'; a.onclick = event => { if (window.RemoteNative) { event.preventDefault(); window.RemoteNative.openExternal(a.href); } }; parent.append(a); }
    at = m.index + value.length;
  }
  parent.append(document.createTextNode(text.slice(at)));
}
function strongCodeRule(state, silent) {
  const start = state.pos, source = state.src;
  if (source.slice(start, start + 2) !== '**' || source[start + 2] !== '`') return false;
  let at = start + 2; while (source[at] === '`') at++;
  const ticks = source.slice(start + 2, at); let close = at;
  while ((close = source.indexOf(ticks, close)) !== -1 && close < state.posMax) {
    if (source[close - 1] === '`' || source[close + ticks.length] === '`') { close += ticks.length; continue; }
    const end = close + ticks.length;
    if (source.slice(end, end + 2) !== '**' || end + 2 > state.posMax) return false;
    if (!silent) {
      state.push('strong_open', 'strong', 1).markup = '**';
      const token = state.push('code_inline', 'code', 0); token.markup = ticks;
      token.content = source.slice(at, close).replace(/\n/g, ' ');
      if (token.content.startsWith(' ') && token.content.endsWith(' ') && /[^ ]/.test(token.content)) token.content = token.content.slice(1, -1);
      state.push('strong_close', 'strong', -1).markup = '**';
    }
    state.pos = end + 2; return true;
  }
  return false;
}
function renderMarkdown(body, text) {
  body.classList.add('markdown');
  const md=window.remoteMarkdown||(window.remoteMarkdown=window.markdownit({html:false,linkify:true,breaks:true,typographer:false}));
  if (!md.remoteStrongCode) { md.inline.ruler.before('emphasis', 'remote_strong_code', strongCodeRule); md.remoteStrongCode = true; }
  const isLocal=url=>/^(?:[A-Za-z]:[\\/]|\/(?!\/)|sandbox:\/mnt\/data\/)/.test(url);
  md.validateLink=url=>/^https?:\/\//i.test(url)||url.startsWith('#')||isLocal(url);
  md.renderer.rules.image=(tokens,index)=>{
    const t=tokens[index],src=t.attrGet('src')||'',alt=t.content||'이미지';
    return /^https:\/\//i.test(src)?'<img class="markdown-image" loading="lazy" src="'+md.utils.escapeHtml(src)+'" alt="'+md.utils.escapeHtml(alt)+'">':'<span class="muted">'+md.utils.escapeHtml(alt)+'</span>';
  };
  body.innerHTML=md.render(String(text||''));
  const headingIds = new Map();
  for (const heading of body.querySelectorAll('h1,h2,h3,h4,h5,h6')) {
    const base = heading.textContent.trim().toLowerCase().replace(/[^\p{L}\p{N} _-]/gu, '').replace(/\s+/g, '-') || 'section';
    const n = headingIds.get(base) || 0; headingIds.set(base, n + 1); heading.id = base + (n ? '-' + n : '');
  }
  for(const a of body.querySelectorAll('a')){
    const url=a.getAttribute('href');a.rel='noopener noreferrer';
    a.onclick=event=>{
      if(isLocal(url)){event.preventDefault();const itemId=body.closest('article')?.dataset.itemId,item=state.items.find(e=>e.item.id===itemId)?.item;const normalized=decodeURI(url).replace(/^sandbox:/,'').replace(/:\d+(?::\d+)?$/,'').replace(/\\/g,'/');const media=item?.media?.find(m=>m.sourcePath?.replace(/\\/g,'/')===normalized||m.name===normalized.split('/').at(-1));if(media)showMedia(media);else banner('PC 파일을 찾지 못했습니다. 파일이 저장되어 있는지 확인하세요.');}
      else if(url.startsWith('#')){event.preventDefault();let id;try{id=decodeURIComponent(url.slice(1));}catch{return;}[...body.querySelectorAll('[id]')].find(n=>n.id===id)?.scrollIntoView({block:'start'});}
      else if(window.RemoteNative){event.preventDefault();window.RemoteNative.openExternal(url);}
      else a.target='_blank';
    };
  }
  for(const table of body.querySelectorAll('table')){const wrap=el('div',undefined,'table-scroll');table.replaceWith(wrap);wrap.append(table);}
  for(const pre of body.querySelectorAll('pre')){const wrapper=el('div',undefined,'code-block'),code=pre.querySelector('code');pre.replaceWith(wrapper);wrapper.append(pre,action('복사',async()=>{if(window.RemoteNative)window.RemoteNative.copyText(code?.textContent||pre.textContent);else await navigator.clipboard.writeText(code?.textContent||pre.textContent);},'copy-code'));}
  for(const li of body.querySelectorAll('li')){const node=li.firstChild?.nodeType===Node.TEXT_NODE?li.firstChild:li.querySelector('p')?.firstChild;const match=node?.nodeType===Node.TEXT_NODE&&node.textContent.match(/^\[([ xX])\]\s+/);if(match){const c=el('input');c.type='checkbox';c.checked=match[1].toLowerCase()==='x';c.disabled=true;c.className='task-checkbox';node.textContent=node.textContent.slice(match[0].length);node.parentNode.insertBefore(c,node);}}
}
function initFeatureUI() {
  document.addEventListener('visibilitychange', refreshGoalClock);
  state.outbox = state.outbox.filter(entry => entry.status !== 'sent');
  for (const entry of state.outbox) if (entry.status === 'sending' && entry.queueProtocol !== 2) { entry.status = 'uncertain'; entry.error = '이전 버전의 전송 결과를 대화에서 확인한 뒤 다시 보내세요.'; }
  saveOutbox();
  feature.theme = saved('remote.theme') || 'system'; applyTheme(); matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (feature.theme === 'system') applyTheme(); });
  $('followupSelect').value = 'queue'; persist('remote.followup', 'queue');
  $('headerNew').onclick = $('emptyNew').onclick = newThread; $('modelButton').onclick = modelPicker; $('permissionButton').onclick = permissionPicker; $('attachButton').onclick = addPicker;
  $('closePicker').onclick = closePicker; $('closeGoal').onclick = () => $('goalOverlay').classList.add('hidden'); $('saveGoal').onclick = saveGoal;
  $('filePicker').onchange = () => { chooseFiles([...$('filePicker').files]); $('filePicker').value = ''; };
  $('sendModeButton').onclick = () => selectValue('followupSelect', $('followupSelect').value === 'steer' ? 'queue' : 'steer');
  $('threadMenuButton').onclick = () => { const root = picker('대화 작업'); for (const o of $('threadAction').options) if (o.value) pickerRow(root, o.textContent, '', () => { closePicker(); selectValue('threadAction', o.value); }); };
  for (const id of ['pickerOverlay', 'goalOverlay', 'settingsOverlay']) $(id).addEventListener('click', e => { if (e.target === $(id)) $(id).classList.add('hidden'); });
  $('messageInput').addEventListener('input', inputChanged);
  initPluginHints();
  initMessageCopy();
  initMessageNavigation();
  for (const id of ['modelSelect', 'effortSelect', 'speedSelect', 'permissionSelect', 'approvalSelect']) $(id).addEventListener('change', renderControlPills);
  if (state.currentId) restoreAssets(state.currentId);
  if (state.queue.length) flushQueue();
  setInterval(syncActiveThread, 1800); setInterval(() => { if (state.online && !document.hidden && !$('sidebar').classList.contains('hidden')) loadThreads(true, { background: true }); }, 15000);
  setInterval(() => { if(!document.hidden&&!$('sidebar').classList.contains('hidden'))refreshConversationActivity(); },2000);
  renderControlPills();
}

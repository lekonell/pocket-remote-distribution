const $ = id => document.getElementById(id);
const saved = scopedSaved;
const removeSaved = key => {localStorage.removeItem(scopedKey(key));removeLegacySaved(key);};
const persist = (key, value) => {
  if(state.leaving)return false;
  const originalKey=key;
  key = scopedKey(key);
  const text = JSON.stringify(value);
  try { localStorage.setItem(key, text);removeLegacySaved(originalKey);return true; }
  catch {
    for (const name of Object.keys(localStorage)) if (name.startsWith('remote.p.') && (name.includes('.cache.') || name.endsWith('.checkpoint'))) localStorage.removeItem(name);
    try { localStorage.setItem(key, text);removeLegacySaved(originalKey);return true; } catch { return false; }
  }
};
const checkpoint = saved('remote.checkpoint');
const uuid = () => {
  if (crypto.randomUUID) return crypto.randomUUID();
  const bytes = new Uint8Array(16); crypto.getRandomValues(bytes);
  return [...bytes].map(x => x.toString(16).padStart(2, '0')).join('');
};
const state = {
  retries: new Map(),
  url: connectionStore.active()?.url || '', token: activeConnectionToken(), cwd: saved('remote.cwd') || connectionStore.active()?.cwd || '', defaultCwd: saved('remote.defaultCwd') || connectionStore.active()?.cwd || '', leaving: false,
  epoch: checkpoint?.epoch || saved('remote.epoch') || '', seq: checkpoint?.threadId === saved('remote.currentId') ? checkpoint.seq : 0, socket: null, online: false, delay: 300,
  pending: new Map(), outbox: saved('remote.outbox') || [], models: saved('remote.models') || [], threads: [], threadCursor: null,
  currentId: saved('remote.currentId') || '', current: null, itemCursor: null, items: checkpoint?.threadId === saved('remote.currentId') ? checkpoint.items || [] : [], activeTurn: '', approvals: new Map(),
  queue: saved('remote.queue') || [], rendering: false, lastReceived: Date.now(), archived: false, executions: new Map(), serverCapabilities: saved('remote.capabilities') || {},
  revision: 0, itemVersions: new Map(), activeTurns: new Map(), turnVersions: new Map(), turnRevision: 0, openingThread: '', historyMode: false, historyLoading: false, historyWindow: new HistoryWindow(), liveItems: new Map(), projectFilter: '', readOnly: false
};
const accountLimits = new AccountLimitsReader({ read: () => rpc('account/rateLimits/read', {}), scope: () => state.online && !state.leaving ? state.socket : null });
let refreshTimer;
let reconnectTimer;
let loadToken = 0;

function banner(message) { $('banner').textContent = message || ''; $('banner').classList.toggle('show', !!message); }
function connectionLabel(text) {
  $('connectionLabel').textContent = activeConnectionName() + ' · ' + text;
  const note = $('upstreamMode');
  if (note) note.textContent = state.serverCapabilities.sharedDesktop ? '공식 PC 앱 공유 연결 · ' + text : '독립 연결 · ' + text;
  window.pocketDots?.refreshAccess(true);
}
function saveOutbox() { return persist('remote.outbox', state.outbox); }
function saveQueue() { return persist('remote.queue', state.queue); }
function cachedItems(items) {
  const serialized = []; let size = 2;
  const shorten = (_, value) => typeof value === 'string' && value.length > 50000 ? value.slice(0, 25000) + '\n[오프라인 캐시에 일부 내용만 저장됨]\n' + value.slice(-25000) : value;
  for (let i = items.length - 1; i >= Math.max(0, items.length - HISTORY_PAGE_SIZE); i--) {
    const text = JSON.stringify(items[i], shorten), next = size + text.length + (serialized.length ? 1 : 0);
    if (next > 1000000) break;
    serialized.push(text); size = next;
  }
  return JSON.parse('[' + serialized.reverse().join(',') + ']');
}
function wsSend(data) { if (!state.leaving && state.socket?.readyState === WebSocket.OPEN) state.socket.send(JSON.stringify(data)); }
function rpc(method, params = {}, id = 'c:' + uuid()) {
  if (state.leaving) return Promise.reject(Object.assign(new Error('연결 대상 전환 중'),{profileSwitch:true}));
  if (method === 'account/rateLimitResetCredit/consume' && !state.online) return Promise.reject(new Error('PC에 연결된 상태에서만 리셋권을 사용할 수 있습니다.'));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      state.pending.delete(id);
      const error = new Error(method === 'thread/list' ? '대화 목록 조회가 지연되고 있습니다.' : 'PC 응답 시간이 초과되었습니다. 내역을 확인한 뒤 다시 시도하세요.');
      error.rpcTimeout = true; error.rpcMethod = method;
      error.uncertain = method === 'turn/start' || method === 'turn/steer' || method === 'account/rateLimitResetCredit/consume';
      reject(error);
    }, method === 'turn/start' || method === 'turn/steer' ? 60000 : 30000);
    state.pending.set(id, { message: { method, params, id }, resolve, reject, timer });
    if (state.online) wsSend({ type: 'rpc', message: { method, params, id } });
  });
}
function connect() {
  if (state.leaving || window.RemoteNative?.connectionSuspended?.()) return;
  clearTimeout(reconnectTimer);
  state.online = false;
  renderStatus();
  if (!state.url || !state.token) { connectionLabel('연결 설정 필요'); return; }
  try {
    state.socket?.close();
    connectionLabel('연결 중…');
    const ws = new WebSocket(state.url, ['codex-remote', 'auth.' + state.token]);
    state.socket = ws;
    ws.onopen = () => { if(state.socket===ws&&!state.leaving) ws.send(JSON.stringify({ type: 'hello', epoch: state.epoch, since: state.seq })); };
    ws.onmessage = event => {
      if (state.socket !== ws || state.leaving) return;
      let data;
      try { data = JSON.parse(event.data); } catch { return; }
      state.lastReceived = Date.now();
      handleTransport(data);
    };
    ws.onerror = () => { if(state.socket===ws&&!state.leaving) connectionLabel('연결 오류'); };
    ws.onclose = () => {
      if (state.socket !== ws) return;
      state.online = false;
      for (const [id, value] of state.pending) if (value.message.method === 'account/rateLimitResetCredit/consume') {
        clearTimeout(value.timer); state.pending.delete(id);
        value.reject(Object.assign(new Error('연결이 끊겨 리셋권 사용 결과를 확인하지 못했습니다.'), { uncertain: true }));
      }
      connectionLabel('재연결 중…');
      banner('PC 연결이 끊겼습니다. 자동으로 다시 연결합니다. 보내기 대기 중인 메시지는 보존됩니다.');
      const jitter = Math.floor(Math.random() * 200);
      reconnectTimer = setTimeout(connect, state.delay + jitter);
      state.delay = Math.min(5000, Math.round(state.delay * 1.7));
    };
  } catch (error) { banner(error.message); reconnectTimer = setTimeout(connect, 3000); }
}
async function handleTransport(data) {
  if (data.type === 'heartbeat') return;
  if (data.type === 'serverRequest') { handleEvent(data.message); return; }
  if (data.type === 'ready') {
    state.retries = new Map((data.retries || []).map(r=>[r.threadId,r]));renderStatus();
    syncHostDefaults(data.defaultCwd);
    state.serverCapabilities = data.capabilities || {}; persist('remote.capabilities', state.serverCapabilities);
    const changed = !!state.epoch && state.epoch !== data.epoch;
    state.epoch = data.epoch;
    persist('remote.epoch', state.epoch);
    state.seq = changed ? 0 : state.seq;
    state.online = !!data.online;
    feature.hashes.clear();
    feature.queueHashes.clear();
    state.delay = 300;
    connectionLabel(state.online ? '연결됨' : 'PC Codex 재시작 중…');
    banner(changed ? 'PC 연결 서버가 재시작되었습니다. 전송 결과가 불확실한 항목을 확인하세요.' : data.gap ? '이벤트 일부가 만료되어 대화를 다시 동기화합니다.' : '');
    if (changed) {
      state.activeTurns.clear(); state.turnVersions.clear();
      for (const entry of state.outbox) if (entry.status === 'sending') entry.status = entry.queueProtocol === 2 ? 'queued' : 'uncertain';
      saveOutbox(); renderOutbox();
      for (const [id, value] of state.pending) { clearTimeout(value.timer); value.reject(new Error('PC 연결 서버 재시작')); state.pending.delete(id); }
    } else {
      for (const value of state.pending.values()) if (value.message.method !== 'account/rateLimitResetCredit/consume') wsSend({ type: 'rpc', message: value.message });
    }
    if (state.online) {
      flushOutbox();
      loadPendingQuestions();
      loadModels();
      loadThreads(true, { background: true });
      if (state.currentId) openThread(state.currentId, false);
      openNotificationThread();
      retryVisibleMedia();
    }
    return;
  }
  if (data.type === 'online') {
    state.online = data.online;
    connectionLabel(data.online ? '연결됨' : 'PC Codex 재시작 중…');
    if (data.online) {
      flushOutbox();
      loadPendingQuestions();
      if(state.serverCapabilities.modelCapacityRetry)rpc('bridge/retry/list').then(r=>{state.retries=new Map(r.retries.map(x=>[x.threadId,x]));renderStatus();}).catch(()=>{});
      for (const value of state.pending.values()) wsSend({ type: 'rpc', message: value.message });
      loadModels(); loadThreads(true, { background: true });
      if (state.currentId) openThread(state.currentId, false);
      openNotificationThread();
    }
    return;
  }
  if (data.type === 'response') {
    const message = data.message || {};
    const pending = state.pending.get(message.id);
    if (pending) {
      clearTimeout(pending.timer);
      state.pending.delete(message.id);
      if (message.error) pending.reject(Object.assign(new Error(message.error.message || '요청 실패'), message.error.data || {}));
      else pending.resolve(message.result);
    }
    const out = state.outbox.find(x => (x.rpcId || x.id) === message.id);
    if (out) {
      out.status = message.error ? (/restarted/.test(message.error.message || '') ? 'uncertain' : 'failed') : 'sent';
      out.error = message.error?.message || '';
      if (!message.error) state.outbox = state.outbox.filter(x => x !== out);
      saveOutbox(); renderOutbox();
    }
    return;
  }
  if (data.type === 'event') {
    if (data.seq <= state.seq) return;
    state.seq = data.seq;
    handleEvent(data.message);
  }
}
function handleEvent(message) {
  if (message.method === 'account/rateLimits/updated' || message.method === 'account/updated') {
    accountLimits.invalidate();
    if (message.method === 'account/updated') $('accountCreditBalance')?.remove();
    pocketResetCredits.refresh(); refreshStatus();
  }
  window.pocketDots?.event(message);
  const method = message.method || '';
  const p = message.params || {};
  if(method==='pocket/retry/changed'){if(p.retry)state.retries.set(p.threadId,p.retry);else state.retries.delete(p.threadId);if(p.threadId===state.currentId){if(!p.retry&&$('banner').textContent==='모델 혼잡으로 자동 재시도 대기 중입니다.')banner('');renderStatus();}else if(!$('sidebar').classList.contains('hidden'))renderThreads();}
  featureEvent(method, p);
  sessionEvent(method, p);
  changesEvent(method, p);
  v03Event(method, p);
  if (method === 'pocket/execution/changed' && p.execution) { state.executions.set(p.threadId, p.execution); if (p.threadId === state.currentId) renderStatus(); }
  if (message.id !== undefined && (method.includes('requestApproval') || method.endsWith('requestUserInput'))) {
    state.approvals.set(message.id, message);
    renderApprovals();
  }
  if (method === 'serverRequest/resolved') {
    for (const [id, req] of state.approvals) if (String(id) === String(p.requestId)) state.approvals.delete(id);
    renderApprovals();
  }
  if (method === 'thread/name/updated') applyThreadName(p.threadId, p.threadName ?? p.name);
  if (method === 'thread/started' || method === 'thread/name/updated' || method === 'thread/archived' || method === 'thread/status/changed') {
    clearTimeout(refreshTimer); refreshTimer = setTimeout(() => { if (!document.hidden && !$('sidebar').classList.contains('hidden')) loadThreads(true, { background: true }); }, 300);
  }
  if (method === 'turn/started' || method === 'turn/completed') state.turnVersions.set(p.threadId, ++state.turnRevision);
  if (method === 'turn/started') state.activeTurns.set(p.threadId, p.turn?.id || '');
  if (method === 'turn/completed') {
    state.activeTurns.delete(p.threadId);
    if (p.threadId === state.currentId) state.activeTurn = '';
    flushQueue(p.threadId);
  }
  if (method === 'turn/started' || method === 'turn/completed') {
    const thread = state.threads.find(t => t.id === p.threadId);
    if (thread) thread.status = { ...thread.status, type: method === 'turn/started' ? 'active' : 'idle' };
  }
  if (['turn/started', 'turn/completed', 'pocket/execution/changed'].includes(method) && !$('sidebar').classList.contains('hidden')) renderThreads();
  if (p.threadId !== state.currentId) return;
  if (method === 'turn/started') { state.activeTurn = p.turn?.id || ''; renderStatus(); }
  if (method === 'turn/completed') {
    state.activeTurn = '';
    renderStatus();
    if (p.turn?.error?.message) banner(state.serverCapabilities.modelCapacityRetry&&(p.turn.error.codexErrorInfo==='serverOverloaded'||/model.{0,30}capacity/i.test(p.turn.error.message))?'모델 혼잡으로 자동 재시도 대기 중입니다.':p.turn.error.message);
    setTimeout(() => { if (state.currentId && !state.historyMode) loadLatestItems(loadToken, false).catch(error => banner(error.message)); flushOutbox(); }, 150);
  }
  if ((method === 'item/started' || method === 'item/completed') && p.item) {
    const i = state.items.findIndex(x => x.item.id === p.item.id);
    const entry = { turnId: p.turnId, item: p.item, liveComplete: method === 'item/completed' };
    if (state.historyMode) {
      state.liveItems.set(p.item.id, entry);
      while (state.liveItems.size > HISTORY_WINDOW_SIZE) state.liveItems.delete(state.liveItems.keys().next().value);
      $('latestItems').classList.remove('hidden');
    }
    if (i >= 0) state.items[i] = entry; else if (!state.historyMode) state.items.push(entry);
    state.itemVersions.set(p.item.id, ++state.revision);
    if (state.items.length > HISTORY_WINDOW_SIZE) state.items.shift();
    if (!state.historyMode || i >= 0) scheduleRender();
  }
  const deltaTypes = {
    'item/agentMessage/delta': 'text', 'item/reasoning/summaryTextDelta': 'summary',
    'item/reasoning/textDelta': 'content', 'item/commandExecution/outputDelta': 'aggregatedOutput', 'item/plan/delta': 'text'
  };
  if (deltaTypes[method]) {
    let entry = state.items.find(x => x.item.id === p.itemId) || state.liveItems.get(p.itemId);
    if (!entry) { entry = { turnId: p.turnId, item: { id: p.itemId, type: method.split('/')[1] } }; if (!state.historyMode) state.items.push(entry); }
    entry.liveComplete = false;
    if (state.historyMode) { state.liveItems.set(p.itemId, entry); $('latestItems').classList.remove('hidden'); }
    while (state.liveItems.size > HISTORY_WINDOW_SIZE) state.liveItems.delete(state.liveItems.keys().next().value);
    const item = entry.item;
    state.itemVersions.set(item.id, ++state.revision);
    const field = deltaTypes[method];
    if (field === 'summary' || field === 'content') {
      if (!Array.isArray(item[field])) item[field] = [];
      const index = Number(p.summaryIndex) || 0;
      item[field][index] = (item[field][index] || '') + (p.delta || '');
    } else item[field] = (item[field] || '') + (p.delta || '');
    if (!state.historyMode || state.items.includes(entry)) scheduleRender();
  }
}
function scheduleRender() {
  if (document.hidden || state.leaving) { state.renderPending = true; return; }
  if (state.rendering) return;
  state.rendering = true;
  setTimeout(() => { state.rendering = false; renderTranscript(); }, 80);
}
function modelFastTier(model) {
  // Modern hosts advertise Fast as priority. An explicit tier list is authoritative.
  if (Array.isArray(model?.serviceTiers)) {
    return model.serviceTiers.find(tier => tier.id === 'priority') || model.serviceTiers.find(tier => tier.id === 'fast') || null;
  }
  return model?.additionalSpeedTiers?.includes('fast') ? { id: 'fast', name: 'Fast', description: '' } : null;
}
function serviceTierForSpeed(speed, model) {
  return speed === 'fast' || speed === 'priority' ? modelFastTier(model)?.id || 'default' : 'default';
}
async function loadModels() {
  try {
    const result = await rpc('model/list', { limit: 100 });
    state.models = result.data || [];
    persist('remote.models', state.models);
    renderModels();
    if (!$('sidebar').classList.contains('hidden')) renderThreads();
  } catch (error) { banner('모델 목록: ' + error.message); }
}
function renderModels() {
  const select = $('modelSelect');
  const keep = saved('remote.model.' + state.currentId) || state.current?.model || select.value || saved('remote.model');
  select.replaceChildren();
  for (const model of state.models) {
    const option = document.createElement('option'); option.value = model.model; option.textContent = model.displayName || model.model; select.append(option);
  }
  select.value = state.models.some(x => x.model === keep) ? keep : (state.models.find(x => x.isDefault)?.model || state.models[0]?.model || '');
  renderEfforts();
}
function renderEfforts() {
  const model = state.models.find(x => x.model === $('modelSelect').value);
  const select = $('effortSelect');
  const keep = select.value || saved('remote.effort');
  select.replaceChildren();
  for (const effort of model?.supportedReasoningEfforts || []) {
    const option = document.createElement('option'); option.value = effort.reasoningEffort; option.textContent = effort.reasoningEffort; select.append(option);
  }
  select.value = [...select.options].some(x => x.value === keep) ? keep : model?.defaultReasoningEffort || '';
  const fast = modelFastTier(model);
  $('speedSelect').querySelector('[value="fast"]').disabled = !fast;
  const speed = saved('remote.speed.' + state.currentId) || saved('remote.speed') || $('speedSelect').value;
  $('speedSelect').value = fast && (speed === 'fast' || speed === 'priority') ? 'fast' : 'default';
  renderControlPills();
}
async function loadThreads(reset = false, { background = false } = {}) {
  if (!state.online) return;
  const params = { limit: THREAD_PAGE_SIZE, sortKey: 'updated_at', sourceKinds: ['cli', 'vscode', 'appServer'], archived: state.archived };
  const projectFilter = state.projectFilter || '';
  if (projectFilter.startsWith('project:')) params.projectId = projectFilter.slice(8) || null;
  else if (projectFilter) params.cwd = projectFilter;
  const filterKey = JSON.stringify(params), socket = state.socket, epoch = state.epoch;
  if (!reset && state.threadCursor) params.cursor = state.threadCursor;
  const key = JSON.stringify(params), previous = state.threadListFlight;
  if (previous && previous.socket === socket && previous.epoch === epoch && previous.filterKey === filterKey && (previous.key === key || background)) return previous.promise;
  const request = { socket, epoch, filterKey, key };
  state.threadListFlight = request;
  const valid = () => !state.leaving && state.online && state.socket === socket && state.epoch === epoch && state.archived === params.archived && (state.projectFilter || '') === projectFilter && state.threadListFlight === request;
  const notice = message => {
    const root = $('threadListNotice'), text = $('threadListNoticeText');
    if (text) text.textContent = message;
    root?.classList.toggle('hidden', !message);
  };
  const work = (async () => { try {
    const revisions = new Map(state.turnVersions);
    const result = await rpc('thread/list', params);
    if (!valid()) return;
    notice('');
    for (const thread of result.data || []) {
      if ((state.turnVersions.get(thread.id) || 0) !== (revisions.get(thread.id) || 0)) thread.status = { ...thread.status, type: state.activeTurns.has(thread.id) ? 'active' : 'idle' };
      else if (thread.status?.type !== 'active') state.activeTurns.delete(thread.id);
    }
    state.threads = reset ? result.data || [] : [...state.threads, ...(result.data || [])];
    state.threadCursor = result.nextCursor;
    $('loadMoreThreads').classList.toggle('hidden', !state.threadCursor);
    renderThreads();
    refreshConversationActivity();
  } catch (error) {
    if (!valid()) return;
    notice(error.rpcTimeout || /timed out|timeout|시간.*초과/i.test(error.message) ? '대화 목록 갱신이 지연되어 기존 목록을 유지합니다.' : '대화 목록을 갱신하지 못했습니다. ' + error.message);
  } })().finally(() => { if (state.threadListFlight === request) state.threadListFlight = null; });
  request.promise = work;
  return work;
}
function refreshConversationActivity() {
  if (!state.online || state.leaving) return;
  const socket = state.socket, epoch = state.epoch, now = Date.now();
  if (state.activitySocket !== socket || state.activityEpoch !== epoch) {
    state.activitySocket = socket; state.activityEpoch = epoch;
    state.activityFlights = new Map(); state.activityChecks = new Map();
  }
  const flights = state.activityFlights, checks = state.activityChecks;
  const threads = state.threads.filter(t => t.status?.type === 'active' || state.activeTurns.has(t.id));
  const known = id => { const e = state.executions.get(id), turn = state.activeTurns.get(id); return !!(turn && e?.model && e.speedKnown && e.turnId === turn); };
  threads.sort((a,b) => Number(known(a.id))-Number(known(b.id)) || Number(b.id===state.currentId)-Number(a.id===state.currentId));
  for (const thread of threads) {
    if (flights.size >= 4) break;
    const id = thread.id, revision = state.turnVersions.get(id) || 0, check = checks.get(id);
    if (flights.has(id) || check?.revision === revision && check.nextAt > now) continue;
    const execution = state.executions.get(id), turnBefore=state.activeTurns.get(id), request = { revision };
    flights.set(id,request); checks.set(id,{revision,nextAt:now+5000});
    // Separate reads let a slow PC session delay only its own row. Avoid
    // includeExecution, which also scans every push watch on older hosts.
    rpc('bridge/notifications/list',{threadIds:[id],activityOnly:true}).then(result => {
      if (state.leaving || !state.online || state.socket!==socket || state.epoch!==epoch || (state.turnVersions.get(id)||0)!==revision) return;
      const active = result.activity?.find(a=>a.threadId===id) || result.active?.find(a=>a.threadId===id&&a.execution);
      if (!active) return;
      const turnNow=state.activeTurns.get(id);if(turnNow!==turnBefore&&turnNow!==active.turnId)return;
      if (active.active === false) {
        state.activeTurns.delete(id);const row=state.threads.find(t=>t.id===id);if(row)row.status={...row.status,type:'idle'};
        if (id===state.currentId) {state.activeTurn='';renderStatus();}
      } else if (active.turnId) {
        state.activeTurns.set(id,active.turnId);
        if (active.execution?.turnId===active.turnId && state.executions.get(id)===execution) {
          const old=execution?.turnId===active.turnId?execution:null;
          state.executions.set(id,old?.speedKnown&&!active.execution.speedKnown?{...active.execution,model:active.execution.model||old.model,serviceTier:old.serviceTier,speedKnown:true}:active.execution);
        }
        if (id===state.currentId) {state.activeTurn=active.turnId;renderStatus();}
      }
      checks.set(id,{revision,nextAt:Date.now()+(known(id)?10000:2000)});
      if (!$('sidebar').classList.contains('hidden')) renderThreads();
    }).catch(()=>{}).finally(()=>{
      if (state.activityFlights!==flights || flights.get(id)!==request) return;
      flights.delete(id);
      if (!$('sidebar').classList.contains('hidden')) refreshConversationActivity();
    });
  }
  const ids=new Set(threads.map(t=>t.id));for(const id of checks.keys())if(!ids.has(id))checks.delete(id);
}
function applyThreadName(id, name) {
  if (!id || typeof name !== 'string' || !name.trim()) return;
  name = name.trim();
  const thread = state.threads.find(t => t.id === id);
  if (thread) thread.name = name;
  if (v03.favoriteThreads[id]) { v03.favoriteThreads[id].name = name; persist('remote.favoriteThreads', v03.favoriteThreads); }
  const metadata = saved('remote.meta.' + id);
  if (metadata) persist('remote.meta.' + id, { ...metadata, name });
  if (state.currentId === id) {
    if (state.current) { state.current.name = name; persist('remote.meta.' + id, { ...metadata, ...state.current, name }); }
    $('threadTitle').textContent = name;
  }
  if (!$('sidebar').classList.contains('hidden')) renderThreads();
}
function renderThreads() {
  renderConversationList();
}
async function openThread(id, hideMenu = true, freshThread = null, focus = null) {
  const token = ++loadToken;
  const sameThread = state.currentId === id && state.items.length > 0;
  const keepHistory = sameThread && state.historyMode;
  state.openingThread = id;
  state.currentId = id; persist('remote.currentId', id);
  state.current = freshThread || state.threads.find(x => x.id === id) || v03.favoriteThreads[id] || saved('remote.meta.' + id) || { id };
  state.agentReportedResult=focus?.report||saved('remote.agentReport.'+id)||null;
  if(focus) { if(focus.report)persist('remote.agentReport.'+id,focus.report);else{state.agentReportedResult=null;removeSaved('remote.agentReport.'+id);} }
  state.readOnly = false; state.historyLoading = false; $('historyStatus').classList.add('hidden');
  if (state.current.cwd) state.cwd = state.current.cwd;
  if (!sameThread) { state.items = saved('remote.cache.' + id) || []; state.itemVersions.clear(); state.liveItems.clear(); }
  state.historyMode = keepHistory;
  if (!keepHistory) { state.itemCursor = null; state.historyWindow = new HistoryWindow(); }
  if(focus?.page){state.items=[...(focus.page.data||[])].reverse();resetHistoryWindow(focus.page,focus.fromOlder?focus.page.backwardsCursor:null);state.historyMode=!!focus.itemId;v03.pinned=false;$('latestItems').classList.toggle('hidden',!state.historyMode);}
  state.activeTurn = state.activeTurns.get(id) || '';
  $('emptyState').classList.add('hidden'); $('chatView').classList.remove('hidden');
  $('threadTitle').textContent = state.current.name || state.current.preview || '새 대화';
  renderSubagentNavigation();
  if (hideMenu) closeSidebar();
  renderThreads(); renderModels(); renderTranscript(); renderApprovals();
  $('messageInput').value = saved('remote.draft.' + id) || '';
  if (!sameThread) restoreAssets(id);
  renderOutbox(); renderGoal(); inputChanged();
  if (!state.online) { state.openingThread = ''; banner('오프라인 상태입니다. 마지막으로 읽은 내역을 표시합니다.'); return; }
  banner('');
  try {
    flushQueue();
    loadFeatureThread(id);
    rpc('bridge/notifications/watch', { threadId: id }).catch(() => {});
    // thread/start already returned this loaded, empty session. Enter it without
    // waiting for a list refresh or querying history that cannot exist yet.
    if (freshThread) { persist('remote.meta.' + id, state.current); renderStatus(); return; }
    // Paint history as soon as it arrives. Metadata, history and turn status
    // are independent reads; a slow one must not delay the other requests.
    const settled = promise => promise.then(value => ({ value }), error => ({ error }));
    const latestWork = keepHistory || focus?.page ? Promise.resolve({ value: true }) : settled(loadLatestItems(token));
    const turnVersion = state.turnVersions.get(id) || 0;
    const turnsWork = state.current.ephemeral ? Promise.resolve({ value: { data: [] } }) : settled(rpc('thread/turns/list', { threadId: id, limit: 1, itemsView: 'notLoaded', sortDirection: 'desc' }));
    let read;
    try { read = await rpc('thread/read', { threadId: id, includeTurns: false }); }
    catch (error) {
      if (!state.current.preview && !state.items.length && /not materialized|thread not loaded|rollout .* is empty/i.test(error.message)) read = { thread: state.current };
      else throw error;
    }
    if (token !== loadToken) return;
    state.current = read.thread || state.current;
    renderSubagentNavigation();
    if (state.current.cwd) state.cwd = state.current.cwd;
    $('threadTitle').textContent = state.current.name || state.current.preview || '새 대화';
    if (state.current.model) $('modelSelect').value = saved('remote.model.' + id) || state.current.model;
    renderEfforts();
    if (state.current.reasoningEffort) $('effortSelect').value = saved('remote.effort.' + id) || state.current.reasoningEffort;
    const subscribeWork = (async () => {
      // A session can have an empty preview despite existing history. Let that
      // page determine whether it needs a subscription instead of skipping it.
      if (!state.items.length && !state.current.preview) await latestWork;
      if (token !== loadToken) return;
      try { if (!state.subagentView && !state.archived && !state.current.ephemeral && (state.items.length || state.current.preview)) await rpc('thread/resume', { threadId: id, excludeTurns: true }); }
      catch (error) { if (token !== loadToken) return; state.readOnly = /active writer|archived/i.test(error.message); banner(/archived/i.test(error.message) ? '보관된 대화입니다. 보관을 해제하면 작업을 이어갈 수 있습니다.' : state.readOnly ? (state.serverCapabilities.sharedDesktop ? '다른 연결에서 진행 중인 대화입니다. PC 앱의 공유 연결 전환을 확인해 주세요. 내역은 계속 갱신됩니다.' : 'PC 앱이 진행 중인 대화입니다. 공유 연결을 설정하면 이 대화에도 지시를 보낼 수 있습니다.') : '대화 연결: ' + error.message); }
    })();
    const history = await latestWork;
    if (token !== loadToken) return;
    let historyLoaded = !history.error;
    if (history.error) {
      const error = history.error;
      if (/thread not loaded/i.test(error.message) && !state.current.preview) historyLoaded = true;
      else banner('내역 조회: ' + error.message);
    }
    await subscribeWork;
    if (token !== loadToken) return;
    if (!historyLoaded) await loadLatestItems(token);
    let turns = { data: [] };
    try {
      const result = await turnsWork;
      if (result.error && /thread not loaded/i.test(result.error.message) && !state.current.ephemeral) turns = await rpc('thread/turns/list', { threadId: id, limit: 1, itemsView: 'notLoaded', sortDirection: 'desc' });
      else if (result.error) throw result.error;
      else turns = result.value;
    }
    catch (error) {
      const emptyThread = !state.current.preview && !state.items.length;
      if (!/thread not loaded/i.test(error.message) && !(emptyThread && /not materialized|rollout .* is empty/i.test(error.message))) throw error;
    }
    if (!state.current.ephemeral && token === loadToken && (state.turnVersions.get(id) || 0) === turnVersion) {
      state.activeTurn = turns.data?.[0]?.status === 'inProgress' ? turns.data[0].id : '';
      if (state.activeTurn) state.activeTurns.set(id, state.activeTurn); else state.activeTurns.delete(id);
    }
    if (token === loadToken) renderStatus();
  } catch (error) { if (token === loadToken) banner('대화 열기: ' + error.message); }
  finally { if (token === loadToken) {
    state.openingThread = ''; globalThis.userMessageNavigation?.refresh(); flushQueue(id); flushOutbox();
    if(focus?.itemId)requestAnimationFrame(()=>{if(token!==loadToken)return;const node=[...$('transcript').children].find(n=>n.dataset.itemId===focus.itemId);if(node){v03.ignoreScroll=true;node.scrollIntoView({block:'center'});v03.pinned=false;rememberScroll();requestAnimationFrame(()=>{if(token===loadToken)v03.ignoreScroll=false;});}});
  } }
}
const historyPageReader = new HistoryPageReader();
function readHistoryPage(direction, cursor, consume = false) {
  const threadId = state.currentId, token = loadToken;
  historyPageReader.bind(state.socket, threadId, token);
  return historyPageReader.read(direction, cursor, async () => {
    const revision = state.revision;
    const page = await rpc('thread/items/list', { threadId, limit: HISTORY_PAGE_SIZE, sortDirection: direction === 'older' ? 'desc' : 'asc', cursor });
    return { page, revision };
  }, consume);
}
function warmHistoryPage(direction = 'older') {
  if (!state.online || !state.currentId || state.current?.ephemeral || document.hidden) return;
  const cursor = direction === 'older' ? state.historyWindow.olderCursor : state.historyWindow.newerCursor;
  if (cursor) readHistoryPage(direction, cursor).catch(() => {});
}
function resetHistoryWindow(page,newerCursor=null) {
  state.historyWindow = new HistoryWindow();
  state.historyWindow.reset(page, state.items,newerCursor);
  state.itemCursor = state.historyWindow.olderCursor;
  warmHistoryPage();
}
async function loadLatestItems(token = loadToken, scroll = true, returningHistory = false) {
  if (!state.currentId) return;
  if (state.current?.ephemeral) {
    state.itemCursor = null;
    renderTranscript(scroll);
    return;
  }
  const revision = state.revision;
  let result;
  try { result = await rpc('thread/items/list', { threadId: state.currentId, limit: HISTORY_PAGE_SIZE, sortDirection: 'desc' }); }
  catch (error) {
    const emptyThread = !state.current?.preview && !state.items.length;
    if (!emptyThread || !/not materialized|not supported yet|thread not loaded|rollout .* is empty/i.test(error.message)) throw error;
    result = { data: [], nextCursor: null };
  }
  if (token !== loadToken || state.historyLoading && !returningHistory || state.historyMode && !scroll) return;
  const changed = [...state.items.filter(x => (state.itemVersions.get(x.item.id) || 0) > revision), ...[...state.liveItems.values()].filter(x => x.liveComplete === false)];
  const changedById = new Map(changed.map(x => [x.item.id, x]));
  state.items = (result.data || []).reverse().map(x => changedById.get(x.item.id) || x);
  const ids = new Set(state.items.map(x => x.item.id));
  state.items.push(...[...changedById.values()].filter(x => !ids.has(x.item.id)));
  state.items = state.items.slice(-HISTORY_WINDOW_SIZE);
  state.historyMode = false; state.liveItems.clear(); $('latestItems').classList.add('hidden');
  persist('remote.cache.' + state.currentId, cachedItems(state.items));
  if (state.current) persist('remote.meta.' + state.currentId, { id: state.currentId, name: state.current.name, preview: state.current.preview, model: state.current.model, cwd: state.current.cwd, reasoningEffort: state.current.reasoningEffort, isPinned: state.current.isPinned, source:state.current.source, parentThreadId:state.current.parentThreadId||null });
  const order = (saved('remote.cacheOrder') || []).filter(x => x !== state.currentId);
  order.push(state.currentId);
  while (order.length > 8) { const old = order.shift(); removeSaved('remote.cache.' + old); removeSaved('remote.meta.' + old); }
  persist('remote.cacheOrder', order);
  resetHistoryWindow(result);
  renderTranscript(scroll);
  renderStatus();
}
async function loadOlderItems() { return loadHistoryItems('older'); }
async function loadNewerItems() { return loadHistoryItems('newer'); }
async function loadHistoryItems(direction) {
  if (state.historyLoading || !state.online || state.openingThread || !state.currentId) return;
  const window = state.historyWindow;
  const cursor = direction === 'older' ? window.olderCursor : window.newerCursor;
  if (!cursor && (direction === 'older' || !state.historyMode)) return;
  const token = loadToken;
  const transcript = $('transcript');
  state.historyLoading = true; state.historyMode = true;
  globalThis.userMessageNavigation?.refresh();
  $('historyStatus').textContent = direction === 'older' ? '이전 대화 불러오는 중…' : '최근 대화 불러오는 중…';
  $('historyStatus').classList.remove('hidden');
  $('latestItems').classList.remove('hidden');
  try {
    if (!cursor) { await loadLatestItems(token, true, true); return; }
    const { page: result, revision } = await readHistoryPage(direction, cursor, true);
    if (token !== loadToken) return;
    const top = transcript.getBoundingClientRect().top;
    const anchor = [...transcript.children].find(x => x.getBoundingClientRect().bottom > top);
    const anchorId = anchor?.dataset.itemId;
    const anchorOffset = anchor ? anchor.getBoundingClientRect().top - top : 0;
    for (const entry of state.items) if (entry.liveComplete === false) state.liveItems.set(entry.item.id, entry);
    const overrides = new Map([...state.items, ...state.liveItems.values()].filter(x => (state.itemVersions.get(x.item.id) || 0) > revision || x.liveComplete === false).map(x => [x.item.id, x]));
    window.accept({ ...result, nextCursor: result.nextCursor === cursor ? null : result.nextCursor }, direction, state.items, overrides);
    state.items = window.items;
    state.itemCursor = window.olderCursor;
    warmHistoryPage(direction);
    v03.ignoreScroll = true;
    renderTranscript(false);
    const restored = [...transcript.children].find(x => x.dataset.itemId === anchorId);
    if (restored) transcript.scrollTop += restored.getBoundingClientRect().top - top - anchorOffset;
    $('latestItems').classList.remove('hidden');
  } catch (error) { if (token === loadToken) banner((direction === 'older' ? '이전 내역: ' : '최근 내역: ') + error.message); }
  finally { if (token === loadToken) {
    state.historyLoading = false; $('historyStatus').classList.add('hidden'); rememberScroll();
    globalThis.userMessageNavigation?.refresh();
    requestAnimationFrame(() => {
      if(token!==loadToken)return;
      v03.ignoreScroll = false;
      if (globalThis.userMessageNavigation?.isNavigating) return;
      // Hidden/empty items can leave the edge in place without another scroll event.
      if(direction==='older'&&transcript.scrollTop<historyLoadDistance(transcript)&&window.olderCursor)loadOlderItems();
      else if(direction==='newer'&&state.historyMode&&transcript.scrollHeight-transcript.scrollTop-transcript.clientHeight<historyLoadDistance(transcript))loadNewerItems();
    });
  } }
}
function textOf(value) {
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(x => typeof x === 'string' ? x : (x?.text || '')).filter(Boolean).join('\n');
  return '';
}
function describe(item) {
  const semantic = semanticItem(item, { liveComplete: true });
  if (semantic) return semantic.text;
  switch (item.type) {
    case 'userMessage': return displayUserText(textOf(item.content));
    case 'agentMessage': return item.text || '';
    case 'reasoning': return textOf(item.summary) || '생각 중…';
    case 'commandExecution': return item.command || '';
    case 'fileChange': return (item.changes || []).map(x => x.path + ' (' + x.kind + ')').join('\n') || '파일 변경';
    case 'webSearch': return item.query || '웹 검색';
    case 'mcpToolCall': return [item.server, item.tool, item.status].filter(Boolean).join(' · ');
    case 'plan': return item.text || '';
    case 'functionCallOutput': return typeof item.output==='string'?item.output.slice(0,2000):textOf(item.output).slice(0,2000);
    case 'imageGeneration': return item.status==='completed'?'':item.status==='failed'?'이미지 생성 실패':'이미지 생성 중…';
    case 'imageView': return '';
    case 'dynamicToolCall': return [item.namespace,item.tool,item.status].filter(Boolean).join(' · ');
    default: return item.text || item.review || '작업 진행 상황';
  }
}
function renderTranscript(toBottom = false) {
  if (document.hidden || state.leaving || globalThis.pocketDots?.ui.open) { state.renderPending = true; return; }
  state.renderPending = false;
  const root = $('transcript');
  const nearBottom = root.scrollHeight - root.scrollTop - root.clientHeight < 150;
  const nodes = new Map([...root.children].map(x => [x.dataset.itemId, x]));
  const keep = new Set();
  let previous = null;
  const report=state.subagentView&&state.agentReportedResult;
  const visibleEntries=report&&!state.items.some(e=>e.item?.type==='agentMessage'&&e.item.text===report.text)?[...state.items,{turnId:'',item:report}]:state.items;
  for (const entry of visibleEntries) {
    const item = entry.item || {};
    if (item.type === 'reasoning' && !textOf(item.summary) && !(entry.liveComplete === false && entry.turnId === state.activeTurn)) continue;
    let article = nodes.get(item.id);
    if (!article) {
      article = document.createElement('article'); article.dataset.itemId = item.id;
      const kind = document.createElement('div'); kind.className = 'kind';
      const body = document.createElement('div'); body.className = 'body';
      article.append(kind, body); article.kindNode = kind; article.bodyNode = body;
    }
    const version = state.itemVersions.get(item.id) || 0, questionStatus = v03.questionStates.get(state.currentId + ':' + item.id)?.status;
    const unchanged = article.remoteItem === item && article.remoteVersion === version && article.remoteQuestionStatus === questionStatus && article.remoteHistoryMode === state.historyMode && article.remoteThreadId === state.currentId && article.remoteTurnId === entry.turnId;
    if (!unchanged) {
    article.className = 'item ' + (item.type || 'other');
    if (item.type === 'userMessage') {
      article.tabIndex = 0; article.title = '길게 눌러 메시지 복사'; article.setAttribute('aria-haspopup', 'dialog');
    }
    const kind = article.kindNode;
    if (article.remoteType !== item.type) kind.textContent = ({ userMessage: '나', agentMessage: 'Codex', reasoning: '생각 중', commandExecution: '명령', fileChange: '파일 변경', webSearch: '검색', mcpToolCall: '도구', plan: '계획',functionCallOutput:'결과',imageGeneration:'생성 이미지',imageView:'이미지',dynamicToolCall:'도구' })[item.type] || '진행';
    if(item.reportedFromParent)kind.textContent='루트 대화에 보고된 결과';
    const body = article.bodyNode; const text = describe(item);
    if (body.remoteText !== text) {
      body.remoteText = text;
      if (['userMessage','agentMessage','plan','reasoning'].includes(item.type)) renderMarkdown(body, text);
      else { body.classList.remove('markdown'); body.textContent = text; }
    }
    renderItemExtras(article, entry);
    renderSemanticItem(article, entry);
    if (item.type === 'commandExecution' && item.aggregatedOutput) {
      let details = article.querySelector('details');
      if (!details) {
        details = document.createElement('details');
        const summary = document.createElement('summary'); summary.textContent = '출력 보기';
        const pre = document.createElement('pre');
        details.append(summary, pre); article.append(details);
        details.ontoggle = () => { pre.textContent = details.open ? details.remoteOutput : ''; };
      }
      details.remoteOutput = item.aggregatedOutput;
      if (details.open) details.querySelector('pre').textContent = item.aggregatedOutput;
    }
    article.remoteItem = item; article.remoteVersion = version; article.remoteQuestionStatus = questionStatus; article.remoteHistoryMode = state.historyMode; article.remoteThreadId = state.currentId; article.remoteTurnId = entry.turnId; article.remoteType = item.type;
    }
    keep.add(article);
    const expected = previous ? previous.nextSibling : root.firstChild;
    if (expected !== article) root.insertBefore(article, expected);
    previous = article;
  }
  for (const article of nodes.values()) if (!keep.has(article)) { releaseItemMedia(article); article.remove(); }
  if (!v03.questionEditor && !globalThis.userMessageNavigation?.busy && (toBottom || nearBottom && !state.historyMode)) root.scrollTop = root.scrollHeight;
  rememberScroll();
  renderSessionChips();
  globalThis.userMessageNavigation?.refresh();
}
function executionLabel(execution) {
  const model = state.models.find(m => m.model === execution?.model);
  const speed = !execution?.speedKnown ? '속도 정보 없음' : ['priority', 'fast'].includes(execution.serviceTier) ? 'Fast' : !execution.serviceTier || execution.serviceTier === 'default' ? '보통' : '속도 정보 없음';
  return [model?.displayName || execution?.model || '모델 정보 없음', speed].join(' · ');
}
function renderStatus() {
  const execution = state.executions.get(state.currentId);
  const retry=state.retries.get(state.currentId),seconds=retry?.nextRetryAt?Math.max(0,Math.ceil((retry.nextRetryAt-Date.now())/1000)):0;
  const retryLabel=retry?.status==='native'?'모델 혼잡 · 서버에서 재시도 중':retry?.status==='checking'?'재시도 전송 결과 확인 중':retry?.status==='loginRequired'?'재시도하려면 PC 로그인을 확인하세요':retry?.reason==='writer'?'PC 작업 연결 확인 · 자동 재시도 대기':!state.online?'재시도 예약 · PC 연결 대기':seconds?seconds+'초 후 자동 재시도':'자동 재시도 준비 중';
  $('threadStatus').textContent = retry ? '↻ '+retryLabel+(execution?.turnId===retry.turnId?' · '+executionLabel(execution):'') : state.activeTurn ? '● 작업 중 · ' + (execution?.turnId === state.activeTurn ? executionLabel(execution) : '모델 · 속도 확인 중') : '대기 중';
  renderControlPills();
  globalThis.userMessageNavigation?.refresh();
  if (state.threads) {
    const thread = state.threads.find(t => t.id === state.currentId);
    if (thread) thread.status = { ...thread.status, type: state.activeTurn ? 'active' : 'idle' };
    if ($('sidebar')?.classList?.contains('hidden') === false) renderThreads();
  }
}
function sandboxPolicy() {
  const mode = $('permissionSelect').value;
  if (mode === 'danger-full-access') return { type: 'dangerFullAccess' };
  if (mode === 'read-only') return { type: 'readOnly', networkAccess: false };
  return { type: 'workspaceWrite', writableRoots: [], networkAccess: false, excludeTmpdirEnvVar: false, excludeSlashTmp: false };
}
async function createThread(project = null) {
  if (!state.online) { banner('먼저 PC에 연결하세요.'); return; }
  const socket = state.socket, epoch = state.epoch, navigation = loadToken;
  if (state.newThreadFlight?.socket === socket) return state.newThreadFlight.promise;
  const request = { socket };
  const valid = () => state.socket === socket && state.epoch === epoch && !state.leaving;
  for (const id of ['newThread', 'emptyNew']) $(id).disabled = true;
  state.newThreadFlight = request;
  request.promise = (async () => { try {
    const cwd = project?.roots?.find(root => typeof root.path === 'string' && root.path)?.path || state.defaultCwd;
    const result = await rpc('thread/start', { projectId: project?.id || null, ...(cwd?{cwd}:{}), model: $('modelSelect').value || null, sandbox: $('permissionSelect').value, approvalPolicy: $('approvalSelect').value, serviceTier: serviceTierForSpeed($('speedSelect').value, state.models.find(x => x.model === $('modelSelect').value)), serviceName: 'codex_pocket_remote' });
    if (!valid()) return;
    if (!result.thread?.id) throw new Error('새 대화 정보를 받지 못했습니다.');
    if (!state.threads.some(t => t.id === result.thread.id)) state.threads.unshift(result.thread);
    persist('remote.projectAssignment.' + result.thread.id, project?.id || '');
    if (navigation === loadToken) { state.archived = false; state.projectFilter = project ? 'project:' + project.id : ''; await openThread(result.thread.id, true, result.thread); }
    loadThreads(true, { background: true });
    return result.thread;
  } catch (error) { if (valid()) banner('새 대화: ' + error.message); }
  finally { if (state.newThreadFlight === request) { state.newThreadFlight = null; for (const id of ['newThread', 'emptyNew']) $(id).disabled = false; } }
  })();
  return request.promise;
}
function projectCatalogScope() { return state.socket; }
async function readProjects(cursor = null) {
  const socket = projectCatalogScope(), epoch = state.epoch;
  const current = state.projectCatalogFlight;
  if (current?.socket === socket && current.epoch === epoch && current.cursor === cursor) return current.promise;
  const request = { socket, epoch, cursor };
  state.projectCatalogFlight = request;
  request.promise = rpc('project/list', { limit: 100, cursor }).then(result => {
    if (socket !== projectCatalogScope() || epoch !== state.epoch || state.leaving) return null;
    if (!Array.isArray(result.data)) throw new Error('프로젝트 목록을 확인하지 못했습니다.');
    const projects = result.data.filter(p => p && typeof p.id === 'string' && typeof p.name === 'string').map(p => ({ id: p.id, name: p.name, roots: Array.isArray(p.roots) ? p.roots.filter(r => typeof r?.path === 'string') : [] }));
    const old = cursor ? saved('remote.projects')?.projects || [] : [];
    const data = { projects: [...new Map([...old, ...projects].map(p => [p.id, p])).values()], nextCursor: result.nextCursor || null };
    persist('remote.projects', data);
    return data;
  }).finally(() => { if (state.projectCatalogFlight === request) state.projectCatalogFlight = null; });
  return request.promise;
}
function newThread() {
  if (!state.online) { banner('먼저 PC에 연결하세요.'); return; }
  if (state.newThreadFlight?.socket === state.socket) return state.newThreadFlight.promise;
  return selectThreadProject('새 대화', project => createThread(project));
}
function selectThreadProject(title, onSelect, { noneLabel = '프로젝트 없이 시작', noneDescription = 'PC의 기본 작업 폴더를 사용합니다.', subtitle = '프로젝트를 선택하면 대화를 시작합니다.', selectedId } = {}) {
  const socket = projectCatalogScope(), epoch = state.epoch;
  const root = picker(title, subtitle);
  let catalog = saved('remote.projects') || { projects: [], nextCursor: null }, loading = false;
  const search = el('input'); search.type = 'search'; search.placeholder = '프로젝트 검색'; search.setAttribute('aria-label', '프로젝트 검색');
  pickerRow(root, noneLabel, noneDescription, () => { closePicker(); return onSelect(null); }, { icon: '＋', checked: selectedId === '' });
  root.append(search);
  const list = el('div', undefined, 'new-project-list'), note = el('p', '프로젝트를 확인하는 중…', 'muted'); note.setAttribute('role', 'status');
  const more = action('프로젝트 더 보기', () => refresh(catalog.nextCursor), 'ghost full');
  root.append(list, note, more);
  const valid = () => projectCatalogScope() === socket && state.epoch === epoch && !state.leaving && root.contains(list) && !$('pickerOverlay').classList.contains('hidden');
  function draw() {
    if (!valid()) return;
    const query = search.value.trim().toLocaleLowerCase(); list.replaceChildren();
    for (const project of catalog.projects) if ((project.name + ' ' + (project.roots || []).map(r => r.path).join(' ')).toLocaleLowerCase().includes(query)) {
      pickerRow(list, project.name, project.roots?.map(r => r.path).join(' · ') || '등록된 프로젝트', () => { closePicker(); return onSelect(project); }, { icon: '▱', checked: selectedId === project.id });
    }
    more.classList.toggle('hidden', !catalog.nextCursor); more.disabled = loading;
  }
  async function refresh(cursor = null) {
    if (loading) return; loading = true; more.disabled = true;
    try { const result = await readProjects(cursor); if (!valid() || !result) return; catalog = result; note.textContent = catalog.projects.length ? '' : '등록된 프로젝트가 없습니다.'; }
    catch (error) { if (valid()) note.textContent = /unknown variant|unknown method|not supported/i.test(error.message) ? '프로젝트 선택을 사용하려면 PC의 Codex를 업데이트해 주세요.' : '프로젝트 갱신이 지연되었습니다. 표시된 프로젝트를 선택하거나 프로젝트 없이 시작할 수 있습니다.'; }
    finally { loading = false; draw(); }
  }
  search.oninput = draw; draw(); refresh();
}
async function enqueueMessage() {
  if(state.subagentView){banner('루트 대화로 돌아가서 지시해 주세요.');return;}
  const text = $('messageInput').value.trim();
  if (commandAction(text)) return;
  let typedMentions = [];
  if (/(?:^|[\s([{])@/.test(text)) {
    if (feature.mentionResolving) return;
    feature.mentionResolving = true;
    const scope = pluginCatalogScope();
    try { const catalog = await readPluginCatalog(); if (scope !== pluginCatalogScope() || $('messageInput').value.trim() !== text) return; typedMentions = resolvePluginMentions(text, catalog.plugins || []); }
    catch (error) { banner(error.message); return; }
    finally { feature.mentionResolving = false; }
  }
  if (!text && !feature.attachments.length && !feature.mentions.length) {
    if(state.retries.has(state.currentId)&&state.serverCapabilities.modelCapacityRetry)try{await rpc('bridge/retry/cancel',{threadId:state.currentId});state.retries.delete(state.currentId);renderStatus();}catch(e){banner(e.message);return;}
    if (state.activeTurn) try { await rpc('turn/interrupt', { threadId: state.currentId, turnId: state.activeTurn }); } catch (e) { banner(e.message); }
    return;
  }
  if (!state.currentId) {
    const assets = { attachments: feature.attachments, mentions: feature.mentions };
    const created = await createThread(); if (!created || state.currentId !== created.id) return;
    feature.attachments = assets.attachments; feature.mentions = assets.mentions; saveAssets(); renderAssets();
  }
  if (!state.currentId) return;
  if (feature.attachments.some(a => !a.complete)) { banner('파일 업로드를 완료하거나 미완료 파일을 제거한 뒤 보내세요.'); return; }
  const task = { id: 'c:' + uuid(), queueProtocol: 2, threadId: state.currentId, text, attachments: structuredClone(feature.attachments), mentions: structuredClone(mergeMentions(feature.mentions, typedMentions)), status: 'queued', epoch: state.epoch, createdAt: Date.now(), cwd: state.cwd, model: $('modelSelect').value, effort: $('effortSelect').value, speed: $('speedSelect').value, sandboxPolicy: sandboxPolicy(), approvalPolicy: $('approvalSelect').value, followup: $('followupSelect').value === 'steer' ? 'steer' : 'queue' };
  task.serviceTierForTurn = serviceTierForSpeed(task.speed, state.models.find(x => x.model === task.model));
  state.outbox.push(task);
  if (!saveOutbox()) { state.outbox.pop(); banner('앱 저장 공간이 부족해 입력을 보관하지 못했습니다. 입력은 편집기에 남겨 두었습니다.'); return; }
  $('messageInput').value = '';
  persist('remote.draft.' + state.currentId, '');
  feature.attachments = []; feature.mentions = []; saveAssets(); renderAssets(); inputChanged();
  renderOutbox(); flushOutbox();
}
function flushQueue() {
  if (state.queue.length) { const ids = new Set(state.outbox.map(x => x.id)); state.outbox.push(...state.queue.filter(x => !ids.has(x.id))); state.queue = []; saveQueue(); saveOutbox(); }
  flushOutbox();
}
async function flushOutbox() {
  if (!state.online) return;
  const operations = [];
  for (const entry of state.outbox) {
    if (entry.status === 'uncertain' || entry.status === 'failed') continue;
    if (entry.followup === 'steer' && !state.serverCapabilities.steeringSend) { entry.status = 'failed'; entry.error = '이 PC의 Pocket Remote를 업데이트하면 Steering 전송을 사용할 수 있습니다.'; saveOutbox(); renderOutbox(); continue; }
    if (entry.status === 'sending' && state.pending.has(entry.rpcId || entry.id)) continue;
    const params = { id: entry.id.slice(2), threadId: entry.threadId, text: entry.text, attachments: entry.attachments || [], mentions: entry.mentions || [], input: buildUserInputs(entry), settings: settingsSnapshot(entry), mode: entry.followup === 'steer' ? 'steer' : 'queue' };
    if (params.mode === 'steer') params.expectedTurnId = entry.threadId === state.currentId ? state.activeTurn : state.activeTurns.get(entry.threadId);
    entry.status = 'sending'; entry.epoch = state.epoch; entry.queueProtocol = 2; entry.rpcId = 'c:' + uuid(); saveOutbox(); renderOutbox();
    operations.push(rpc('bridge/queue/add', params, entry.rpcId).then(result => {
      // A retried ID returns the durable receipt without starting a duplicate turn.
      if (result.entry && ['queued', 'dispatching', 'failed', 'uncertain'].includes(result.entry.status)) {
        const list = feature.queues.get(entry.threadId) || []; feature.queues.set(entry.threadId, [...list.filter(x => x.id !== result.entry.id), result.entry]); renderOutbox();
      }
    }).catch(error => {
      entry.status = error.profileSwitch || /reconnecting|restarted|timed out|재시작|초과/i.test(error.message) ? 'queued' : 'failed';
      if (/reconnecting/i.test(error.message)) state.online = false;
      entry.error = error.message; saveOutbox(); renderOutbox();
    }));
  }
  await Promise.allSettled(operations);
}
function renderOutbox() {
  renderQueueRows();
}
function renderApprovals() {
  renderQuestionAttention();
  const relevant = [...state.approvals.values()].filter(x => x.params?.threadId === state.currentId);
  const pendingQuestions=[...v03.questionStates.values()].filter(q=>q.threadId===state.currentId&&['pending','answering','uncertain'].includes(q.status));
  const box = $('approvalBox'),key=JSON.stringify([state.currentId,relevant,pendingQuestions]);
  if(box.remoteKey===key)return;box.remoteKey=key;
  const wanted=[];
  for (const request of relevant) {
    const row = document.createElement('div'); row.className = 'approval';
    const label = document.createElement('strong'); label.textContent = '승인 요청 · ' + request.method;
    const detail = document.createElement('pre'); detail.textContent = request.params?.reason || request.params?.command || request.params?.grantRoot || JSON.stringify(request.params?.networkApprovalContext || {});
    row.append(label, detail);
    if (request.method.endsWith('requestUserInput')) {
      const key=state.currentId+':'+request.params.itemId;
      if(v03.questionStates.get(key)?.status==='answered')continue;
      wanted.push(questionCard(request.params.itemId,request.params.questions||[],request.params.turnId,request.id));continue;
    }
    for (const [title, decision] of [['한 번 허용', 'accept'], ['이 대화에서 허용', 'acceptForSession'], ['거부', 'decline']]) {
      const button = document.createElement('button'); button.className = decision === 'decline' ? 'ghost' : 'primary'; button.textContent = title;
      button.onclick = () => {
        const result = request.method === 'item/permissions/requestApproval' ? { permissions: decision === 'decline' ? {} : request.params.permissions, scope: decision === 'acceptForSession' ? 'session' : 'turn' } : { decision };
        wsSend({ type: 'response', message: { id: request.id, result } }); state.approvals.delete(request.id); renderApprovals();
      };
      row.append(button);
    }
    wanted.push(row);
  }
  for(const q of pendingQuestions)if(!relevant.some(r=>r.params?.itemId===q.itemId))wanted.push(questionCard(q.itemId,q.questions,q.turnId));
  syncQuestionEditor(wanted);
  // Updating the conversation or replaying a question must not detach its
  // input element: Android closes the IME and cancels composition on detach.
  for(const node of [...box.children])if(!wanted.includes(node))node.remove();
  for(const node of wanted)if(node.parentNode!==box)box.append(node);
  box.classList.toggle('hidden',!box.children.length);
}

$('menuButton').onclick = toggleSidebar;
$('closeMenu').onclick = closeSidebar;
$('settingsButton').onclick = $('emptySettings').onclick = () => {
  closeMenus(); renderNotificationSettings(); renderConnectionChrome();
  $('settingsOverlay').classList.remove('hidden');
};
$('closeSettings').onclick = () => $('settingsOverlay').classList.add('hidden');
$('newThread').onclick = newThread;
$('loadMoreThreads').onclick = () => loadThreads(false);
$('retryThreadList').onclick = () => loadThreads(true);
$('searchThreads').oninput = renderThreads;
$('latestItems').onclick = () => { $('latestItems').classList.add('hidden'); loadLatestItems(loadToken, true).catch(error => banner(error.message)); };
$('archiveToggle').onclick = () => { state.archived = !state.archived; $('archiveToggle').textContent = state.archived ? '현재 대화 보기' : '보관된 대화 보기'; loadThreads(true); };
$('refreshChat').onclick = () => openThread(state.currentId, false);
$('sendButton').onclick = enqueueMessage;
$('messageInput').oninput = () => { if (state.currentId) persist('remote.draft.' + state.currentId, $('messageInput').value); };
$('threadAction').onchange = async () => {
  const action = $('threadAction').value; $('threadAction').value = '';
  if (!action || !state.currentId) return;
  if (action === 'changes') { changesPanel(); return; }
  if (action === 'pin') { toggleThreadFavorite(state.current || { id: state.currentId }); return; }
  if (!state.online) { banner('PC 연결 후 다시 시도하세요.'); return; }
  try {
    if (action === 'rename') {
      const name = prompt('대화 이름', state.current?.name || '');
      if (name?.trim()) { await rpc('thread/name/set', { threadId: state.currentId, name: name.trim() }); $('threadTitle').textContent = name.trim(); }
    }
    if (action === 'unarchive') await rpc('thread/unarchive', { threadId: state.currentId });
    if (action === 'archive') { await rpc('thread/archive', { threadId: state.currentId }); state.currentId = ''; persist('remote.currentId', ''); $('chatView').classList.add('hidden'); $('emptyState').classList.remove('hidden'); }
    if (action === 'compact') await rpc('thread/compact/start', { threadId: state.currentId });
    if (action === 'fork') { const result = await rpc('thread/fork', { threadId: state.currentId, excludeTurns: true }); await openThread(result.thread.id); }
    if (action === 'stop' && state.activeTurn) await rpc('turn/interrupt', { threadId: state.currentId, turnId: state.activeTurn });
    await loadThreads(true);
  } catch (error) { banner(error.message); }
};
$('messageInput').onkeydown = event => { if (!event.isComposing && event.key === 'Enter' && (event.ctrlKey || event.metaKey)) { event.preventDefault(); enqueueMessage(); } };
$('modelSelect').onchange = () => { persist('remote.model', $('modelSelect').value); if (state.currentId) persist('remote.model.' + state.currentId, $('modelSelect').value); renderEfforts(); };
$('effortSelect').onchange = () => { persist('remote.effort', $('effortSelect').value); if (state.currentId) persist('remote.effort.' + state.currentId, $('effortSelect').value); };
$('speedSelect').onchange = () => { persist('remote.speed', $('speedSelect').value); if (state.currentId) persist('remote.speed.' + state.currentId, $('speedSelect').value); };
$('permissionSelect').onchange = () => persist('remote.permission', $('permissionSelect').value);
$('approvalSelect').onchange = () => persist('remote.approval', $('approvalSelect').value);
$('followupSelect').onchange = () => { persist('remote.followup', $('followupSelect').value); renderStatus(); };
for (const [id, key] of [['speedSelect', 'speed'], ['permissionSelect', 'permission'], ['approvalSelect', 'approval'], ['followupSelect', 'followup']]) {
  const value = saved('remote.' + key);
  if (value) $(id).value = value;
}
initFeatureUI();
initV03UI();
initConnectionUI();
renderOutbox();
renderModels();
if (state.currentId) openThread(state.currentId, false);
window.remoteDisconnect = () => {
  clearTimeout(reconnectTimer);
  const socket = state.socket; state.socket = null; state.online = false;
  socket?.close();
  for (const [id, value] of state.pending) { clearTimeout(value.timer); value.reject(new Error('PC reconnecting: 연결을 해제했습니다.')); state.pending.delete(id); }
  for (const entry of state.outbox) if (entry.status === 'sending') entry.status = entry.queueProtocol === 2 ? 'queued' : 'uncertain';
  saveOutbox(); renderOutbox(); renderStatus(); connectionLabel('연결 해제됨');
  banner('연결을 해제했습니다. 앱을 다시 열면 연결을 시도합니다.');
};
window.remoteNetworkChanged = () => { if (window.RemoteNative?.connectionSuspended?.()) return; state.socket?.close(); state.delay = 300; connect(); };
window.remoteWakeup = () => { if (window.RemoteNative?.connectionSuspended?.()) { window.remoteDisconnect(); return; } if (!state.online || Date.now() - state.lastReceived > 20000) window.remoteNetworkChanged(); else { syncActiveThread(); loadFeatureThread(state.currentId); } };
document.addEventListener('visibilitychange', () => { if (!document.hidden) window.remoteWakeup(); });
setInterval(() => { if (state.online && Date.now() - state.lastReceived > 25000) window.remoteNetworkChanged(); }, 3000);
setInterval(() => { if (state.online && state.outbox.some(x => x.status === 'queued')) flushOutbox(); }, 2000);
setInterval(()=>{if(!document.hidden&&state.retries.has(state.currentId))renderStatus();},1000);
let checkpointKey = '';
let checkpointItems = null, checkpointRevision = -1, checkpointSnapshot = [];
function saveCheckpoint() {
  if (state.openingThread || state.leaving) return;
  const key = state.epoch + ':' + state.seq + ':' + state.currentId;
  if (checkpointKey === key && checkpointItems === state.items && checkpointRevision === state.revision) return;
  if (checkpointItems !== state.items || checkpointRevision !== state.revision) {
    checkpointSnapshot = cachedItems(state.items); checkpointItems = state.items; checkpointRevision = state.revision;
  }
  if (persist('remote.checkpoint', { epoch: state.epoch, seq: state.seq, threadId: state.currentId, items: checkpointSnapshot })) checkpointKey = key;
}
setInterval(() => { if (!document.hidden) saveCheckpoint(); }, 2000);
document.addEventListener('visibilitychange', () => { if (document.hidden) saveCheckpoint(); else if (state.renderPending) scheduleRender(); });
window.addEventListener('pagehide', saveCheckpoint);
if (state.url && state.token) connect(); else connectionStore.active() ? connectionEditor(connectionStore.activeId) : connectionPicker();
window.remoteNotificationOpened();

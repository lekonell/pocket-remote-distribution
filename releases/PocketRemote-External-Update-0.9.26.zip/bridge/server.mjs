import { settingsPath, migrateSettings } from './settings.mjs';
import http from 'node:http';
import { randomBytes, randomUUID, timingSafeEqual, createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync, createReadStream } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { createItemPager } from './history.mjs';
import { createUploads } from './uploads.mjs';
import { loadCatalog } from './catalog.mjs';
import { createGoalRunner } from './goals.mjs';
import { createMessageQueue } from './queue.mjs';
import { createNotifications } from './notifications.mjs';
import { createMedia } from './media.mjs';
import { createDelivery } from './delivery.mjs';
import { connectUpstream, upstreamSettings } from './upstream.mjs';
import { createSubscriptions } from './subscriptions.mjs';
import { createAgents } from './agents.mjs';
import { createChanges } from './changes.mjs';
import { createGitChanges } from './git-changes.mjs';
import { createDesktopProxy } from './desktop-proxy.mjs';
import { createExecutionTracker } from './execution.mjs';
import { createThreadTitles } from './thread-titles.mjs';
import { createDots } from './dots.mjs';
import { createPairing, attachPairingSocket } from './pairing.mjs';
import { readHostSettings } from './host-settings.mjs';
import { createCapacityRetry } from './capacity-retry.mjs';
import { createMessageNavigator } from './message-navigation.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
if (!process.env.REMOTE_STATE_DIR) migrateSettings(root);
const stateRoot = process.env.REMOTE_STATE_DIR ? resolve(process.env.REMOTE_STATE_DIR) : root;
const upstreamConfig = upstreamSettings(process.env.REMOTE_STATE_DIR ? stateRoot : root);
mkdirSync(stateRoot, { recursive: true });
const host = process.env.REMOTE_BIND || '127.0.0.1';
const port = Number(process.env.REMOTE_PORT || 4545);
const secretPath = process.env.REMOTE_SECRET_FILE || (process.env.REMOTE_STATE_DIR ? resolve(stateRoot, '.remote-secret') : settingsPath(root, '.remote-secret'));
if (!existsSync(secretPath)) {
  mkdirSync(dirname(secretPath), { recursive: true });
  writeFileSync(secretPath, randomBytes(32).toString('base64url'), { mode: 0o600, flag: 'wx' });
}
const secret = readFileSync(secretPath, 'utf8').trim();
if (!/^[A-Za-z0-9_-]{43,128}$/.test(secret)) throw new Error('Invalid pairing token. Use a randomly generated token of at least 256 bits.');
const pairing = createPairing({ secret });
const epoch = randomUUID();
const sockets = new Set();
const events = [];
const delivery = createDelivery(sendWire);
const internalPending = new Map();
const serverRequests = new Map();
let sequence = 0;
let eventBytes = 0;
let upstream = null;
let ready = false;
let restartTimer;
let stopping = false;
const nativeRequests = new Map();

function sendWire(socket, wire) {
  if (socket.readyState === WebSocket.OPEN) socket.send(wire);
}
function safeSend(socket, data) { sendWire(socket, JSON.stringify(data)); }
function broadcast(data, wire = JSON.stringify(data)) {
  for (const socket of sockets) {
    if (!socket.initialized) continue;
    if (socket.notificationsOnly && data.type === 'event' && !data.message?.method?.startsWith('pocket/notifications/')) continue;
    if (socket.notificationsOnly && data.message?.params?.subagent) continue;
    sendWire(socket, wire);
  }
}
function emitEvent(message) {
  const event = { type: 'event', seq: ++sequence, message };
  const wire = JSON.stringify(event), size = Buffer.byteLength(wire);
  events.push({ seq: event.seq, method: message.method, subagent: !!message.params?.subagent, wire, size });
  eventBytes += size;
  while (events.length > 3000 || eventBytes > 10 * 1024 * 1024) eventBytes -= events.shift().size;
  broadcast(event, wire);
}
let instantSteeringSupported = false, instantSteeringProbe = Promise.resolve();
const threadLoads = new Set(['thread/start', 'thread/resume', 'thread/fork']);
function steeringConfig(message) {
  return instantSteeringSupported && threadLoads.has(message.method) ? { ...message, params: { ...message.params, config: { ...message.params?.config, 'features.instant_interrupt': true } } } : message;
}
function writeUpstream(message) {
  if (!ready || !upstream) return false;
  message = steeringConfig(message);
  executionTracker.request('bridge', message);
  if (message.id !== undefined && [...threadLoads, 'thread/list', 'turn/start', 'thread/goal/set'].includes(message.method)) nativeRequests.set(message.id, message);
  if (upstream.send(message)) return true;
  nativeRequests.delete(message.id);
  executionTracker.cancel('bridge', message.id);
  return false;
}
function callUpstream(method, params) {
  return threadLoads.has(method) ? instantSteeringProbe.then(() => callNative(method, params)) : callNative(method, params);
}
function callNative(method, params) {
  return new Promise((resolve, reject) => {
    const id = 'bridge:history:' + randomUUID();
    const timer = setTimeout(() => { internalPending.delete(id); nativeRequests.delete(id); executionTracker.cancel('bridge', id); reject(new Error('PC history read timed out')); }, 30000);
    internalPending.set(id, { resolve: result => {
      resolve(result);
    }, reject, timer });
    if (!writeUpstream({ id, method, params })) {
      clearTimeout(timer); internalPending.delete(id); reject(new Error('Codex is reconnecting.'));
    }
  });
}
const itemPager = createItemPager(callUpstream);
const messageNavigator = createMessageNavigator({ pager: itemPager });
const uploads = createUploads(stateRoot);
const media = createMedia({ root: stateRoot });
const reservedThreads = new Set();
const coordinator = { acquire(id) { if (reservedThreads.has(id)) return false; reservedThreads.add(id); return true; }, release(id) { reservedThreads.delete(id); } };
const subscriptions = createSubscriptions(callUpstream);
const threadTitles = createThreadTitles({ root: stateRoot, call: callUpstream, online: () => ready });
const ensureThread = upstreamConfig.mode === 'shared' ? id => subscriptions.ensure(id) : undefined;
const agents = createAgents({ call: callUpstream, pager: itemPager, ensureThread });
const changes = createChanges({ agents, repository: createGitChanges(), pager: { list: params => itemPager.list(params), metadata: async threadId => (await callUpstream('thread/read', { threadId, includeTurns: false })).thread, latest: async threadId => (await callUpstream('thread/turns/list', { threadId, limit: 1, sortDirection: 'desc', itemsView: 'notLoaded' })).data?.[0] } });
const messageQueue = createMessageQueue({ root: stateRoot, call: callUpstream, ensureThread, notify: emitEvent, online: () => ready, coordinator });
const capacityRetry = createCapacityRetry({root:stateRoot,call:callUpstream,ensureThread,coordinator,online:()=>ready,notify:message=>{notifications.onEvent(message);emitEvent(message);},hasQueued:id=>messageQueue.hasWaiting(id),isGoalYielded:id=>goalRunner.isYielded(id)});
const goalRunner = createGoalRunner({ root: stateRoot, call: callUpstream, ensureThread, notify: emitEvent, online: () => ready, coordinator, canStart: id => !messageQueue.hasWaiting(id)&&!capacityRetry.hasWaiting(id) });
const notifications = createNotifications({ root: stateRoot, call: callUpstream, emit: emitEvent, online: () => ready, answer: answerQuestion });
const executionTracker = createExecutionTracker({ capture: (...args) => notifications.captureExecution(...args) });
const dots = createDots({ call: callUpstream, emit: emitEvent });
const desktopProxy = upstreamConfig.desktopUrl ? createDesktopProxy({ listenUrl: upstreamConfig.desktopUrl, upstreamUrl: upstreamConfig.url, tracker: executionTracker, onRequest:message=>{capacityRetry.observeRequest(message);goalRunner.observeRequest(message);threadTitles.onRequest(message);},onEvent:message=>{capacityRetry.onEvent(message);threadTitles.onEvent(message);}, onError: error => { console.error('Desktop proxy:', error.message); process.exitCode = 1; stop(); } }) : null;
const mediaEvents=new Map();
async function answerQuestion(q, params) {
  if(q.requestId!==null){
    const request=serverRequests.get(String(q.requestId));
    if(!request||request.params?.threadId!==q.threadId)throw new Error('질문이 이미 종료되었습니다.');
    const answers=Object.fromEntries(q.questions.map((question,i)=>[question.id,{answers:[params.answers[i].trim()]}]));
    if(!writeUpstream({id:q.requestId,result:{answers}}))throw new Error('Codex is reconnecting.');
    return {accepted:true};
  }
  const text=q.questions.map((question,i)=>(question.title||question.question)+'\n답변: '+params.answers[i].trim()).join('\n\n');
  const latest=await callUpstream('thread/turns/list',{threadId:q.threadId,limit:1,sortDirection:'desc',itemsView:'notLoaded'});
  const turn=await notifications.currentTurn(q.threadId,latest.data?.[0]);
  if(turn?.status==='inProgress'){
    try {await callUpstream('turn/steer',{threadId:q.threadId,expectedTurnId:turn.id,clientUserMessageId:params.answerId,input:[{type:'text',text}]});}
    catch(e){if(/not loaded|active writer/i.test(e.message))throw new Error('PC 앱이 진행 중인 대화에는 이 연결에서 답변을 전송할 수 없습니다. Pocket Remote에서 만든 대화에서 질문에 답변할 수 있습니다.');throw e;}
  }else{
    await messageQueue.handle('bridge/queue/add',{id:params.answerId,threadId:q.threadId,text,input:[{type:'text',text}],attachments:[],mentions:[],settings:params.settings||{}});
  }
  return {accepted:true};
}
async function synchronizeThread(params) {
  const threadId = params.threadId;
  // The latest legacy page must also reflect work done by another PC session.
  itemPager.invalidate(threadId, true);
  const [items, turns, goal] = await Promise.allSettled([
    itemPager.list({ threadId, limit: 60, sortDirection: 'desc' }),
    callUpstream('thread/turns/list', { threadId, limit: 1, itemsView: 'notLoaded', sortDirection: 'desc' }),
    goalRunner.handle('bridge/goal/get', { threadId })
  ]);
  if (items.status === 'rejected') throw items.reason;
  const page = await media.page(items.value, threadId);
  notifications.inspectItems(threadId, page.data);
  agents.observe(threadId, page.data);
  changes.observe(threadId, page.data);
  const hash = createHash('sha256').update(JSON.stringify(page)).digest('hex');
  const turn = await notifications.currentTurn(threadId, turns.status === 'fulfilled' ? turns.value.data?.[0] : null);
  const execution = turn?.status === 'inProgress' ? await notifications.currentExecution(threadId, turn.id) : null;
  const queue = (await messageQueue.handle('bridge/queue/list', { threadId })).entries;
  const queueHash = createHash('sha256').update(JSON.stringify(queue)).digest('hex');
  return { hash, queueHash, changed: hash !== params.hash, ...(hash !== params.hash ? { page } : {}), ...(queueHash !== params.queueHash ? { queue } : {}), ...(goal.status === 'fulfilled' ? { goalState: goal.value } : {}), activeTurn: turn?.status === 'inProgress' ? turn.id : '', execution, statusKnown: turns.status === 'fulfilled' };
}
function onUpstreamMessage(message) {
  if(message.method==='account/updated'){dots.invalidateAuth();messageNavigator.reset();}
  executionTracker.receive('bridge', message);
  if (message.id !== undefined && !message.method) {
    const request = nativeRequests.get(message.id);
    nativeRequests.delete(message.id);
    if (request) { subscriptions.observe(request, message); threadTitles.observe(request, message); }
    if (request?.method === 'thread/list' && message.result) notifications.observeThreads(message.result.data);
  }
  if (message.method === 'thread/closed') subscriptions.closed(message.params?.threadId);
  const internal = internalPending.get(message.id);
  if (internal) {
    clearTimeout(internal.timer); internalPending.delete(message.id);
    if (message.error) internal.reject(Object.assign(new Error(message.error.message), { code: message.error.code }));
    else internal.resolve(message.result);
    return;
  }
  if (message.id === 'bridge:init') {
    if (message.error) {
      console.error('Codex initialization failed:', message.error.message);
      upstream.close();
      return;
    }
    upstream.send({ method: 'initialized', params: {} });
    ready = true;
    const currentUpstream = upstream;
    instantSteeringProbe = Promise.race([
      callNative('experimentalFeature/list', { limit: 200 }).then(result => { if (upstream === currentUpstream && ready) instantSteeringSupported = result.data?.some(f => f.name === 'instant_interrupt' && !['removed', 'deprecated'].includes(f.stage)) || false; }).catch(() => {}),
      new Promise(resolve => { const timer = setTimeout(resolve, 2000); timer.unref(); })
    ]);
    broadcast({ type: 'online', online: true });
    goalRunner.onReady();
    messageQueue.onReady();
    notifications.onReady();
    capacityRetry.onReady();
    threadTitles.onReady();
    if (upstreamConfig.mode === 'shared') subscriptions.restore().catch(error => console.error('Conversation subscription:', error.message));
    return;
  }
  if (typeof message.id === 'string' && message.id.startsWith('c:') && !message.method) {
    delivery.complete(message);
    return;
  }
  if (message.id !== undefined && message.method) serverRequests.set(String(message.id), message);
  if (message.method === 'serverRequest/resolved') serverRequests.delete(String(message.params?.requestId));
  if (/^(item\/(started|completed)|turn\/(started|completed))$/.test(message.method || '')) itemPager.invalidate(message.params?.threadId);
  goalRunner.onEvent(message);
  threadTitles.onEvent(message);
  capacityRetry.onEvent(message);
  agents.onEvent(message);
  messageNavigator.onEvent(message);
  changes.onEvent(message);
  messageQueue.onEvent(message);
  notifications.onEvent(message);
  if (message.params?.item && ['item/started','item/completed'].includes(message.method)) {
    const key=message.params.threadId+':'+message.params.item.id;
    const task=(mediaEvents.get(key)||Promise.resolve()).then(()=>media.item(message.params.item,message.params.threadId,message.params.turnId))
      .then(item=>emitEvent({...message,params:{...message.params,item}}))
      .catch(()=>emitEvent({...message,params:{...message.params,item:{id:message.params.item.id,type:message.params.item.type,text:message.params.item.text,mediaError:'결과를 다시 보려면 대화를 동기화하세요.'}}}));
    mediaEvents.set(key,task);task.finally(()=>{if(mediaEvents.get(key)===task)mediaEvents.delete(key);});
  } else emitEvent(message);
}
function startUpstream() {
  ready = false;
  instantSteeringSupported = false; instantSteeringProbe = Promise.resolve();
  itemPager.reset();
  messageNavigator.reset();
  upstream = connectUpstream({
    settings: upstreamConfig,
    cwd: process.env.REMOTE_CWD || process.cwd(),
    onMessage: onUpstreamMessage,
    onError: error => console.error('Codex connection:', error.message),
    onLog: line => console.error('Codex:', line),
    onOpen: () => upstream.send({
      method: 'initialize', id: 'bridge:init',
      params: { clientInfo: { name: 'codex_pocket_remote', title: 'Codex Pocket Remote', version: '0.8.5' }, capabilities: { experimentalApi: true } }
    }),
    onClose: () => {
    ready = false;
    executionTracker.disconnect('bridge');
    subscriptions.reset(); nativeRequests.clear();
    goalRunner.onOffline(); messageQueue.onOffline();capacityRetry.onOffline();
    broadcast({ type: 'online', online: false });
    delivery.failAll('Codex connection restarted; check the thread before retrying.');
    for (const entry of internalPending.values()) { clearTimeout(entry.timer); entry.reject(new Error('Codex connection restarted')); }
    internalPending.clear();
    for (const [requestId] of serverRequests) emitEvent({ method: 'serverRequest/resolved', params: { requestId } });
    serverRequests.clear();
    if (!stopping) restartTimer = setTimeout(startUpstream, 1000);
    }
  });
}

const server = http.createServer((request, response) => {
  if (request.url === '/pairing' && request.method === 'POST') {
    const token = String(request.headers.authorization || '').replace(/^Bearer /, '');
    const local = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(request.socket.remoteAddress);
    if (!local || !pairing.matches(token) || request.headers.origin) { response.writeHead(401); response.end(); return; }
    response.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    response.end(JSON.stringify(pairing.issue())); return;
  }
  if (request.url === '/health') {
    response.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    response.end(JSON.stringify({ online: ready, clients: sockets.size, upstream: upstreamConfig.mode, desktopProxy: !!desktopProxy?.server.listening }));
    return;
  }
  const files = { '/': 'index.html', '/app.js': 'app.js', '/profiles.js': 'profiles.js', '/history.js': 'history.js', '/features.js': 'features.js', '/mentions.js': 'mentions.js', '/image-viewer.js': 'image-viewer.js', '/message-copy.js': 'message-copy.js', '/session.js':'session.js', '/session.css':'session.css', '/changes.js':'changes.js', '/v03.js': 'v03.js', '/vendor/markdown-it.min.js': 'vendor/markdown-it.min.js', '/app-icon.png':'app-icon.png', '/styles.css': 'styles.css', '/v03.css':'v03.css' };
  const name = files[request.url];
  if (!name) { response.writeHead(404); response.end(); return; }
  response.writeHead(200, { 'content-type': name.endsWith('.js') ? 'text/javascript; charset=utf-8' : name.endsWith('.css') ? 'text/css; charset=utf-8' : name.endsWith('.png')?'image/png':'text/html; charset=utf-8', 'cache-control': 'no-store' });
  createReadStream(resolve(root, 'app/src/main/assets', name)).pipe(response);
});

// A selected VPN/LAN interface may not include loopback. Keep authenticated
// wizard management reachable locally on the same port without exposing RPC.
const management = !['127.0.0.1', '::1', '0.0.0.0', '::'].includes(host) ? http.createServer((request, response) => {
  if (['/health', '/pairing'].includes(request.url)) server.emit('request', request, response);
  else { response.writeHead(404); response.end(); }
}) : null;
management?.listen(port, '127.0.0.1');
management?.on('error', error => { console.error('Local setup listener:', error.code); stop(); process.exitCode = 1; });

const wss = new WebSocketServer({ noServer: true, maxPayload: 1024 * 1024, handleProtocols: protocols => protocols.has('codex-remote') ? 'codex-remote' : false });
const pairWss = new WebSocketServer({ noServer: true, maxPayload: 1024, handleProtocols: protocols => protocols.has('codex-pair') ? 'codex-pair' : false });
server.on('upgrade', (request, socket, head) => {
  const offered = String(request.headers['sec-websocket-protocol'] || '').split(',').map(x => x.trim());
  if (request.url === '/socket' && offered.includes('codex-pair')) {
    if (pairWss.clients.size >= 16) { socket.write('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    const settings = readHostSettings(stateRoot);
    pairWss.handleUpgrade(request, socket, head, ws => { ws.on('error', () => {}); attachPairingSocket(ws, pairing, { name: settings.hostName, cwd: settings.defaultCwd }); });
    return;
  }
  const supplied = offered.find(x => x.startsWith('auth.'))?.slice(5) || '';
  const a = Buffer.from(supplied);
  const b = Buffer.from(secret);
  if (request.url !== '/socket' || a.length !== b.length || !timingSafeEqual(a, b)) {
    socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  wss.handleUpgrade(request, socket, head, ws => wss.emit('connection', ws));
});
wss.on('connection', socket => {
  socket.dotOwner = randomUUID();
  sockets.add(socket);
  socket.on('message', bytes => {
    let data;
    try { data = JSON.parse(bytes.toString()); } catch { return; }
    if (data.type === 'hello') {
      socket.initialized = true;
      socket.notificationsOnly = data.notificationsOnly === true;
      const since = Number(data.since) || 0;
      const sameEpoch = data.epoch === epoch;
      const gap = sameEpoch && (events.length ? since < events[0].seq - 1 : since < sequence);
      safeSend(socket, { type: 'ready', epoch, seq: sequence, online: ready, gap, ...readHostSettings(stateRoot), retries:capacityRetry.list(), capabilities: { steeringSend: true, executionStatus: true, sharedDesktop: upstreamConfig.mode === 'shared', dots: true,reviewScopes: true,modelCapacityRetry:true,agentHistoryFocus:true,userMessageJump:true } });
      if (sameEpoch && !gap) for (const event of events) if (event.seq > since && (!socket.notificationsOnly || (event.method?.startsWith('pocket/notifications/') && !event.subagent))) sendWire(socket, event.wire);
      if (!socket.notificationsOnly) for (const message of serverRequests.values()) safeSend(socket, { type: 'serverRequest', message });
      return;
    }
    if (data.type === 'rpc') {
      if (!socket.initialized) return;
      const msg = data.message;
      if (!msg || typeof msg.method !== 'string' || typeof msg.id !== 'string' || !/^c:[a-zA-Z0-9-]{8,80}$/.test(msg.id)) return;
      if (socket.notificationsOnly) {
        if (msg.method !== 'bridge/notifications/list') return;
      }
      if (!delivery.begin(socket, msg)) return;
      if(msg.method==='bridge/history/userMessage'){
        messageNavigator.handle(msg.params).then(async result=>result.page?{...result,page:await media.page(result.page,msg.params.threadId)}:result).then(result=>onUpstreamMessage({id:msg.id,result}),error=>onUpstreamMessage({id:msg.id,error:{code:-32000,message:error.message}}));return;
      }
      if (msg.method.startsWith('bridge/dots/')) {
        dots.handle(msg.method, msg.params || {}, socket.dotOwner).then(result => onUpstreamMessage({ id: msg.id, result }), error => onUpstreamMessage({ id: msg.id, error: { code: -32000, message: error.message, data: { status: error.status, kind: error.kind, operation: error.operation, retryAt: error.retryAt, deliveryUnknown: !!error.deliveryUnknown } } }));
        return;
      }
      if (msg.method.startsWith('bridge/agents/') || msg.method.startsWith('bridge/changes/')) {
        const inspector = msg.method.startsWith('bridge/agents/') ? agents : changes;
        inspector.handle(msg.method, msg.params || {}).then(async result => result.focusPage ? {...result,focusPage:await media.page(result.focusPage,msg.params.agentId)} : result).then(result => onUpstreamMessage({ id: msg.id, result }), error => onUpstreamMessage({ id: msg.id, error: { code: -32000, message: error.message } }));
        return;
      }
      capacityRetry.observeRequest(msg);
      goalRunner.observeRequest(msg);
      threadTitles.onRequest(msg);
      if(msg.method.startsWith('bridge/retry/')){capacityRetry.handle(msg.method,msg.params).then(result=>onUpstreamMessage({id:msg.id,result}),error=>onUpstreamMessage({id:msg.id,error:{code:-32000,message:error.message}}));return;}
      if (msg.method.startsWith('bridge/notifications/') || msg.method.startsWith('bridge/question/') || msg.method === 'bridge/status/read' || msg.method.startsWith('bridge/media/')) {
        const operation = msg.method.startsWith('bridge/media/') ? media.handle(msg.method,msg.params) : notifications.handle(msg.method, msg.params || {});
        operation.then(result => onUpstreamMessage({ id: msg.id, result }), error => onUpstreamMessage({ id: msg.id, error: { code: -32000, message: error.message } }));
        return;
      }
      if (msg.method.startsWith('bridge/file/') || msg.method === 'bridge/catalog/list' || msg.method.startsWith('bridge/goal/') || msg.method.startsWith('bridge/queue/') || msg.method === 'bridge/sync/read') {
        const operation = msg.method.startsWith('bridge/file/') ? uploads.handle(msg.method, msg.params) : msg.method === 'bridge/catalog/list' ? loadCatalog(callUpstream, msg.params) : msg.method.startsWith('bridge/queue/') ? messageQueue.handle(msg.method, msg.params || {}).then(result => {
          // The durable queue receipt is already available. A slow goal read
          // must not keep the mobile message in "sending" or report a false failure.
          if (['bridge/queue/add', 'bridge/queue/retry'].includes(msg.method) && result.entry?.mode !== 'steer' && messageQueue.hasWaiting(msg.params?.threadId)) goalRunner.onQueueWaiting(msg.params.threadId).catch(error => emitEvent({ method: 'pocket/goal/state', params: { threadId: msg.params.threadId, native: true, error: error.message } }));
          return result;
        }) : msg.method === 'bridge/sync/read' ? synchronizeThread(msg.params || {}) : goalRunner.handle(msg.method, msg.params || {});
        operation.then(result => onUpstreamMessage({ id: msg.id, result }), error => onUpstreamMessage({ id: msg.id, error: { code: error.code || -32000, message: error.message } }));
        return;
      }
      if (msg.method === 'thread/items/list') {
        itemPager.list(msg.params || {}).then(result => media.page(result,msg.params.threadId)).then(result => { agents.observe(msg.params.threadId,result.data); changes.observe(msg.params.threadId,result.data); if(!msg.params.cursor)notifications.inspectItems(msg.params.threadId,result.data); onUpstreamMessage({ id: msg.id, result }); }, error => onUpstreamMessage({ id: msg.id, error: { code: error.code || -32000, message: error.message } }));
        return;
      }
      const send = () => { if (!writeUpstream(msg)) delivery.complete({ id: msg.id, error: { code: -32000, message: 'Codex is reconnecting.' } }); };
      if (threadLoads.has(msg.method)) instantSteeringProbe.then(send); else send();
      return;
    }
    if (socket.initialized && !socket.notificationsOnly && data.type === 'response' && data.message && serverRequests.has(String(data.message.id))) writeUpstream(data.message);
  });
  socket.on('close', () => { sockets.delete(socket); delivery.disconnect(socket); dots.disconnect(socket.dotOwner); });
  socket.on('pong', () => { socket.isAlive = true; });
  socket.isAlive = true;
});
setInterval(() => {
  broadcast({ type: 'heartbeat', time: Date.now() });
  for (const socket of sockets) {
    if (!socket.isAlive) { socket.terminate(); continue; }
    socket.isAlive = false;
    socket.ping();
  }
}, 10000).unref();

server.listen(port, host, () => {
  startUpstream();
  console.log(`Codex Pocket Remote bridge on http://${host}:${port}`);
  console.log(`Pairing token: ${secret}`);
  console.log('Keep this token private. For access outside your LAN, use a private HTTPS/WSS tunnel.');
});
function stop() { stopping = true; clearTimeout(restartTimer);threadTitles.stop();capacityRetry.stop(); dots.close(); desktopProxy?.close(); notifications.stop(); goalRunner.stop(); messageQueue.stop(); upstream?.close(); for (const socket of sockets) socket.close(); for (const socket of pairWss.clients) socket.close(); management?.close(); server.close(); }
server.on('error', error => { console.error('Bridge:', error.message); stop(); process.exitCode = 1; });
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Web.Script.Serialization;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Codex Pocket Remote Background Host")]
[assembly: AssemblyDescription("Starts the remote bridge without a console or taskbar window.")]
[assembly: AssemblyVersion("0.9.26.0")]
[assembly: AssemblyFileVersion("0.9.26.0")]

internal static class RemoteHostLauncher
{
    private static readonly string Root = AppDomain.CurrentDomain.BaseDirectory;
    private static readonly bool Shared = Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location).Equals("PocketRemoteSharedHost", StringComparison.OrdinalIgnoreCase);
    private static readonly object LogLock = new object();
    [DllImport("user32.dll")] private static extern bool DestroyIcon(IntPtr handle);

    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if (args.Length == 1 && args[0] == "--tray-self-test") return File.Exists(Path.Combine(Root, ".fixture-tray")) ? TraySelfTest() : 1;
            // The OS releases this lock after exit, including a crash. It also
            // prevents manual starts and scheduled starts from running together.
            using (var instance = new FileStream(Path.Combine(Root, Shared ? ".shared-launcher.lock" : ".launcher.lock"),
                FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
            {
                var id = Encoding.ASCII.GetBytes(Process.GetCurrentProcess().Id.ToString());
                instance.SetLength(0);
                instance.Write(id, 0, id.Length);
                instance.Flush();

                var configPath = PersistentPath(".launcher.json");
                var config = File.Exists(configPath)
                    ? new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(File.ReadAllText(configPath))
                    : new Dictionary<string, string>();
                string shell, node;
                if (!config.TryGetValue("shellPath", out shell))
                    shell = FindExecutable("pwsh.exe") ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
                if (!config.TryGetValue("nodePath", out node) || !File.Exists(node)) node = File.Exists(Path.Combine(Root, "tools", "node.exe")) ? Path.Combine(Root, "tools", "node.exe") : FindExecutable("node.exe");
                var script = Path.Combine(Root, Shared ? "bridge\\shared-server.mjs" : "RUN-REMOTE.ps1");
                if (!File.Exists(shell) || !File.Exists(node) || !File.Exists(script))
                    throw new FileNotFoundException("PowerShell, Node.js or RUN-REMOTE.ps1 is missing. Run INSTALL-AUTOSTART.ps1 to configure this installation.");

                var start = new ProcessStartInfo
                {
                    FileName = Shared ? node : shell,
                    Arguments = Shared ? Quote(script) : "-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File " + Quote(script) + " -Quiet -NodePath " + Quote(node),
                    WorkingDirectory = Root,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using (var host = new Process { StartInfo = start })
                {
                    host.OutputDataReceived += (sender, e) => RecordOutput(e.Data);
                    host.ErrorDataReceived += (sender, e) => RecordOutput(e.Data);
                    if (!host.Start()) throw new InvalidOperationException("Could not start the background host.");
                    WriteLog("Background host started; PowerShell PID " + host.Id + ".");
                    host.BeginOutputReadLine();
                    host.BeginErrorReadLine();
                    if (Shared) host.WaitForExit();
                    else RunTray(host, node);
                    WriteLog("Background host exited with code " + host.ExitCode + ".");
                    return host.ExitCode;
                }
            }
        }
        catch (IOException e)
        {
            var code = e.HResult & 0xffff;
            if (code == 32 || code == 33) return 0; // Already running.
            WriteLog(e.Message);
            return 1;
        }
        catch (Exception e)
        {
            WriteLog(e.Message);
            return 1;
        }
    }

    private static ContextMenuStrip TrayMenu(string node, Action<string> feedback, Action<string> manualFeedback = null, Action exit = null)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("설정 마법사 열기", null, (sender, e) => {
            try { Process.Start(new ProcessStartInfo(Path.Combine(Root, "PocketRemoteSetup.exe")) { UseShellExecute = true, WorkingDirectory = Root }); }
            catch { feedback("설정 마법사를 열지 못했습니다."); }
        });
        menu.Items.Add("업데이트 확인", null, (sender, e) => {
            var report = manualFeedback ?? feedback;
            report("새 버전을 확인하고 있습니다…");
            try
            {
                var worker = Path.Combine(Root, "bridge", "update-worker.mjs");
                if (!File.Exists(worker)) throw new FileNotFoundException();
                var pid = File.ReadAllText(Path.Combine(Root, ".host.pid")).Trim();
                int value; if (!Int32.TryParse(pid, out value) || value <= 0) throw new InvalidOperationException();
                File.WriteAllText(Path.Combine(Root, ".pc-update-request"), DateTime.UtcNow.ToString("o"));
                File.WriteAllText(Path.Combine(Root, ".pc-update-feedback"), DateTime.UtcNow.ToString("o"));
                Process.Start(new ProcessStartInfo(node, Quote(worker) + " --check-now --parent " + value) {
                    UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden, WorkingDirectory = Root
                });
                report("새 버전이 있으면 바로 업데이트합니다. 원격 연결이 잠시 끊긴 뒤 다시 연결됩니다.");
            }
            catch { report("업데이트 확인기를 시작하지 못했습니다. 설정 마법사에서 연결을 확인하세요."); }
        });
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("종료", null, (sender, e) => { if (exit != null) exit(); });
        return menu;
    }

    private static string UpdateNotice(string status, string version)
    {
        switch (status)
        {
            case "checking": return "새 버전을 확인하고 있습니다… " + version;
            case "current": return "최신 버전을 사용 중입니다. " + version;
            case "downloading": return "새 버전을 다운로드하고 확인합니다. " + version;
            case "waiting-for-idle": return "업데이트 준비 완료. 작업 종료 후 적용합니다. " + version;
            case "waiting-for-wizard-close": return "설정 마법사를 닫으면 업데이트를 적용합니다. " + version;
            case "applying": return "업데이트를 적용합니다. 연결이 잠시 끊긴 뒤 다시 연결됩니다.";
            case "installed": return "업데이트가 완료되었습니다. " + version;
            case "retry-later": return "업데이트 서버에 연결하지 못했습니다. 나중에 재시도합니다.";
            case "failed": return "업데이트에 실패했습니다. 설정 마법사에서 연결을 확인하세요.";
            default: return null;
        }
    }

    private static void RunTray(Process host, string node)
    {
        Application.EnableVisualStyles();
        UpdateWindow window = null;
        DateTime lastManual = DateTime.MinValue;
        using (var tray = new NotifyIcon())
        using (var icon = TrayIcon())
        using (var timer = new System.Windows.Forms.Timer { Interval = 1000 })
        using (var menu = TrayMenu(node, message => tray.ShowBalloonTip(5000, "Pocket Remote", message, ToolTipIcon.Info), message => {
            lastManual = DateTime.UtcNow;
            if (window == null || window.IsDisposed) window = new UpdateWindow();
            window.SetMessage(message); window.Show(); window.Activate();
        }, () => {
            try {
                var shell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
                Process.Start(new ProcessStartInfo(shell, "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Quote(Path.Combine(Root, "STOP-REMOTE.ps1"))) { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden, WorkingDirectory = Root });
            } catch { MessageBox.Show("종료하지 못했습니다. 설정 마법사에서 연결 상태를 확인하세요.", "Pocket Remote"); }
        }))
        {
            tray.Icon = icon;
            tray.Text = "Pocket Remote · 백그라운드 연결";
            tray.ContextMenuStrip = menu;
            tray.Visible = true;
            string previous = null;
            timer.Tick += (sender, e) => {
                if (host.HasExited) { if (window != null) window.Dispose(); Application.ExitThread(); return; }
                if (window != null && !window.IsDisposed && lastManual != DateTime.MinValue && DateTime.UtcNow - lastManual > TimeSpan.FromSeconds(40)) {
                    window.SetMessage("업데이트 확인 응답이 지연되고 있습니다. 네트워크를 확인하고 트레이에서 다시 확인할 수 있습니다."); lastManual = DateTime.MinValue;
                }
                try
                {
                    var path = Path.Combine(Root, ".pc-update.json");
                    if (!File.Exists(path)) return;
                    var state = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(File.ReadAllText(path));
                    object value; var stamp = state.TryGetValue("updatedAt", out value) ? Convert.ToString(value) : "";
                    if (previous == stamp) return;
                    previous = stamp;
                    var status = state.TryGetValue("status", out value) ? Convert.ToString(value) : "";
                    var version = state.TryGetValue("availableVersion", out value) ? Convert.ToString(value) : state.TryGetValue("version", out value) ? Convert.ToString(value) : "";
                    var notice = UpdateNotice(status, version);
                    // Routine background checks stay quiet; requested checks show a result.
                    var feedbackPath = Path.Combine(Root, ".pc-update-feedback");
                    DateTime requestedAt, updatedAt;
                    var relevant = File.Exists(feedbackPath) && DateTime.TryParse(File.ReadAllText(feedbackPath), out requestedAt) && DateTime.TryParse(stamp, out updatedAt) && updatedAt >= requestedAt;
                    if (relevant && notice != null && window != null && !window.IsDisposed) {
                        object detail;
                        window.SetMessage(notice + (state.TryGetValue("error", out detail) && !String.IsNullOrWhiteSpace(Convert.ToString(detail)) ? "\n\n" + Convert.ToString(detail) : ""));
                        lastManual = DateTime.MinValue;
                    }
                    if (notice != null && relevant) tray.ShowBalloonTip(5000, "Pocket Remote", notice, status == "failed" ? ToolTipIcon.Warning : ToolTipIcon.Info);
                    if (relevant && (status == "current" || status == "installed" || status == "failed" || status == "retry-later")) File.Delete(feedbackPath);
                }
                catch { } // A concurrently replaced state file is read on the next tick.
            };
            timer.Start();
            Application.Run();
            timer.Stop(); tray.Visible = false;
        }
    }

    private static Icon TrayIcon()
    {
        try
        {
            using (var source = new Bitmap(Path.Combine(Root, "app", "src", "main", "assets", "app-icon.png")))
            using (var bitmap = new Bitmap(source, 32, 32))
            {
                var handle = bitmap.GetHicon();
                try { return (Icon)Icon.FromHandle(handle).Clone(); } finally { DestroyIcon(handle); }
            }
        }
        catch { return (Icon)SystemIcons.Application.Clone(); }
    }

    private static int TraySelfTest()
    {
        string feedback = "";
        using (var menu = TrayMenu(FindExecutable("node.exe"), value => feedback = value))
        {
            ((ToolStripMenuItem)menu.Items[1]).PerformClick();
            for (int i = 0; i < 50 && !File.Exists(Path.Combine(Root, "fixture-worker.json")); i++) Thread.Sleep(100);
            var results = new Dictionary<string, object> {
                {"menu", new [] {menu.Items[0].Text, menu.Items[1].Text}},
                {"requested", File.Exists(Path.Combine(Root, ".pc-update-request"))},
                {"worker", File.Exists(Path.Combine(Root, "fixture-worker.json"))},
                {"feedback", feedback}, {"waiting", UpdateNotice("waiting-for-idle", "2.0.0")}, {"exit", menu.Items[3].Text}, {"checking", UpdateNotice("checking", "1.0.0")}
            };
            File.WriteAllText(Path.Combine(Root, "fixture-tray.json"), new JavaScriptSerializer().Serialize(results), Encoding.UTF8);
            return 0;
        }
    }

    private sealed class UpdateWindow : Form
    {
        private readonly Label message = new Label();
        public UpdateWindow() {
            Text = "Pocket Remote · 업데이트"; ClientSize = new Size(470, 220); StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false; Font = new Font("Malgun Gothic", 10);
            message.Location = new Point(24, 24); message.Size = new Size(422, 134); Controls.Add(message);
            var close = new Button { Text = "닫기", Location = new Point(346, 169), Size = new Size(100, 34) }; close.Click += (s, e) => Close(); Controls.Add(close);
        }
        public void SetMessage(string value) { message.Text = value; }
    }

    private static string FindExecutable(string name)
    {
        foreach (var directory in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator))
        {
            try
            {
                var candidate = Path.Combine(directory.Trim().Trim('"'), name);
                if (File.Exists(candidate)) return Path.GetFullPath(candidate);
            }
            catch (ArgumentException) { }
        }
        return null;
    }

    private static string PersistentPath(string name)
    {
        var marker = Path.Combine(Root, "distribution.json");
        if (!File.Exists(marker)) return Path.Combine(Root, name);
        var value = new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(File.ReadAllText(marker));
        string channel; if (!value.TryGetValue("channel", out channel) || (channel != "standard" && channel != "external")) throw new InvalidDataException("Invalid distribution channel");
        var directory = Environment.GetEnvironmentVariable("REMOTE_DATA_DIR") ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PocketRemote", channel);
        Directory.CreateDirectory(directory);
        var destination = Path.Combine(directory, name);
        var legacy = Path.Combine(Root, name);
        if (!File.Exists(destination) && File.Exists(legacy)) File.Copy(legacy, destination, false);
        return destination;
    }

    private static string Quote(string path)
    {
        if (path.IndexOfAny(new[] { '"', '\r', '\n' }) >= 0)
            throw new ArgumentException("Invalid executable or script path.");
        return "\"" + path + "\"";
    }

    private static void RecordOutput(string line)
    {
        if (String.IsNullOrWhiteSpace(line) || line.TrimStart().StartsWith("Pairing token", StringComparison.OrdinalIgnoreCase)) return;
        WriteLog(line);
    }

    private static void WriteLog(string message)
    {
        try
        {
            lock (LogLock)
            {
                var path = Path.Combine(Root, Shared ? ".shared-launcher.log" : ".launcher.log");
                if (File.Exists(path) && new FileInfo(path).Length > 1024 * 1024)
                {
                    var previous = path + ".1";
                    if (File.Exists(previous)) File.Delete(previous);
                    File.Move(path, previous);
                }
                File.AppendAllText(path, DateTime.UtcNow.ToString("o") + " " + message.Substring(0, Math.Min(message.Length, 3000)) + Environment.NewLine);
            }
        }
        catch { } // Diagnostics never open a dialog or interrupt desktop use.
    }
}
